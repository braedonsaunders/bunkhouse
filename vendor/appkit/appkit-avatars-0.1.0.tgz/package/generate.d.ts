export type ImageModelId = 'cf-sdxl-lightning' | 'cf-sdxl-base' | 'cf-flux-schnell' | 'replicate-flux-schnell' | 'replicate-sdxl' | 'gemini-nano-banana' | 'gemini-nano-banana-pro';
export declare const IMAGE_MODELS: {
    id: ImageModelId;
    name: string;
    provider: 'cloudflare' | 'replicate' | 'gemini';
}[];
export type ImageProviderConfig = {
    provider: 'cloudflare';
    accountId: string;
    apiToken: string;
} | {
    provider: 'replicate';
    apiToken: string;
} | {
    provider: 'gemini';
    apiKey: string;
};
export type GenerateImagesRequest = {
    prompt: string;
    negativePrompt?: string;
    model: ImageModelId;
    count?: number;
    seed?: number;
};
export type GenerateImagesResult = {
    /** data: URIs (base64 PNG) or https URLs, provider-dependent. */
    images: string[];
    seed: number;
    model: ImageModelId;
};
export declare function generateImages(config: ImageProviderConfig, request: GenerateImagesRequest): Promise<GenerateImagesResult>;
/**
 * A consistent portrait prompt for staff avatars: one flat-illustration
 * head-and-shoulders portrait per subject, uniform style across a roster.
 */
export declare function buildPortraitPrompt(subject: {
    description: string;
    tone?: string[];
}): {
    prompt: string;
    negativePrompt: string;
};
//# sourceMappingURL=generate.d.ts.map