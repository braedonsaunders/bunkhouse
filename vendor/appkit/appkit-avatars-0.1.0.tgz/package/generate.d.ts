/** Structurally identical to @appkit/ai's AiConfig — pass it straight in. */
export type ImageAiConfig = {
    provider: string;
    apiKey: string;
    baseUrl?: string | null;
};
export type ImageModelId = string;
export declare const IMAGE_MODELS: {
    id: ImageModelId;
    name: string;
    provider: 'openai' | 'google';
}[];
/** Provider kinds (as named by @appkit/ai) that can generate images. */
export declare const IMAGE_CAPABLE_PROVIDERS: readonly ["openai", "google"];
export type GenerateImagesRequest = {
    prompt: string;
    model: ImageModelId;
    count?: number;
};
export type GenerateImagesResult = {
    /** data: URIs (base64). */
    images: string[];
    model: ImageModelId;
};
export declare function generateImages(config: ImageAiConfig, request: GenerateImagesRequest): Promise<GenerateImagesResult>;
/**
 * A consistent portrait prompt for staff avatars: one flat-illustration
 * head-and-shoulders portrait per subject, uniform style across a roster.
 */
export declare function buildPortraitPrompt(subject: {
    description: string;
    tone?: string[];
}): string;
//# sourceMappingURL=generate.d.ts.map