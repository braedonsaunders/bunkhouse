# @appkit/avatars

AI avatar/image generation over Cloudflare Workers AI, Replicate, and Google Gemini — credentials injected, extracted from the OpenStudio production generator.

## Install

```bash
pnpm add @appkit/avatars
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
