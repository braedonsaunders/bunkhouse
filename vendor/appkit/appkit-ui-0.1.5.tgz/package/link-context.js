'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
const UiLinkContext = React.createContext(null);
/** Inject an app router link once so appkit primitives never force full reloads. */
export function UiLinkProvider({ link, children, }) {
    return _jsx(UiLinkContext.Provider, { value: link, children: children });
}
export function UiLink({ href, ...rest }) {
    const Link = React.useContext(UiLinkContext) ?? 'a';
    return _jsx(Link, { href: href, ...rest });
}
const UiBackLinkContext = React.createContext(null);
/** Inject an app-aware history resolver for every PageHeader back link. */
export function UiBackLinkProvider({ backLink, children, }) {
    return _jsx(UiBackLinkContext.Provider, { value: backLink, children: children });
}
export function UiBackLink({ href, label, className }) {
    const BackLink = React.useContext(UiBackLinkContext);
    if (BackLink)
        return _jsx(BackLink, { href: href, label: label, className: className });
    return (_jsxs(UiLink, { href: href, className: className, children: ["\u2190 ", label] }));
}
//# sourceMappingURL=link-context.js.map