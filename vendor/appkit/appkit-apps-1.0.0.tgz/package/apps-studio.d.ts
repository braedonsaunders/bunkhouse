import * as React from 'react';
import type { AppFile, AppListing, AppMetaUpdate, AppRun, AppStatus, InstalledApp } from './index.js';
import type { AppBundleFile } from './bundle.js';
import type { BridgeContext, BridgeMethod } from './bridge.js';
export interface AppsStudioProps {
    apps: InstalledApp[];
    files: Record<string, AppFile[]>;
    runs?: Record<string, AppRun[]>;
    capabilities: Array<{
        key: string;
        label: string;
        description: string;
    }>;
    contextFor: (app: InstalledApp) => BridgeContext;
    selectedKey?: string | 'new' | null;
    onSelectedKeyChange?: (key: string | 'new' | null) => void;
    onCreate: (name: string) => Promise<void> | void;
    onImport: (archive: Uint8Array) => Promise<void> | void;
    onSaveMeta: (key: string, update: AppMetaUpdate) => Promise<void> | void;
    onSaveFile: (key: string, file: AppBundleFile) => Promise<void> | void;
    onDeleteFile: (key: string, path: string) => Promise<void> | void;
    onStatusChange: (key: string, status: AppStatus) => Promise<void> | void;
    onDelete: (key: string) => Promise<void> | void;
    onPublish: (key: string) => Promise<void> | void;
    onBridgeCall: (app: InstalledApp, request: {
        method: BridgeMethod;
        payload: unknown;
    }) => Promise<unknown>;
    className?: string;
}
export interface AppLibraryProps {
    listings: AppListing[];
    installedKeys?: ReadonlySet<string>;
    onInstall: (listing: AppListing) => Promise<void> | void;
    className?: string;
}
export declare function AppsStudio(props: AppsStudioProps): React.JSX.Element;
export declare function AppLibrary({ listings, installedKeys, onInstall, className }: AppLibraryProps): React.JSX.Element;
//# sourceMappingURL=apps-studio.d.ts.map