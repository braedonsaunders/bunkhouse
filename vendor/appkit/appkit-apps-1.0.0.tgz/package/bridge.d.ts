export declare const BRIDGE_MARKER: "__appkit";
export declare const BRIDGE_METHODS: readonly ["callBackend", "records.list", "records.get"];
export type BridgeMethod = (typeof BRIDGE_METHODS)[number];
export interface BridgeContext {
    app: {
        id: string;
        key: string;
        name: string;
        version: string;
    };
    user: {
        id: string;
        name: string;
        role?: string;
    } | null;
    tenant?: {
        id: string;
        name: string;
    };
}
export interface BridgeRequest {
    [BRIDGE_MARKER]: true;
    type: 'call';
    id: string;
    method: string;
    payload: unknown;
}
export interface BridgeResult {
    [BRIDGE_MARKER]: true;
    type: 'result';
    id: string;
    ok: boolean;
    result?: unknown;
    error?: string;
}
export declare const APP_CSP = "default-src 'none'; script-src 'unsafe-inline' data:; style-src 'unsafe-inline' data:; img-src data:; font-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
export declare function parseBridgeRequest(data: unknown): BridgeRequest | null;
export declare function makeBridgeResult(id: string, ok: boolean, value: unknown): BridgeResult;
export declare function isBridgeMethod(method: string): method is BridgeMethod;
/** Source for the promise-based SDK injected into the opaque-origin iframe. */
export declare function bridgeClientSource(context: BridgeContext, globalName?: string): string;
export declare function inlineDocument(entryHtml: string, replacements: Record<string, string>, headHtml: string): string;
//# sourceMappingURL=bridge.d.ts.map