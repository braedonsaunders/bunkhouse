'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { json } from '@codemirror/lang-json';
import { Box, Braces, Check, ChevronDown, ChevronRight, File, FileArchive, FileCode2, FileImage, FilePlus2, FileText, Folder, FolderOpen, Globe2, PackagePlus, Palette, Plus, Search, ShieldCheck, Store, Trash2, Upload } from 'lucide-react';
import { Badge, Button, Drawer, Input, Label, Select, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, Textarea, cn } from '@appkit/ui';
import { contentTypeFor } from './manifest.js';
import { AppFrame } from './app-frame.js';
function buildTree(files) {
    const root = { name: '', path: '', folders: [], files: [] };
    const folderAt = (segments) => {
        let node = root;
        let prefix = '';
        for (const segment of segments) {
            prefix = prefix ? `${prefix}/${segment}` : segment;
            let next = node.folders.find((folder) => folder.name === segment);
            if (!next) {
                next = { name: segment, path: prefix, folders: [], files: [] };
                node.folders.push(next);
            }
            node = next;
        }
        return node;
    };
    for (const file of [...files].sort((left, right) => left.path.localeCompare(right.path))) {
        const parts = file.path.split('/');
        folderAt(parts.slice(0, -1)).files.push(file);
    }
    const sort = (folder) => {
        folder.folders.sort((left, right) => left.name.localeCompare(right.name));
        folder.folders.forEach(sort);
    };
    sort(root);
    return root;
}
function fileIcon(path) {
    const extension = path.slice(path.lastIndexOf('.') + 1).toLowerCase();
    if (extension === 'js' || extension === 'mjs')
        return _jsx(FileCode2, { className: "size-3.5 text-warning" });
    if (extension === 'html')
        return _jsx(FileCode2, { className: "size-3.5 text-danger" });
    if (extension === 'css')
        return _jsx(Palette, { className: "size-3.5 text-info" });
    if (extension === 'json')
        return _jsx(Braces, { className: "size-3.5 text-success" });
    if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(extension))
        return _jsx(FileImage, { className: "size-3.5 text-primary" });
    if (extension === 'md' || extension === 'txt')
        return _jsx(FileText, { className: "size-3.5 text-fg-subtle" });
    return _jsx(File, { className: "size-3.5 text-fg-subtle" });
}
function editorExtensions(path) {
    const extension = path.slice(path.lastIndexOf('.') + 1).toLowerCase();
    if (extension === 'js' || extension === 'mjs')
        return [javascript()];
    if (extension === 'html')
        return [html()];
    if (extension === 'css')
        return [css()];
    if (extension === 'json')
        return [json()];
    return [];
}
export function AppsStudio(props) {
    const [internalSelected, setInternalSelected] = React.useState(null);
    const [query, setQuery] = React.useState('');
    const [creating, setCreating] = React.useState(false);
    const [newName, setNewName] = React.useState('');
    const currentKey = props.selectedKey === undefined ? internalSelected : props.selectedKey;
    const choose = (key) => {
        if (props.selectedKey === undefined)
            setInternalSelected(key);
        props.onSelectedKeyChange?.(key);
    };
    const selected = currentKey && currentKey !== 'new' ? props.apps.find((app) => app.key === currentKey) ?? null : null;
    const filtered = props.apps.filter((app) => `${app.name} ${app.key} ${app.description ?? ''}`.toLowerCase().includes(query.trim().toLowerCase()));
    async function create() {
        if (!newName.trim())
            return;
        setCreating(true);
        try {
            await props.onCreate(newName.trim());
            setNewName('');
            choose(null);
        }
        finally {
            setCreating(false);
        }
    }
    async function importArchive(event) {
        const file = event.currentTarget.files?.[0];
        if (!file)
            return;
        await props.onImport(new Uint8Array(await file.arrayBuffer()));
        event.currentTarget.value = '';
    }
    return (_jsxs("div", { className: cn('space-y-4', props.className), children: [_jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [_jsxs("div", { className: "relative min-w-64 flex-1 sm:max-w-sm", children: [_jsx(Search, { "aria-hidden": true, className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.currentTarget.value), placeholder: "Search installed apps", className: "pl-9" })] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs("label", { className: "inline-flex", children: [_jsx("input", { type: "file", accept: ".zip,application/zip", className: "sr-only", onChange: importArchive }), _jsxs("span", { className: "inline-flex h-9 cursor-pointer items-center gap-2 rounded-md border border-border bg-surface px-3 text-sm font-medium text-fg shadow-sm hover:bg-surface-hover", children: [_jsx(Upload, { className: "size-4" }), " Import ZIP"] })] }), _jsxs(Button, { onClick: () => choose('new'), children: [_jsx(Plus, { className: "size-4" }), " New app"] })] })] }), _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsxs(TableRow, { noAnimate: true, children: [_jsx(TableHead, { children: "App" }), _jsx(TableHead, { children: "Version" }), _jsx(TableHead, { children: "Capabilities" }), _jsx(TableHead, { children: "Navigation" }), _jsx(TableHead, { children: "Last run" }), _jsx(TableHead, { children: "Status" })] }) }), _jsxs(TableBody, { children: [filtered.map((app) => {
                                const latest = props.runs?.[app.id]?.[0];
                                return _jsxs(TableRow, { className: "cursor-pointer", onClick: () => choose(app.key), children: [_jsx(TableCell, { children: _jsxs("span", { className: "flex items-center gap-3", children: [_jsx("span", { className: "grid size-9 place-items-center rounded-lg bg-primary-subtle text-primary", children: _jsx(Box, { className: "size-4" }) }), _jsxs("span", { children: [_jsx("span", { className: "block font-medium text-fg", children: app.name }), _jsx("span", { className: "text-xs text-fg-muted", children: app.key })] })] }) }), _jsx(TableCell, { className: "font-mono text-xs", children: app.version }), _jsx(TableCell, { children: _jsxs("span", { className: "text-sm text-fg-muted", children: [app.grantedPermissions.length, " granted"] }) }), _jsx(TableCell, { children: app.showInNav ? 'Shown' : 'Hidden' }), _jsx(TableCell, { className: "text-fg-muted", children: latest ? formatDate(latest.at) : 'Never' }), _jsx(TableCell, { children: _jsx(Badge, { variant: app.status === 'installed' ? 'success' : 'outline', children: app.status === 'installed' ? 'Installed' : 'Disabled' }) })] }, app.id);
                            }), !filtered.length ? _jsx(TableRow, { children: _jsx(TableCell, { colSpan: 6, className: "py-14 text-center text-fg-muted", children: "No installed apps match this view." }) }) : null] })] }), _jsx(Drawer, { open: currentKey === 'new', onClose: () => choose(null), title: "New app", description: "Create an editable app bundle with a frontend and governed backend endpoint.", size: "md", footer: _jsxs("div", { className: "flex w-full justify-end gap-2", children: [_jsx(Button, { variant: "outline", onClick: () => choose(null), children: "Cancel" }), _jsxs(Button, { onClick: create, disabled: creating || !newName.trim(), children: [_jsx(PackagePlus, { className: "size-4" }), " Create app"] })] }), children: _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "new-app-name", children: "App name" }), _jsx(Input, { id: "new-app-name", autoFocus: true, value: newName, onChange: (event) => setNewName(event.currentTarget.value), onKeyDown: (event) => { if (event.key === 'Enter')
                                void create(); }, placeholder: "Operations console" })] }) }), selected ? _jsx(AppEditorDrawer, { app: selected, files: props.files[selected.id] ?? [], runs: props.runs?.[selected.id] ?? [], capabilities: props.capabilities, context: props.contextFor(selected), onClose: () => choose(null), onSaveMeta: props.onSaveMeta, onSaveFile: props.onSaveFile, onDeleteFile: props.onDeleteFile, onStatusChange: props.onStatusChange, onDelete: props.onDelete, onPublish: props.onPublish, onBridgeCall: (request) => props.onBridgeCall(selected, request) }, selected.id) : null] }));
}
function AppEditorDrawer({ app, files, runs, capabilities, context, onClose, onSaveMeta, onSaveFile, onDeleteFile, onStatusChange, onDelete, onPublish, onBridgeCall }) {
    const [tab, setTab] = React.useState('overview');
    const [meta, setMeta] = React.useState(() => ({ name: app.name, description: app.description ?? '', iconKey: app.iconKey, version: app.version ?? '0.1.0', showInNav: app.showInNav, requestedPermissions: [...(app.manifest?.permissions ?? [])], grantedPermissions: [...app.grantedPermissions] }));
    const [selectedPath, setSelectedPath] = React.useState(app.manifest?.frontend.entry ?? files[0]?.path ?? '');
    const [draftFiles, setDraftFiles] = React.useState(() => new Map(files.map((file) => [file.path, { ...file }])));
    const [endpoints, setEndpoints] = React.useState(() => structuredClone(app.manifest?.endpoints ?? []));
    const [busy, setBusy] = React.useState(false);
    const [newPath, setNewPath] = React.useState('');
    const [dirtyPaths, setDirtyPaths] = React.useState(() => new Set());
    const [openDirs, setOpenDirs] = React.useState(() => new Set(buildTree(files).folders.map((folder) => folder.path)));
    const uploadRef = React.useRef(null);
    const selectedFile = draftFiles.get(selectedPath);
    const fileList = [...draftFiles.values()].sort((left, right) => left.path.localeCompare(right.path));
    const tree = React.useMemo(() => buildTree(fileList), [draftFiles]);
    const preview = app.manifest ? browserBundle({ ...app.manifest, endpoints }, fileList) : null;
    async function saveMeta() {
        setBusy(true);
        try {
            await onSaveMeta(app.key, { ...meta, description: meta.description || null, endpoints });
        }
        finally {
            setBusy(false);
        }
    }
    async function saveFile() {
        if (!selectedFile)
            return;
        setBusy(true);
        try {
            await onSaveFile(app.key, { path: selectedFile.path, content: selectedFile.content, isBinary: selectedFile.isBinary });
            setDirtyPaths((current) => {
                const next = new Set(current);
                next.delete(selectedFile.path);
                return next;
            });
        }
        finally {
            setBusy(false);
        }
    }
    async function addFile() {
        const path = newPath.trim();
        if (!path || draftFiles.has(path))
            return;
        const { contentType, binary } = contentTypeFor(path);
        const file = { id: `draft-${path}`, tenantId: app.tenantId, appId: app.id, versionId: app.activeVersionId, path, kind: path.startsWith('frontend/') ? 'frontend' : path.startsWith('backend/') ? 'backend' : path.startsWith('objects/') ? 'object' : 'asset', contentType, content: '', isBinary: binary, size: 0 };
        setDraftFiles((current) => new Map(current).set(path, file));
        setDirtyPaths((current) => new Set(current).add(path));
        setSelectedPath(path);
        setNewPath('');
    }
    async function removeFile() {
        if (!selectedFile)
            return;
        await onDeleteFile(app.key, selectedFile.path);
        setDraftFiles((current) => { const next = new Map(current); next.delete(selectedFile.path); return next; });
        setDirtyPaths((current) => { const next = new Set(current); next.delete(selectedFile.path); return next; });
        setSelectedPath(fileList.find((file) => file.path !== selectedFile.path)?.path ?? '');
    }
    async function uploadFile(file) {
        const path = `${selectedPath.split('/').slice(0, -1).join('/')}${selectedPath.includes('/') ? '/' : ''}${file.name}`;
        const { contentType, binary } = contentTypeFor(path);
        const content = binary ? bytesToBase64(new Uint8Array(await file.arrayBuffer())) : await file.text();
        await onSaveFile(app.key, { path, content, isBinary: binary });
        const uploaded = { id: `uploaded-${path}`, tenantId: app.tenantId, appId: app.id, versionId: app.activeVersionId, path, kind: path.startsWith('frontend/') ? 'frontend' : path.startsWith('backend/') ? 'backend' : path.startsWith('objects/') ? 'object' : 'asset', contentType, content, isBinary: binary, size: binary ? file.size : content.length };
        setDraftFiles((current) => new Map(current).set(path, uploaded));
        setSelectedPath(path);
    }
    function toggleDir(path) {
        setOpenDirs((current) => {
            const next = new Set(current);
            if (next.has(path))
                next.delete(path);
            else
                next.add(path);
            return next;
        });
    }
    function renderFolder(folder, depth) {
        return _jsxs("div", { children: [folder.path ? _jsxs("button", { type: "button", onClick: () => toggleDir(folder.path), className: "flex w-full items-center gap-1.5 rounded px-2 py-1 text-left text-[13px] text-fg-muted hover:bg-surface-hover hover:text-fg", style: { paddingLeft: `${depth * 14 + 8}px` }, children: [openDirs.has(folder.path) ? _jsx(ChevronDown, { className: "size-3.5" }) : _jsx(ChevronRight, { className: "size-3.5" }), openDirs.has(folder.path) ? _jsx(FolderOpen, { className: "size-3.5 text-primary" }) : _jsx(Folder, { className: "size-3.5 text-primary" }), _jsx("span", { className: "truncate", children: folder.name })] }) : null, !folder.path || openDirs.has(folder.path) ? _jsxs(_Fragment, { children: [folder.folders.map((child) => renderFolder(child, depth + (folder.path ? 1 : 0))), folder.files.map((file) => _jsxs("button", { type: "button", onClick: () => setSelectedPath(file.path), className: cn('flex w-full items-center gap-1.5 rounded px-2 py-1 text-left text-[13px] transition-colors', selectedPath === file.path ? 'bg-primary-subtle text-primary' : 'text-fg hover:bg-surface-hover'), style: { paddingLeft: `${(depth + (folder.path ? 1 : 0)) * 14 + 26}px` }, children: [fileIcon(file.path), _jsx("span", { className: "truncate", children: file.path.split('/').pop() }), dirtyPaths.has(file.path) ? _jsx("span", { className: "ml-auto text-warning", children: "\u25CF" }) : null] }, file.path))] }) : null] }, folder.path || 'root');
    }
    return _jsxs(Drawer, { open: true, onClose: onClose, title: app.name, description: `${app.key} · v${app.version}`, size: "xl", bodyClassName: "flex min-h-0 flex-col overflow-hidden px-6 py-5", headerActions: _jsxs(_Fragment, { children: [tab === 'overview' ? _jsxs(Button, { size: "sm", onClick: saveMeta, disabled: busy || !meta.name.trim(), children: [_jsx(Check, { className: "size-4" }), " Save settings"] }) : null, tab === 'files' ? _jsxs(Button, { size: "sm", onClick: saveFile, disabled: busy || !selectedFile || selectedFile.isBinary || !dirtyPaths.has(selectedFile.path), children: [_jsx(Check, { className: "size-4" }), " ", dirtyPaths.has(selectedFile?.path ?? '') ? 'Save file' : 'Saved'] }) : null] }), children: [_jsxs("div", { className: "flex shrink-0 gap-1 overflow-x-auto border-b border-border px-1", children: [_jsx(Tab, { active: tab === 'overview', onClick: () => setTab('overview'), children: "Overview" }), _jsx(Tab, { active: tab === 'files', onClick: () => setTab('files'), children: "Files" }), _jsx(Tab, { active: tab === 'preview', onClick: () => setTab('preview'), children: "Preview" }), _jsxs(Tab, { active: tab === 'runs', onClick: () => setTab('runs'), children: ["Runs", runs.length ? _jsx("span", { className: "ml-1.5 rounded-full bg-bg-subtle px-1.5 text-[11px] text-fg-muted", children: runs.length }) : null] })] }), _jsxs("div", { className: "min-h-0 flex-1 overflow-y-auto p-1 pt-4", children: [tab === 'overview' ? _jsxs("div", { className: "mx-auto max-w-3xl space-y-6", children: [_jsxs("div", { className: "grid gap-5 sm:grid-cols-2", children: [_jsx(Field, { label: "Name", children: _jsx(Input, { value: meta.name, onChange: (event) => setMeta((current) => ({ ...current, name: event.currentTarget.value })) }) }), _jsx(Field, { label: "Version", children: _jsx(Input, { value: meta.version, onChange: (event) => setMeta((current) => ({ ...current, version: event.currentTarget.value })) }) }), _jsx(Field, { label: "Icon key", children: _jsx(Input, { value: meta.iconKey, onChange: (event) => setMeta((current) => ({ ...current, iconKey: event.currentTarget.value })) }) }), _jsxs("label", { className: "flex items-center gap-3 self-end rounded-lg border border-border bg-bg-subtle px-4 py-3 text-sm", children: [_jsx("input", { type: "checkbox", className: "size-4 accent-primary", checked: meta.showInNav, onChange: (event) => setMeta((current) => ({ ...current, showInNav: event.currentTarget.checked })) }), " Show in navigation"] }), _jsx(Field, { label: "Description", className: "sm:col-span-2", children: _jsx(Textarea, { value: meta.description, onChange: (event) => setMeta((current) => ({ ...current, description: event.currentTarget.value })), rows: 3 }) })] }), _jsxs("section", { className: "space-y-3", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-semibold text-fg", children: "Capabilities" }), _jsx("p", { className: "text-sm text-fg-muted", children: "Requested capabilities are granted explicitly and intersected with the invoking user." })] }), _jsx("div", { className: "grid gap-2 sm:grid-cols-2", children: capabilities.map((capability) => { const requested = meta.requestedPermissions.includes(capability.key); const granted = meta.grantedPermissions.includes(capability.key); return _jsxs("div", { className: cn('rounded-lg border p-3', requested ? 'border-border bg-surface' : 'border-border-subtle bg-bg-subtle'), children: [_jsx("span", { className: "block text-sm font-medium text-fg", children: capability.label }), _jsx("span", { className: "block text-xs leading-5 text-fg-muted", children: capability.description }), _jsxs("span", { className: "mt-3 flex gap-4 text-xs text-fg-muted", children: [_jsxs("label", { className: "flex items-center gap-2", children: [_jsx("input", { type: "checkbox", className: "size-4 accent-primary", checked: requested, onChange: (event) => setMeta((current) => ({ ...current, requestedPermissions: event.currentTarget.checked ? [...current.requestedPermissions, capability.key] : current.requestedPermissions.filter((key) => key !== capability.key), grantedPermissions: event.currentTarget.checked ? current.grantedPermissions : current.grantedPermissions.filter((key) => key !== capability.key) })) }), " Requested"] }), _jsxs("label", { className: cn('flex items-center gap-2', !requested && 'opacity-50'), children: [_jsx("input", { type: "checkbox", className: "size-4 accent-primary", disabled: !requested, checked: granted, onChange: (event) => setMeta((current) => ({ ...current, grantedPermissions: event.currentTarget.checked ? [...current.grantedPermissions, capability.key] : current.grantedPermissions.filter((key) => key !== capability.key) })) }), " Granted"] })] })] }, capability.key); }) })] }), _jsx(EndpointEditor, { endpoints: endpoints, files: fileList, onChange: setEndpoints }), _jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 border-t border-border pt-5", children: [_jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { size: "sm", variant: "outline", onClick: () => void onPublish(app.key), children: [_jsx(Globe2, { className: "size-4" }), " Publish"] }), _jsx(Button, { size: "sm", variant: "outline", onClick: () => void onStatusChange(app.key, app.status === 'installed' ? 'disabled' : 'installed'), children: app.status === 'installed' ? 'Disable' : 'Enable' })] }), _jsxs(Button, { size: "sm", variant: "destructive", onClick: () => void onDelete(app.key), children: [_jsx(Trash2, { className: "size-4" }), " Delete app"] })] })] }) : null, tab === 'files' ? _jsxs("div", { className: "flex h-[calc(100vh-16rem)] min-h-[420px] overflow-hidden rounded-lg border border-border", children: [_jsxs("aside", { className: "flex w-60 shrink-0 flex-col border-r border-border bg-bg-subtle", children: [_jsxs("div", { className: "flex items-center gap-1 border-b border-border px-2 py-1.5", children: [_jsx("input", { ref: uploadRef, type: "file", className: "hidden", onChange: (event) => { const file = event.currentTarget.files?.[0]; if (file)
                                                    void uploadFile(file); event.currentTarget.value = ''; } }), _jsx(Button, { size: "sm", variant: "ghost", title: "New file", onClick: () => setNewPath((current) => current || `${selectedPath.split('/').slice(0, -1).join('/')}/`), children: _jsx(FilePlus2, { className: "size-4" }) }), _jsx(Button, { size: "sm", variant: "ghost", title: "Upload file", onClick: () => uploadRef.current?.click(), children: _jsx(Upload, { className: "size-4" }) }), _jsx(Button, { size: "sm", variant: "ghost", title: "Delete file", disabled: !selectedFile || selectedFile.path === app.manifest?.frontend.entry || endpoints.some((endpoint) => endpoint.file === selectedFile.path), onClick: removeFile, children: _jsx(Trash2, { className: "size-4" }) })] }), newPath ? _jsxs("div", { className: "flex gap-1 border-b border-border p-2", children: [_jsx(Input, { autoFocus: true, value: newPath, onChange: (event) => setNewPath(event.currentTarget.value), placeholder: "frontend/file.js", className: "h-8 text-xs", onKeyDown: (event) => { if (event.key === 'Enter')
                                                    void addFile(); if (event.key === 'Escape')
                                                    setNewPath(''); } }), _jsx(Button, { size: "sm", onClick: addFile, children: "Add" })] }) : null, _jsx("div", { className: "min-h-0 flex-1 overflow-y-auto p-1", children: renderFolder(tree, 0) })] }), _jsx("section", { className: "min-w-0 flex-1 bg-bg", children: selectedFile ? _jsxs("div", { className: "flex h-full flex-col", children: [_jsxs("div", { className: "flex shrink-0 items-center justify-between border-b border-border px-3 py-1.5", children: [_jsxs("span", { className: "truncate font-mono text-xs text-fg-muted", children: [selectedFile.path, dirtyPaths.has(selectedFile.path) ? _jsx("span", { className: "ml-1 text-warning", children: "\u25CF" }) : null] }), _jsx("span", { className: "text-[11px] text-fg-subtle", children: selectedFile.kind })] }), selectedFile.isBinary ? _jsx("div", { className: "grid flex-1 place-items-center", children: _jsxs("div", { className: "text-center text-sm text-fg-muted", children: [_jsx(FileImage, { className: "mx-auto mb-2 size-8 text-fg-subtle" }), _jsx("p", { className: "font-mono text-xs", children: selectedFile.path }), _jsxs("p", { className: "mt-1 text-xs", children: ["Binary file \u00B7 ", selectedFile.contentType, " \u00B7 ", selectedFile.size.toLocaleString(), " bytes"] })] }) }) : _jsx("div", { className: "min-h-0 flex-1 overflow-auto", children: _jsx(CodeMirror, { className: "appkit-code-editor", value: selectedFile.content, onChange: (value) => { setDraftFiles((current) => { const next = new Map(current); next.set(selectedFile.path, { ...selectedFile, content: value, size: value.length }); return next; }); setDirtyPaths((current) => new Set(current).add(selectedFile.path)); }, extensions: editorExtensions(selectedFile.path), theme: "dark", height: "100%", basicSetup: { lineNumbers: true, foldGutter: true, autocompletion: true }, onKeyDown: (event) => { if ((event.metaKey || event.ctrlKey) && event.key === 's') {
                                                    event.preventDefault();
                                                    void saveFile();
                                                } } }) })] }) : _jsx("div", { className: "grid h-full place-items-center text-sm text-fg-muted", children: "Select or create a file." }) })] }) : null, tab === 'preview' ? _jsx("div", { className: "rounded-lg bg-bg-subtle p-4", children: preview ? _jsxs("div", { className: "mx-auto max-w-6xl overflow-hidden rounded-xl border border-border bg-surface shadow-lg", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-border px-4 py-2 text-xs text-fg-muted", children: [_jsxs("span", { className: "flex items-center gap-2", children: [_jsx(ShieldCheck, { className: "size-3.5 text-success" }), " Opaque-origin sandbox"] }), _jsx("span", { children: "No cookies \u00B7 no parent DOM \u00B7 no ambient network" })] }), _jsx(AppFrame, { appKey: app.key, context: context, bundle: preview, onBridgeCall: onBridgeCall })] }) : _jsx("div", { className: "grid min-h-80 place-items-center text-sm text-fg-muted", children: "The frontend entry file is missing." }) }) : null, tab === 'runs' ? _jsx(AppRuns, { runs: runs }) : null] }, tab)] });
}
function EndpointEditor({ endpoints, files, onChange }) {
    const backendFiles = files.filter((file) => file.kind === 'backend' || file.path.startsWith('backend/'));
    return _jsxs("section", { className: "space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-semibold text-fg", children: "Backend endpoints" }), _jsx("p", { className: "text-sm text-fg-muted", children: "Each handler runs in QuickJS with governed host capabilities." })] }), _jsxs(Button, { size: "sm", variant: "outline", onClick: () => onChange([...endpoints, { name: `endpoint-${endpoints.length + 1}`, file: backendFiles[0]?.path ?? 'backend/handler.js', method: 'POST' }]), children: [_jsx(Plus, { className: "size-4" }), " Add endpoint"] })] }), endpoints.map((endpoint, index) => _jsxs("div", { className: "grid gap-3 rounded-lg border border-border bg-surface p-4 sm:grid-cols-[1fr_8rem_1.4fr_auto]", children: [_jsx(Field, { label: "Name", children: _jsx(Input, { value: endpoint.name, onChange: (event) => onChange(replaceAt(endpoints, index, { ...endpoint, name: event.currentTarget.value })) }) }), _jsx(Field, { label: "Method", children: _jsx(Select, { value: endpoint.method, onChange: (event) => onChange(replaceAt(endpoints, index, { ...endpoint, method: event.currentTarget.value })), children: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'ANY'].map((method) => _jsx("option", { children: method }, method)) }) }), _jsx(Field, { label: "Handler file", children: _jsx(Select, { value: endpoint.file, onChange: (event) => onChange(replaceAt(endpoints, index, { ...endpoint, file: event.currentTarget.value })), children: backendFiles.map((file) => _jsx("option", { value: file.path, children: file.path }, file.path)) }) }), _jsx(Button, { size: "icon", variant: "ghost", className: "self-end", onClick: () => onChange(endpoints.filter((_, candidate) => candidate !== index)), "aria-label": `Delete ${endpoint.name}`, children: _jsx(Trash2, { className: "size-4" }) })] }, `${endpoint.name}-${index}`)), !endpoints.length ? _jsx("div", { className: "grid min-h-32 place-items-center rounded-lg border border-dashed border-border text-sm text-fg-muted", children: "This app has no backend endpoints." }) : null] });
}
function AppRuns({ runs }) {
    const [selected, setSelected] = React.useState(0);
    const run = runs[selected];
    if (!runs.length)
        return _jsx("div", { className: "grid h-full min-h-80 place-items-center text-sm text-fg-muted", children: "No backend calls have run yet." });
    return _jsxs("div", { className: "grid h-full min-h-[34rem] lg:grid-cols-[minmax(17rem,1fr)_2fr]", children: [_jsx("aside", { className: "overflow-auto border-r border-border p-2", children: runs.map((item, index) => _jsxs("button", { type: "button", onClick: () => setSelected(index), className: cn('flex w-full items-center justify-between gap-3 rounded-md px-3 py-3 text-left', selected === index ? 'bg-primary-subtle' : 'hover:bg-surface-hover'), children: [_jsxs("span", { children: [_jsx("span", { className: "block text-sm font-medium text-fg", children: item.endpoint }), _jsxs("span", { className: "text-xs text-fg-muted", children: [formatDate(item.at), " \u00B7 ", item.durationMs, " ms"] })] }), _jsx(Badge, { variant: item.status === 'ok' ? 'success' : 'destructive', children: item.status })] }, `${item.at.toISOString()}-${index}`)) }), _jsxs("section", { className: "min-w-0 space-y-4 overflow-auto p-5", children: [run?.errorMessage ? _jsx("div", { className: "rounded-md border border-danger bg-danger-subtle p-3 text-sm text-danger", children: run.errorMessage }) : null, _jsx(Log, { title: "Governance", value: `${run?.units ?? 0} units · ${run?.durationMs ?? 0} ms` }), _jsx(Log, { title: "Console", value: run?.logs.join('\n') || 'No log output.' })] })] });
}
export function AppLibrary({ listings, installedKeys = new Set(), onInstall, className }) {
    return _jsx("div", { className: cn('grid gap-4 sm:grid-cols-2 xl:grid-cols-3', className), children: listings.map((listing) => { const installed = installedKeys.has(listing.key); return _jsxs("article", { className: "flex min-h-56 flex-col rounded-xl border border-border bg-surface p-5 shadow-sm", children: [_jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsx("span", { className: "grid size-11 place-items-center rounded-xl bg-primary-subtle text-primary", children: _jsx(Store, { className: "size-5" }) }), _jsxs(Badge, { variant: "outline", children: ["v", listing.version] })] }), _jsx("h3", { className: "mt-4 text-lg font-semibold text-fg", children: listing.name }), _jsx("p", { className: "mt-1 line-clamp-3 flex-1 text-sm leading-6 text-fg-muted", children: listing.description || 'No description provided.' }), _jsxs("div", { className: "mt-4 flex items-center justify-between gap-3", children: [_jsxs("span", { className: "text-xs text-fg-subtle", children: [listing.manifest.permissions.length, " capabilities requested"] }), _jsxs(Button, { size: "sm", disabled: installed, onClick: () => void onInstall(listing), children: [installed ? _jsx(Check, { className: "size-4" }) : _jsx(FileArchive, { className: "size-4" }), installed ? 'Installed' : 'Install'] })] })] }, listing.id); }) });
}
function Tab({ active, onClick, children }) { return _jsx("button", { type: "button", onClick: onClick, className: cn('-mb-px flex shrink-0 items-center border-b-2 px-3 py-2 text-sm font-medium transition-colors', active ? 'border-primary text-primary' : 'border-transparent text-fg-muted hover:text-fg'), children: children }); }
function Field({ label, className, children }) { return _jsxs("div", { className: cn('space-y-2', className), children: [_jsx(Label, { children: label }), children] }); }
function Log({ title, value }) { return _jsxs("section", { className: "space-y-2", children: [_jsx("h3", { className: "text-xs font-semibold tracking-wide text-fg-muted uppercase", children: title }), _jsx("pre", { className: "max-h-80 overflow-auto whitespace-pre-wrap rounded-lg bg-bg-subtle p-4 font-mono text-xs leading-5 text-fg", children: value })] }); }
function replaceAt(values, index, value) { return values.map((current, candidate) => candidate === index ? value : current); }
function formatDate(value) { return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(value); }
function bytesToBase64(value) {
    let binary = '';
    for (const byte of value)
        binary += String.fromCharCode(byte);
    return btoa(binary);
}
function browserBundle(manifest, files) {
    const entry = files.find((file) => file.path === manifest.frontend.entry);
    if (!entry)
        return null;
    const replacements = {};
    for (const file of files) {
        if (file.path === entry.path || file.kind === 'backend' || file.kind === 'object')
            continue;
        const base64 = file.isBinary ? file.content : btoa(unescape(encodeURIComponent(file.content)));
        replacements[file.path] = `data:${file.contentType.replace(/;\s*/g, ';')};base64,${base64}`;
    }
    return { entry: entry.path, entryHtml: entry.content, replacements };
}
//# sourceMappingURL=apps-studio.js.map