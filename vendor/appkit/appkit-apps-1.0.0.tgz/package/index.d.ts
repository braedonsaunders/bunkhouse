import { type HostFunction, type RecordsAdapter, type StorageAdapter } from '@appkit/endpoints';
import type { AppBundle, AppBundleFile } from './bundle.js';
import { type AppEndpoint, type AppManifest } from './manifest.js';
import { type AppObjectSpec } from './objects.js';
export type AppStatus = 'installed' | 'disabled';
export type AppVersionStatus = 'draft' | 'active' | 'superseded';
export type AppFileKind = 'frontend' | 'backend' | 'asset' | 'object';
export type AppRunStatus = 'ok' | 'error' | 'timeout' | 'forbidden';
export interface InstalledApp {
    id: string;
    tenantId: string;
    key: string;
    name: string;
    description: string | null;
    iconKey: string;
    status: AppStatus;
    activeVersionId: string | null;
    grantedPermissions: string[];
    showInNav: boolean;
    sortOrder: number;
    provisionedObjects: string[];
    version: string | null;
    manifest: AppManifest | null;
}
export interface AppVersion {
    id: string;
    tenantId: string;
    appId: string;
    version: string;
    manifest: AppManifest;
    status: AppVersionStatus;
    createdAt: Date;
}
export interface AppFile {
    id: string;
    tenantId: string;
    appId: string;
    versionId: string;
    path: string;
    kind: AppFileKind;
    contentType: string;
    content: string;
    isBinary: boolean;
    size: number;
}
export interface AppRun {
    id?: string;
    tenantId: string;
    appId: string;
    versionId: string | null;
    endpoint: string;
    status: AppRunStatus;
    units: number;
    logs: string[];
    errorMessage: string | null;
    durationMs: number;
    actorId: string | null;
    at: Date;
}
export interface AppListing {
    id: string;
    publisherTenantId: string;
    key: string;
    name: string;
    description: string | null;
    iconKey: string;
    version: string;
    manifest: AppManifest;
    files: AppBundleFile[];
    isActive: boolean;
    updatedAt: Date;
}
export interface AppMetaUpdate {
    name?: string;
    description?: string | null;
    iconKey?: string;
    requestedPermissions?: string[];
    grantedPermissions?: string[];
    showInNav?: boolean;
    sortOrder?: number;
    version?: string;
    frontendEntry?: string;
    endpoints?: AppEndpoint[];
}
/**
 * Applies an authored manifest/settings change through the same capability
 * registry used at install time. Store adapters remain responsible for the
 * atomic manifest + installation update.
 */
export declare function updateApp(options: {
    store: AppStore;
    tenantId: string;
    actorId: string;
    key: string;
    update: AppMetaUpdate;
    capabilityKeys: ReadonlySet<string>;
}): Promise<void>;
export interface AppObjectProvisioner {
    /** Validate domain-owned object declarations before persistence begins. */
    validate(objects: AppObjectSpec[]): Promise<string[]> | string[];
    /** Called inside the persistence adapter's install transaction. */
    provision(input: {
        tenantId: string;
        appId: string;
        objects: AppObjectSpec[];
        previouslyOwned: string[];
        transaction: unknown;
    }): Promise<string[]>;
}
export interface PersistInstallInput {
    tenantId: string;
    actorId: string;
    manifest: AppManifest;
    grantedPermissions: string[];
    files: Array<AppBundleFile & {
        kind: AppFileKind;
        contentType: string;
    }>;
    objects: AppObjectSpec[];
    provisioner?: AppObjectProvisioner;
}
/** Persistence contract; the Drizzle and in-memory implementations are complete adapters. */
export interface AppStore {
    listApps(tenantId: string): Promise<InstalledApp[]>;
    getApp(tenantId: string, key: string): Promise<InstalledApp | null>;
    installBundle(input: PersistInstallInput): Promise<InstalledApp>;
    setStatus(tenantId: string, key: string, status: AppStatus): Promise<void>;
    deleteApp(tenantId: string, key: string): Promise<void>;
    updateMeta(tenantId: string, actorId: string, key: string, update: AppMetaUpdate): Promise<void>;
    listFiles(tenantId: string, key: string): Promise<AppFile[]>;
    readFile(tenantId: string, key: string, path: string): Promise<AppFile | null>;
    writeFile(tenantId: string, actorId: string, key: string, file: AppBundleFile): Promise<void>;
    deleteFile(tenantId: string, key: string, path: string): Promise<void>;
    storage(tenantId: string, appId: string): StorageAdapter;
    recordRun(run: AppRun): Promise<void>;
    listRuns(tenantId: string, appId: string, limit?: number): Promise<AppRun[]>;
    listListings(input: {
        query?: string;
        page: number;
        perPage: number;
    }): Promise<{
        listings: AppListing[];
        total: number;
    }>;
    publish(tenantId: string, actorId: string, key: string): Promise<AppListing>;
    getListing(listingId: string): Promise<AppListing | null>;
}
export interface AppRuntimeAdapters {
    /** Registry of capabilities a deployment allows manifests to request. */
    capabilityKeys: ReadonlySet<string>;
    records?: (tenantId: string, user: AppUser) => RecordsAdapter;
    functions?: (input: {
        tenantId: string;
        app: InstalledApp;
        user: AppUser;
        granted: ReadonlySet<string>;
    }) => Record<string, HostFunction>;
    userCan: (user: AppUser, permission: string) => boolean;
    /** Host global used by authored backend files. Defaults to `appkit`. */
    hostGlobalName?: string;
}
export interface AppUser {
    id: string;
    name: string;
    role?: string;
}
export declare class AppError extends Error {
    readonly status: number;
    readonly name = "AppError";
    constructor(message: string, status?: number);
}
export declare function installApp(options: {
    store: AppStore;
    tenantId: string;
    actorId: string;
    bundle: AppBundle;
    capabilityKeys: ReadonlySet<string>;
    provisioner?: AppObjectProvisioner;
}): Promise<InstalledApp>;
export declare function installFromListing(options: {
    store: AppStore;
    tenantId: string;
    actorId: string;
    listingId: string;
    capabilityKeys: ReadonlySet<string>;
    grantedPermissions?: string[];
    provisioner?: AppObjectProvisioner;
}): Promise<InstalledApp>;
export declare function getFrontendBundle(store: AppStore, tenantId: string, key: string): Promise<{
    entry: string;
    entryHtml: string;
    replacements: Record<string, string>;
}>;
export declare function runBridgeMethod(options: {
    store: AppStore;
    adapters: AppRuntimeAdapters;
    tenantId: string;
    key: string;
    user: AppUser;
    method: string;
    payload: unknown;
}): Promise<{
    ok: true;
    result: unknown;
} | {
    ok: false;
    error: string;
    status: number;
}>;
export declare function createAppScaffold(options: {
    store: AppStore;
    tenantId: string;
    actorId: string;
    name: string;
    capabilityKeys: ReadonlySet<string>;
}): Promise<InstalledApp>;
export type { AppBundle, AppBundleFile } from './bundle.js';
export { parseZipBundle, AppBundleError } from './bundle.js';
export type { AppManifest, AppEndpoint } from './manifest.js';
export { parseManifest, validateBundle, contentTypeFor, manifestSchema, endpointSchema, HTTP_METHODS } from './manifest.js';
export type { AppObjectSpec, ParsedAppObjects } from './objects.js';
export { parseAppObjects } from './objects.js';
export * from './bridge.js';
//# sourceMappingURL=index.d.ts.map