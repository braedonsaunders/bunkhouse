import { z } from 'zod';
export declare const HTTP_METHODS: readonly ["GET", "POST", "PUT", "PATCH", "DELETE", "ANY"];
export type AppHttpMethod = (typeof HTTP_METHODS)[number];
export declare const endpointSchema: z.ZodObject<{
    name: z.ZodString;
    file: z.ZodString;
    method: z.ZodDefault<z.ZodEnum<{
        GET: "GET";
        POST: "POST";
        PUT: "PUT";
        PATCH: "PATCH";
        DELETE: "DELETE";
        ANY: "ANY";
    }>>;
}, z.core.$strip>;
export declare const manifestSchema: z.ZodObject<{
    key: z.ZodString;
    name: z.ZodString;
    version: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    icon: z.ZodOptional<z.ZodString>;
    permissions: z.ZodDefault<z.ZodArray<z.ZodString>>;
    frontend: z.ZodObject<{
        entry: z.ZodString;
    }, z.core.$strip>;
    endpoints: z.ZodDefault<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        file: z.ZodString;
        method: z.ZodDefault<z.ZodEnum<{
            GET: "GET";
            POST: "POST";
            PUT: "PUT";
            PATCH: "PATCH";
            DELETE: "DELETE";
            ANY: "ANY";
        }>>;
    }, z.core.$strip>>>;
    nav: z.ZodOptional<z.ZodObject<{
        show: z.ZodDefault<z.ZodBoolean>;
        label: z.ZodOptional<z.ZodString>;
        icon: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type AppManifest = z.infer<typeof manifestSchema>;
export type AppEndpoint = z.infer<typeof endpointSchema>;
export interface ManifestResult {
    ok: boolean;
    manifest?: AppManifest;
    errors: string[];
}
export declare function parseManifest(raw: unknown): ManifestResult;
export declare function validateBundle(manifest: AppManifest, paths: string[]): {
    ok: boolean;
    errors: string[];
    kinds: Record<string, 'frontend' | 'backend' | 'asset' | 'object'>;
};
export declare function contentTypeFor(path: string): {
    contentType: string;
    binary: boolean;
};
//# sourceMappingURL=manifest.d.ts.map