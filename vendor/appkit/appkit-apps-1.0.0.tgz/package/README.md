# @appkit/apps

Installable application bundles with immutable versions, governed QuickJS backends, opaque-origin frontends, capabilities, authoring, and distribution.

## Install

```bash
pnpm add @appkit/apps
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
