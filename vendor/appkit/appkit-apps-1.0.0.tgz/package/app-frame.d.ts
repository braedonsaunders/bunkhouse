import * as React from 'react';
import { type BridgeContext, type BridgeMethod } from './bridge.js';
export interface AppFrameProps {
    appKey: string;
    context: BridgeContext;
    bundle: {
        entry: string;
        entryHtml: string;
        replacements: Record<string, string>;
    };
    onBridgeCall: (request: {
        method: BridgeMethod;
        payload: unknown;
    }) => Promise<unknown>;
    className?: string;
    title?: string;
    /** SDK global exposed inside the iframe. Defaults to `appkit`. */
    globalName?: string;
}
/** Host for an uploaded frontend: opaque origin, no cookies, no parent DOM, no network. */
export declare function AppFrame({ appKey, context, bundle, onBridgeCall, className, title, globalName }: AppFrameProps): React.JSX.Element;
//# sourceMappingURL=app-frame.d.ts.map