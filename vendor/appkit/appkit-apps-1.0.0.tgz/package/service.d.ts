import { type AppBundle, type AppMetaUpdate, type AppObjectProvisioner, type AppRuntimeAdapters, type AppStatus, type AppStore, type AppUser } from './index.js';
export interface AppBridgeInvocation {
    key: string;
    user: AppUser;
    method: string;
    payload: unknown;
    userCan: (permission: string) => boolean;
}
export interface BoundAppServiceOptions<TBridge extends AppBridgeInvocation> {
    store: AppStore;
    capabilityKeys: ReadonlySet<string>;
    /** Resolve the package tenant key from an application's existing bridge request. */
    tenantId: (input: TBridge) => string;
    /** Supply deployment-owned records, writes, globals, and authorization adapters. */
    runtime: (input: TBridge) => Omit<AppRuntimeAdapters, 'capabilityKeys' | 'userCan'>;
    provisioner?: AppObjectProvisioner;
}
/**
 * Bind the complete installable-app lifecycle to application-owned adapters.
 * Method signatures deliberately remain positional so existing routes can
 * replace their store import with one configured service export.
 */
export declare function createBoundAppService<TBridge extends AppBridgeInvocation>(options: BoundAppServiceOptions<TBridge>): {
    listApps: (tenantId: string) => Promise<import("./index").InstalledApp[]>;
    getAppByKey: (tenantId: string, key: string) => Promise<import("./index").InstalledApp | null>;
    installApp(tenantId: string, actorId: string, bundle: AppBundle): Promise<{
        key: string;
    }>;
    setAppStatus: (tenantId: string, key: string, status: AppStatus) => Promise<void>;
    deleteApp: (tenantId: string, key: string) => Promise<void>;
    getFrontendBundle: (tenantId: string, key: string) => Promise<{
        entry: string;
        entryHtml: string;
        replacements: Record<string, string>;
    }>;
    runBridgeMethod: (input: TBridge) => Promise<{
        ok: true;
        result: unknown;
    } | {
        ok: false;
        error: string;
        status: number;
    }>;
    createAppScaffold(tenantId: string, actorId: string, name: string): Promise<{
        key: string;
    }>;
    updateAppMeta: (tenantId: string, actorId: string, key: string, update: AppMetaUpdate) => Promise<void>;
    listAppFiles: (tenantId: string, key: string) => Promise<import("./index").AppFile[]>;
    readAppFile: (tenantId: string, key: string, path: string) => Promise<import("./index").AppFile | null>;
    writeAppFile: (tenantId: string, actorId: string, key: string, path: string, content: string, isBinary?: boolean) => Promise<void>;
    deleteAppFile: (tenantId: string, key: string, path: string) => Promise<void>;
    listListings: (input: {
        query?: string;
        page: number;
        perPage: number;
    }) => Promise<{
        listings: import("./index").AppListing[];
        total: number;
    }>;
    isAppPublished(key: string): Promise<boolean>;
    publishApp(tenantId: string, actorId: string, key: string): Promise<{
        id: string;
    }>;
    installFromListing(tenantId: string, actorId: string, listingId: string): Promise<{
        key: string;
    }>;
};
//# sourceMappingURL=service.d.ts.map