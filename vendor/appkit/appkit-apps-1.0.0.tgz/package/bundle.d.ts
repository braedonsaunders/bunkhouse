export interface AppBundleFile {
    path: string;
    content: string;
    isBinary?: boolean;
}
export interface AppBundle {
    manifest: unknown;
    files: AppBundleFile[];
    grantedPermissions?: string[];
}
export declare class AppBundleError extends Error {
    readonly name = "AppBundleError";
}
export declare function parseZipBundle(bytes: Uint8Array): AppBundle;
//# sourceMappingURL=bundle.d.ts.map