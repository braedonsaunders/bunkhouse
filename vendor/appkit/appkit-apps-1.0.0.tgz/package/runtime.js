import { runEndpoint } from '@appkit/endpoints';
/**
 * Source-shaped application backend runtime entry. The implementation lives in
 * @appkit/endpoints so standalone programmable endpoints and installed apps use
 * one governed QuickJS kernel.
 */
export { runEndpoint as runAppEndpoint, DEFAULT_COSTS as APP_ENDPOINT_DEFAULT_COSTS } from '@appkit/endpoints';
/**
 * Bind the generalized endpoint kernel to an application's existing authored
 * global and adapter shape. The returned function retains the source-shaped
 * positional options contract used by a direct runtime import.
 */
export function createAppEndpointRuntime(configuration) {
    return (options) => runEndpoint({
        ...options,
        adapters: configuration.adapters(options.adapters),
        globalName: configuration.globalName,
    });
}
//# sourceMappingURL=runtime.js.map