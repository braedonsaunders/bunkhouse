/** Parse every objects/*.json declaration without imposing an application domain schema. */
export function parseAppObjects(files) {
    const objects = [];
    const errors = [];
    const seen = new Set();
    for (const file of files) {
        if (!/^objects\/[^/]+\.json$/.test(file.path))
            continue;
        if (file.isBinary) {
            errors.push(`${file.path}: must be a JSON text file`);
            continue;
        }
        let value;
        try {
            value = JSON.parse(file.content);
        }
        catch {
            errors.push(`${file.path}: invalid JSON`);
            continue;
        }
        if (!value || typeof value !== 'object' || Array.isArray(value)) {
            errors.push(`${file.path}: object declaration must be an object`);
            continue;
        }
        const definition = value;
        const type = typeof definition.type === 'string' ? definition.type.trim() : '';
        const key = typeof definition.key === 'string' ? definition.key.trim() : '';
        if (!/^[a-z][a-z0-9_-]*$/.test(type)) {
            errors.push(`${file.path}: type must be a slug`);
            continue;
        }
        if (!/^[a-z][a-z0-9_-]*$/.test(key)) {
            errors.push(`${file.path}: key must be a slug`);
            continue;
        }
        const identity = `${type}:${key}`;
        if (seen.has(identity)) {
            errors.push(`${file.path}: duplicate object "${identity}"`);
            continue;
        }
        seen.add(identity);
        objects.push({ type, key, definition, sourcePath: file.path });
    }
    return { objects, errors };
}
//# sourceMappingURL=objects.js.map