import { type AppFile, type AppListing, type AppRun, type AppStatus, type AppStore, type AppVersion, type InstalledApp } from './index.js';
export declare function createMemoryAppStore(seed?: {
    apps?: InstalledApp[];
    versions?: AppVersion[];
    files?: AppFile[];
    runs?: AppRun[];
    listings?: AppListing[];
}): AppStore;
export type { AppStatus };
//# sourceMappingURL=memory.d.ts.map