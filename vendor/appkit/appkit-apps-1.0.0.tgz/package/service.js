import { createAppScaffold, getFrontendBundle, installApp, installFromListing, runBridgeMethod, updateApp, } from './index.js';
/**
 * Bind the complete installable-app lifecycle to application-owned adapters.
 * Method signatures deliberately remain positional so existing routes can
 * replace their store import with one configured service export.
 */
export function createBoundAppService(options) {
    return {
        listApps: (tenantId) => options.store.listApps(tenantId),
        getAppByKey: (tenantId, key) => options.store.getApp(tenantId, key),
        async installApp(tenantId, actorId, bundle) {
            const app = await installApp({ store: options.store, tenantId, actorId, bundle, capabilityKeys: options.capabilityKeys, provisioner: options.provisioner });
            return { key: app.key };
        },
        setAppStatus: (tenantId, key, status) => options.store.setStatus(tenantId, key, status),
        deleteApp: (tenantId, key) => options.store.deleteApp(tenantId, key),
        getFrontendBundle: (tenantId, key) => getFrontendBundle(options.store, tenantId, key),
        runBridgeMethod: (input) => runBridgeMethod({
            store: options.store,
            tenantId: options.tenantId(input),
            key: input.key,
            user: input.user,
            method: input.method,
            payload: input.payload,
            adapters: {
                ...options.runtime(input),
                capabilityKeys: options.capabilityKeys,
                userCan: (_user, permission) => input.userCan(permission),
            },
        }),
        async createAppScaffold(tenantId, actorId, name) {
            const app = await createAppScaffold({ store: options.store, tenantId, actorId, name, capabilityKeys: options.capabilityKeys });
            return { key: app.key };
        },
        updateAppMeta: (tenantId, actorId, key, update) => updateApp({ store: options.store, tenantId, actorId, key, update, capabilityKeys: options.capabilityKeys }),
        listAppFiles: (tenantId, key) => options.store.listFiles(tenantId, key),
        readAppFile: (tenantId, key, path) => options.store.readFile(tenantId, key, path),
        writeAppFile: (tenantId, actorId, key, path, content, isBinary = false) => options.store.writeFile(tenantId, actorId, key, { path, content, isBinary }),
        deleteAppFile: (tenantId, key, path) => options.store.deleteFile(tenantId, key, path),
        listListings: (input) => options.store.listListings(input),
        async isAppPublished(key) { return Boolean((await options.store.listListings({ query: key, page: 1, perPage: 100 })).listings.find((listing) => listing.key === key)); },
        async publishApp(tenantId, actorId, key) { return { id: (await options.store.publish(tenantId, actorId, key)).id }; },
        async installFromListing(tenantId, actorId, listingId) {
            const app = await installFromListing({ store: options.store, tenantId, actorId, listingId, capabilityKeys: options.capabilityKeys, provisioner: options.provisioner });
            return { key: app.key };
        },
    };
}
//# sourceMappingURL=service.js.map