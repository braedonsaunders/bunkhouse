import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import { type AppFile, type AppListing, type AppRun, type AppStore } from './index.js';
type Db = NodePgDatabase<Record<string, never>>;
export declare function createDrizzleAppStore(db: Db): AppStore;
export { apps, appVersions, appFiles, appStorage, appRuns, appListings, APP_TENANT_TABLES } from './schema.js';
export type { AppFile, AppRun, AppListing };
//# sourceMappingURL=drizzle.d.ts.map