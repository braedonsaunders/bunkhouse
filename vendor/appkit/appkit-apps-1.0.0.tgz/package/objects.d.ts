import type { AppBundleFile } from './bundle.js';
export interface AppObjectSpec {
    type: string;
    key: string;
    definition: Record<string, unknown>;
    sourcePath: string;
}
export interface ParsedAppObjects {
    objects: AppObjectSpec[];
    errors: string[];
}
/** Parse every objects/*.json declaration without imposing an application domain schema. */
export declare function parseAppObjects(files: AppBundleFile[]): ParsedAppObjects;
//# sourceMappingURL=objects.d.ts.map