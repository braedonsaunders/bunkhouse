export declare const SUPPORTED_LOCALES: readonly ["en", "fr", "es"];
export type AppLocale = (typeof SUPPORTED_LOCALES)[number];
export declare const DEFAULT_LOCALE: AppLocale;
export declare const LOCALE_OPTIONS: readonly [{
    readonly value: "en";
    readonly label: "English";
    readonly nativeLabel: "English";
}, {
    readonly value: "fr";
    readonly label: "French";
    readonly nativeLabel: "Français";
}, {
    readonly value: "es";
    readonly label: "Spanish";
    readonly nativeLabel: "Español";
}];
export declare function isAppLocale(value: unknown): value is AppLocale;
export declare function parseAppLocale(value: unknown): AppLocale | null;
/** Best-effort locale negotiation for unauthenticated/public requests. */
export declare function localeFromAcceptLanguage(header: string | null | undefined): AppLocale;
/**
 * Return a stable, de-duplicated supported-locale list. Unknown persisted values
 * are deliberately discarded so stale configuration can never reach Intl or a
 * message-catalogue import.
 */
export declare function normalizeEnabledLocales(values: readonly unknown[]): AppLocale[];
export declare function normalizeLocalePolicy(args: {
    defaultLocale: unknown;
    enabledLocales: readonly unknown[];
}): {
    defaultLocale: AppLocale;
    enabledLocales: AppLocale[];
};
/** Resolve `tenant-user override -> tenant default -> platform default`. */
export declare function resolveLocale(args: {
    defaultLocale: unknown;
    enabledLocales: readonly unknown[];
    userLocale?: unknown;
}): AppLocale;
/** Canonical locale state stored on request and worker contexts. */
export declare function resolveLocalePreferences(args: {
    defaultLocale: unknown;
    enabledLocales: readonly unknown[];
    userLocale?: unknown;
}): {
    locale: AppLocale;
    defaultLocale: AppLocale;
    enabledLocales: AppLocale[];
    localeOverride: AppLocale | null;
};
export type LocalizedText = Readonly<Partial<Record<AppLocale, string>>> & Readonly<Record<string, string | undefined>>;
/**
 * Resolve tenant-authored multilingual content without losing older English
 * content. The tenant default is preferred after the user's effective locale,
 * followed by English and finally the first non-empty supported translation.
 */
export declare function localizeText(value: LocalizedText | string | null | undefined, locale: AppLocale, fallback: string, tenantDefault?: AppLocale): string;
//# sourceMappingURL=index.d.ts.map