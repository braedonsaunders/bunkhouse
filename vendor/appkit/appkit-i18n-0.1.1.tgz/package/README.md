# @appkit/i18n

Tenant-aware locale policy and localized-content resolution for AppKit applications.

## Install

```bash
pnpm add @appkit/i18n
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
