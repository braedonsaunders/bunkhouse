/** Stable, browser-safe key shared by catalog extraction and runtime lookup. */
export declare function systemMessageKey(source: string): `m_${string}`;
//# sourceMappingURL=system-key.d.ts.map