export const SUPPORTED_LOCALES = ['en', 'fr', 'es'];
export const DEFAULT_LOCALE = 'en';
export const LOCALE_OPTIONS = [
    { value: 'en', label: 'English', nativeLabel: 'English' },
    { value: 'fr', label: 'French', nativeLabel: 'Français' },
    { value: 'es', label: 'Spanish', nativeLabel: 'Español' },
];
export function isAppLocale(value) {
    return typeof value === 'string' && SUPPORTED_LOCALES.includes(value);
}
export function parseAppLocale(value) {
    return isAppLocale(value) ? value : null;
}
/** Best-effort locale negotiation for unauthenticated/public requests. */
export function localeFromAcceptLanguage(header) {
    if (!header)
        return DEFAULT_LOCALE;
    const requested = header
        .split(',')
        .map((part) => {
        const [tag = '', ...parameters] = part.trim().split(';');
        const quality = parameters
            .map((parameter) => parameter.trim())
            .find((parameter) => parameter.startsWith('q='));
        const parsedQuality = quality ? Number(quality.slice(2)) : 1;
        return {
            locale: parseAppLocale(tag.toLowerCase().split('-')[0]),
            quality: Number.isFinite(parsedQuality) ? Math.max(0, Math.min(1, parsedQuality)) : 0,
        };
    })
        .filter((entry) => entry.locale !== null && entry.quality > 0)
        .sort((a, b) => b.quality - a.quality);
    return requested[0]?.locale ?? DEFAULT_LOCALE;
}
/**
 * Return a stable, de-duplicated supported-locale list. Unknown persisted values
 * are deliberately discarded so stale configuration can never reach Intl or a
 * message-catalogue import.
 */
export function normalizeEnabledLocales(values) {
    const selected = new Set(values.filter(isAppLocale));
    return SUPPORTED_LOCALES.filter((locale) => selected.has(locale));
}
export function normalizeLocalePolicy(args) {
    const requestedDefault = parseAppLocale(args.defaultLocale) ?? DEFAULT_LOCALE;
    const enabledLocales = normalizeEnabledLocales([...args.enabledLocales, requestedDefault]);
    return { defaultLocale: requestedDefault, enabledLocales };
}
/** Resolve `tenant-user override -> tenant default -> platform default`. */
export function resolveLocale(args) {
    const policy = normalizeLocalePolicy(args);
    const userLocale = parseAppLocale(args.userLocale);
    return userLocale && policy.enabledLocales.includes(userLocale)
        ? userLocale
        : policy.defaultLocale;
}
/** Canonical locale state stored on request and worker contexts. */
export function resolveLocalePreferences(args) {
    const policy = normalizeLocalePolicy(args);
    const requestedOverride = parseAppLocale(args.userLocale);
    const localeOverride = requestedOverride && policy.enabledLocales.includes(requestedOverride)
        ? requestedOverride
        : null;
    return {
        ...policy,
        locale: localeOverride ?? policy.defaultLocale,
        localeOverride,
    };
}
/**
 * Resolve tenant-authored multilingual content without losing older English
 * content. The tenant default is preferred after the user's effective locale,
 * followed by English and finally the first non-empty supported translation.
 */
export function localizeText(value, locale, fallback, tenantDefault = DEFAULT_LOCALE) {
    if (typeof value === 'string')
        return value.trim() || fallback;
    if (!value)
        return fallback;
    const candidates = [locale, tenantDefault, DEFAULT_LOCALE, ...SUPPORTED_LOCALES];
    for (const candidate of candidates) {
        const translated = value[candidate];
        if (typeof translated === 'string' && translated.trim())
            return translated;
    }
    return fallback;
}
//# sourceMappingURL=index.js.map