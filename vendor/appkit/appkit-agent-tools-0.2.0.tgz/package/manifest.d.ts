import { z } from 'zod';
/**
 * How much damage a tool can do if it misbehaves. This drives the `allow_safe`
 * policy mode and nothing else — it is a statement about the tool, not about
 * any particular invocation of it.
 */
export type AgentToolRisk = 'low' | 'medium' | 'high';
/**
 * Where the executable comes from.
 *
 * - `npm-package` — a version-pinned package installed into a directory this
 *   package owns, so a tool can be added without rebuilding the image.
 * - `binary-path` — an executable already present in the image, named so it can
 *   be catalogued, health-checked, and governed like any other tool.
 * - `apt-package` — a Debian package baked into the golden base image at an
 *   exact pinned version. The image build installs it; the runtime never does.
 *   The manifest is the declaration of what the image contains.
 */
export type AgentToolSourceKind = 'npm-package' | 'binary-path' | 'apt-package';
/**
 * What an approved execution covers.
 *
 * - `exact-argv` (default) — the grant covers precisely the argument vector that
 *   was approved. Anything else asks again.
 * - `command` — the grant covers the named command with any arguments. Only
 *   appropriate for tools whose every invocation is equally safe.
 */
export type AgentToolApprovalScope = 'exact-argv' | 'command';
export declare const AGENT_TOOL_RISKS: readonly AgentToolRisk[];
export declare const agentToolBinarySchema: z.ZodObject<{
    name: z.ZodString;
    bin: z.ZodString;
    versionArgs: z.ZodOptional<z.ZodArray<z.ZodString>>;
    healthCheckArgs: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export declare const agentToolLimitsSchema: z.ZodObject<{
    cpuSeconds: z.ZodOptional<z.ZodNumber>;
    addressSpaceBytes: z.ZodOptional<z.ZodNumber>;
    fileSizeBytes: z.ZodOptional<z.ZodNumber>;
    processes: z.ZodOptional<z.ZodNumber>;
    openFiles: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export declare const agentToolManifestSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    description: z.ZodString;
    sourceKind: z.ZodEnum<{
        "npm-package": "npm-package";
        "binary-path": "binary-path";
        "apt-package": "apt-package";
    }>;
    risk: z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
    }>;
    packageName: z.ZodOptional<z.ZodString>;
    packageVersion: z.ZodOptional<z.ZodString>;
    binaryPath: z.ZodOptional<z.ZodString>;
    aptPackage: z.ZodOptional<z.ZodString>;
    aptVersion: z.ZodOptional<z.ZodString>;
    docsUrl: z.ZodOptional<z.ZodString>;
    capabilities: z.ZodDefault<z.ZodArray<z.ZodString>>;
    bins: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        bin: z.ZodString;
        versionArgs: z.ZodOptional<z.ZodArray<z.ZodString>>;
        healthCheckArgs: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    requiresNetwork: z.ZodDefault<z.ZodBoolean>;
    approvalScope: z.ZodDefault<z.ZodEnum<{
        "exact-argv": "exact-argv";
        command: "command";
    }>>;
    limits: z.ZodOptional<z.ZodObject<{
        cpuSeconds: z.ZodOptional<z.ZodNumber>;
        addressSpaceBytes: z.ZodOptional<z.ZodNumber>;
        fileSizeBytes: z.ZodOptional<z.ZodNumber>;
        processes: z.ZodOptional<z.ZodNumber>;
        openFiles: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    defaultTimeoutMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type AgentToolBinary = z.infer<typeof agentToolBinarySchema>;
export type AgentToolLimits = z.infer<typeof agentToolLimitsSchema>;
export type AgentToolManifest = z.infer<typeof agentToolManifestSchema>;
/** A manifest as an author writes it, before defaults are applied. */
export type AgentToolManifestInput = z.input<typeof agentToolManifestSchema>;
export declare class AgentToolError extends Error {
    readonly name = "AgentToolError";
}
/** Validate and normalize a manifest, applying declared defaults. */
export declare function defineAgentTool(manifest: AgentToolManifestInput): AgentToolManifest;
/**
 * Whether a tool is safe enough for the `allow_safe` policy mode: low risk and
 * unable to reach the network while it runs. A low-risk tool that phones out is
 * still a tool that phones out, so it does not qualify.
 */
export declare function isSafeAgentTool(manifest: AgentToolManifest): boolean;
/** The command names a manifest declares. */
export declare function agentToolCommands(manifest: AgentToolManifest): string[];
//# sourceMappingURL=manifest.d.ts.map