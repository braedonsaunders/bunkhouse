import { type AgentToolManifest } from './manifest.js';
/**
 * One package the base image must contain, traced back to the tool that
 * declared it so a conflict or a removal can be attributed.
 */
export interface ImageManifestPackage {
    name: string;
    version: string;
    toolId: string;
}
/**
 * Everything a golden base image must contain to satisfy a set of tool
 * manifests. Plain JSON-able data, deterministically ordered, so two builds
 * from the same shelf produce byte-identical input regardless of the order
 * the manifests arrived in.
 */
export interface ImageManifest {
    aptPackages: ImageManifestPackage[];
    npmPackages: ImageManifestPackage[];
    binaryPaths: string[];
}
/**
 * Fold a set of tool manifests into base-image build input.
 *
 * Two tools may pin the same package at the same version — the image only
 * contains it once, attributed to the lexicographically-first tool id so
 * attribution is order-independent. Two tools pinning the same package at
 * *different* versions is a contradiction the image cannot satisfy, so it
 * throws rather than letting one pin silently win.
 */
export declare function imageManifest(tools: readonly AgentToolManifest[]): ImageManifest;
/**
 * The `apt-get install` fragment for a Dockerfile `RUN` or an mmdebstrap
 * hook: every apt-pinned tool, exactly versioned, sorted one per line so the
 * fragment diffs cleanly between image builds. Empty when no tool needs apt.
 */
export declare function renderAptInstallFragment(tools: readonly AgentToolManifest[]): string;
//# sourceMappingURL=image-manifest.d.ts.map