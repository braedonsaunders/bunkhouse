import type { AttachedFile, AttachmentAdapter, AttachmentTarget } from './attachments.js';
export interface MemoryAttachmentSeed {
    target: AttachmentTarget;
    attachment: AttachedFile;
    url: string;
}
export interface MemoryAttachmentAdapterOptions {
    seed?: MemoryAttachmentSeed[];
    createId?: () => string;
    now?: () => Date;
    createdBy?: string | null;
    createObjectUrl?: (file: File) => string;
    revokeObjectUrl?: (url: string) => void;
}
/** Fully functional, database-free adapter for demos, tests, and local tools. */
export declare function createMemoryAttachmentAdapter({ seed, createId, now, createdBy, createObjectUrl, revokeObjectUrl, }?: MemoryAttachmentAdapterOptions): AttachmentAdapter;
//# sourceMappingURL=attachments-memory.d.ts.map