export interface AttachmentTarget {
    targetTable: string;
    targetId: string;
}
/** File metadata retained from the production attachment workspace contract. */
export interface AttachedFile {
    id: string;
    name: string;
    fileType: string;
    contentType: string;
    sizeBytes: number;
    createdAt: string;
    createdBy: string | null;
    attachmentId: string;
}
export type AttachmentUrlIntent = 'download' | 'open' | 'preview';
/**
 * Host boundary for the attachment workspace. Applications keep ownership of
 * authorization, tenancy, persistence, object storage, and signed URL policy.
 */
export interface AttachmentAdapter {
    list: (target: AttachmentTarget, signal?: AbortSignal) => Promise<AttachedFile[]>;
    upload: (target: AttachmentTarget, file: File) => Promise<AttachedFile>;
    remove: (target: AttachmentTarget, attachment: AttachedFile) => Promise<void>;
    url: (attachment: AttachedFile, intent: AttachmentUrlIntent) => string;
    dispose?: () => void;
}
export type AttachmentGroup = 'pdf' | 'image' | 'other';
export declare function attachmentGroup(file: Pick<AttachedFile, 'contentType'>): AttachmentGroup;
export declare function isPreviewableAttachment(file: Pick<AttachedFile, 'contentType'>): boolean;
export declare function formatAttachmentSize(bytes: number): string;
export declare class AttachmentRequestError extends Error {
    readonly status: number;
    readonly code?: string;
    constructor(message: string, status: number, code?: string);
}
export interface HttpAttachmentAdapterOptions {
    /** Collection endpoint implementing GET + POST and DELETE /:attachmentId. */
    collectionUrl: string;
    /** Resolve the authenticated or signed file URL for preview/download. */
    fileUrl: (attachment: AttachedFile, intent: AttachmentUrlIntent) => string;
    fetcher?: typeof fetch;
    removeUrl?: (attachment: AttachedFile) => string;
}
/**
 * HTTP adapter matching the extracted production route contract:
 * GET `{ attachments }`, POST multipart `{ attachment }`, DELETE by link id.
 */
export declare function createHttpAttachmentAdapter({ collectionUrl, fileUrl, fetcher, removeUrl, }: HttpAttachmentAdapterOptions): AttachmentAdapter;
//# sourceMappingURL=attachments.d.ts.map