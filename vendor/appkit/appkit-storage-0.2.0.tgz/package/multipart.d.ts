export declare const MULTIPART_UPLOAD_THRESHOLD_BYTES: number;
export declare const MULTIPART_UPLOAD_PART_SIZE_BYTES: number;
export declare function shouldUseMultipartUpload(sizeBytes: number): boolean;
export declare function multipartPartCount(sizeBytes: number, partSizeBytes?: number): number;
//# sourceMappingURL=multipart.d.ts.map