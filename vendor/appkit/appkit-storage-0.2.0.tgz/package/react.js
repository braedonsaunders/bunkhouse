export { AttachmentPanel, DEFAULT_ATTACHMENT_ACCEPT, DEFAULT_ATTACHMENT_MAX_BYTES, DEFAULT_ATTACHMENT_PAGE_SIZE, } from './attachment-panel.js';
//# sourceMappingURL=react.js.map