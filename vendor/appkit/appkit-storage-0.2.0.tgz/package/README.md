# @appkit/storage

Tenant-safe S3-compatible storage with multipart upload, streaming, ranges, promotion, lifecycle policy, and presigned access.

## Install

```bash
pnpm add @appkit/storage
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
