// S3-compatible object storage (Cloudflare R2 in prod, MinIO in dev, or AWS).
// Same code path either way — only the endpoint and credentials change.
import { AbortMultipartUploadCommand, CompleteMultipartUploadCommand, CopyObjectCommand, CreateBucketCommand, CreateMultipartUploadCommand, DeleteBucketPolicyCommand, DeleteObjectCommand, GetBucketLifecycleConfigurationCommand, GetObjectCommand, HeadBucketCommand, HeadObjectCommand, ListPartsCommand, PutObjectCommand, PutBucketLifecycleConfigurationCommand, S3Client, UploadPartCommand, } from '@aws-sdk/client-s3';
import { randomUUID } from 'node:crypto';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { storageObjectTagging, withManagedStorageLifecycleRules } from './lifecycle.js';
import { MULTIPART_UPLOAD_PART_SIZE_BYTES, multipartPartCount, shouldUseMultipartUpload } from './multipart.js';
export * from './keys.js';
export * from './lifecycle.js';
export * from './multipart.js';
export * from './attachments.js';
export function createStorage(config) {
    let endpoint;
    try {
        endpoint = new URL(config.endpoint);
    }
    catch {
        throw new Error('Storage endpoint must be an absolute HTTP(S) URL');
    }
    if (!['http:', 'https:'].includes(endpoint.protocol) || endpoint.username || endpoint.password)
        throw new Error('Storage endpoint must be an absolute HTTP(S) URL without credentials');
    const client = config.client ?? new S3Client({
        region: config.region ?? 'auto',
        endpoint: config.endpoint,
        forcePathStyle: config.forcePathStyle ?? true,
        credentials: { accessKeyId: config.accessKeyId, secretAccessKey: config.secretAccessKey },
    });
    const Bucket = config.bucket;
    const stateTagKey = config.stateTagKey ?? 'appkit-state';
    async function put(input) {
        if (typeof input.body !== 'string' && shouldUseMultipartUpload(input.body.byteLength)) {
            const uploadId = await createMultipartUpload({
                key: input.key,
                contentType: input.contentType ?? 'application/octet-stream',
                contentDisposition: input.contentDisposition,
                lifecycle: input.lifecycle,
            });
            try {
                const parts = [];
                const count = multipartPartCount(input.body.byteLength);
                for (let partNumber = 1; partNumber <= count; partNumber += 1) {
                    const offset = (partNumber - 1) * MULTIPART_UPLOAD_PART_SIZE_BYTES;
                    const result = await client.send(new UploadPartCommand({ Bucket, Key: input.key, UploadId: uploadId, PartNumber: partNumber, Body: input.body.subarray(offset, Math.min(offset + MULTIPART_UPLOAD_PART_SIZE_BYTES, input.body.byteLength)) }));
                    if (!result.ETag)
                        throw new Error(`Storage did not confirm multipart part ${partNumber}`);
                    parts.push({ ETag: result.ETag, PartNumber: partNumber });
                }
                await client.send(new CompleteMultipartUploadCommand({ Bucket, Key: input.key, UploadId: uploadId, MultipartUpload: { Parts: parts } }));
            }
            catch (error) {
                try {
                    await abortMultipartUpload(input.key, uploadId);
                }
                catch (cleanupError) {
                    throw new AggregateError([error, cleanupError], 'Multipart upload and abort both failed');
                }
                throw error;
            }
            return;
        }
        await client.send(new PutObjectCommand({
            Bucket,
            Key: input.key,
            Body: input.body,
            ContentType: input.contentType,
            ContentDisposition: input.contentDisposition ?? 'attachment',
            Metadata: input.metadata,
            Tagging: input.tagging ?? storageObjectTagging(input.lifecycle, stateTagKey),
        }));
    }
    async function getBytes(key) {
        const res = await client.send(new GetObjectCommand({ Bucket, Key: key }));
        if (!res.Body)
            throw new Error(`Object ${key} has no body`);
        return await res.Body.transformToByteArray();
    }
    async function del(key) {
        await client.send(new DeleteObjectCommand({ Bucket, Key: key }));
    }
    async function head(key) {
        const metadata = await headObject(key);
        return metadata ? { size: metadata.contentLength, ...(metadata.contentType ? { contentType: metadata.contentType } : {}) } : null;
    }
    async function headObject(key) {
        try {
            const res = await client.send(new HeadObjectCommand({ Bucket, Key: key }));
            return { contentLength: res.ContentLength ?? 0, contentType: res.ContentType ?? null, contentDisposition: res.ContentDisposition ?? null, metadata: res.Metadata ?? {}, etag: res.ETag ?? null };
        }
        catch (error) {
            const status = error.$metadata?.httpStatusCode;
            const name = error.name;
            if (status === 404 || name === 'NotFound' || name === 'NoSuchKey')
                return null;
            throw error;
        }
    }
    async function exists(key) { return (await headObject(key)) !== null; }
    async function getRange(key, start, end, ifMatch) {
        if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end < start)
            throw new Error('Invalid object byte range');
        const result = await client.send(new GetObjectCommand({ Bucket, Key: key, Range: `bytes=${start}-${end}`, IfMatch: ifMatch }));
        if (!result.Body)
            throw new Error(`Object ${key} has no body`);
        return result.Body.transformToByteArray();
    }
    async function getStream(key) {
        const result = await client.send(new GetObjectCommand({ Bucket, Key: key }));
        if (!result.Body)
            throw new Error(`Object ${key} has no body`);
        return { stream: result.Body.transformToWebStream(), ...(result.ContentLength === undefined ? {} : { contentLength: result.ContentLength }), ...(result.ContentType === undefined ? {} : { contentType: result.ContentType }) };
    }
    function presignPut(key, opts) {
        return getSignedUrl(client, new PutObjectCommand({ Bucket, Key: key, ContentType: opts?.contentType, Metadata: opts?.metadata, Tagging: opts?.tagging }), { expiresIn: opts?.expiresIn ?? 900 });
    }
    function presignGet(key, opts) {
        return getSignedUrl(client, new GetObjectCommand({ Bucket, Key: key }), {
            expiresIn: opts?.expiresIn ?? 900,
        });
    }
    async function presignExistingGet(key, opts) {
        return (await exists(key)) ? presignGet(key, opts) : null;
    }
    async function createMultipartUpload(input) {
        const result = await client.send(new CreateMultipartUploadCommand({ Bucket, Key: input.key, ContentType: input.contentType, ContentDisposition: input.contentDisposition ?? 'attachment', Metadata: input.uploadToken ? { 'upload-token': input.uploadToken } : undefined, Tagging: input.tagging ?? (input.uploadToken ? `${stateTagKey}=pending` : storageObjectTagging(input.lifecycle, stateTagKey)) }));
        if (!result.UploadId)
            throw new Error('Storage did not create a multipart upload');
        return result.UploadId;
    }
    function presignMultipartPart(key, uploadId, partNumber, expiresIn = 3_600) {
        if (!Number.isInteger(partNumber) || partNumber < 1 || partNumber > 10_000)
            throw new Error('Multipart part number must be between 1 and 10000');
        return getSignedUrl(client, new UploadPartCommand({ Bucket, Key: key, UploadId: uploadId, PartNumber: partNumber }), { expiresIn });
    }
    async function completeMultipartUpload(key, uploadId) {
        const parts = [];
        let marker;
        do {
            const page = await client.send(new ListPartsCommand({ Bucket, Key: key, UploadId: uploadId, PartNumberMarker: marker }));
            for (const part of page.Parts ?? []) {
                if (!part.ETag || !part.PartNumber)
                    throw new Error('Storage returned an incomplete multipart part record');
                parts.push({ ETag: part.ETag, PartNumber: part.PartNumber });
            }
            marker = page.IsTruncated ? page.NextPartNumberMarker : undefined;
        } while (marker);
        if (!parts.length)
            throw new Error('Multipart upload contains no parts');
        parts.sort((left, right) => left.PartNumber - right.PartNumber);
        await client.send(new CompleteMultipartUploadCommand({ Bucket, Key: key, UploadId: uploadId, MultipartUpload: { Parts: parts } }));
    }
    async function abortMultipartUpload(key, uploadId) {
        await client.send(new AbortMultipartUploadCommand({ Bucket, Key: key, UploadId: uploadId }));
    }
    async function promote(input) {
        if (!input.sourceEtag.trim())
            throw new Error('Verified source ETag is required');
        const source = `${Bucket}/${input.sourceKey}`.split('/').map(encodeURIComponent).join('/');
        await client.send(new CopyObjectCommand({ Bucket, Key: input.destinationKey, CopySource: source, CopySourceIfMatch: input.sourceEtag, ContentType: input.contentType, ContentDisposition: input.contentDisposition, MetadataDirective: 'REPLACE', Metadata: {}, TaggingDirective: 'REPLACE', Tagging: '' }));
    }
    function missingBucket(error) {
        const value = error;
        return value.$metadata?.httpStatusCode === 404 || ['NotFound', 'NoSuchBucket'].includes(value.name ?? value.code ?? value.Code ?? '');
    }
    function missingPolicy(error) {
        const value = error;
        return value.$metadata?.httpStatusCode === 404 || ['NoSuchBucketPolicy', 'NoSuchLifecycleConfiguration', 'NoSuchPolicy', 'NotFound'].includes(value.name ?? value.code ?? value.Code ?? '');
    }
    async function ensureReady() {
        try {
            await client.send(new HeadBucketCommand({ Bucket }));
        }
        catch (error) {
            if (!missingBucket(error))
                throw error;
            await client.send(new CreateBucketCommand({ Bucket }));
        }
        const hostname = endpoint.hostname.toLowerCase();
        const r2 = hostname === 'r2.cloudflarestorage.com' || hostname.endsWith('.r2.cloudflarestorage.com');
        if (r2) {
            if (config.privateBucketConfirmed !== true)
                throw new Error('privateBucketConfirmed=true is required after disabling every R2 public development URL and custom domain');
        }
        else {
            try {
                await client.send(new DeleteBucketPolicyCommand({ Bucket }));
            }
            catch (error) {
                if (!missingPolicy(error))
                    throw error;
            }
        }
        let existing = [];
        try {
            existing = (await client.send(new GetBucketLifecycleConfigurationCommand({ Bucket }))).Rules ?? [];
        }
        catch (error) {
            if (!missingPolicy(error))
                throw error;
        }
        await client.send(new PutBucketLifecycleConfigurationCommand({ Bucket, LifecycleConfiguration: { Rules: withManagedStorageLifecycleRules(existing, stateTagKey) } }));
        const probeKey = `_privacy-probe/${randomUUID()}`;
        await put({ key: probeKey, body: new Uint8Array([1]), contentType: 'application/octet-stream' });
        try {
            const base = config.endpoint.replace(/\/$/, '');
            const encodedKey = probeKey.split('/').map(encodeURIComponent).join('/');
            const response = await fetch(`${base}/${encodeURIComponent(Bucket)}/${encodedKey}`, { method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(15_000) });
            try {
                if (response.status >= 200 && response.status < 400)
                    throw new Error(`Storage privacy verification failed: anonymous read returned HTTP ${response.status}`);
            }
            finally {
                await response.body?.cancel();
            }
        }
        finally {
            await del(probeKey);
        }
    }
    return { bucket: Bucket, client, put, getBytes, delete: del, head, headObject, exists, getRange, getStream, presignPut, presignGet, presignExistingGet, createMultipartUpload, presignMultipartPart, completeMultipartUpload, abortMultipartUpload, promote, ensureReady };
}
//# sourceMappingURL=index.js.map