import * as React from 'react';
import { type AttachmentAdapter } from './attachments.js';
export declare const DEFAULT_ATTACHMENT_MAX_BYTES: number;
export declare const DEFAULT_ATTACHMENT_PAGE_SIZE = 12;
export declare const DEFAULT_ATTACHMENT_ACCEPT: string;
export interface AttachmentPanelLabels {
    title: string;
    fileCount: (count: number) => string;
    addFiles: string;
    searchPlaceholder: string;
    searchLabel: string;
    typeFilter: string;
    allTypes: string;
    types: Record<'pdf' | 'image' | 'other', string>;
    loading: string;
    empty: string;
    noMatches: string;
    tooLarge: (name: string, maximum: string) => string;
    attached: (name: string) => string;
    attachFailed: (name: string) => string;
    removed: (name: string) => string;
    removeFailed: (name: string) => string;
    downloadAria: (name: string) => string;
    removeAria: (name: string) => string;
    uploading: (count: number) => string;
    dropShort: string;
    openAria: (name: string) => string;
    restorePreviewAria: string;
    expandPreviewAria: string;
    previewTitle: (name: string) => string;
    previewEmptyTitle: string;
    previewUnavailable: string;
    previewEmptyDescription: string;
}
export type AttachmentPanelFeedback = (event: {
    tone: 'success' | 'error';
    message: string;
    error?: unknown;
}) => void;
export interface AttachmentPanelProps {
    targetTable: string;
    targetId: string;
    canEdit: boolean;
    adapter: AttachmentAdapter;
    labels?: Partial<Omit<AttachmentPanelLabels, 'types'>> & {
        types?: Partial<AttachmentPanelLabels['types']>;
    };
    maxBytes?: number;
    pageSize?: number;
    accept?: string;
    /** Prefix for URL-backed search, type, and page parameters. Defaults to `att`. */
    paramPrefix?: string;
    locale?: string;
    initialSelectedId?: string | null;
    feedback?: AttachmentPanelFeedback;
    className?: string;
}
/**
 * The complete production attachment workspace: upload, URL-backed search and
 * type filters, paging, preview, download, expansion, and removal. Host apps
 * inject the tenant/authorization-aware storage adapter.
 */
export declare function AttachmentPanel({ targetTable, targetId, canEdit, adapter, labels: labelOverrides, maxBytes, pageSize, accept, paramPrefix, locale, initialSelectedId, feedback, className, }: AttachmentPanelProps): React.JSX.Element;
//# sourceMappingURL=attachment-panel.d.ts.map