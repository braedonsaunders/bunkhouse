/** Fully functional, database-free adapter for demos, tests, and local tools. */
export function createMemoryAttachmentAdapter({ seed = [], createId = defaultId, now = () => new Date(), createdBy = null, createObjectUrl = (file) => URL.createObjectURL(file), revokeObjectUrl = (url) => URL.revokeObjectURL(url), } = {}) {
    const records = new Map();
    for (const entry of seed) {
        const key = targetKey(entry.target);
        records.set(key, [...(records.get(key) ?? []), { attachment: { ...entry.attachment }, url: entry.url, owned: false }]);
    }
    const adapter = {
        async list(target) {
            return (records.get(targetKey(target)) ?? []).map((entry) => ({ ...entry.attachment }));
        },
        async upload(target, file) {
            const id = createId();
            const attachment = {
                id,
                attachmentId: `attachment:${id}`,
                name: file.name,
                fileType: file.name.includes('.') ? file.name.split('.').pop() ?? '' : '',
                contentType: file.type || 'application/octet-stream',
                sizeBytes: file.size,
                createdAt: now().toISOString(),
                createdBy,
            };
            const key = targetKey(target);
            records.set(key, [
                { attachment, url: createObjectUrl(file), owned: true },
                ...(records.get(key) ?? []),
            ]);
            return { ...attachment };
        },
        async remove(target, attachment) {
            const key = targetKey(target);
            const entries = records.get(key) ?? [];
            const removed = entries.find((entry) => entry.attachment.attachmentId === attachment.attachmentId);
            if (removed?.owned)
                revokeObjectUrl(removed.url);
            records.set(key, entries.filter((entry) => entry.attachment.attachmentId !== attachment.attachmentId));
        },
        url(attachment, _intent) {
            for (const entries of records.values()) {
                const match = entries.find((entry) => entry.attachment.id === attachment.id);
                if (match)
                    return match.url;
            }
            return '';
        },
        dispose() {
            for (const entries of records.values()) {
                for (const entry of entries)
                    if (entry.owned)
                        revokeObjectUrl(entry.url);
            }
            records.clear();
        },
    };
    return adapter;
}
function targetKey(target) {
    return `${target.targetTable}\u0000${target.targetId}`;
}
function defaultId() {
    return globalThis.crypto.randomUUID();
}
//# sourceMappingURL=attachments-memory.js.map