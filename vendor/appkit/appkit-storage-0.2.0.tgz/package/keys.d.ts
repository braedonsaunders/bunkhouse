export declare function assertTenantObjectKey(args: {
    tenantId: string;
    key: string;
}): void;
export declare function assertTenantBrandingObjectKey(args: {
    tenantId: string;
    key: string;
}): void;
/** Branding-specific alias for logo upload adapters. */
export declare const assertTenantLogoObjectKey: typeof assertTenantBrandingObjectKey;
export declare function newTenantObjectKey(args: {
    tenantId: string;
    scope: string;
    filename: string;
}): string;
export declare function newAttachmentKey(args: {
    tenantId: string;
    kind: 'image' | 'document' | 'video' | 'audio' | 'signature' | 'other';
    filename: string;
}): string;
export declare function newPendingUploadKey(args: {
    tenantId: string;
    uploadId: string;
}): string;
export declare function objectKeyFromStorageUrl(args: {
    url: string;
    endpoint: string;
    bucket: string;
}): string | null;
//# sourceMappingURL=keys.d.ts.map