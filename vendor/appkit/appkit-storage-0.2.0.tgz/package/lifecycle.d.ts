import type { LifecycleRule } from '@aws-sdk/client-s3';
export type StorageObjectLifecycle = 'durable' | 'transient';
export declare function storageObjectTagging(lifecycle: StorageObjectLifecycle | undefined, stateTagKey?: string): string | undefined;
export declare function withManagedStorageLifecycleRules(existingRules: readonly LifecycleRule[], stateTagKey?: string): LifecycleRule[];
//# sourceMappingURL=lifecycle.d.ts.map