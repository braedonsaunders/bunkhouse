export function attachmentGroup(file) {
    if (file.contentType === 'application/pdf')
        return 'pdf';
    if (file.contentType.startsWith('image/'))
        return 'image';
    return 'other';
}
export function isPreviewableAttachment(file) {
    return attachmentGroup(file) !== 'other';
}
export function formatAttachmentSize(bytes) {
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
export class AttachmentRequestError extends Error {
    status;
    code;
    constructor(message, status, code) {
        super(message);
        this.name = 'AttachmentRequestError';
        this.status = status;
        this.code = code;
    }
}
/**
 * HTTP adapter matching the extracted production route contract:
 * GET `{ attachments }`, POST multipart `{ attachment }`, DELETE by link id.
 */
export function createHttpAttachmentAdapter({ collectionUrl, fileUrl, fetcher = fetch, removeUrl = (attachment) => `${collectionUrl}/${encodeURIComponent(attachment.attachmentId)}`, }) {
    return {
        async list(target, signal) {
            const url = new URL(collectionUrl, 'http://appkit.local');
            url.searchParams.set('targetTable', target.targetTable);
            url.searchParams.set('targetId', target.targetId);
            const response = await fetcher(toRequestUrl(url, collectionUrl), { signal });
            const body = await readJson(response);
            if (!response.ok)
                throw requestError(response, body, 'Unable to load attachments');
            if (!isRecord(body) || !Array.isArray(body.attachments)) {
                throw new AttachmentRequestError('Attachment response is invalid', response.status);
            }
            return body.attachments;
        },
        async upload(target, file) {
            const form = new FormData();
            form.append('file', file);
            form.append('targetTable', target.targetTable);
            form.append('targetId', target.targetId);
            const response = await fetcher(collectionUrl, { method: 'POST', body: form });
            const body = await readJson(response);
            if (!response.ok)
                throw requestError(response, body, `Unable to attach ${file.name}`);
            if (!isRecord(body) || !isRecord(body.attachment)) {
                throw new AttachmentRequestError('Attachment response is invalid', response.status);
            }
            return body.attachment;
        },
        async remove(_target, attachment) {
            const response = await fetcher(removeUrl(attachment), { method: 'DELETE' });
            const body = await readJson(response);
            if (!response.ok)
                throw requestError(response, body, `Unable to remove ${attachment.name}`);
        },
        url: fileUrl,
    };
}
function toRequestUrl(url, original) {
    return /^https?:\/\//.test(original) ? url.toString() : `${url.pathname}${url.search}`;
}
async function readJson(response) {
    const contentType = response.headers.get('content-type') ?? '';
    if (!contentType.includes('json'))
        return null;
    return response.json().catch((error) => {
        throw new AttachmentRequestError(error instanceof Error ? error.message : 'Attachment response could not be read', response.status);
    });
}
function requestError(response, body, fallback) {
    const record = isRecord(body) ? body : null;
    const message = typeof record?.error === 'string' ? record.error : fallback;
    const code = typeof record?.code === 'string' ? record.code : undefined;
    return new AttachmentRequestError(message, response.status, code);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
//# sourceMappingURL=attachments.js.map