import { type Storage, type StorageConfig } from './index.js';
export type StorageEnvironment = Readonly<Partial<Record<'APPKIT_STORAGE_ENDPOINT' | 'APPKIT_STORAGE_ACCESS_KEY_ID' | 'APPKIT_STORAGE_SECRET_ACCESS_KEY' | 'APPKIT_STORAGE_BUCKET' | 'APPKIT_STORAGE_REGION' | 'APPKIT_STORAGE_FORCE_PATH_STYLE' | 'APPKIT_STORAGE_PRIVATE_BUCKET_CONFIRMED' | 'APPKIT_STORAGE_STATE_TAG_KEY', string>>>;
/**
 * Create the full storage runtime from a portable AppKit environment contract.
 * Applications that use another configuration system should call createStorage directly.
 */
export declare function createStorageFromEnv(environment?: StorageEnvironment, overrides?: Pick<StorageConfig, 'client'>): Storage;
//# sourceMappingURL=env.d.ts.map