import { S3Client } from '@aws-sdk/client-s3';
import { type StorageObjectLifecycle } from './lifecycle.js';
export * from './keys.js';
export * from './lifecycle.js';
export * from './multipart.js';
export * from './attachments.js';
export type StorageConfig = {
    /** e.g. http://localhost:9000 (MinIO) or https://{account}.r2.cloudflarestorage.com */
    endpoint: string;
    accessKeyId: string;
    secretAccessKey: string;
    bucket: string;
    region?: string;
    /** Path-style addressing (required for MinIO/R2). Default true. */
    forcePathStyle?: boolean;
    /** Required for Cloudflare R2 after public development/custom domains are disabled. */
    privateBucketConfirmed?: boolean;
    /** Existing client for custom middleware, tracing, or deterministic tests. */
    client?: S3Client;
    /** Object tag key used by pending/transient lifecycle rules. */
    stateTagKey?: string;
};
export type PutObjectInput = {
    key: string;
    body: Uint8Array | Buffer | string;
    contentType?: string;
    metadata?: Record<string, string>;
    contentDisposition?: 'inline' | 'attachment';
    lifecycle?: StorageObjectLifecycle;
    tagging?: string;
};
export type StoredObjectMetadata = {
    contentLength: number;
    contentType: string | null;
    contentDisposition: string | null;
    metadata: Readonly<Record<string, string>>;
    etag: string | null;
};
export type Storage = {
    bucket: string;
    client: S3Client;
    put: (input: PutObjectInput) => Promise<void>;
    /** Fetch an object's bytes. */
    getBytes: (key: string) => Promise<Uint8Array>;
    delete: (key: string) => Promise<void>;
    /** Object metadata; null if it doesn't exist. */
    head: (key: string) => Promise<{
        size: number;
        contentType?: string;
    } | null>;
    headObject: (key: string) => Promise<StoredObjectMetadata | null>;
    exists: (key: string) => Promise<boolean>;
    getRange: (key: string, start: number, end: number, ifMatch?: string) => Promise<Uint8Array>;
    getStream: (key: string) => Promise<{
        stream: ReadableStream;
        contentLength?: number;
        contentType?: string;
    }>;
    /** A presigned URL to upload directly (PUT). */
    presignPut: (key: string, opts?: {
        expiresIn?: number;
        contentType?: string;
        metadata?: Record<string, string>;
        tagging?: string;
    }) => Promise<string>;
    /** A presigned URL to download directly (GET). */
    presignGet: (key: string, opts?: {
        expiresIn?: number;
    }) => Promise<string>;
    presignExistingGet: (key: string, opts?: {
        expiresIn?: number;
    }) => Promise<string | null>;
    createMultipartUpload: (input: {
        key: string;
        contentType: string;
        contentDisposition?: 'inline' | 'attachment';
        uploadToken?: string;
        lifecycle?: StorageObjectLifecycle;
        tagging?: string;
    }) => Promise<string>;
    presignMultipartPart: (key: string, uploadId: string, partNumber: number, expiresIn?: number) => Promise<string>;
    completeMultipartUpload: (key: string, uploadId: string) => Promise<void>;
    abortMultipartUpload: (key: string, uploadId: string) => Promise<void>;
    promote: (input: {
        sourceKey: string;
        sourceEtag: string;
        destinationKey: string;
        contentType: string;
        contentDisposition: 'inline' | 'attachment';
    }) => Promise<void>;
    /** Idempotently create the bucket, remove anonymous policy, install lifecycle rules, and prove private reads. */
    ensureReady: () => Promise<void>;
};
export declare function createStorage(config: StorageConfig): Storage;
//# sourceMappingURL=index.d.ts.map