import { type SmsProvider } from './providers.js';
/** Unseal a stored secret → plaintext. Supplied by the app (e.g. @appkit/crypto). */
export type Unseal = (sealed: {
    ciphertext: string;
    nonce: string;
}) => string | null;
export type SendSmsInput = {
    /** Destination phone number, E.164 (e.g. +15551234567). */
    to: string;
    body: string;
    /** Override the configured sender (phone number / sender ID). */
    from?: string;
};
export type RawSmsConfig = {
    enabled?: boolean;
    provider?: SmsProvider;
    /** Universal sender — a phone number (E.164) or alphanumeric sender ID. */
    fromNumber?: string;
    twilioAccountSid?: string;
    vonageApiKey?: string;
    plivoAuthId?: string;
    telnyxMessagingProfileId?: string;
    keyCiphertext?: string;
    keyNonce?: string;
};
export type SmsPolicyMode = 'tenant_optional' | 'global_only' | 'disabled';
export declare function isSmsPolicyMode(value: unknown): value is SmsPolicyMode;
export type PlatformSmsConfig = RawSmsConfig & {
    mode?: SmsPolicyMode;
};
export type PlainSmsConfig = Omit<RawSmsConfig, 'keyCiphertext' | 'keyNonce'> & {
    secret?: string;
};
/** Strict E.164 validation used for every outbound destination. */
export declare function isValidSmsDestination(value: string): boolean;
/** Validate a persisted SMS provider before save or runtime resolution. */
export declare function validateStoredSmsConfig(raw: RawSmsConfig | PlatformSmsConfig, options?: {
    requireComplete?: boolean;
}): void;
export type SmsTransport = {
    provider: 'twilio';
    accountSid: string;
    authToken: string;
    from: string;
} | {
    provider: 'vonage';
    apiKey: string;
    apiSecret: string;
    from: string;
} | {
    provider: 'messagebird';
    accessKey: string;
    from: string;
} | {
    provider: 'plivo';
    authId: string;
    authToken: string;
    from: string;
} | {
    provider: 'telnyx';
    apiKey: string;
    from: string;
    messagingProfileId?: string;
};
/** Build a transport from already-plaintext config, or null when incomplete. */
export declare function buildSmsTransport(c: PlainSmsConfig): SmsTransport | null;
/** Unseal a stored config and build its transport, or null when not configured. */
export declare function resolveSmsTransport(raw: RawSmsConfig | null | undefined, unseal: Unseal): SmsTransport | null;
export type EffectiveSms = {
    kind: 'suppressed';
} | {
    kind: 'transport';
    transport: SmsTransport;
    source: 'tenant' | 'platform';
} | {
    kind: 'unconfigured';
};
/**
 * The platform → tenant resolution policy, as a pure function:
 *   'disabled'        → suppressed (kill switch; do not send, do not retry)
 *   'global_only'     → platform provider, else unconfigured
 *   'tenant_optional' → tenant provider (if scoped + configured), else platform.
 * `tenantScoped` is false for platform sends; a broken tenant override fails
 * closed rather than silently switching sender/provider.
 */
export declare function resolveEffectiveSmsTransport(platform: PlatformSmsConfig | null | undefined, tenant: RawSmsConfig | null | undefined, opts: {
    tenantScoped: boolean;
    unseal: Unseal;
}): EffectiveSms;
/** Send an SMS through a resolved transport. Throws on provider error. */
export declare function sendSmsVia(transport: SmsTransport, input: SendSmsInput): Promise<{
    id: string;
}>;
//# sourceMappingURL=transport.d.ts.map