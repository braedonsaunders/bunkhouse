# @appkit/sms

SMS delivery — five providers (Twilio, Vonage, MessageBird, Plivo, Telnyx) via fetch, sealed-secret config, platform→tenant policy.

## Install

```bash
pnpm add @appkit/sms
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
