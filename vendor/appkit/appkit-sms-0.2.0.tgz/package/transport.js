// SMS transport factory + provider implementations.
//
// `RawSmsConfig` is what an app persists per tenant (and per platform), with the
// single secret sealed. `resolveSmsTransport` unseals it (via an injected
// `unseal`, e.g. @appkit/crypto's unsealSecret) into an `SmsTransport`;
// `buildSmsTransport` does the same from already-plaintext values. `sendSmsVia`
// performs the network send, switching on provider. Every provider goes through
// `fetch` (no SDKs), so the package stays dependency-free.
//
// `unsealSecret` is injected, and the egress helper is a bounded fetch
// (timeout, no redirects, response-size cap).
import { isSmsProvider } from './providers.js';
const SMS_TIMEOUT_MS = 15_000;
const MAX_SMS_RESPONSE_BYTES = 64 * 1_024;
const MAX_SMS_BODY_CHARS = 1_600;
export function isSmsPolicyMode(value) {
    return value === 'tenant_optional' || value === 'global_only' || value === 'disabled';
}
const MAX_SMS_SENDER_LENGTH = 100;
const MAX_PROVIDER_IDENTIFIER_LENGTH = 320;
const MAX_SEALED_SECRET_LENGTH = 8_192;
function isSafeConfigText(value, maxLength) {
    return Boolean(value.trim()) && value.length <= maxLength && !/[\u0000-\u001f\u007f]/.test(value);
}
/** Strict E.164 validation used for every outbound destination. */
export function isValidSmsDestination(value) {
    return /^\+[1-9][0-9]{7,14}$/.test(value);
}
function validateSmsConfigFields(raw, requireComplete) {
    if (raw.provider !== undefined && !isSmsProvider(raw.provider)) {
        throw new Error('Select a valid SMS provider.');
    }
    if (raw.enabled !== undefined && typeof raw.enabled !== 'boolean') {
        throw new Error('SMS enabled state must be a boolean.');
    }
    if (raw.fromNumber !== undefined && !isSafeConfigText(raw.fromNumber, MAX_SMS_SENDER_LENGTH)) {
        throw new Error('SMS sender must contain 1 to 100 characters without control characters.');
    }
    for (const [label, value] of [
        ['Twilio account SID', raw.twilioAccountSid],
        ['Vonage API key', raw.vonageApiKey],
        ['Plivo auth ID', raw.plivoAuthId],
        ['Telnyx messaging profile ID', raw.telnyxMessagingProfileId],
    ]) {
        if (value !== undefined && !isSafeConfigText(value, MAX_PROVIDER_IDENTIFIER_LENGTH)) {
            throw new Error(`${label} is invalid or too long.`);
        }
    }
    if (!requireComplete)
        return;
    if (!raw.provider)
        throw new Error('Select an SMS provider before enabling SMS delivery.');
    if (!raw.fromNumber)
        throw new Error('Enter an SMS sender before enabling SMS delivery.');
    if (raw.provider === 'twilio' && !raw.twilioAccountSid) {
        throw new Error('Enter the Twilio account SID before enabling SMS delivery.');
    }
    if (raw.provider === 'vonage' && !raw.vonageApiKey) {
        throw new Error('Enter the Vonage API key before enabling SMS delivery.');
    }
    if (raw.provider === 'plivo' && !raw.plivoAuthId) {
        throw new Error('Enter the Plivo auth ID before enabling SMS delivery.');
    }
    if ('secret' in raw && !raw.secret?.trim()) {
        throw new Error("Enter this provider's credential before enabling SMS delivery.");
    }
}
/** Validate a persisted SMS provider before save or runtime resolution. */
export function validateStoredSmsConfig(raw, options = {}) {
    if ('mode' in raw && raw.mode !== undefined && !isSmsPolicyMode(raw.mode)) {
        throw new Error('Select a valid platform SMS policy.');
    }
    const requireComplete = options.requireComplete ?? raw.enabled === true;
    validateSmsConfigFields(raw, requireComplete);
    const hasCiphertext = Boolean(raw.keyCiphertext?.trim());
    const hasNonce = Boolean(raw.keyNonce?.trim());
    if (hasCiphertext !== hasNonce) {
        throw new Error('The stored SMS credential is incomplete; replace it before enabling SMS.');
    }
    if ((raw.keyCiphertext && raw.keyCiphertext.length > MAX_SEALED_SECRET_LENGTH) ||
        (raw.keyNonce && raw.keyNonce.length > MAX_SEALED_SECRET_LENGTH)) {
        throw new Error('The stored SMS credential is invalid; replace it before enabling SMS.');
    }
    if (requireComplete && raw.enabled !== true) {
        throw new Error('Enable SMS delivery before selecting a live SMS policy.');
    }
    if (requireComplete && !(hasCiphertext && hasNonce)) {
        throw new Error("Enter this provider's credential before enabling SMS delivery.");
    }
}
/** Build a transport from already-plaintext config, or null when incomplete. */
export function buildSmsTransport(c) {
    try {
        validateSmsConfigFields(c, true);
    }
    catch {
        return null;
    }
    const from = c.fromNumber?.trim();
    if (!from)
        return null;
    const secret = c.secret?.trim() || undefined;
    switch (c.provider) {
        case 'twilio': {
            const accountSid = c.twilioAccountSid?.trim();
            if (!accountSid || !secret)
                return null;
            return { provider: 'twilio', accountSid, authToken: secret, from };
        }
        case 'vonage': {
            const apiKey = c.vonageApiKey?.trim();
            if (!apiKey || !secret)
                return null;
            return { provider: 'vonage', apiKey, apiSecret: secret, from };
        }
        case 'messagebird':
            if (!secret)
                return null;
            return { provider: 'messagebird', accessKey: secret, from };
        case 'plivo': {
            const authId = c.plivoAuthId?.trim();
            if (!authId || !secret)
                return null;
            return { provider: 'plivo', authId, authToken: secret, from };
        }
        case 'telnyx':
            if (!secret)
                return null;
            return {
                provider: 'telnyx',
                apiKey: secret,
                from,
                messagingProfileId: c.telnyxMessagingProfileId?.trim() || undefined,
            };
        default:
            return null;
    }
}
/** Unseal a stored config and build its transport, or null when not configured. */
export function resolveSmsTransport(raw, unseal) {
    if (!raw || !raw.provider || raw.enabled !== true)
        return null;
    try {
        validateStoredSmsConfig(raw, { requireComplete: true });
    }
    catch {
        return null;
    }
    let secret;
    if (raw.keyCiphertext && raw.keyNonce) {
        secret = unseal({ ciphertext: raw.keyCiphertext, nonce: raw.keyNonce }) ?? undefined;
    }
    return buildSmsTransport({ ...raw, secret });
}
/**
 * The platform → tenant resolution policy, as a pure function:
 *   'disabled'        → suppressed (kill switch; do not send, do not retry)
 *   'global_only'     → platform provider, else unconfigured
 *   'tenant_optional' → tenant provider (if scoped + configured), else platform.
 * `tenantScoped` is false for platform sends; a broken tenant override fails
 * closed rather than silently switching sender/provider.
 */
export function resolveEffectiveSmsTransport(platform, tenant, opts) {
    const rawMode = platform?.mode;
    if (rawMode !== undefined && !isSmsPolicyMode(rawMode))
        return { kind: 'unconfigured' };
    const mode = rawMode ?? 'tenant_optional';
    if (mode === 'disabled')
        return { kind: 'suppressed' };
    const platformTransport = resolveSmsTransport(platform ?? null, opts.unseal);
    if (mode === 'global_only') {
        return platformTransport
            ? { kind: 'transport', transport: platformTransport, source: 'platform' }
            : { kind: 'unconfigured' };
    }
    if (opts.tenantScoped && tenant?.enabled === true) {
        const tenantTransport = resolveSmsTransport(tenant ?? null, opts.unseal);
        if (tenantTransport)
            return { kind: 'transport', transport: tenantTransport, source: 'tenant' };
        return { kind: 'unconfigured' };
    }
    if (platformTransport)
        return { kind: 'transport', transport: platformTransport, source: 'platform' };
    return { kind: 'unconfigured' };
}
// --- Send ------------------------------------------------------------------
function sanitizedText(value, redactions) {
    let printable = value.replace(/[\u0000-\u001f\u007f]+/g, ' ');
    for (const sensitiveValue of [...redactions].filter(Boolean).sort((a, b) => b.length - a.length)) {
        printable = printable.split(sensitiveValue).join('[redacted]');
    }
    return printable.replace(/\s+/g, ' ').trim().slice(0, 300);
}
function errText(body, status, redactions) {
    if (typeof body === 'string' && body)
        return sanitizedText(body, redactions);
    if (body && typeof body === 'object') {
        const record = body;
        const message = record.message ?? record.error ?? record.Message ?? record.detail;
        if (typeof message === 'string')
            return sanitizedText(message, redactions);
        if (Array.isArray(record.errors)) {
            const details = record.errors
                .map((item) => {
                if (!item || typeof item !== 'object')
                    return '';
                const error = item;
                const detail = error.detail ?? error.title ?? error.description ?? error.message;
                return typeof detail === 'string' ? detail : '';
            })
                .filter(Boolean);
            if (details.length > 0)
                return sanitizedText(details.join('; '), redactions);
        }
    }
    return `HTTP ${status}`;
}
/** Strip a single leading + — providers that want a bare international number. */
function stripPlus(n) {
    return n.startsWith('+') ? n.slice(1) : n;
}
function validateSendInput(input, from) {
    if (!isValidSmsDestination(input.to)) {
        throw new Error('SMS recipient must be a valid E.164 phone number.');
    }
    if (!input.body.trim() || input.body.length > MAX_SMS_BODY_CHARS) {
        throw new Error(`SMS body must contain 1 to ${MAX_SMS_BODY_CHARS} characters.`);
    }
    if (!from || from.length > 100 || /[\u0000-\u001f\u007f]/.test(from)) {
        throw new Error('SMS sender is invalid or too long.');
    }
}
async function readBoundedText(response) {
    if (!response.body)
        return '';
    const reader = response.body.getReader();
    const chunks = [];
    let received = 0;
    while (received < MAX_SMS_RESPONSE_BYTES) {
        const { done, value } = await reader.read();
        if (done)
            break;
        const remaining = MAX_SMS_RESPONSE_BYTES - received;
        chunks.push(value.byteLength > remaining ? value.subarray(0, remaining) : value);
        received += Math.min(value.byteLength, remaining);
        if (value.byteLength > remaining) {
            await reader.cancel();
            break;
        }
    }
    if (received === MAX_SMS_RESPONSE_BYTES)
        await reader.cancel().catch(() => undefined);
    const bytes = new Uint8Array(received);
    let offset = 0;
    for (const chunk of chunks) {
        bytes.set(chunk, offset);
        offset += chunk.byteLength;
    }
    return new TextDecoder().decode(bytes);
}
// Bounded fetch: hard timeout, no redirects, response-size cap. The body is
// streamed into a fixed-size buffer instead of calling response.text(), which
// would allocate an unbounded provider response before checking its size.
async function requestJson(url, options) {
    const response = await fetch(url, {
        method: 'POST',
        headers: options.headers,
        body: options.body,
        redirect: 'manual',
        signal: AbortSignal.timeout(SMS_TIMEOUT_MS),
    });
    const text = await readBoundedText(response);
    if (!text)
        return { response, body: null };
    try {
        return { response, body: JSON.parse(text) };
    }
    catch {
        return { response, body: text };
    }
}
function responseRecord(body) {
    return body && typeof body === 'object' && !Array.isArray(body)
        ? body
        : null;
}
function requiredProviderId(value, provider) {
    if (typeof value !== 'string' || !value.trim()) {
        throw new Error(`${provider}: provider returned success without a message id`);
    }
    return value;
}
/** Send an SMS through a resolved transport. Throws on provider error. */
export async function sendSmsVia(transport, input) {
    const from = input.from?.trim() || transport.from;
    validateSendInput(input, from);
    switch (transport.provider) {
        case 'twilio':
            return sendTwilio(transport, input, from);
        case 'vonage':
            return sendVonage(transport, input, from);
        case 'messagebird':
            return sendMessagebird(transport, input, from);
        case 'plivo':
            return sendPlivo(transport, input, from);
        case 'telnyx':
            return sendTelnyx(transport, input, from);
    }
}
async function sendTwilio(t, input, from) {
    const params = new URLSearchParams({ To: input.to, Body: input.body });
    // A Messaging Service SID (starts MG) goes in its own field; a number is `From`.
    if (from.startsWith('MG'))
        params.set('MessagingServiceSid', from);
    else
        params.set('From', from);
    const { response, body } = await requestJson(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(t.accountSid)}/Messages.json`, {
        headers: {
            Authorization: `Basic ${Buffer.from(`${t.accountSid}:${t.authToken}`).toString('base64')}`,
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params,
    });
    const json = responseRecord(body);
    if (!response.ok)
        throw new Error(`Twilio: ${errText(body, response.status, [t.authToken])}`);
    return { id: requiredProviderId(json?.sid, 'Twilio') };
}
async function sendVonage(t, input, from) {
    const params = new URLSearchParams({
        api_key: t.apiKey,
        api_secret: t.apiSecret,
        to: stripPlus(input.to),
        from,
        text: input.body,
    });
    const { response, body } = await requestJson('https://rest.nexmo.com/sms/json', {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
        body: params,
    });
    const json = responseRecord(body);
    const msg = json?.messages?.[0];
    // Vonage returns HTTP 200 even for per-message failures — status '0' is success.
    if (!response.ok || !msg || msg.status !== '0') {
        const detail = msg?.['error-text']
            ? sanitizedText(msg['error-text'], [t.apiKey, t.apiSecret])
            : errText(body, response.status, [t.apiKey, t.apiSecret]);
        throw new Error(`Vonage: ${detail}`);
    }
    return { id: requiredProviderId(msg['message-id'], 'Vonage') };
}
async function sendMessagebird(t, input, from) {
    const { response, body } = await requestJson('https://rest.messagebird.com/messages', {
        headers: { Authorization: `AccessKey ${t.accessKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipients: [input.to], originator: from, body: input.body }),
    });
    const json = responseRecord(body);
    if (!response.ok || json?.errors?.length) {
        throw new Error(`MessageBird: ${json?.errors?.[0]?.description ? sanitizedText(json.errors[0].description, [t.accessKey]) : errText(body, response.status, [t.accessKey])}`);
    }
    return { id: requiredProviderId(json?.id, 'MessageBird') };
}
async function sendPlivo(t, input, from) {
    const { response, body } = await requestJson(`https://api.plivo.com/v1/Account/${encodeURIComponent(t.authId)}/Message/`, {
        headers: {
            Authorization: `Basic ${Buffer.from(`${t.authId}:${t.authToken}`).toString('base64')}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ src: from, dst: input.to, text: input.body }),
    });
    const json = responseRecord(body);
    if (!response.ok || json?.error)
        throw new Error(`Plivo: ${json?.error ? sanitizedText(json.error, [t.authToken]) : errText(body, response.status, [t.authToken])}`);
    return { id: requiredProviderId(json?.message_uuid?.[0], 'Plivo') };
}
async function sendTelnyx(t, input, from) {
    const { response, body } = await requestJson('https://api.telnyx.com/v2/messages', {
        headers: { Authorization: `Bearer ${t.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
            from,
            to: input.to,
            text: input.body,
            messaging_profile_id: t.messagingProfileId,
        }),
    });
    const json = responseRecord(body);
    if (!response.ok || json?.errors?.length) {
        const e = json?.errors?.[0];
        const detail = e?.detail ?? e?.title;
        throw new Error(`Telnyx: ${detail ? sanitizedText(detail, [t.apiKey]) : errText(body, response.status, [t.apiKey])}`);
    }
    return { id: requiredProviderId(json?.data?.id, 'Telnyx') };
}
//# sourceMappingURL=transport.js.map