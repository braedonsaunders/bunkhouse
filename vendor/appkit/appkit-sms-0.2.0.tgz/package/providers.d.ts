export type SmsProvider = 'twilio' | 'vonage' | 'messagebird' | 'plivo' | 'telnyx';
export type SmsFieldKind = 'text' | 'number' | 'boolean' | 'select';
export type SmsProviderField = {
    key: string;
    kind: SmsFieldKind;
    label: string;
    placeholder?: string;
    required?: boolean;
    options?: {
        value: string;
        label: string;
    }[];
    help?: string;
};
export type SmsProviderSpec = {
    value: SmsProvider;
    label: string;
    /** Whether this provider authenticates with a single sealed secret. */
    hasSecret: boolean;
    /** Label for the single sealed secret (auth token / api secret / key). */
    secretLabel: string;
    /** Placeholder shown in the secret field. */
    keyHint: string;
    /** Whether the secret is mandatory. */
    secretRequired: boolean;
    /** Extra non-secret config fields this provider needs. */
    fields: SmsProviderField[];
    /** Optional note shown under the provider picker. */
    docsHint?: string;
};
export declare const SMS_PROVIDER_SPECS: SmsProviderSpec[];
export declare function isSmsProvider(value: unknown): value is SmsProvider;
export declare function smsProviderSpec(provider: SmsProvider): SmsProviderSpec;
//# sourceMappingURL=providers.d.ts.map