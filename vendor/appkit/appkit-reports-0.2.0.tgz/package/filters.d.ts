import { type ReportEntity } from './entities.js';
export declare const REPORT_FILTER_OPERATORS: readonly ["eq", "neq", "in", "not_in", "gte", "lte", "contains", "is_null", "is_not_null", "is_true", "is_false", "between_days_ago", "due_within_days", "since_today", "this_week", "this_month", "this_year", "before_now", "period_preset"];
export type ReportFilterOperator = (typeof REPORT_FILTER_OPERATORS)[number];
export type ReportRule = {
    field: string;
    op: ReportFilterOperator;
    value?: string | number | boolean | string[] | number[] | null;
};
export type ReportRuleGroup = {
    combinator: 'and' | 'or';
    not?: boolean;
    rules: (ReportRule | ReportRuleGroup)[];
};
export type ReportFilterOperatorMeta = {
    key: ReportFilterOperator;
    label: string;
    needsValue: 'none' | 'one' | 'list';
};
export declare function operatorsForKind(kind: ReportEntity['columns'][number]['kind']): ReportFilterOperatorMeta[];
export declare class SqlParameters {
    readonly values: unknown[];
    add(value: unknown): string;
}
export declare function compileReportRule(entity: ReportEntity, rule: ReportRule, parameters: SqlParameters, now?: Date, fiscalStartMonth?: number): string | null;
export declare function compileReportRuleGroup(entity: ReportEntity, group: ReportRuleGroup, parameters: SqlParameters, options?: {
    maxDepth?: number;
    maxRules?: number;
    now?: Date;
    fiscalStartMonth?: number;
}): string | null;
//# sourceMappingURL=filters.d.ts.map