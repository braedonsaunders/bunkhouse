export function queryResultToReport(result, options = {}) {
    const columns = result.columns.map((column) => ({
        key: column.key,
        label: column.label,
        semanticType: column.semanticType,
        align: column.semanticType === 'number' || column.semanticType === 'currency' ? 'right' : 'left',
    }));
    const groupKey = options.groupBy;
    const groups = [];
    if (groupKey) {
        const buckets = new Map();
        for (const row of result.rows) {
            const label = displayCell(row[groupKey]);
            const bucket = buckets.get(label) ?? [];
            bucket.push(row);
            buckets.set(label, bucket);
        }
        for (const [title, rows] of buckets) {
            groups.push({ kind: 'section', title, subtitle: `${rows.length} ${rows.length === 1 ? 'row' : 'rows'}`, columns, rows });
        }
    }
    else {
        groups.push({ kind: 'results', title: options.title ?? 'Results', columns, rows: result.rows, isEmpty: result.rows.length === 0 });
    }
    return {
        groups,
        summary: options.summary ?? [],
        rowCount: result.rowCount,
        truncated: result.truncated,
        durationMs: result.durationMs,
    };
}
export function createReportDocument(title, result, options = {}) {
    if (!title.trim())
        throw new Error('A report document requires a title');
    return {
        title,
        subtitle: options.subtitle,
        generatedAt: options.generatedAt ?? new Date(),
        groups: result.groups,
        summary: result.summary,
        rowCount: result.rowCount,
    };
}
export function displayCell(value) {
    if (value === null || value === undefined)
        return '';
    if (value instanceof Date)
        return value.toISOString();
    if (typeof value === 'object')
        return JSON.stringify(value);
    return String(value);
}
//# sourceMappingURL=document.js.map