import type { ReportEntity } from './entities.js';
/** Refine one entity: drop jsonb/array columns, resolve FK uuid columns whose
 *  relation target (looked up in `resolveTarget`) has a display column. */
export declare function refineReportEntityForDocuments(entity: ReportEntity, resolveTarget: (key: string) => ReportEntity | undefined): ReportEntity;
/** Refine a list (the studio's source picker). Targets resolve within the same
 *  list so FK labels line up with what the picker offers. */
export declare function refineReportEntitiesForDocuments(entities: ReportEntity[]): ReportEntity[];
/** Refine an executor entity map lazily (it may be a Proxy that resolves
 *  scoped per-app keys on demand, so eager enumeration is not an option). */
export declare function refineEntityMapForDocuments(map: Record<string, ReportEntity>): Record<string, ReportEntity>;
//# sourceMappingURL=refine.d.ts.map