import * as React from 'react';
import type { ReportCustomQuery } from './custom-query.js';
import type { CustomReportDefinition } from './definitions.js';
import type { ReportEntityCatalog } from './entities.js';
import { reportEntity } from './entities.js';
import type { ReportLayout, ReportRunResult, ReportSchedule } from './types.js';
import { type ReportExportOption } from './export-menu.js';
import { type ReportDrillLoader, type ReportDrillRecord, type ReportCellContext } from './viewer-types.js';
export type ReportStudioValue = {
    definition: CustomReportDefinition;
    schedule?: ReportSchedule | null;
};
export type ReportStudioSaveResult = {
    ok: true;
    value?: ReportStudioValue;
} | {
    ok: false;
    error: string;
};
export type ReportStudioDeleteResult = {
    ok: true;
} | {
    ok: false;
    error: string;
} | {
    ok: false;
    cancelled: true;
};
export type ReportStudioTemplate = {
    id: string;
    label: string;
    description: string;
    query: ReportCustomQuery;
};
export declare function ReportStudio<TDrillTarget = never, TRecord extends ReportDrillRecord = ReportDrillRecord>({ value, catalog, result, onChange, onPreview, onSave, onSaved, onDelete, onDeleted, organization, logoUrl, primaryColor, currency, drill, exports: exportOptions, printHref, pdfHref, templates, autoPreviewMs, autoSaveMs, className }: {
    value: ReportStudioValue;
    catalog: ReportEntityCatalog;
    result: ReportRunResult | null;
    onChange: (value: ReportStudioValue) => void;
    onPreview: (value: ReportStudioValue) => Promise<ReportRunResult>;
    onSave: (value: ReportStudioValue) => Promise<ReportStudioSaveResult>;
    /** Called only after persistence succeeds. Framework navigation remains host-owned. */
    onSaved?: (value: ReportStudioValue, result: Extract<ReportStudioSaveResult, {
        ok: true;
    }>) => void;
    /** Deletes a persisted definition. The host owns confirmation and durable persistence. */
    onDelete?: (value: ReportStudioValue) => Promise<ReportStudioDeleteResult>;
    /** Called only after deletion succeeds. Framework navigation remains host-owned. */
    onDeleted?: (value: ReportStudioValue) => void;
    organization?: string;
    logoUrl?: string | null;
    primaryColor?: string | null;
    currency?: string;
    drill?: {
        target: (context: ReportCellContext) => TDrillTarget | null | undefined;
        load: ReportDrillLoader<TDrillTarget, TRecord>;
        onOpenRecord?: (record: TRecord) => void;
    };
    exports?: ReportExportOption[];
    printHref?: string;
    /** Direct PDF action. The studio saves the current definition before opening it. */
    pdfHref?: string;
    templates?: ReportStudioTemplate[] | ((entity: NonNullable<ReturnType<typeof reportEntity>>) => ReportStudioTemplate[]);
    /** Debounced production live preview. Set false for manual-run-only hosts. */
    autoPreviewMs?: number | false;
    /** Debounced production autosave. Set false when the host owns save timing. */
    autoSaveMs?: number | false;
    className?: string;
}): React.JSX.Element;
/** Generic production templates derived only from the injected catalogue. */
export declare function reportStudioTemplates(entity: NonNullable<ReturnType<typeof reportEntity>>): ReportStudioTemplate[];
export declare function ReportResultView({ organization, logoUrl, primaryColor, title, description, layout, result }: {
    organization?: string;
    logoUrl?: string | null;
    primaryColor?: string | null;
    title?: string;
    description?: string;
    layout?: Partial<ReportLayout>;
    result: ReportRunResult;
}): React.JSX.Element;
//# sourceMappingURL=report-studio.d.ts.map