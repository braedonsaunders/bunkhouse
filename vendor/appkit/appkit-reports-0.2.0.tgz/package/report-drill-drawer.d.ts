import * as React from 'react';
import type { ReportDrillLoader, ReportDrillRecord } from './viewer-types.js';
export type ReportDrillDrawerText = {
    title: string;
    loadFailed: string;
    empty: string;
    previous: string;
    next: string;
    page: (current: number, total: number) => string;
};
/** Result rows over the report; applications can open their native record surface from a linked cell. */
export declare function ReportDrillDrawer<TDrillTarget, TRecord extends ReportDrillRecord = ReportDrillRecord>({ target, load, onClose, onOpenRecord, text: textOverrides, }: {
    target: TDrillTarget | null;
    load: ReportDrillLoader<TDrillTarget, TRecord>;
    onClose: () => void;
    onOpenRecord?: (record: TRecord) => void;
    text?: Partial<ReportDrillDrawerText>;
}): React.JSX.Element;
//# sourceMappingURL=report-drill-drawer.d.ts.map