export type Cadence = 'daily' | 'weekly' | 'monthly';
export type CadenceInput = {
    cadence: Cadence;
    /** 0 = Sunday … 6 = Saturday. Required for weekly. */
    dayOfWeek?: number | null;
    /** 1..31. Required for monthly. */
    dayOfMonth?: number | null;
    /** Monthly nth-weekday mode: 1..4 = ordinal, 5 = last. */
    weekOfMonth?: number | null;
    /** Repeat every N cadence periods. */
    repeatEvery?: number | null;
    hour: number;
    minute: number;
    /** IANA zone (e.g. 'America/Toronto'). */
    timezone: string;
    /** Inclusive local-date bounds (YYYY-MM-DD). */
    startsOn?: string | null;
    endsOn?: string | null;
};
/**
 * Returns the next future UTC Date matching the cadence (strictly > `from`).
 */
export declare function computeNextRunAt(input: CadenceInput, from?: Date): Date | null;
//# sourceMappingURL=cadence.d.ts.map