import type { QueryResult } from '@appkit/analytics';
import { type ReportDefinition, type ReportRunResult } from './types.js';
export type ReportExecutor = (query: ReportDefinition['query'], options: {
    signal?: AbortSignal;
}) => Promise<QueryResult>;
export declare function runReport(definition: ReportDefinition, execute: ReportExecutor, options?: {
    signal?: AbortSignal;
    groupBy?: string;
}): Promise<ReportRunResult>;
//# sourceMappingURL=run.d.ts.map