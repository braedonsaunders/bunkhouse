import { type DateRange } from './fiscal-calendar.js';
export type PeriodPresetGroup = 'fiscal_year' | 'fiscal_quarter' | 'fiscal_half' | 'period' | 'calendar' | 'rolling' | 'days' | 'custom';
export type PeriodPreset = {
    id: string;
    label: string;
    group: PeriodPresetGroup;
    /** True for point-in-time presets a balance-sheet-style report reads as "as of". */
    pointInTime?: boolean;
};
export declare const PERIOD_PRESET_GROUP_LABELS: Record<PeriodPresetGroup, string>;
/** The ordered, grouped preset catalog. Ids are stable — they persist in URLs
 *  and stored report definitions, so never rename an id (change the label). */
export declare const PERIOD_PRESETS: PeriodPreset[];
export declare const PERIOD_PRESET_IDS: string[];
export declare const DEFAULT_PERIOD_PRESET = "this_fiscal_year";
export declare function isPeriodPreset(id: unknown): id is string;
export type ResolvePresetInput = {
    startMonth: number;
    /** Reference "now" as an ISO `yyyy-mm-dd` string (caller-supplied). */
    today: string;
    /** Only used by the `custom` preset. */
    customFrom?: string | null;
    customTo?: string | null;
};
/**
 * Resolve a preset id into a concrete inclusive `{ from, to }` window plus a
 * descriptive label (e.g. "FY 2026", "Q2 FY 2026", "2026-07"). Returns `null`
 * for an unknown id or a `custom` preset missing its bounds — callers fall back
 * to a default. `to` doubles as the as-of instant for point-in-time reports.
 */
export declare function resolvePreset(id: string, input: ResolvePresetInput): DateRange | null;
//# sourceMappingURL=period-presets.d.ts.map