// Document refinement — makes discovered entities print like documents, not
// database dumps. Applied by the REPORTS layer only (studio picker + every
// executor map); analytics and public API consumers keep the raw catalogue.
//
//   • jsonb/array columns (discovery flags them `arrayUnnest`) are DROPPED —
//     raw JSON never belongs in a printed report.
//   • Foreign-key uuid columns with a discovered relation are RESOLVED to the
//     target's display column via a scalar subselect (e.g. site_org_unit_id →
//     the org unit's name). Same column key, so saved plans keep working;
//     label loses the "ID" suffix and the kind becomes text.
//
// Injection safety: every identifier comes from the schema-discovered
// catalog (table names, physical column names, single-column FKs) — never
// from user input.
/** Physical display-column preference for a relation target, best first. */
const DISPLAY_PREFERENCE = [
    'name',
    'title',
    'display_name',
    'full_name',
    'label',
    'reference',
    'course_name',
    'certification_name',
    'asset_tag',
    'serial_number',
    'key',
    'slug',
    'email',
];
const IDENT_RE = /^[a-z_][a-z0-9_]*$/i;
function q(ident) {
    return `"${ident}"`;
}
/** SQL expression (against alias `_ref`) that best names one row of `target`,
 *  or null when the target has no usable display column. */
function displayExprFor(target) {
    const physical = new Map();
    for (const c of target.columns) {
        const name = c.sql ?? c.key;
        const expression = c.expression ?? c.expr ?? name;
        const plain = expression === name || expression === c.key;
        const qualified = new RegExp(`^(?:"?[a-z_][a-z0-9_]*"?\\.)?"?${name}"?$`, 'i').test(expression);
        if (!plain && !qualified)
            continue;
        if (IDENT_RE.test(name))
            physical.set(name, name);
    }
    // People-style names read better as "Last, First".
    if (physical.has('last_name') && physical.has('first_name')) {
        return `("_ref".${q('last_name')} || ', ' || "_ref".${q('first_name')})`;
    }
    for (const pref of DISPLAY_PREFERENCE) {
        if (physical.has(pref))
            return `"_ref".${q(pref)}`;
    }
    return null;
}
/** Refine one entity: drop jsonb/array columns, resolve FK uuid columns whose
 *  relation target (looked up in `resolveTarget`) has a display column. */
export function refineReportEntityForDocuments(entity, resolveTarget) {
    const e = entity;
    const sourceTable = e.table ?? e.from;
    const relationByVia = new Map();
    for (const r of e.relations ?? [])
        relationByVia.set(r.via, r);
    let changed = false;
    const columns = [];
    for (const col of e.columns) {
        if (col.arrayUnnest) {
            changed = true;
            continue;
        }
        const rel = col.kind === 'uuid' ? relationByVia.get(col.sql ?? col.key) : undefined;
        if (!rel || !sourceTable || !IDENT_RE.test(rel.via) || !IDENT_RE.test(rel.foreignColumn) || !IDENT_RE.test(sourceTable)) {
            columns.push(col);
            continue;
        }
        const target = resolveTarget(rel.target);
        const targetTable = target?.table ?? target?.from;
        const display = target && targetTable && IDENT_RE.test(targetTable) ? displayExprFor(target) : null;
        if (!display) {
            columns.push(col);
            continue;
        }
        changed = true;
        columns.push({
            key: col.key,
            label: rel.label,
            kind: 'text',
            expression: `(SELECT ${display} FROM ${q(targetTable)} "_ref" WHERE "_ref".${q(rel.foreignColumn)} = ${q(sourceTable)}.${q(rel.via)})`,
        });
    }
    return changed ? { ...entity, columns } : entity;
}
/** Refine a list (the studio's source picker). Targets resolve within the same
 *  list so FK labels line up with what the picker offers. */
export function refineReportEntitiesForDocuments(entities) {
    const byKey = new Map(entities.map((e) => [e.key, e]));
    return entities.map((e) => refineReportEntityForDocuments(e, (k) => byKey.get(k)));
}
/** Refine an executor entity map lazily (it may be a Proxy that resolves
 *  scoped per-app keys on demand, so eager enumeration is not an option). */
export function refineEntityMapForDocuments(map) {
    const cache = new Map();
    const resolve = (key) => {
        if (cache.has(key))
            return cache.get(key);
        const raw = map[key];
        if (!raw)
            return undefined;
        const refined = refineReportEntityForDocuments(raw, (k) => map[k]);
        cache.set(key, refined);
        return refined;
    };
    return new Proxy({}, {
        get(_t, prop) {
            return typeof prop === 'string' ? resolve(prop) : undefined;
        },
        has(_t, prop) {
            return typeof prop === 'string' && prop in map;
        },
    });
}
//# sourceMappingURL=refine.js.map