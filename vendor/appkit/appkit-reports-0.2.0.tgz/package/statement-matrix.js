'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { cn } from '@appkit/ui';
function descendantEnd(lines, index) {
    const row = lines[index];
    if (!row)
        return index;
    let cursor = index + 1;
    if (row.kind === 'section') {
        while (cursor < lines.length && lines[cursor]?.kind === 'account')
            cursor++;
        return cursor - 1;
    }
    if (row.kind === 'account') {
        while (cursor < lines.length && lines[cursor]?.kind === 'account' && (lines[cursor]?.depth ?? 0) > row.depth)
            cursor++;
        return cursor - 1;
    }
    return index;
}
function scaleDivisor(scale) {
    if (scale === 'millions')
        return 1_000_000;
    if (scale === 'thousands')
        return 1_000;
    return 1;
}
function defaultFormatStatementCell(value, column, scale, currency, locale) {
    if (column.kind === 'variance_pct' || column.kind === 'percentage') {
        const normalized = column.kind === 'variance_pct' ? value / 100 : value;
        return new Intl.NumberFormat(locale, {
            style: 'percent',
            minimumFractionDigits: 1,
            maximumFractionDigits: 1,
        }).format(normalized);
    }
    const scaled = value / scaleDivisor(scale);
    const digits = scale === 'actual' ? 2 : 0;
    if (Math.abs(scaled) < (digits === 0 ? 0.5 : 0.005))
        return '–';
    if (column.kind === 'amount' && /^[A-Z]{3}$/.test(currency)) {
        return new Intl.NumberFormat(locale, {
            style: 'currency',
            currency,
            currencySign: 'accounting',
            minimumFractionDigits: digits,
            maximumFractionDigits: digits,
        }).format(scaled);
    }
    return new Intl.NumberFormat(locale, {
        minimumFractionDigits: digits,
        maximumFractionDigits: digits,
    }).format(scaled);
}
/**
 * The complete production statement surface: grouped column headings,
 * collapsible section/account hierarchies, scaling, accounting currency,
 * variance percentages, account links, total rules, and per-cell drill-through.
 * Domain-specific routes and drill target construction stay application-owned.
 */
export function StatementMatrixTable({ view, scale = 'actual', currency = '', locale, visibility, visibilityRevision, drillTarget, onDrill, onOpenRow, renderRowLink, formatValue, isNegative = (value) => value < 0, labels, }) {
    const columns = view.columns;
    const lines = view.lines;
    // Consecutive columns with the same group render beneath one merged heading.
    const spans = [];
    const hasGroups = columns.some((column) => column.group);
    if (hasGroups) {
        for (const column of columns) {
            const last = spans.at(-1);
            if (last && last.group === (column.group ?? ''))
                last.span++;
            else
                spans.push({ group: column.group ?? '', span: 1 });
        }
    }
    const groupStart = new Set();
    if (hasGroups) {
        let index = 0;
        for (const span of spans) {
            if (index > 0)
                groupStart.add(index);
            index += span.span;
        }
    }
    const ranges = React.useMemo(() => {
        const map = new Map();
        lines.forEach((_, index) => {
            const end = descendantEnd(lines, index);
            if (end > index)
                map.set(index, end);
        });
        return map;
    }, [lines]);
    const [collapsed, setCollapsed] = React.useState(new Set());
    React.useEffect(() => {
        if (visibility)
            setCollapsed(visibility === 'collapse' ? new Set(ranges.keys()) : new Set());
    }, [ranges, visibility, visibilityRevision]);
    const hidden = React.useMemo(() => {
        const result = new Set();
        for (const index of collapsed) {
            const end = ranges.get(index);
            if (end !== undefined) {
                for (let cursor = index + 1; cursor <= end; cursor++)
                    result.add(cursor);
            }
        }
        return result;
    }, [collapsed, ranges]);
    const toggle = (index) => setCollapsed((current) => {
        const next = new Set(current);
        if (next.has(index))
            next.delete(index);
        else
            next.add(index);
        return next;
    });
    return _jsx("div", { className: "app-scroll overflow-x-auto", children: _jsxs("table", { className: "w-full text-sm tabular-nums", children: [_jsxs("thead", { children: [hasGroups ? _jsxs("tr", { children: [_jsx("th", { className: "min-w-64" }), spans.map((span, index) => _jsx("th", { colSpan: span.span, className: "border-b border-border px-4 pt-1 pb-1 text-center text-xs font-semibold tracking-wide text-fg-muted uppercase", children: span.group }, `${span.group}-${index}`))] }) : null, _jsxs("tr", { className: "border-b border-border-strong", children: [_jsx("th", { className: "min-w-64 py-2 pr-4 text-left font-semibold text-fg-muted" }), columns.map((column, index) => _jsx("th", { className: cn('py-2 pl-4 text-right font-semibold whitespace-nowrap', column.kind === 'amount' ? 'text-fg-muted' : 'text-fg-subtle', groupStart.has(index) && 'border-l border-border'), children: column.label }, column.key))] })] }), _jsx("tbody", { children: lines.map((line, lineIndex) => {
                        if (hidden.has(lineIndex))
                            return null;
                        const canToggle = ranges.has(lineIndex);
                        const isCollapsed = collapsed.has(lineIndex);
                        const chevron = canToggle ? _jsx("button", { type: "button", onClick: () => toggle(lineIndex), "aria-label": isCollapsed ? labels?.expandSection?.(line.label) ?? `Expand ${line.label}` : labels?.collapseSection?.(line.label) ?? `Collapse ${line.label}`, className: "mr-0.5 inline-flex size-4 shrink-0 items-center justify-center rounded text-fg-subtle hover:bg-surface-hover hover:text-fg", children: isCollapsed ? _jsx(ChevronRight, { size: 13 }) : _jsx(ChevronDown, { size: 13 }) }) : _jsx("span", { className: "mr-0.5 inline-block size-4 shrink-0" });
                        if (line.kind === 'section')
                            return _jsx("tr", { children: _jsx("td", { colSpan: columns.length + 1, className: "pt-4 pb-1 text-xs font-semibold tracking-wide text-fg-muted uppercase", children: _jsxs("span", { className: "inline-flex items-center", children: [chevron, line.label] }) }) }, line.key ?? lineIndex);
                        const subtotal = line.kind === 'subtotal';
                        const total = line.kind === 'total';
                        const weight = total || line.emphasis ? 'font-semibold text-fg' : subtotal ? 'font-medium' : '';
                        const rowContent = _jsxs(_Fragment, { children: [line.number ? _jsx("span", { className: "mr-1.5 font-mono text-xs text-fg-subtle", children: line.number }) : null, line.label] });
                        return _jsxs("tr", { className: cn((subtotal || total) && '[&>td]:border-t [&>td]:border-border-strong', total && '[&>td]:border-b-[3px] [&>td]:border-double [&>td]:border-border-strong'), children: [_jsx("td", { className: cn('py-1 pr-4', weight, line.depth === 1 && 'pl-6', line.depth === 2 && 'pl-10', line.depth >= 3 && 'pl-14'), children: _jsxs("span", { className: "inline-flex items-baseline", children: [line.kind === 'account' ? chevron : null, line.kind === 'account' && renderRowLink ? renderRowLink(line, rowContent) : line.kind === 'account' && onOpenRow ? _jsx("button", { type: "button", onClick: () => onOpenRow(line), className: "hover:text-primary hover:underline", children: rowContent }) : rowContent] }) }), columns.map((column, columnIndex) => {
                                    const value = line.values?.[columnIndex];
                                    if (value === undefined)
                                        return _jsx("td", { className: cn('py-1 pl-4 text-right whitespace-nowrap', weight, groupStart.has(columnIndex) && 'border-l border-border-subtle') }, column.key);
                                    const context = { line, column, value, lineIndex, columnIndex, view };
                                    const target = drillTarget?.(context);
                                    const content = formatValue?.({ ...context, scale, currency, locale }) ?? defaultFormatStatementCell(value, column, scale, currency, locale);
                                    return _jsx("td", { className: cn('py-1 pl-4 text-right whitespace-nowrap', weight, isNegative(value, column) && 'text-danger', groupStart.has(columnIndex) && 'border-l border-border-subtle'), children: target != null && onDrill ? _jsx("button", { type: "button", onClick: () => onDrill(target), className: "hover:text-primary hover:underline", children: content }) : content }, column.key);
                                })] }, line.key ?? lineIndex);
                    }) })] }) });
}
//# sourceMappingURL=statement-matrix.js.map