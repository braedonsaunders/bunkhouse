import { type ReportDensity, type ReportLayout as ReportLayoutConfig, type ReportPaperSize } from './types.js';
import type { ReportColumn, ReportSummaryItem } from './types.js';
export type { ReportDensity, ReportLayoutConfig, ReportPaperSize };
export declare const DEFAULT_REPORT_LAYOUT: Required<ReportLayoutConfig>;
export declare const REPORT_MARGIN_MM_MIN = 5;
export declare const REPORT_MARGIN_MM_MAX = 30;
export declare const REPORT_DOCUMENT_FONT_FAMILY = "\"AppKit Report Sans\", sans-serif";
/** Normalise a stored (or user-supplied) layout: whitelist paper/orientation/
 *  density, clamp margins, default the optionals — always returns a fully
 *  populated config. */
export declare function resolveReportLayout(layout?: Partial<ReportLayoutConfig> | null): Required<ReportLayoutConfig>;
export declare const REPORT_PAPER_SIZE_LABELS: Record<ReportPaperSize, string>;
export type ReportDocumentInput = {
    tenantName: string;
    tenantLogoUrl?: string | null;
    primaryColor?: string | null;
    reportName: string;
    dateRangeLabel: string;
    generatedAt?: Date;
    summary?: ReportSummaryItem[];
    groups: {
        title: string;
        subtitle?: string;
        columns: (string | ReportColumn)[];
        rows: (unknown[] | Record<string, unknown>)[];
        isEmpty?: boolean;
    }[];
    translate?: (source: string) => string;
};
/** The @page rule for a layout. With `opts.marginBoxes` (browser preview only)
 *  it adds running footer margin boxes with live page counters — the print
 *  path must NOT pass it (Puppeteer's footerTemplate draws those instead). */
export declare function buildReportPageCss(layout: ReportLayoutConfig, opts?: {
    marginBoxes?: {
        footerLeft: string;
    };
}): string;
/** Element styles for the document markup. Kept SEPARATE from the markup so
 *  the browser preview can hand them to Paged.js's Polisher (which only
 *  processes CSS passed through its stylesheets argument — inline <style>
 *  tags inside the flowed content are never parsed, so @page/break rules in
 *  them would be silently ignored). Selectors are scoped under
 *  .appkit-report-doc so the fragment can mount inside the app without
 *  restyling the page around it. `density: 'compact'` shrinks type + padding
 *  so more rows fit per page.
 *
 *  The look mirrors the on-screen <ReportPaper>/<PaperView>: a centered
 *  document header, a divided summary band (no cards), plain uppercase section
 *  headers, and clean borderless rows under a ruled header — so the exported
 *  PDF is visually identical to the in-app preview. */
export declare function buildReportDocumentCss(_primaryColor?: string | null, density?: ReportDensity): string;
/** Self-contained font-face rules for the report body and Chromium's isolated
 * header/footer document. Both consume the same embedded bytes. */
export declare function buildReportDocumentFontCss(): string;
/** The document body fragment: cover header + summary band + one section per
 *  group. Style-free and @page-free — callers pair it with
 *  buildReportDocumentCss() and buildReportPageCss() (browser preview passes
 *  both to Paged.js; the PDF shell puts them in <head>). */
export declare function renderReportDocumentBodyHtml(input: ReportDocumentInput): string;
//# sourceMappingURL=document-render.d.ts.map