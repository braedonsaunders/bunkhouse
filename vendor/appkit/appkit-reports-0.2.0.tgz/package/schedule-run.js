/**
 * Creates the durable execution record before queue publication. Scheduled
 * occurrences are idempotent at (scheduleId, scheduledFor); manual requests
 * remain distinct even when requested in the same millisecond.
 */
export async function claimReportRun(store, input) {
    const context = await store.loadContext(input.scheduleId);
    if (!context)
        throw new Error(`Report schedule ${input.scheduleId} was not found`);
    const requestSnapshot = {
        scheduleName: context.scheduleName,
        definition: structuredClone(context.definition),
        filters: structuredClone(context.filters),
        recipientUserIds: [...context.recipientUserIds],
        recipientEmails: [...context.recipientEmails],
        emailSubject: context.emailSubject,
        emailMessage: context.emailMessage,
        runAsTenantUserId: context.runAsTenantUserId,
        runAsRoleId: context.runAsRoleId,
    };
    let scheduledFor = input.scheduledFor;
    for (;;) {
        const inserted = await store.insert({
            tenantId: context.tenantId,
            scheduleId: context.scheduleId,
            scheduledFor,
            trigger: input.trigger,
            requestSnapshot,
            status: 'queued',
        });
        if (inserted)
            return { id: inserted.id, scheduledFor, created: true };
        const existing = await store.find(context.scheduleId, scheduledFor);
        if (!existing)
            throw new Error('Report run conflict was not visible after insertion');
        if (input.trigger === 'scheduled' && existing.trigger === 'scheduled')
            return { id: existing.id, scheduledFor, created: false };
        scheduledFor = new Date(scheduledFor.getTime() + 1);
    }
}
//# sourceMappingURL=schedule-run.js.map