import { resolveReportLayout } from './types.js';
export function reportPaperSummary(data) {
    if (!resolveReportLayout(data.layout).showSummary)
        return [];
    return data.summary ?? [];
}
export function reportRunResultToPaper(title, result, options = {}) {
    return {
        title,
        periodPhrase: options.periodPhrase,
        note: options.note,
        layout: options.layout,
        summary: result.summary.map((item) => ({ key: item.key, label: item.label, value: item.value })),
        groups: result.groups.map((group, groupIndex) => ({
            title: group.title,
            subtitle: group.subtitle,
            columns: group.columns.map((column) => column.label),
            align: group.columns.map((column) => column.align ?? (column.semanticType === 'number' || column.semanticType === 'currency' ? 'right' : 'left')),
            money: group.columns.map((column) => column.semanticType === 'currency'),
            rows: group.rows.map((row) => group.columns.map((column) => row[column.key])),
            drills: options.drillTarget
                ? group.rows.map((row, rowIndex) => group.columns.map((column, columnIndex) => options.drillTarget?.({ groupIndex, rowIndex, columnIndex, row, columnKey: column.key })))
                : undefined,
            isEmpty: group.isEmpty,
        })),
    };
}
//# sourceMappingURL=viewer-types.js.map