import type { ReportEntity, ReportEntityColumn } from './entities.js';
export declare const CUSTOM_REPORT_COLUMN_PREFIX = "cf_";
export type CustomReportFieldDefinition = {
    key: string;
    label: string;
    fieldType: string;
};
export type CustomReportFieldSource = {
    list(entity: ReportEntity): Promise<readonly CustomReportFieldDefinition[]>;
};
/** Converts active custom-field definitions into safe synthetic report columns. */
export declare function buildCustomReportColumns(table: string, definitions: readonly CustomReportFieldDefinition[]): ReportEntityColumn[];
export declare function augmentReportEntityWithCustomFields(entity: ReportEntity, source: CustomReportFieldSource): Promise<ReportEntity>;
export declare function augmentReportCatalogWithCustomFields(entities: readonly ReportEntity[], source: CustomReportFieldSource): Promise<ReportEntity[]>;
//# sourceMappingURL=custom-columns.d.ts.map