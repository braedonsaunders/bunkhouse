import * as React from 'react';
export type ReportFilterValue = Record<string, string | boolean | null | undefined>;
export type ReportFilterSelect = {
    key: string;
    label?: string;
    value: string;
    options: {
        value: string;
        label: string;
    }[];
    ariaLabel?: string;
};
export type ReportDimensionOption = {
    id: string;
    name: string;
};
export type ReportSegmentOption = {
    key: string;
    name: string;
    pluralName: string;
    showInReports: boolean;
    values: ReportDimensionOption[];
};
export type ReportBuiltinSegmentOption = Omit<ReportSegmentOption, 'values'>;
export type ReportSubsidiaryOption = {
    id: string;
    label: string;
};
export type ReportControls = {
    search?: boolean;
    period?: boolean;
    dateRange?: boolean;
    asOf?: boolean;
    breakout?: boolean;
    breakoutOptions?: ('department' | 'project' | 'location' | 'class' | 'month' | 'quarter')[];
    compare?: boolean;
    basis?: boolean;
    dimensions?: boolean;
    customer?: boolean;
    subsidiary?: boolean;
    showZero?: boolean;
    scale?: boolean;
    sections?: boolean;
};
export type ReportFilterLabels = Partial<Record<'period' | 'asOf' | 'from' | 'to' | 'options' | 'showZeros' | 'expandAll' | 'collapseAll' | 'breakout' | 'breakoutNone' | 'compare' | 'compareNone' | 'comparePriorPeriod' | 'comparePriorYear' | 'subsidiary' | 'customer' | 'allCustomers' | 'department' | 'project' | 'location' | 'class' | 'basis' | 'basisAccrual' | 'basisCash' | 'scale' | 'scaleActual' | 'scaleThousands' | 'scaleMillions', string>> & {
    breakoutOption?: (key: string) => string;
    allSegment?: (pluralName: string) => string;
};
/**
 * Complete production report toolbar with an application-owned state boundary.
 * It preserves the single-row, low-chrome source UI and all source controls,
 * while leaving URL routing, localization, and domain option loading to the
 * consuming application through `value`, `onChange`, and typed inputs.
 */
export declare function ReportFilterBar({ value, onChange, controls, period, asOf, dateRange, defaultPeriod, search, searchPlaceholder, selects, primaryFilter, dimensions, customers, subsidiaries, resolvedDateRange, options, actions, leading, labels, }: {
    value: ReportFilterValue;
    onChange: (next: ReportFilterValue) => void;
    /** Source-shaped capability switches. When omitted, the smaller controlled
     * API (`period`, `asOf`, `dateRange`, `selects`) remains valid. */
    controls?: ReportControls;
    period?: boolean;
    asOf?: boolean;
    dateRange?: boolean;
    defaultPeriod?: string;
    search?: {
        value: string;
        placeholder?: string;
    };
    searchPlaceholder?: string;
    selects?: ReportFilterSelect[];
    primaryFilter?: ReportFilterSelect;
    dimensions?: {
        departments: ReportDimensionOption[];
        projects: ReportDimensionOption[];
        locations: ReportDimensionOption[];
        classes: ReportDimensionOption[];
        segments?: ReportSegmentOption[];
        builtinSegments?: ReportBuiltinSegmentOption[];
    };
    customers?: ReportDimensionOption[];
    /** First item represents the root/consolidated context. */
    subsidiaries?: ReportSubsidiaryOption[];
    resolvedDateRange?: {
        from: string;
        to: string;
    };
    options?: {
        showZero?: boolean;
        sections?: boolean;
        basis?: boolean;
        scale?: boolean;
        onExpandAll?: () => void;
        onCollapseAll?: () => void;
    };
    actions?: React.ReactNode;
    leading?: React.ReactNode;
    labels?: ReportFilterLabels;
}): React.JSX.Element;
//# sourceMappingURL=report-filter-bar.d.ts.map