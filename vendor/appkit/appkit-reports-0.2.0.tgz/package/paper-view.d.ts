import * as React from 'react';
import { type ReportPaperData } from './viewer-types.js';
/**
 * The shared on-screen renderer for the unified report shape. Its paper header,
 * summary band, document table rules, totals, currency treatment, and per-cell
 * drill behavior are the same surface used by both builders and result pages.
 */
export declare function PaperView<TDrillTarget>({ organization, data, emptyLabel, currency, locale, onDrill, renderLink, }: {
    organization: string;
    data: ReportPaperData<TDrillTarget>;
    emptyLabel?: string;
    currency?: string;
    locale?: string;
    onDrill?: (target: TDrillTarget) => void;
    renderLink?: (href: string, content: React.ReactNode) => React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=paper-view.d.ts.map