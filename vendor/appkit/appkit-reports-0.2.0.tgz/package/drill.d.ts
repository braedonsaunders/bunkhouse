export type ReportDrillCodec<T> = {
    encode(target: T): string;
    parse(raw: string | null): T | null;
};
/**
 * URL drill state is untrusted input. This factory preserves the source
 * implementation's bounded, fail-closed contract while allowing each app to
 * validate its own target vocabulary.
 */
export declare function createReportDrillCodec<T>(validate: (value: unknown) => T | null, options?: {
    maxLength?: number;
}): ReportDrillCodec<T>;
//# sourceMappingURL=drill.d.ts.map