import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '@appkit/ui';
import { resolveReportLayout } from './types.js';
const PAPER_WIDTH = {
    letter: 'max-w-5xl',
    a4: 'max-w-[62rem]',
    legal: 'max-w-[78rem]',
};
/** The shared in-app paper surface used by report previews and result pages. */
export function ReportPaper({ organization, title, periodPhrase, note, wide = false, layout, children, className, }) {
    const resolved = resolveReportLayout(layout);
    const paperStyle = {
        '--report-paper-margin': `${resolved.marginMm}mm`,
    };
    return _jsxs("article", { "data-report-paper": true, "data-paper-size": resolved.paperSize, "data-paper-orientation": resolved.orientation, "data-paper-density": resolved.density, style: paperStyle, className: cn('mx-auto w-full rounded-lg border border-border bg-surface p-[var(--report-paper-margin)] text-fg shadow-sm print:border-0 print:p-0 print:shadow-none', resolved.density === 'compact' && 'text-[13px]', wide || resolved.orientation === 'landscape' ? (resolved.paperSize === 'legal' ? PAPER_WIDTH.legal : 'max-w-none') : PAPER_WIDTH[resolved.paperSize], className), children: [_jsxs("header", { className: "mb-6 space-y-0.5 text-center", children: [organization ? _jsx("div", { className: "text-base font-semibold", children: organization }) : null, _jsx("h2", { className: "text-xl font-bold tracking-tight", children: title }), periodPhrase ? _jsx("div", { className: "text-sm text-fg-muted", children: periodPhrase }) : null, note ? _jsx("div", { className: "text-xs text-fg-subtle italic", children: note }) : null] }), children] });
}
//# sourceMappingURL=report-paper.js.map