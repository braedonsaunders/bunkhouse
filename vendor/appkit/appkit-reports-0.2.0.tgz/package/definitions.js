export function createReportDefinitionRegistry(definitions) {
    const ids = new Set();
    for (const definition of definitions) {
        assertCustomReportDefinition(definition);
        if (ids.has(definition.id) || ids.has(definition.slug))
            throw new Error(`Duplicate report definition "${definition.id}"`);
        ids.add(definition.id);
        ids.add(definition.slug);
    }
    return {
        definitions: [...definitions],
        get: (idOrSlug) => definitions.find((definition) => definition.id === idOrSlug || definition.slug === idOrSlug) ?? null,
        list: (options = {}) => definitions.filter((definition) => (!options.state || definition.state === options.state) && (!options.tags?.length || options.tags.every((tag) => definition.tags?.includes(tag)))),
    };
}
export function assertCustomReportDefinition(value) {
    if (value.schemaVersion !== 1)
        throw new Error('Unsupported report definition version');
    if (!value.id.trim() || !value.name.trim())
        throw new Error('Report id and name are required');
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value.slug))
        throw new Error('Report slug must use kebab case');
    if (!value.query.entity.trim())
        throw new Error('Report query entity is required');
    if ((value.query.mode ?? 'rows') === 'rows' && !value.query.columns.length)
        throw new Error('A row report requires at least one column');
}
//# sourceMappingURL=definitions.js.map