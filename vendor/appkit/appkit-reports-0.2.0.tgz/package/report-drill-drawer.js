'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button, Drawer, Skeleton, cn } from '@appkit/ui';
import { ReportTable, ReportTableBody, ReportTableCell, ReportTableHead, ReportTableHeader, ReportTableRow, } from './report-table.js';
const DEFAULT_TEXT = {
    title: 'Report details',
    loadFailed: 'The supporting records could not be loaded.',
    empty: 'No supporting records.',
    previous: 'Previous',
    next: 'Next',
    page: (current, total) => `Page ${current} of ${total}`,
};
/** Result rows over the report; applications can open their native record surface from a linked cell. */
export function ReportDrillDrawer({ target, load, onClose, onOpenRecord, text: textOverrides, }) {
    const text = { ...DEFAULT_TEXT, ...textOverrides };
    const [page, setPage] = React.useState(1);
    const [data, setData] = React.useState(null);
    const [error, setError] = React.useState(null);
    React.useEffect(() => { setPage(1); }, [target]);
    React.useEffect(() => {
        if (target === null) {
            setData(null);
            setError(null);
            return;
        }
        const controller = new AbortController();
        setData(null);
        setError(null);
        load(target, page, controller.signal)
            .then(setData)
            .catch((cause) => {
            if (cause instanceof DOMException && cause.name === 'AbortError')
                return;
            setError(cause instanceof Error ? cause.message : text.loadFailed);
        });
        return () => controller.abort();
    }, [load, page, target, text.loadFailed]);
    const pages = data ? Math.max(1, Math.ceil(data.total / Math.max(1, data.perPage))) : 1;
    return _jsx(Drawer, { open: target !== null, onClose: onClose, size: "2xl", title: data?.title ?? text.title, description: data?.description, children: !data && !error ? _jsxs("div", { className: "space-y-3", children: [_jsx(Skeleton, { className: "h-16 w-full" }), _jsx(Skeleton, { className: "h-8 w-full" }), _jsx(Skeleton, { className: "h-8 w-full" }), _jsx(Skeleton, { className: "h-8 w-2/3" })] }) : error ? _jsx("div", { role: "alert", className: "rounded-lg border border-danger/30 bg-danger-subtle px-4 py-3 text-sm text-danger", children: error }) : data ? _jsxs("div", { className: "space-y-5", children: [data.summary.length ? _jsx("div", { className: "grid grid-flow-col auto-cols-fr divide-x divide-border border-y border-border py-3", children: data.summary.map((item, index) => _jsxs("div", { className: "min-w-0 px-3 text-center", children: [_jsx("div", { className: "truncate text-xs text-fg-muted", children: item.label }), _jsx("div", { className: "truncate font-semibold tabular-nums", children: item.value })] }, item.key ?? `${item.label}-${index}`)) }) : null, data.rows.length ? _jsxs(ReportTable, { children: [_jsx(ReportTableHeader, { children: _jsx(ReportTableRow, { children: data.columns.map((column, index) => _jsx(ReportTableHead, { className: cn(column.align === 'right' && 'text-right', column.align === 'center' && 'text-center'), children: column.label }, column.key ?? index)) }) }), _jsx(ReportTableBody, { children: data.rows.map((row) => _jsx(ReportTableRow, { children: row.cells.map((cell, index) => {
                                    const column = data.columns[index];
                                    const content = cell == null ? '' : String(cell);
                                    return _jsx(ReportTableCell, { className: cn(column?.align === 'right' && 'text-right tabular-nums', column?.align === 'center' && 'text-center'), children: row.record && data.linkColumn === index && onOpenRecord ? _jsx("button", { type: "button", className: "font-medium text-primary hover:underline", onClick: () => onOpenRecord(row.record), children: content }) : content }, index);
                                }) }, row.key)) })] }) : _jsx("p", { className: "py-10 text-center text-sm text-fg-muted", children: text.empty }), _jsxs("div", { className: "flex items-center justify-between border-t border-border pt-3", children: [_jsxs("span", { className: "text-xs text-fg-muted", children: [text.page(data.page, pages), " \u00B7 ", data.total.toLocaleString(), " rows"] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { type: "button", variant: "outline", size: "sm", disabled: page <= 1, onClick: () => setPage((value) => Math.max(1, value - 1)), children: [_jsx(ChevronLeft, { size: 14 }), text.previous] }), _jsxs(Button, { type: "button", variant: "outline", size: "sm", disabled: page >= pages, onClick: () => setPage((value) => Math.min(pages, value + 1)), children: [text.next, _jsx(ChevronRight, { size: 14 })] })] })] })] }) : null });
}
//# sourceMappingURL=report-drill-drawer.js.map