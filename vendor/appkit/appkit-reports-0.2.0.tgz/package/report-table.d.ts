import * as React from 'react';
/** Report-only table primitives: ruled document typography without list chrome. */
export declare function ReportTable({ className, ...props }: React.TableHTMLAttributes<HTMLTableElement>): React.JSX.Element;
export declare function ReportTableHeader({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>): React.JSX.Element;
export declare function ReportTableBody({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>): React.JSX.Element;
export declare function ReportTableRow({ className, ...props }: React.HTMLAttributes<HTMLTableRowElement>): React.JSX.Element;
export declare function ReportTableHead({ className, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>): React.JSX.Element;
export declare function ReportTableCell({ className, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>): React.JSX.Element;
export declare const reportSubtotalRowClass = "border-t border-border-strong";
export declare const reportTotalRowClass = "border-t border-b-[3px] border-double border-border-strong";
//# sourceMappingURL=report-table.d.ts.map