'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from '@appkit/ui';
import { ReportPaper } from './report-paper.js';
import { ReportTable, ReportTableBody, ReportTableCell, ReportTableHead, ReportTableHeader, ReportTableRow, reportTotalRowClass, } from './report-table.js';
import { reportPaperSummary } from './viewer-types.js';
function isNumericCell(value) {
    if (typeof value === 'number')
        return true;
    if (typeof value !== 'string')
        return false;
    return /^-?[$(]?-?[\d,]+(\.\d+)?\)?%?$/.test(value.trim());
}
function formatMoney(value, currency, locale) {
    if (currency && /^[A-Z]{3}$/.test(currency)) {
        return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(value);
    }
    const formatted = Math.abs(value).toLocaleString(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return value < 0 ? `(${currency}${formatted})` : `${currency}${formatted}`;
}
function formatCell(value, money, currency, locale) {
    if (value === null || value === undefined || value === '')
        return '';
    if (typeof value === 'boolean')
        return value ? 'Yes' : 'No';
    if (typeof value === 'number') {
        if (money)
            return formatMoney(value, currency, locale);
        return value.toLocaleString(locale, { maximumFractionDigits: 2 });
    }
    return value;
}
function DrillValue({ target, onDrill, children, }) {
    if (!onDrill)
        return children;
    return _jsx("button", { type: "button", onClick: () => onDrill(target), className: "font-inherit text-inherit hover:text-primary hover:underline", children: children });
}
/**
 * The shared on-screen renderer for the unified report shape. Its paper header,
 * summary band, document table rules, totals, currency treatment, and per-cell
 * drill behavior are the same surface used by both builders and result pages.
 */
export function PaperView({ organization, data, emptyLabel = 'No data.', currency = '', locale, onDrill, renderLink, }) {
    const wide = data.groups.some((group) => group.columns.length > 5);
    const summary = reportPaperSummary(data);
    return _jsxs(ReportPaper, { organization: organization, title: data.title, periodPhrase: data.periodPhrase, note: data.note, wide: wide, layout: data.layout, children: [summary.length ? _jsx("div", { className: "mb-6 grid grid-flow-col auto-cols-fr divide-x divide-border border-y border-border py-3", children: summary.map((item, index) => {
                    const target = item.drill ?? (isNumericCell(item.value) ? data.defaultDrillTarget : undefined);
                    const value = formatCell(item.value, false, currency, locale);
                    return _jsxs("div", { className: "min-w-0 px-3 text-center", children: [_jsx("div", { className: "truncate text-xs text-fg-muted", children: item.label }), _jsx("div", { className: "truncate font-semibold tabular-nums", children: target !== undefined ? _jsx(DrillValue, { target: target, onDrill: onDrill, children: value }) : value })] }, item.key ?? `${item.label}-${index}`);
                }) }) : null, _jsx("div", { className: "space-y-7", children: data.groups.map((group, groupIndex) => {
                    const showTitle = group.title && (data.groups.length > 1 || Boolean(group.subtitle));
                    const alignOf = (columnIndex, cell) => group.align?.[columnIndex] ?? (isNumericCell(cell) ? 'right' : 'left');
                    return _jsxs("section", { className: "space-y-1.5", children: [showTitle ? _jsxs("div", { className: "flex items-baseline gap-2", children: [_jsx("h3", { className: "pt-2 text-xs font-semibold tracking-wide uppercase", children: group.title }), group.subtitle ? _jsx("span", { className: "text-xs text-fg-muted", children: group.subtitle }) : null] }) : null, group.isEmpty || group.rows.length === 0 ? _jsx("p", { className: "py-6 text-center text-sm text-fg-subtle italic", children: emptyLabel }) : _jsxs(ReportTable, { children: [_jsx(ReportTableHeader, { children: _jsx(ReportTableRow, { children: group.columns.map((column, columnIndex) => _jsx(ReportTableHead, { className: (group.align?.[columnIndex] ?? (columnIndex === 0 ? 'left' : 'right')) === 'right' ? 'text-right' : (group.align?.[columnIndex] === 'center' ? 'text-center' : 'text-left'), children: column }, `${column}-${columnIndex}`)) }) }), _jsx(ReportTableBody, { children: group.rows.map((row, rowIndex) => {
                                            const total = group.totalRowIndex === rowIndex;
                                            return _jsx(ReportTableRow, { className: cn(total && reportTotalRowClass, total && 'font-semibold'), children: row.map((cell, columnIndex) => {
                                                    const align = alignOf(columnIndex, cell);
                                                    const money = Boolean(group.money?.[columnIndex]);
                                                    const negative = typeof cell === 'number' && cell < 0;
                                                    const href = group.links?.[rowIndex]?.[columnIndex];
                                                    const target = group.drills?.[rowIndex]?.[columnIndex] ?? (isNumericCell(cell) ? data.defaultDrillTarget : undefined);
                                                    const content = formatCell(cell, money, currency, locale);
                                                    return _jsx(ReportTableCell, { className: cn(align === 'right' && 'text-right tabular-nums', align === 'center' && 'text-center', negative && 'text-danger'), children: target !== undefined ? _jsx(DrillValue, { target: target, onDrill: onDrill, children: content }) : href ? (renderLink?.(href, content) ?? _jsx("a", { href: href, className: "hover:text-primary hover:underline", children: content })) : content }, columnIndex);
                                                }) }, rowIndex);
                                        }) })] })] }, `${group.title ?? 'group'}-${groupIndex}`);
                }) })] });
}
//# sourceMappingURL=paper-view.js.map