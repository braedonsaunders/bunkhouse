export declare const REPORT_SCHEDULE_LIMITS: {
    readonly nameChars: 200;
    readonly emailSubjectChars: 500;
    readonly emailMessageChars: 20000;
    readonly timezoneChars: 100;
    readonly recipientCount: 1000;
    readonly recipientEmailChars: 320;
    readonly recipientUserIdChars: 128;
    readonly recipientEmailListChars: 400000;
    readonly recipientUserIdListChars: 150000;
    readonly filtersChars: 65536;
    readonly filtersBytes: 131072;
    readonly filtersDepth: 12;
    readonly filtersNodes: 2000;
    readonly filterKeyChars: 128;
};
export declare function normalizeReportRecipientEmails(values: readonly string[]): string[];
export declare function normalizeReportRecipientUserIds(values: readonly string[]): string[];
export declare function assertReportRecipientLimit(userIds: readonly string[], emails: readonly string[]): void;
export declare function assertBoundedReportFilters(value: unknown): asserts value is Record<string, unknown>;
/** Compatibility helper for packages that use a single email-recipient list. */
export declare function validateScheduleRecipients(recipients: string[]): string[];
/** Compatibility helper for optional filters. */
export declare function assertScheduleFilters(value: unknown): void;
//# sourceMappingURL=schedule-policy.d.ts.map