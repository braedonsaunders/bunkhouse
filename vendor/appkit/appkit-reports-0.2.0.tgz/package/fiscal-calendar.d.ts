/** A resolved date window: inclusive ISO `from`/`to` plus a display label. */
export type DateRange = {
    from: string;
    to: string;
    label: string;
};
/** Last calendar day of month `m` (1-12) in year `y`. */
export declare function lastDayOfMonth(y: number, m: number): number;
export declare function startOfMonth(y: number, m: number): string;
export declare function endOfMonth(y: number, m: number): string;
/** Add `n` months to a (year, month 1-12) pair, normalising into a new pair. */
export declare function addMonths(y: number, m: number, n: number): [number, number];
/** Add `n` days to an ISO date (UTC-safe; crosses month/year boundaries). */
export declare function addDays(dateIso: string, n: number): string;
/** Add `n` months to a full ISO date, clamping the day to the target month. */
export declare function addMonthsIso(dateIso: string, n: number): string;
/** The fiscal year (named by its END calendar year) that a date falls in. */
export declare function fiscalYearOf(dateIso: string, startMonth: number): number;
/** Start/end ISO dates + label for a whole fiscal year (named by end year). */
export declare function fiscalYearRangeFor(fyEndYear: number, startMonth: number): DateRange;
/** Months elapsed from the fiscal-year start to `dateIso` (0-based, 0…11). */
export declare function fiscalMonthOffset(dateIso: string, startMonth: number): number;
/** Fiscal quarter `q` (1-4) of the fiscal year ending `fyEndYear`. */
export declare function fiscalQuarterRange(fyEndYear: number, q: number, startMonth: number): DateRange;
/** Fiscal half `h` (1-2) of the fiscal year ending `fyEndYear`. */
export declare function fiscalHalfRange(fyEndYear: number, h: number, startMonth: number): DateRange;
/** Fiscal period/month `p` (1-12) of the fiscal year ending `fyEndYear`. The
 *  label is the calendar month it maps to (e.g. `2026-07`). */
export declare function fiscalPeriodRange(fyEndYear: number, p: number, startMonth: number): DateRange;
/** Enumerate the fiscal months (as ranges) overlapping an inclusive window —
 *  drives per-month breakout columns. Capped defensively at 60. */
export declare function fiscalMonthsBetween(from: string, to: string): DateRange[];
/** Enumerate the fiscal quarters overlapping an inclusive window. */
export declare function fiscalQuartersBetween(from: string, to: string, startMonth: number): DateRange[];
//# sourceMappingURL=fiscal-calendar.d.ts.map