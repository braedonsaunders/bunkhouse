import * as React from 'react';
import type { DashboardActionResult, DashboardLayout, DashboardLibraryItem } from './types.js';
export declare function DashboardGrid({ initialLayout, nodes, items, categoryLabels, mode, onSave, onReset, onSaved, toolbarLabel, saveLabel, resetLabel, addLabel, emptyLabel, className, }: {
    initialLayout: DashboardLayout;
    nodes: Record<string, React.ReactNode>;
    items: DashboardLibraryItem[];
    categoryLabels?: Record<string, string>;
    mode?: 'view' | 'edit';
    onSave?: (layout: DashboardLayout) => Promise<DashboardActionResult>;
    onReset?: () => Promise<DashboardActionResult>;
    onSaved?: () => void;
    toolbarLabel?: string;
    saveLabel?: string;
    resetLabel?: string;
    addLabel?: string;
    emptyLabel?: string;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=dashboard-grid.d.ts.map