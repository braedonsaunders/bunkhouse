export type DashboardAccessContext = {
    permissions: Iterable<string>;
    roleTier?: number;
};
export type DashboardAccessRule = {
    permission?: string;
    minimumRoleTier?: number;
    predicate?: (context: DashboardAccessContext) => boolean;
};
export declare function canAccessDashboardItem(context: DashboardAccessContext, rule?: DashboardAccessRule): boolean;
export declare function filterDashboardItems<T extends {
    access?: DashboardAccessRule;
}>(items: T[], context: DashboardAccessContext): T[];
//# sourceMappingURL=access.d.ts.map