import type { DashboardLayout, DashboardLibraryItem } from './types.js';
export type DashboardLayoutSource = 'user' | 'role' | 'default';
export type ResolvedDashboardLayout = {
    layout: DashboardLayout;
    source: DashboardLayoutSource;
};
export declare function resolveDashboardLayout(options: {
    user?: DashboardLayout | null;
    role?: DashboardLayout | null;
    fallback: DashboardLayout;
    library: DashboardLibraryItem[];
}): ResolvedDashboardLayout;
export declare function normalizeDashboardLayout(layout: DashboardLayout, library: DashboardLibraryItem[]): DashboardLayout;
export declare function layoutForRole<T extends string>(role: T, layouts: Partial<Record<T, DashboardLayout>>, fallback: DashboardLayout): DashboardLayout;
//# sourceMappingURL=layout.d.ts.map