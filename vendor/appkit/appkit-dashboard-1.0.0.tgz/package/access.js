export function canAccessDashboardItem(context, rule) {
    if (!rule)
        return true;
    if (rule.minimumRoleTier !== undefined && (context.roleTier ?? 0) < rule.minimumRoleTier)
        return false;
    if (rule.permission && !hasPermission(context.permissions, rule.permission))
        return false;
    return rule.predicate?.(context) ?? true;
}
export function filterDashboardItems(items, context) { return items.filter((item) => canAccessDashboardItem(context, item.access)); }
function hasPermission(permissions, requested) { for (const permission of permissions) {
    if (permission === '*' || permission === requested || (permission.endsWith('.*') && requested.startsWith(permission.slice(0, -1))))
        return true;
} return false; }
//# sourceMappingURL=access.js.map