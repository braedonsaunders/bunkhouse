export function resolveDashboardLayout(options) {
    const selected = options.user ? { value: options.user, source: 'user' }
        : options.role ? { value: options.role, source: 'role' }
            : { value: options.fallback, source: 'default' };
    return { layout: normalizeDashboardLayout(selected.value, options.library), source: selected.source };
}
export function normalizeDashboardLayout(layout, library) {
    const definitions = new Map(library.map((item) => [item.id, item]));
    const seen = new Set();
    const widgets = layout.widgets.flatMap((widget) => {
        const definition = definitions.get(widget.id);
        if (!definition || seen.has(widget.id))
            return [];
        seen.add(widget.id);
        const width = clamp(widget.w, definition.minSize.w, definition.maxSize?.w ?? 12);
        const height = clamp(widget.h, definition.minSize.h, definition.maxSize?.h ?? 100);
        return [{ id: widget.id, x: clamp(widget.x, 0, Math.max(0, 12 - width)), y: Math.max(0, Math.trunc(widget.y)), w: width, h: height }];
    });
    return { widgets, quickActions: layout.quickActions ? [...layout.quickActions] : undefined };
}
export function layoutForRole(role, layouts, fallback) { return layouts[role] ?? fallback; }
function clamp(value, minimum, maximum) { return Math.max(minimum, Math.min(maximum, Math.trunc(Number.isFinite(value) ? value : minimum))); }
//# sourceMappingURL=layout.js.map