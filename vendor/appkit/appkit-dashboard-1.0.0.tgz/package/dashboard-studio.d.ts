import * as React from 'react';
import type { DashboardDraft, DashboardLibraryItem, DashboardStudioAdapter } from './types.js';
export type DashboardStudioProps = {
    initial: DashboardDraft;
    nodes: Record<string, React.ReactNode>;
    items: DashboardLibraryItem[];
    adapter: DashboardStudioAdapter;
    onRemoved?: () => void;
    onSaved?: (draft: DashboardDraft) => void;
    categoryLabels?: Record<string, string>;
    readOnly?: boolean;
    className?: string;
};
export declare function DashboardStudio({ initial, nodes, items, adapter, onRemoved, onSaved, categoryLabels, readOnly, className }: DashboardStudioProps): React.JSX.Element;
//# sourceMappingURL=dashboard-studio.d.ts.map