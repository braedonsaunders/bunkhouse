import * as React from 'react';
import { type AnalyticsCatalog, type InsightQuery } from '@appkit/analytics';
import type { CardPreviewResult, CardStudioResult, InsightCardDraft } from './types.js';
export declare function CardStudio({ initial, catalog, onSave, onRun, onDelete, onPublishChange, className }: {
    initial: InsightCardDraft;
    catalog: AnalyticsCatalog;
    onSave: (draft: InsightCardDraft) => Promise<CardStudioResult>;
    onRun: (query: InsightQuery) => Promise<CardPreviewResult>;
    onDelete?: (draft: InsightCardDraft) => Promise<CardStudioResult>;
    onPublishChange?: (published: boolean, draft: InsightCardDraft) => Promise<CardStudioResult>;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=card-studio.d.ts.map