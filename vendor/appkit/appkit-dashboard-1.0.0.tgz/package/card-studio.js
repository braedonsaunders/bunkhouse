'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Activity, BarChart3, ChartNoAxesCombined, CircleGauge, Filter, Grid2X2, Grid3X3, Hash, LineChart, Loader2, PieChart, Plus, Rows3, ScatterChart, Table2, Trash2, } from 'lucide-react';
import { FILTER_OPERATORS, VISUALIZATIONS, fieldFromSource, filterOperatorsForField, parseFormula, serializeFormula, sourceFromCatalog, } from '@appkit/analytics';
import { Badge, Button, Checkbox, Input, Label, SearchSelect, Textarea, cn } from '@appkit/ui';
import { InsightResultView } from './insight-card.js';
const VIZ_ICONS = {
    scalar: _jsx(Hash, {}), progress: _jsx(Activity, {}), table: _jsx(Table2, {}), bar: _jsx(BarChart3, {}),
    row: _jsx(Rows3, {}), line: _jsx(LineChart, {}), area: _jsx(Activity, {}), pie: _jsx(PieChart, {}),
    donut: _jsx(PieChart, {}), gauge: _jsx(CircleGauge, {}), pivot: _jsx(Grid3X3, {}), heatmap: _jsx(Grid2X2, {}),
    combo: _jsx(ChartNoAxesCombined, {}), funnel: _jsx(Filter, {}), scatter: _jsx(ScatterChart, {}),
};
const FLAT_VISUALIZATIONS = [
    'scalar', 'progress', 'table', 'bar', 'row', 'line', 'area', 'combo',
    'pie', 'donut', 'funnel', 'gauge', 'scatter',
];
const FILTER_LABELS = {
    eq: 'equals', neq: 'does not equal', in: 'is any of', not_in: 'is not any of', gt: 'greater than',
    gte: 'at least', lt: 'less than', lte: 'at most', contains: 'contains', is_null: 'is empty',
    is_not_null: 'is not empty', last_n_days: 'within last days', this_month: 'this month',
    this_quarter: 'this quarter', this_year: 'this year', ytd: 'year to date',
};
const NO_VALUE_FILTERS = new Set(['is_null', 'is_not_null', 'this_month', 'this_quarter', 'this_year', 'ytd']);
export function CardStudio({ initial, catalog, onSave, onRun, onDelete, onPublishChange, className }) {
    const [draft, setDraft] = React.useState(initial);
    const [saveState, setSaveState] = React.useState('saved');
    const [saveError, setSaveError] = React.useState(null);
    const [preview, setPreview] = React.useState(null);
    const [previewError, setPreviewError] = React.useState(null);
    const [running, setRunning] = React.useState(false);
    const [formulaErrors, setFormulaErrors] = React.useState({});
    const changed = React.useRef(false);
    const saveRef = React.useRef(onSave);
    const runRef = React.useRef(onRun);
    saveRef.current = onSave;
    runRef.current = onRun;
    const source = sourceFromCatalog(catalog, draft.query.source) ?? catalog.sources[0] ?? null;
    const fields = source?.fields ?? [];
    function update(updater) {
        changed.current = true;
        setDraft(updater);
    }
    function updateQuery(updater) {
        update((current) => ({ ...current, query: updater(current.query) }));
    }
    React.useEffect(() => {
        if (!changed.current)
            return;
        setSaveState('saving');
        setSaveError(null);
        const timer = window.setTimeout(async () => {
            const result = await saveRef.current(draft);
            if (result.ok) {
                setSaveState('saved');
                if (result.id && !draft.id)
                    setDraft((current) => ({ ...current, id: result.id }));
            }
            else {
                setSaveState('error');
                setSaveError(result.error);
            }
        }, 700);
        return () => window.clearTimeout(timer);
    }, [draft]);
    React.useEffect(() => {
        setRunning(true);
        setPreviewError(null);
        const timer = window.setTimeout(async () => {
            const result = await runRef.current(draft.query);
            if (result.ok)
                setPreview(result.result);
            else {
                setPreview(null);
                setPreviewError(result.error);
            }
            setRunning(false);
        }, 350);
        return () => window.clearTimeout(timer);
    }, [draft.query]);
    function changeSource(key) {
        update((current) => ({ ...current, query: { source: key, measures: [{ fn: 'count' }], dimensions: [], filters: [], limit: 100 } }));
        setFormulaErrors({});
    }
    return _jsxs("div", { className: cn('flex min-h-0 flex-1 flex-col', className), children: [_jsxs("div", { className: "grid min-h-0 flex-1 lg:grid-cols-[minmax(280px,380px)_minmax(0,1fr)]", children: [_jsxs("div", { className: "app-scroll min-h-0 space-y-6 overflow-y-auto border-r border-border p-5", children: [_jsxs("section", { className: "space-y-4", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "card-name", children: "Name" }), _jsx(Input, { id: "card-name", value: draft.name, onChange: (event) => update((current) => ({ ...current, name: event.target.value })), placeholder: "Monthly activity" })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "card-description", children: "Description" }), _jsx(Input, { id: "card-description", value: draft.description ?? '', onChange: (event) => update((current) => ({ ...current, description: event.target.value })), placeholder: "Optional" })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Source" }), _jsx(SearchSelect, { value: draft.query.source, onChange: changeSource, options: catalog.sources.map((item) => ({ value: item.key, label: item.label, hint: item.description })) }), source?.description ? _jsx("p", { className: "text-xs leading-relaxed text-fg-muted", children: source.description }) : null] })] }), _jsxs(StudioSection, { title: "Measures", onAdd: () => updateQuery((query) => ({ ...query, measures: [...(query.measures ?? []), { fn: 'count' }] })), children: [(draft.query.measures ?? []).map((measure, index) => _jsx(MeasureRow, { measure: measure, fields: fields, error: formulaErrors[index], onChange: (next) => updateQuery((query) => ({ ...query, measures: (query.measures ?? []).map((item, itemIndex) => itemIndex === index ? next : item) })), onFormulaError: (error) => setFormulaErrors((current) => ({ ...current, [index]: error })), onRemove: () => updateQuery((query) => ({ ...query, measures: (query.measures ?? []).filter((_, itemIndex) => itemIndex !== index) })) }, index)), _jsx(Button, { type: "button", variant: "ghost", size: "sm", className: "w-full border border-dashed border-border text-xs", onClick: () => updateQuery((query) => ({ ...query, measures: [...(query.measures ?? []), { kind: 'formula', alias: 'custom_metric', label: 'Custom metric', formula: { expression: 'aggregate', fn: 'count' } }] })), children: "\u0192x Add formula" })] }), _jsx(StudioSection, { title: "Group by", onAdd: () => { const field = fields.find((item) => item.canDimension ?? !['number', 'currency'].includes(item.semanticType)); if (field)
                                    updateQuery((query) => ({ ...query, dimensions: [...(query.dimensions ?? []), { field: field.key }] })); }, children: (draft.query.dimensions ?? []).map((dimension, index) => _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(SearchSelect, { className: "min-w-0 flex-1", value: dimension.field, onChange: (field) => updateQuery((query) => ({ ...query, dimensions: (query.dimensions ?? []).map((item, itemIndex) => itemIndex === index ? { ...item, field } : item) })), options: fields.filter((field) => field.canDimension ?? !['number', 'currency'].includes(field.semanticType)).map((field) => ({ value: field.key, label: field.label })) }), fieldFromSource(source, dimension.field)?.semanticType === 'date' ? _jsx(SearchSelect, { className: "w-28", value: dimension.bin ?? '', onChange: (bin) => updateQuery((query) => ({ ...query, dimensions: (query.dimensions ?? []).map((item, itemIndex) => itemIndex === index ? { ...item, bin: bin ? bin : undefined } : item) })), options: [{ value: '', label: 'Exact' }, ...['day', 'week', 'month', 'quarter', 'year'].map((value) => ({ value, label: value }))] }) : null, _jsx(IconButton, { label: "Remove dimension", onClick: () => updateQuery((query) => ({ ...query, dimensions: (query.dimensions ?? []).filter((_, itemIndex) => itemIndex !== index) })) })] }, index)) }), _jsx(StudioSection, { title: "Filters", onAdd: () => { const field = fields[0]; if (field)
                                    updateQuery((query) => ({ ...query, filters: [...(query.filters ?? []), { field: field.key, operator: 'eq', value: '' }] })); }, children: (draft.query.filters ?? []).map((filter, index) => _jsx(FilterRow, { filter: filter, fields: fields, onChange: (next) => updateQuery((query) => ({ ...query, filters: (query.filters ?? []).map((item, itemIndex) => itemIndex === index ? next : item) })), onRemove: () => updateQuery((query) => ({ ...query, filters: (query.filters ?? []).filter((_, itemIndex) => itemIndex !== index) })) }, index)) })] }), _jsx("div", { className: "app-scroll min-h-0 overflow-y-auto bg-bg-subtle p-5", children: _jsxs("div", { className: "space-y-4", children: [_jsx("div", { className: "flex flex-wrap gap-1.5", children: FLAT_VISUALIZATIONS.map((key) => _jsxs("button", { type: "button", onClick: () => update((current) => ({ ...current, visualization: key })), className: cn('flex items-center gap-1.5 rounded-md border px-3 py-2 text-sm transition [&_svg]:size-4', draft.visualization === key ? 'border-primary bg-primary-subtle text-primary' : 'border-border bg-surface text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [VIZ_ICONS[key], VISUALIZATIONS[key].label] }, key)) }), _jsx(VisualizationSettingsPanel, { visualization: draft.visualization, settings: draft.visualizationSettings, result: preview, onChange: (visualizationSettings) => update((current) => ({ ...current, visualizationSettings })) }), _jsxs("div", { className: "relative min-h-[420px] rounded-xl border border-border bg-surface p-4 shadow-sm", children: [running ? _jsx("div", { className: "absolute inset-0 z-10 grid place-items-center rounded-xl bg-surface/70 backdrop-blur-sm", children: _jsxs("div", { className: "flex items-center gap-2 text-sm text-fg-muted", children: [_jsx(Loader2, { className: "size-4 animate-spin" }), "Running preview\u2026"] }) }) : null, previewError ? _jsx("div", { role: "alert", className: "grid min-h-[380px] place-items-center px-8 text-center text-sm text-danger", children: previewError }) : preview ? _jsx("div", { className: "h-[380px]", children: _jsx(InsightResultView, { result: preview, visualization: draft.visualization, settings: draft.visualizationSettings }) }) : null] }), preview ? _jsxs("div", { className: "flex items-center justify-between text-xs text-fg-subtle", children: [_jsxs("span", { children: [preview.rowCount, " rows \u00B7 ", preview.durationMs, "ms"] }), preview.truncated ? _jsx(Badge, { variant: "warning", children: "Truncated" }) : null] }) : null] }) })] }), _jsxs("footer", { className: "flex min-h-12 shrink-0 items-center justify-between gap-3 border-t border-border bg-surface px-5 text-xs text-fg-muted", children: [_jsx("span", { children: saveState === 'saving' ? 'Saving changes…' : saveState === 'error' ? saveError : 'All changes saved' }), _jsxs("div", { className: "flex gap-2", children: [onDelete ? _jsxs(Button, { type: "button", variant: "ghost", size: "sm", className: "text-danger", onClick: async () => { await onDelete(draft); }, children: [_jsx(Trash2, { size: 14 }), "Delete"] }) : null, onPublishChange ? _jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: async () => { const published = draft.status !== 'published'; const result = await onPublishChange(published, draft); if (result.ok)
                                    update((current) => ({ ...current, status: published ? 'published' : 'draft', id: result.id ?? current.id })); }, children: draft.status === 'published' ? 'Unpublish' : 'Publish' }) : null] })] })] });
}
function StudioSection({ title, onAdd, children }) {
    return _jsxs("section", { className: "space-y-2", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: title }), _jsxs(Button, { type: "button", variant: "ghost", size: "sm", onClick: onAdd, children: [_jsx(Plus, { size: 13 }), "Add"] })] }), _jsx("div", { className: "space-y-2", children: children })] });
}
function MeasureRow({ measure, fields, error, onChange, onFormulaError, onRemove }) {
    if (measure.kind === 'formula')
        return _jsx(FormulaRow, { measure: measure, fields: fields, error: error, onChange: onChange, onError: onFormulaError, onRemove: onRemove });
    return _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(SearchSelect, { className: "w-32", value: measure.fn, onChange: (fn) => onChange({ ...measure, fn: fn, field: fn === 'count' ? undefined : measure.field ?? fields.find((field) => field.canMeasure ?? ['number', 'currency'].includes(field.semanticType))?.key }), options: ['count', 'count_distinct', 'sum', 'avg', 'min', 'max'].map((value) => ({ value, label: value.replace('_', ' ') })) }), measure.fn !== 'count' ? _jsx(SearchSelect, { className: "min-w-0 flex-1", value: measure.field ?? '', onChange: (field) => onChange({ ...measure, field }), options: fields.filter((field) => measure.fn === 'count_distinct' || (field.canMeasure ?? ['number', 'currency'].includes(field.semanticType))).map((field) => ({ value: field.key, label: field.label })) }) : _jsx("div", { className: "flex-1 rounded-md border border-border bg-bg-subtle px-3 py-2 text-sm text-fg-muted", children: "Rows" }), _jsx(IconButton, { label: "Remove measure", onClick: onRemove })] });
}
function FormulaRow({ measure, fields, error, onChange, onError, onRemove }) {
    const [formula, setFormula] = React.useState(() => serializeFormula(measure.formula, (key) => fields.find((field) => field.key === key)?.label ?? key));
    function parse(value) {
        setFormula(value);
        const parsed = parseFormula(value, { resolveField: (label) => fields.find((field) => field.label.toLowerCase() === label.toLowerCase() || field.key === label)?.key ?? null });
        if (parsed.ok) {
            onError('');
            onChange({ ...measure, formula: parsed.expression });
        }
        else
            onError(`${parsed.error} at character ${parsed.position + 1}`);
    }
    return _jsxs("div", { className: "space-y-1.5 rounded-lg border border-border bg-bg-subtle p-2.5", children: [_jsxs("div", { className: "flex gap-2", children: [_jsx(Input, { value: measure.label ?? measure.alias, onChange: (event) => onChange({ ...measure, label: event.target.value, alias: event.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '_') || 'custom_metric' }), "aria-label": "Formula label", className: "h-9" }), _jsx(IconButton, { label: "Remove formula", onClick: onRemove })] }), _jsx(Textarea, { value: formula, onChange: (event) => parse(event.target.value), "aria-invalid": !!error, className: "min-h-20 font-mono text-xs", "aria-label": "Formula expression" }), error ? _jsx("p", { className: "text-xs text-danger", children: error }) : _jsx("p", { className: "text-[11px] text-fg-subtle", children: "Use fields like [Created at] and functions such as count(), sum(), datediff(), and case()." })] });
}
function FilterRow({ filter, fields, onChange, onRemove }) {
    const selectedField = fields.find((field) => field.key === filter.field) ?? fields[0];
    const operators = selectedField ? filterOperatorsForField(selectedField) : [...FILTER_OPERATORS];
    return _jsxs("div", { className: "space-y-2 rounded-lg border border-border bg-bg-subtle p-2.5", children: [_jsxs("div", { className: "flex gap-2", children: [_jsx(SearchSelect, { className: "min-w-0 flex-1", value: filter.field, onChange: (field) => { const nextField = fields.find((item) => item.key === field); const allowed = nextField ? filterOperatorsForField(nextField) : []; onChange({ ...filter, field, operator: allowed.includes(filter.operator) ? filter.operator : 'eq' }); }, options: fields.map((field) => ({ value: field.key, label: field.label })) }), _jsx(IconButton, { label: "Remove filter", onClick: onRemove })] }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(SearchSelect, { value: filter.operator, onChange: (operator) => onChange({ ...filter, operator: operator, value: NO_VALUE_FILTERS.has(operator) ? undefined : filter.value }), options: operators.map((operator) => ({ value: operator, label: FILTER_LABELS[operator] })) }), NO_VALUE_FILTERS.has(filter.operator) ? _jsx("div", {}) : _jsx(Input, { value: Array.isArray(filter.value) ? filter.value.join(', ') : String(filter.value ?? ''), onChange: (event) => onChange({ ...filter, value: filter.operator === 'in' || filter.operator === 'not_in' ? event.target.value.split(',').map((value) => value.trim()).filter(Boolean) : filter.operator === 'last_n_days' ? Number(event.target.value) : event.target.value }), placeholder: "Value" })] })] });
}
function VisualizationSettingsPanel({ visualization, settings, result, onChange }) {
    const measures = result?.columns.filter((column) => column.role === 'measure') ?? [];
    if (visualization === 'table')
        return null;
    return _jsxs("div", { className: "flex flex-wrap items-end gap-4 rounded-xl border border-border bg-surface p-3", children: [_jsxs("div", { className: "min-w-40 space-y-1", children: [_jsx(Label, { children: "Value" }), _jsx(SearchSelect, { value: typeof settings.valueField === 'string' ? settings.valueField : '', onChange: (valueField) => onChange({ ...settings, valueField }), options: [{ value: '', label: 'Auto' }, ...measures.map((measure) => ({ value: measure.key, label: measure.label }))] })] }), visualization === 'progress' || visualization === 'gauge' ? _jsxs("div", { className: "w-28 space-y-1", children: [_jsx(Label, { children: "Goal" }), _jsx(Input, { type: "number", value: Number(settings.goal ?? 100), onChange: (event) => onChange({ ...settings, goal: Number(event.target.value) }) })] }) : null, ['bar', 'row', 'line', 'area'].includes(visualization) ? _jsxs("label", { className: "flex items-center gap-2 pb-2 text-sm", children: [_jsx(Checkbox, { checked: settings.showValues === true, onChange: (event) => onChange({ ...settings, showValues: event.target.checked }) }), "Values"] }) : null] });
}
function IconButton({ label, onClick }) {
    return _jsx("button", { type: "button", "aria-label": label, onClick: onClick, className: "grid size-9 shrink-0 place-items-center rounded-md text-fg-subtle transition hover:bg-surface-hover hover:text-danger", children: _jsx(Trash2, { size: 14 }) });
}
//# sourceMappingURL=card-studio.js.map