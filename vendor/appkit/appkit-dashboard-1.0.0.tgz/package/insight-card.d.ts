import * as React from 'react';
import { type AnalyticResult, type QueryResult, type VisualizationKey, type VisualizationSettings } from '@appkit/analytics';
export declare function DashboardMetricCard({ label, value, detail, icon, trend, tone, className }: {
    label: string;
    value: React.ReactNode;
    detail?: React.ReactNode;
    icon?: React.ReactNode;
    trend?: React.ReactNode;
    tone?: 'primary' | 'info' | 'success' | 'warning' | 'danger';
    className?: string;
}): React.JSX.Element;
export declare function DashboardPanel({ title, icon, actions, children, className }: {
    title: React.ReactNode;
    icon?: React.ReactNode;
    actions?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
}): React.JSX.Element;
export declare function InsightCard({ title, description, result, visualization, settings, className }: {
    title: string;
    description?: string | null;
    result: QueryResult;
    visualization: VisualizationKey;
    settings?: VisualizationSettings;
    className?: string;
}): React.JSX.Element;
export declare function InsightResultView({ result, visualization, settings }: {
    result: QueryResult;
    visualization: VisualizationKey;
    settings?: VisualizationSettings;
}): React.JSX.Element;
export declare function AdvancedInsightResultView({ result, visualization, settings }: {
    result: AnalyticResult;
    visualization: VisualizationKey;
    settings?: VisualizationSettings;
}): React.JSX.Element;
//# sourceMappingURL=insight-card.d.ts.map