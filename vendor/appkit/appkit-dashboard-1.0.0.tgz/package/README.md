# @appkit/dashboard

Optional dashboard layouts, insight cards, visual studio, and feature-owned persistence.

## Install

```bash
pnpm add @appkit/dashboard
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
