import { sql } from 'drizzle-orm';
import { boolean, index, jsonb, pgTable, text, timestamp, uniqueIndex, uuid } from 'drizzle-orm/pg-core';
import { id, tenantRef } from '@appkit/db';
/** One personal dashboard per user and tenant, including role-default lineage. */
export const userDashboardLayouts = pgTable('user_dashboard_layouts', {
    id: id(),
    tenantId: tenantRef(),
    userId: uuid('user_id').notNull(),
    layout: jsonb('layout').$type().notNull().default(sql `'{"widgets":[]}'::jsonb`),
    sourceRole: text('source_role'),
    isCustomized: boolean('is_customized').notNull().default(true),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
    uniqueIndex('user_dashboard_layouts_tenant_user_key').on(table.tenantId, table.userId),
    index('user_dashboard_layouts_tenant_idx').on(table.tenantId),
]);
/** Saved semantic query + visualization. Cards are library items and dashboard widgets. */
export const insightCards = pgTable('insight_cards', {
    id: id(),
    tenantId: tenantRef(),
    ownerUserId: uuid('owner_user_id').notNull(),
    name: text('name').notNull(),
    description: text('description'),
    query: jsonb('query').$type().notNull(),
    visualization: text('visualization').$type().notNull().default('table'),
    visualizationSettings: jsonb('visualization_settings').$type().notNull().default(sql `'{}'::jsonb`),
    status: text('status').$type().notNull().default('draft'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
    index('insight_cards_tenant_owner_idx').on(table.tenantId, table.ownerUserId),
    index('insight_cards_tenant_status_idx').on(table.tenantId, table.status),
]);
export const DASHBOARD_TENANT_TABLES = ['user_dashboard_layouts', 'insight_cards'];
//# sourceMappingURL=schema.js.map