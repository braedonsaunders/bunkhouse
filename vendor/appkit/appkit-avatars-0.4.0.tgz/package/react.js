// Client entry — the composition surface.
//
// Kept separate from the package root so that importing a renderer never pulls
// the AI SDK provider factories (and their server credentials path) into a
// browser bundle. Pure composition types and helpers live at
// `@appkit/avatars/composition`, which both entries share.
export { ComposedAvatar, } from './react/composed-avatar.js';
export { AvatarComposer } from './react/avatar-composer.js';
export { ComposerStage } from './react/composer-stage.js';
export { PartLibraryPanel } from './react/part-library-panel.js';
export { LayerPanel } from './react/layer-panel.js';
export { TransformControls } from './react/transform-controls.js';
export { useCompositionState } from './react/use-composition-state.js';
//# sourceMappingURL=react.js.map