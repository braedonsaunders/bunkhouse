'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Redo2, RotateCcw, Undo2 } from 'lucide-react';
import { Alert, AlertDescription, Badge, Button, SubtabNav } from '@appkit/ui';
import { missingRequiredCategories, } from '../composition.js';
import { ComposedAvatar } from './composed-avatar.js';
import { ComposerStage } from './composer-stage.js';
import { LayerPanel } from './layer-panel.js';
import { PartLibraryPanel } from './part-library-panel.js';
import { TransformControls } from './transform-controls.js';
import { useCompositionState } from './use-composition-state.js';
/**
 * The avatar composer — library on the left, stage in the middle, layer stack
 * and transform on the right.
 *
 * Ported from OpenStudio's `AvatarCanvasEditor`, which owned its own data
 * fetching, its own save endpoint, and a Konva export step. Here the component
 * is pure: it takes the library and the composition, and reports every edit
 * through `onChange`. Persistence, generation, and authorization belong to the
 * application.
 */
export function AvatarComposer({ composition: initialComposition, parts, categories, onChange, onSave, saving, saveLabel = 'Save avatar', stageWidth = 340, subjectName, generateAction, }) {
    const state = useCompositionState(initialComposition, categories);
    const [mode, setMode] = React.useState('compose');
    const { composition } = state;
    const changeRef = React.useRef(onChange);
    changeRef.current = onChange;
    const firstRender = React.useRef(true);
    React.useEffect(() => {
        if (firstRender.current) {
            firstRender.current = false;
            return;
        }
        changeRef.current?.(composition);
    }, [composition]);
    const placedPartIds = React.useMemo(() => new Set(Object.values(composition.parts).map((placement) => placement.partId)), [composition]);
    const missing = React.useMemo(() => missingRequiredCategories(composition, categories), [composition, categories]);
    const selectedCategory = categories.find((category) => category.id === state.selectedCategoryId);
    return (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [_jsx(SubtabNav, { tabs: [
                            { key: 'compose', label: 'Compose' },
                            { key: 'headFraming', label: 'Head framing' },
                        ], active: mode, onSelect: (key) => {
                            setMode(key);
                            state.select(null);
                        }, ariaLabel: "Composer mode" }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Button, { type: "button", variant: "ghost", size: "sm", title: "Undo", disabled: !state.canUndo, onClick: state.undo, children: _jsx(Undo2, { className: "size-4" }) }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", title: "Redo", disabled: !state.canRedo, onClick: state.redo, children: _jsx(Redo2, { className: "size-4" }) }), _jsxs(Button, { type: "button", variant: "ghost", size: "sm", title: "Clear the figure", onClick: state.reset, children: [_jsx(RotateCcw, { className: "mr-1.5 size-4" }), " Clear"] }), onSave ? (_jsx(Button, { type: "button", disabled: saving, onClick: () => onSave(composition), children: saving ? 'Saving…' : saveLabel })) : null] })] }), parts.length === 0 ? (_jsx(Alert, { children: _jsxs(AlertDescription, { className: "flex flex-wrap items-center gap-3", children: [_jsx("span", { children: "The parts library is empty \u2014 generate a set of parts and the figure builds from them." }), generateAction] }) })) : null, _jsxs("div", { className: "grid gap-4 xl:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)]", children: [_jsx("div", { className: "min-h-0 xl:h-[36rem]", children: _jsx(PartLibraryPanel, { categories: categories, parts: parts, placedPartIds: placedPartIds, activeCategoryId: state.selectedCategoryId, onPlace: state.place }) }), _jsxs("div", { className: "flex flex-col items-center gap-3", children: [_jsx(ComposerStage, { composition: composition, parts: parts, categories: categories, selectedCategoryId: state.selectedCategoryId, mode: mode, width: stageWidth, onSelect: state.select, onTransform: state.transform, onHeadViewport: state.setHeadViewport }), _jsx("p", { className: "max-w-[22rem] text-center text-xs text-fg-muted", children: mode === 'compose'
                                    ? 'Drag a part to move it, the corners to scale, the top handle to rotate. Hold Shift to bypass snapping.'
                                    : 'Drag the frame over the face. Every portrait in the app is this crop of the figure — there is no second image.' })] }), _jsxs("div", { className: "flex min-h-0 flex-col gap-3 xl:h-[36rem]", children: [_jsx("div", { className: "min-h-0 flex-1", children: _jsx(LayerPanel, { composition: composition, orderedCategoryIds: state.orderedCategoryIds, categories: categories, parts: parts, selectedCategoryId: state.selectedCategoryId, onSelect: state.select, onRemove: state.remove, onReorder: state.reorder, onSetColorVariant: state.setColorVariant, onSetOpacity: state.setOpacity, onSetHidden: state.setHidden }) }), _jsx(TransformControls, { categoryId: state.selectedCategoryId, category: selectedCategory, placement: state.selectedCategoryId ? composition.parts[state.selectedCategoryId] : undefined, onTransform: state.transform })] })] }), _jsxs("div", { className: "flex flex-wrap items-center gap-4 rounded-lg border border-border bg-surface p-3", children: [_jsxs("div", { className: "flex items-center gap-3", children: [_jsx(ComposedAvatar, { composition: composition, parts: parts, categories: categories, variant: "head", size: 56, rounded: true, ...(subjectName ? { name: subjectName } : {}) }), _jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-fg", children: "Portrait" }), _jsx("p", { className: "text-xs text-fg-muted", children: "Directory rows, record headers, calls." })] })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx(ComposedAvatar, { composition: composition, parts: parts, categories: categories, variant: "full", size: 56, animate: "idle", ...(subjectName ? { name: subjectName } : {}) }), _jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-fg", children: "Standing" }), _jsx("p", { className: "text-xs text-fg-muted", children: "The lobby and any scene." })] })] }), missing.length > 0 ? (_jsxs(Badge, { variant: "outline", className: "ml-auto", children: ["still to place: ", missing.map((category) => category.label.toLowerCase()).join(', ')] })) : null] })] }));
}
//# sourceMappingURL=avatar-composer.js.map