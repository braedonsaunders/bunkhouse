'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { CANVAS_HEIGHT, CANVAS_WIDTH, clampHeadViewport, resolvePartUrl, sortLayers, } from '../composition.js';
/**
 * The stage — direct manipulation of the composition.
 *
 * Ported from OpenStudio's `CanvasWorkspace`, which drove a Konva `<Stage>`
 * with a `<Transformer>`: drag the part to move, corner anchors to resize, a
 * handle to rotate. This is the same interaction on DOM nodes and pointer
 * events, for the reason the renderer is DOM too — one code path paints the
 * composition in the editor, in a list row, and on a call, so what an operator
 * arranges is exactly what ships.
 *
 * Coordinates are canvas units throughout (see `composition.ts`); the stage
 * only scales them for display, so nothing stored depends on the editor size.
 */
/** Snap tolerance in canvas units for the centre line and the unit grid. */
const CENTER_SNAP = 8;
const GRID = 4;
export function ComposerStage({ composition, parts, categories, selectedCategoryId, mode, width, onSelect, onTransform, onHeadViewport, }) {
    const k = width / CANVAS_WIDTH;
    const height = CANVAS_HEIGHT * k;
    const stageRef = React.useRef(null);
    const [guides, setGuides] = React.useState({ centerX: false });
    const layers = React.useMemo(() => sortLayers(composition, parts, categories, { includeHidden: true }), [composition, parts, categories]);
    /** Pointer position in canvas units. */
    const toCanvas = React.useCallback((event) => {
        const rect = stageRef.current?.getBoundingClientRect();
        if (!rect)
            return { x: 0, y: 0 };
        return { x: (event.clientX - rect.left) / k, y: (event.clientY - rect.top) / k };
    }, [k]);
    const selected = selectedCategoryId ? composition.parts[selectedCategoryId] : undefined;
    const selectedCategory = categories.find((c) => c.id === selectedCategoryId);
    const selectedBox = selected && selectedCategory
        ? {
            left: selected.transform.x,
            top: selected.transform.y,
            width: selectedCategory.frame.width * selected.transform.scale,
            height: selectedCategory.frame.height * selected.transform.scale,
            rotation: selected.transform.rotation,
        }
        : null;
    /** Shared pointer-drag driver: capture, stream deltas, commit on release. */
    const drag = React.useCallback((event, onMove, onEnd) => {
        event.preventDefault();
        event.stopPropagation();
        const move = (native) => onMove(toCanvas(native), native.shiftKey);
        const up = () => {
            window.removeEventListener('pointermove', move);
            window.removeEventListener('pointerup', up);
            setGuides({ centerX: false });
            onEnd?.();
        };
        window.addEventListener('pointermove', move);
        window.addEventListener('pointerup', up);
    }, [toCanvas]);
    const startMove = (event, categoryId) => {
        const placement = composition.parts[categoryId];
        const category = categories.find((c) => c.id === categoryId);
        if (!placement || !category)
            return;
        onSelect(categoryId);
        const origin = toCanvas(event);
        const start = { ...placement.transform };
        const boxWidth = category.frame.width * start.scale;
        drag(event, (canvas, shift) => {
            let x = start.x + (canvas.x - origin.x);
            let y = start.y + (canvas.y - origin.y);
            if (!shift) {
                x = Math.round(x / GRID) * GRID;
                y = Math.round(y / GRID) * GRID;
                // Snap the part's own centre to the stage centre line.
                const centre = x + boxWidth / 2;
                if (Math.abs(centre - CANVAS_WIDTH / 2) < CENTER_SNAP) {
                    x = CANVAS_WIDTH / 2 - boxWidth / 2;
                    setGuides({ centerX: true });
                }
                else
                    setGuides({ centerX: false });
            }
            onTransform(categoryId, { x, y }, false);
        }, () => onTransform(categoryId, {}, true));
    };
    const startScale = (event, categoryId) => {
        const placement = composition.parts[categoryId];
        const category = categories.find((c) => c.id === categoryId);
        if (!placement || !category)
            return;
        const start = { ...placement.transform };
        const centre = {
            x: start.x + (category.frame.width * start.scale) / 2,
            y: start.y + (category.frame.height * start.scale) / 2,
        };
        const origin = toCanvas(event);
        const startDistance = Math.hypot(origin.x - centre.x, origin.y - centre.y) || 1;
        drag(event, (canvas) => {
            const distance = Math.hypot(canvas.x - centre.x, canvas.y - centre.y);
            const scale = Math.min(4, Math.max(0.1, (start.scale * distance) / startDistance));
            // Scale about the centre so the part does not walk across the stage.
            onTransform(categoryId, {
                scale,
                x: centre.x - (category.frame.width * scale) / 2,
                y: centre.y - (category.frame.height * scale) / 2,
            }, false);
        }, () => onTransform(categoryId, {}, true));
    };
    const startRotate = (event, categoryId) => {
        const placement = composition.parts[categoryId];
        const category = categories.find((c) => c.id === categoryId);
        if (!placement || !category)
            return;
        const start = { ...placement.transform };
        const centre = {
            x: start.x + (category.frame.width * start.scale) / 2,
            y: start.y + (category.frame.height * start.scale) / 2,
        };
        const origin = toCanvas(event);
        const startAngle = Math.atan2(origin.y - centre.y, origin.x - centre.x);
        drag(event, (canvas, shift) => {
            const angle = Math.atan2(canvas.y - centre.y, canvas.x - centre.x);
            let rotation = start.rotation + ((angle - startAngle) * 180) / Math.PI;
            rotation = ((rotation + 180) % 360) - 180;
            if (!shift)
                rotation = Math.round(rotation / 5) * 5;
            onTransform(categoryId, { rotation }, false);
        }, () => onTransform(categoryId, {}, true));
    };
    const startViewportMove = (event) => {
        const start = { ...composition.headViewport };
        const origin = toCanvas(event);
        drag(event, (canvas) => onHeadViewport(clampHeadViewport({
            ...start,
            x: start.x + (canvas.x - origin.x),
            y: start.y + (canvas.y - origin.y),
        }), false), () => onHeadViewport(composition.headViewport, true));
    };
    const startViewportResize = (event, corner) => {
        const start = { ...composition.headViewport };
        const origin = toCanvas(event);
        drag(event, (canvas) => {
            const dx = canvas.x - origin.x;
            // The head frame stays square: a portrait frame is square, and a
            // non-square crop would letterbox in every list row. The horizontal
            // drag drives both axes.
            const delta = corner === 'nw' || corner === 'sw' ? -dx : dx;
            const size = Math.max(40, start.width + delta);
            const next = {
                width: size,
                height: size,
                x: corner === 'nw' || corner === 'sw' ? start.x + start.width - size : start.x,
                y: corner === 'nw' || corner === 'ne' ? start.y + start.height - size : start.y,
            };
            onHeadViewport(clampHeadViewport(next), false);
        }, () => onHeadViewport(composition.headViewport, true));
    };
    const viewport = composition.headViewport;
    return (_jsxs("div", { ref: stageRef, className: "relative shrink-0 overflow-hidden rounded-lg border border-border", style: {
            width,
            height,
            // Checkerboard: the parts are alpha-cut, so the stage must read as empty.
            backgroundImage: 'linear-gradient(45deg, var(--color-border) 25%, transparent 25%), linear-gradient(-45deg, var(--color-border) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, var(--color-border) 75%), linear-gradient(-45deg, transparent 75%, var(--color-border) 75%)',
            backgroundSize: '16px 16px',
            backgroundPosition: '0 0, 0 8px, 8px -8px, -8px 0px',
            backgroundColor: 'var(--color-bg-subtle)',
            touchAction: 'none',
        }, onPointerDown: (event) => {
            if (event.target === stageRef.current)
                onSelect(null);
        }, children: [layers.map((layer) => (_jsx("div", { onPointerDown: (event) => mode === 'compose' && startMove(event, layer.categoryId), className: mode === 'compose' ? 'cursor-move' : 'pointer-events-none', style: {
                    position: 'absolute',
                    left: layer.box.left * k,
                    top: layer.box.top * k,
                    width: layer.box.width * k,
                    height: layer.box.height * k,
                    transform: `rotate(${layer.placement.transform.rotation}deg)`,
                    opacity: layer.placement.hidden ? 0.18 : layer.opacity,
                }, children: _jsx("img", { src: resolvePartUrl(layer.part, layer.placement.colorVariant), alt: "", draggable: false, className: "pointer-events-none h-full w-full select-none object-contain" }) }, layer.categoryId))), guides.centerX ? (_jsx("div", { className: "pointer-events-none absolute inset-y-0 left-1/2 w-px bg-primary/70" })) : null, mode === 'compose' && selectedBox && selectedCategoryId ? (_jsxs("div", { className: "pointer-events-none absolute border-2 border-primary", style: {
                    left: selectedBox.left * k,
                    top: selectedBox.top * k,
                    width: selectedBox.width * k,
                    height: selectedBox.height * k,
                    transform: `rotate(${selectedBox.rotation}deg)`,
                }, children: [CORNERS.map((corner) => (_jsx("button", { type: "button", "aria-label": `Scale from ${corner}`, onPointerDown: (event) => startScale(event, selectedCategoryId), className: "pointer-events-auto absolute size-3 cursor-nwse-resize rounded-full border-2 border-primary bg-surface", style: cornerStyle(corner) }, corner))), _jsx("button", { type: "button", "aria-label": "Rotate", onPointerDown: (event) => startRotate(event, selectedCategoryId), className: "pointer-events-auto absolute -top-7 left-1/2 size-3 -translate-x-1/2 cursor-grab rounded-full border-2 border-primary bg-surface" }), _jsx("span", { className: "absolute -top-5 left-1/2 h-5 w-px -translate-x-1/2 bg-primary" })] })) : null, mode === 'headFraming' ? (_jsxs(_Fragment, { children: [_jsx("div", { className: "pointer-events-none absolute inset-0 bg-bg/70" }), _jsx("div", { className: "pointer-events-none absolute overflow-hidden", style: {
                            left: viewport.x * k,
                            top: viewport.y * k,
                            width: viewport.width * k,
                            height: viewport.height * k,
                        }, children: _jsx("div", { className: "absolute", style: { left: -viewport.x * k, top: -viewport.y * k, width, height }, children: layers
                                .filter((layer) => !layer.placement.hidden)
                                .map((layer) => (_jsx("div", { style: {
                                    position: 'absolute',
                                    left: layer.box.left * k,
                                    top: layer.box.top * k,
                                    width: layer.box.width * k,
                                    height: layer.box.height * k,
                                    transform: `rotate(${layer.placement.transform.rotation}deg)`,
                                    opacity: layer.opacity,
                                }, children: _jsx("img", { src: resolvePartUrl(layer.part, layer.placement.colorVariant), alt: "", className: "h-full w-full object-contain" }) }, layer.categoryId))) }) }), _jsx("div", { onPointerDown: startViewportMove, className: "absolute cursor-move border-2 border-primary", style: {
                            left: viewport.x * k,
                            top: viewport.y * k,
                            width: viewport.width * k,
                            height: viewport.height * k,
                        }, children: CORNERS.map((corner) => (_jsx("button", { type: "button", "aria-label": `Resize head frame from ${corner}`, onPointerDown: (event) => startViewportResize(event, corner), className: "absolute size-3 cursor-nwse-resize rounded-full border-2 border-primary bg-surface", style: cornerStyle(corner) }, corner))) })] })) : null] }));
}
const CORNERS = ['nw', 'ne', 'sw', 'se'];
function cornerStyle(corner) {
    return {
        left: corner === 'nw' || corner === 'sw' ? -6 : undefined,
        right: corner === 'ne' || corner === 'se' ? -6 : undefined,
        top: corner === 'nw' || corner === 'ne' ? -6 : undefined,
        bottom: corner === 'sw' || corner === 'se' ? -6 : undefined,
    };
}
//# sourceMappingURL=composer-stage.js.map