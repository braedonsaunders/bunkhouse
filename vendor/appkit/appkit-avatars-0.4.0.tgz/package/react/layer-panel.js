'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronDown, ChevronUp, Eye, EyeOff, Palette, Trash2 } from 'lucide-react';
import { Slider } from '@appkit/ui';
import { resolvePartUrl } from '../composition.js';
/**
 * The layer stack — the composer's right rail.
 *
 * Ported from OpenStudio's `LayerPanel`: top layer first, thumbnail, name and
 * slot, a colour-variant tray with an opacity slider, and per-layer remove.
 * Drag-to-reorder is replaced by explicit up/down controls — the same
 * operation, but keyboard-reachable and unambiguous on touch, which HTML5
 * drag-and-drop reordering is not.
 */
export function LayerPanel({ composition, orderedCategoryIds, categories, parts, selectedCategoryId, onSelect, onRemove, onReorder, onSetColorVariant, onSetOpacity, onSetHidden, }) {
    const [openVariants, setOpenVariants] = React.useState(null);
    const categoriesById = React.useMemo(() => new Map(categories.map((c) => [c.id, c])), [categories]);
    const partsById = React.useMemo(() => new Map(parts.map((p) => [p.id, p])), [parts]);
    // Top of the stack reads first, as in every layer list.
    const rows = [...orderedCategoryIds].reverse();
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col rounded-lg border border-border bg-surface", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-border px-3 py-2", children: [_jsx("h3", { className: "text-sm font-medium text-fg", children: "Layers" }), _jsx("span", { className: "text-xs text-fg-muted", children: rows.length })] }), _jsx("div", { className: "min-h-0 flex-1 overflow-y-auto", children: rows.length === 0 ? (_jsx("p", { className: "p-4 text-sm text-fg-muted", children: "Nothing placed yet. Pick a part from the library to start the figure." })) : (rows.map((categoryId, index) => {
                    const placement = composition.parts[categoryId];
                    const category = categoriesById.get(categoryId);
                    const part = partsById.get(placement.partId);
                    const selected = selectedCategoryId === categoryId;
                    const variants = part?.colorVariants ? Object.keys(part.colorVariants) : [];
                    return (_jsxs("div", { className: "border-b border-border last:border-b-0", children: [_jsxs("div", { role: "button", tabIndex: 0, onClick: () => onSelect(selected ? null : categoryId), onKeyDown: (event) => {
                                    if (event.key === 'Enter' || event.key === ' ') {
                                        event.preventDefault();
                                        onSelect(selected ? null : categoryId);
                                    }
                                }, className: `flex cursor-pointer items-center gap-2 p-2 transition-colors ${selected ? 'bg-primary-subtle' : 'hover:bg-bg-subtle'}`, children: [_jsx("div", { className: "size-9 shrink-0 overflow-hidden rounded border border-border bg-bg-subtle", children: part ? (
                                        // eslint-disable-next-line @next/next/no-img-element
                                        _jsx("img", { src: resolvePartUrl(part, placement.colorVariant), alt: "", className: "h-full w-full object-contain" })) : null }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("p", { className: "truncate text-sm font-medium text-fg", children: part?.name ?? 'Part no longer in the library' }), _jsx("p", { className: "truncate text-xs text-fg-muted", children: category?.label ?? categoryId })] }), _jsxs("div", { className: "flex items-center gap-0.5", children: [_jsx(IconButton, { label: "Move up", disabled: index === 0, onClick: () => onReorder(categoryId, 'up'), children: _jsx(ChevronUp, { className: "size-4" }) }), _jsx(IconButton, { label: "Move down", disabled: index === rows.length - 1, onClick: () => onReorder(categoryId, 'down'), children: _jsx(ChevronDown, { className: "size-4" }) }), _jsx(IconButton, { label: placement.hidden ? 'Show layer' : 'Hide layer', onClick: () => onSetHidden(categoryId, !placement.hidden), children: placement.hidden ? _jsx(EyeOff, { className: "size-4" }) : _jsx(Eye, { className: "size-4" }) }), variants.length > 0 ? (_jsx(IconButton, { label: "Colour", active: openVariants === categoryId, onClick: () => setOpenVariants((v) => (v === categoryId ? null : categoryId)), children: _jsx(Palette, { className: "size-4" }) })) : null, _jsx(IconButton, { label: "Remove layer", tone: "danger", onClick: () => onRemove(categoryId), children: _jsx(Trash2, { className: "size-4" }) })] })] }), openVariants === categoryId ? (_jsxs("div", { className: "space-y-3 border-t border-border bg-bg-subtle p-3", children: [_jsxs("div", { className: "flex flex-wrap gap-1.5", children: [_jsx(VariantChip, { label: "Original", active: !placement.colorVariant, onClick: () => onSetColorVariant(categoryId, null) }), variants.map((variant) => (_jsx(VariantChip, { label: variant, active: placement.colorVariant === variant, onClick: () => onSetColorVariant(categoryId, variant) }, variant)))] }), _jsxs("div", { children: [_jsxs("label", { className: "mb-1 block text-xs text-fg-muted", children: ["Opacity ", Math.round((placement.opacity ?? 1) * 100), "%"] }), _jsx(Slider, { min: 0, max: 100, value: Math.round((placement.opacity ?? 1) * 100), onChange: (event) => onSetOpacity(categoryId, Number(event.target.value) / 100, false), onPointerUp: () => onSetOpacity(categoryId, placement.opacity ?? 1, true) })] })] })) : null] }, categoryId));
                })) })] }));
}
function IconButton({ label, onClick, children, disabled, active, tone, }) {
    return (_jsx("button", { type: "button", title: label, "aria-label": label, disabled: disabled, onClick: (event) => {
            event.stopPropagation();
            onClick();
        }, className: `rounded p-1.5 transition-colors disabled:cursor-not-allowed disabled:opacity-40 ${active
            ? 'bg-primary-subtle text-primary'
            : tone === 'danger'
                ? 'text-fg-muted hover:bg-danger-subtle hover:text-danger'
                : 'text-fg-muted hover:bg-bg-subtle hover:text-fg'}`, children: children }));
}
function VariantChip({ label, active, onClick, }) {
    return (_jsx("button", { type: "button", onClick: onClick, className: `rounded-full border px-2.5 py-1 text-xs capitalize transition-colors ${active
            ? 'border-primary bg-primary-subtle text-primary'
            : 'border-border text-fg-muted hover:border-primary hover:text-fg'}`, children: label }));
}
//# sourceMappingURL=layer-panel.js.map