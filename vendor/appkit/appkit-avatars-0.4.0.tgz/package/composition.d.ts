/** Full-body stage width, in canvas units. */
export declare const CANVAS_WIDTH = 512;
/** Full-body stage height, in canvas units. */
export declare const CANVAS_HEIGHT = 768;
/**
 * Where one part sits on the stage.
 *
 * `x`/`y` are the **top-left** of the part's frame (the category's
 * {@link AvatarPartCategory.frame}) in canvas units — the same anchor
 * OpenStudio's `renderX`/`renderY` used. `scale` multiplies that frame, and
 * `rotation` is degrees clockwise **about the frame's centre**.
 *
 * (OpenStudio rotated about the top-left origin, inherited from Konva's node
 * model, which swings a part away from the pointer as it turns. Rotating about
 * the centre is the same data with the pivot moved to where a person expects
 * it; nothing else about the transform changed.)
 */
export type AvatarPartTransform = {
    x: number;
    y: number;
    scale: number;
    rotation: number;
};
/**
 * A slot on the figure. Categories are the app's vocabulary — body, hair,
 * outfit — and they carry the layer order and the placement a freshly added
 * part starts from, so a library drops onto the stage already assembled.
 */
export type AvatarPartCategory = {
    id: string;
    label: string;
    /** Lower paints first (behind). Ported from OpenStudio's `layerOrder`. */
    layerOrder: number;
    /** A composition without this category is incomplete. */
    required?: boolean;
    /** Whether parts in this category ship recoloured variants. */
    supportsColorVariants?: boolean;
    /** The part's natural box in canvas units at `scale: 1`. */
    frame: {
        width: number;
        height: number;
    };
    /** Where a newly placed part of this category lands. */
    defaultTransform: AvatarPartTransform;
    /**
     * Category-specific art direction appended to the generation prompt —
     * OpenStudio's `promptAddition`, kept because a library is only as coherent
     * as the sentence that produced it.
     */
    promptAddition?: string;
};
/** One drawable asset in the library. */
export type AvatarPart = {
    id: string;
    categoryId: string;
    name: string;
    /** The base artwork. Alpha-cut PNG — parts stack, so they must be cut out. */
    imageUrl: string;
    /** Recoloured takes, keyed by variant name (`{ black: url, blonde: url }`). */
    colorVariants?: Record<string, string>;
    tags?: string[];
};
/** A part placed on the stage. */
export type AvatarPartPlacement = {
    partId: string;
    colorVariant?: string;
    transform: AvatarPartTransform;
    /** Hidden layers stay in the composition but are not painted. */
    hidden?: boolean;
    /**
     * Paint order override. Categories carry the default order; a composition
     * only stores this when the operator has reordered layers by hand.
     */
    layerOrder?: number;
    /** 0–1. Defaults to fully opaque. */
    opacity?: number;
};
/**
 * The head crop, in canvas units, on the same stage as the parts. Rendering a
 * portrait scales and translates the composition until this rectangle fills
 * the frame — there is no second image to keep in sync.
 */
export type AvatarHeadViewport = {
    x: number;
    y: number;
    width: number;
    height: number;
};
/**
 * One subject's avatar: which part fills each category, where each sits, and
 * how to crop in on the face.
 */
export type AvatarComposition = {
    /** Schema version, so stored compositions can be migrated in place. */
    version: 1;
    /** Keyed by category id — one part per category, as OpenStudio's selections were. */
    parts: Record<string, AvatarPartPlacement>;
    headViewport: AvatarHeadViewport;
};
/**
 * A head-and-shoulders crop for a figure standing on the 512×768 stage: a
 * square roughly the top fifth of the frame, centred. Templates and the
 * composer both start here and adjust.
 */
export declare const DEFAULT_HEAD_VIEWPORT: AvatarHeadViewport;
/** An empty composition — no parts placed, default head framing. */
export declare function createEmptyComposition(headViewport?: AvatarHeadViewport): AvatarComposition;
/** One resolved layer, ready to paint. */
export type AvatarLayer = {
    categoryId: string;
    category: AvatarPartCategory;
    part: AvatarPart;
    placement: AvatarPartPlacement;
    /** The resolved artwork URL, honouring the selected colour variant. */
    url: string;
    /** Effective paint order — the placement override, else the category's. */
    order: number;
    /** The part's painted box in canvas units, before rotation. */
    box: {
        left: number;
        top: number;
        width: number;
        height: number;
    };
    opacity: number;
};
/**
 * Resolve a composition into back-to-front paint order.
 *
 * Ported from OpenStudio's compositor, which sorted the categories by
 * `layerOrder` and drew each selection at the category's fixed render box.
 * Here the placement carries its own transform, so the box is the category
 * frame scaled by the placement — free placement rather than fixed slots —
 * and the order may be overridden per layer.
 *
 * Categories and parts that no longer exist are skipped rather than thrown on:
 * a library is editable, and a person's saved composition must survive a part
 * being retired.
 */
export declare function sortLayers(composition: AvatarComposition, parts: readonly AvatarPart[], categories: readonly AvatarPartCategory[], options?: {
    includeHidden?: boolean;
}): AvatarLayer[];
/** The artwork for a part, preferring the requested colour variant. */
export declare function resolvePartUrl(part: AvatarPart, colorVariant?: string): string;
/** Place a part in its category, keeping any transform already set there. */
export declare function placePart(composition: AvatarComposition, part: AvatarPart, category: AvatarPartCategory): AvatarComposition;
/** Remove a category's part from the composition. */
export declare function removePart(composition: AvatarComposition, categoryId: string): AvatarComposition;
/**
 * Which required categories are still empty. A composition can be saved
 * incomplete — half a figure is a legitimate work in progress — but the
 * composer says so.
 */
export declare function missingRequiredCategories(composition: AvatarComposition, categories: readonly AvatarPartCategory[]): AvatarPartCategory[];
/**
 * The transform that makes a rectangle of the stage fill a frame.
 *
 * This is the whole headshot mechanism: pass {@link AvatarComposition.headViewport}
 * and the frame size, and the composition — rendered at its natural
 * {@link CANVAS_WIDTH}×{@link CANVAS_HEIGHT} — lands cropped to the head.
 * `cover` (the default) scales until the shorter viewport axis fills the
 * frame, so a portrait never shows empty bars; `contain` guarantees the whole
 * viewport is visible.
 */
export declare function viewportTransform(viewport: AvatarHeadViewport, frame: {
    width: number;
    height: number;
}, fit?: 'cover' | 'contain'): {
    scale: number;
    translateX: number;
    translateY: number;
};
/** Clamp a head viewport to the stage, keeping it at least 40 units square. */
export declare function clampHeadViewport(viewport: AvatarHeadViewport): AvatarHeadViewport;
//# sourceMappingURL=composition.d.ts.map