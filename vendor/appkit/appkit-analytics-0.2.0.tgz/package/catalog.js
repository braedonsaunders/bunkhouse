export function sourceFromCatalog(catalog, key) {
    return catalog.sources.find((source) => source.key === key) ?? null;
}
export function fieldFromSource(source, key) {
    return source.fields.find((field) => field.key === key) ?? null;
}
export function canDimension(field) {
    return field.canDimension ?? (field.semanticType !== 'number' && field.semanticType !== 'currency');
}
export function canMeasure(field) {
    return field.canMeasure ?? (field.semanticType === 'number' || field.semanticType === 'currency');
}
export function canBin(field) {
    return field.canBin ?? field.semanticType === 'date';
}
const NULL_OPERATORS = ['is_null', 'is_not_null'];
export function filterOperatorsForField(field) {
    switch (field.semanticType) {
        case 'text':
        case 'category': return ['eq', 'neq', 'in', 'not_in', 'contains', ...NULL_OPERATORS];
        case 'number':
        case 'currency': return ['eq', 'neq', 'in', 'not_in', 'gt', 'gte', 'lt', 'lte', ...NULL_OPERATORS];
        case 'date': return ['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'last_n_days', 'this_month', 'this_quarter', 'this_year', 'ytd', ...NULL_OPERATORS];
        case 'boolean': return ['eq', 'neq', ...NULL_OPERATORS];
    }
}
//# sourceMappingURL=catalog.js.map