import type { QueryResult, VisualizationKey } from './types.js';
export type VisualizationDefinition = {
    key: VisualizationKey;
    label: string;
    iconKey: string;
    group: 'numbers' | 'tables' | 'comparison' | 'trend' | 'proportion';
    minSize: {
        w: number;
        h: number;
    };
    defaultSize: {
        w: number;
        h: number;
    };
    sensibleRank: number;
    isSensible: (result: QueryResult) => boolean;
};
export declare const VISUALIZATIONS: Record<VisualizationKey, VisualizationDefinition>;
export declare function suggestVisualization(result: QueryResult): VisualizationKey;
//# sourceMappingURL=viz.d.ts.map