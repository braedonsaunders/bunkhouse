import type { AnalyticsCatalog, AnalyticsField, AnalyticsSource, FilterOperator } from './types.js';
export declare function sourceFromCatalog(catalog: AnalyticsCatalog, key: string): AnalyticsSource | null;
export declare function fieldFromSource(source: AnalyticsSource, key: string): AnalyticsField | null;
export declare function canDimension(field: AnalyticsField): boolean;
export declare function canMeasure(field: AnalyticsField): boolean;
export declare function canBin(field: AnalyticsField): boolean;
export declare function filterOperatorsForField(field: AnalyticsField): FilterOperator[];
//# sourceMappingURL=catalog.d.ts.map