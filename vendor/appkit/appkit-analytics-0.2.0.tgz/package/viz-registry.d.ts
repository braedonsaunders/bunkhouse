import { type AnalyticResult, type AnalyticResultColumn, type ResultShape } from './result.js';
import type { RichSemanticType } from './semantic.js';
import type { VisualizationKey, VisualizationSettings } from './types.js';
export type VisualizationGroup = 'numbers' | 'tables' | 'comparison' | 'trend' | 'proportion' | 'distribution';
export type VisualizationSetting = {
    key: string;
    label: string;
    widget: 'field' | 'number' | 'text' | 'toggle' | 'conditional-format';
    section?: 'Data' | 'Format' | 'Display';
};
export type AdvancedVisualizationDefinition = {
    key: VisualizationKey;
    label: string;
    iconKey: string;
    group: VisualizationGroup;
    consumes: 'scalar' | 'rows' | 'series' | 'pivot';
    minSize: {
        w: number;
        h: number;
    };
    defaultSize: {
        w: number;
        h: number;
    };
    sensibleRank: number;
    settings: VisualizationSetting[];
    isSensible: (shape: ResultShape, semanticTypes: RichSemanticType[], columns: AnalyticResultColumn[]) => boolean;
    checkRenderable: (result: AnalyticResult, settings: VisualizationSettings) => void;
};
export declare const VISUALIZATION_REGISTRY: Record<VisualizationKey, AdvancedVisualizationDefinition>;
export declare const VISUALIZATION_LIST: AdvancedVisualizationDefinition[];
export declare function suggestAdvancedVisualization(result: AnalyticResult): VisualizationKey;
export declare function assertVisualizationRenderable(key: VisualizationKey, result: AnalyticResult, settings?: VisualizationSettings): void;
//# sourceMappingURL=viz-registry.d.ts.map