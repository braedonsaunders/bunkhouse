export type ConditionalTone = 'success' | 'warning' | 'danger' | 'neutral' | 'info' | 'primary';
export type ConditionalRule = {
    type: 'threshold';
    column: string;
    operator: 'gt' | 'gte' | 'lt' | 'lte' | 'eq' | 'between';
    value: number;
    value2?: number;
    tone: ConditionalTone;
} | {
    type: 'scale';
    column: string;
    min: number;
    max: number;
    lowTone: ConditionalTone;
    highTone: ConditionalTone;
} | {
    type: 'discrete';
    column: string;
    values: Record<string, ConditionalTone>;
};
export type ConditionalStyle = {
    className?: string;
    background?: string;
};
export declare function resolveConditionalStyle(value: unknown, column: string, rules: ConditionalRule[]): ConditionalStyle;
export declare function conditionalToneClass(tone: ConditionalTone): string;
//# sourceMappingURL=conditional-format.d.ts.map