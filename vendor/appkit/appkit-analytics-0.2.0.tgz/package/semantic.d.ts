/** Framework-neutral schema discovery contracts used by the visual query builder. */
export type DataColumnKind = 'text' | 'number' | 'date' | 'timestamp' | 'boolean' | 'enum' | 'uuid';
export type DiscoveredColumn = {
    key: string;
    label: string;
    kind: DataColumnKind;
    nullable?: boolean;
    description?: string;
};
export type DiscoveredEntity = {
    key: string;
    label: string;
    category: string;
    description?: string;
    columns: DiscoveredColumn[];
};
export type RichSemanticType = 'dimension' | 'category' | 'entity-name' | 'measure' | 'temporal' | 'pk' | 'fk' | 'uuid' | 'currency' | 'percentage' | 'lat' | 'lng';
export type SemanticOverlay = {
    semanticType?: RichSemanticType;
    enumOptions?: {
        value: string;
        label: string;
    }[];
    foreignEntity?: string;
    arrayUnnest?: 'array' | 'json';
};
export type AnalyticsRelation = {
    via: string;
    target: string;
    foreignColumn: string;
    label: string;
};
export type SemanticColumn = DiscoveredColumn & {
    semanticType: RichSemanticType;
    enumOptions?: {
        value: string;
        label: string;
    }[];
    foreignEntity?: string;
    arrayUnnest?: 'array' | 'json';
    canDimension: boolean;
    canMeasure: boolean;
    canBinTemporal: boolean;
    canBinNumeric: boolean;
};
export type SemanticEntity = Omit<DiscoveredEntity, 'columns'> & {
    columns: SemanticColumn[];
    featured?: boolean;
    relations?: AnalyticsRelation[];
};
export declare function deriveSemanticType(column: DiscoveredColumn): RichSemanticType;
export declare function decorateSemanticColumn(column: DiscoveredColumn, overlay?: SemanticOverlay): SemanticColumn;
export declare function buildSemanticEntities(entities: DiscoveredEntity[], overlays?: Partial<Record<string, Record<string, SemanticOverlay>>>, relations?: Partial<Record<string, AnalyticsRelation[]>>): SemanticEntity[];
export declare function semanticEntity(entities: SemanticEntity[], key: string): SemanticEntity | null;
export declare function semanticColumn(entity: SemanticEntity, key: string): SemanticColumn | null;
//# sourceMappingURL=semantic.d.ts.map