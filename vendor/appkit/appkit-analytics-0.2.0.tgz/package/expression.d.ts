import type { FormulaExpression } from './types.js';
export declare const FORMULA_FUNCTIONS: readonly ["now", "current_date", "coalesce", "nullif", "abs", "round", "ceil", "floor", "power", "sqrt", "lower", "upper", "length", "trim", "concat", "datediff", "datetrunc", "datepart"];
export declare const FORMULA_FUNCTION_ARITY: Record<(typeof FORMULA_FUNCTIONS)[number], {
    min: number;
    max: number;
}>;
export declare function validFormulaFunctionArity(fn: string, count: number): boolean;
export declare const FORMULA_HELP: Record<string, {
    signature: string;
    description: string;
}>;
type ParseOptions = {
    resolveField: (label: string) => string | null;
};
export type FormulaParseResult = {
    ok: true;
    expression: FormulaExpression;
} | {
    ok: false;
    error: string;
    position: number;
};
export declare function parseFormula(input: string, options: ParseOptions): FormulaParseResult;
export declare function serializeFormula(expression: FormulaExpression, labelForField: (key: string) => string): string;
export {};
//# sourceMappingURL=expression.d.ts.map