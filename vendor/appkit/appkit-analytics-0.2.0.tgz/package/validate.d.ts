import type { AnalyticsCatalog, InsightQuery } from './types.js';
export type QueryValidationCode = 'unknown_source' | 'unknown_field' | 'invalid_measure' | 'invalid_dimension' | 'invalid_filter' | 'invalid_formula' | 'invalid_sort' | 'invalid_limit' | 'invalid_query';
export declare class QueryValidationError extends Error {
    readonly code: QueryValidationCode;
    readonly subject?: string | undefined;
    readonly name = "QueryValidationError";
    constructor(message: string, code?: QueryValidationCode, subject?: string | undefined);
}
/** Validates persisted or request JSON before it reaches the SQL compiler. */
export declare function validateQuery(input: unknown, catalog: AnalyticsCatalog): InsightQuery;
//# sourceMappingURL=validate.d.ts.map