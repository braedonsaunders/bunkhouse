'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Camera, FileUp, Loader2, Trash2 } from 'lucide-react';
import { Button, uploadReservedFile, } from '@appkit/ui';
function kindFromType(mime) {
    if (mime.startsWith('image/'))
        return 'image';
    if (mime.startsWith('video/'))
        return 'video';
    if (mime.startsWith('audio/'))
        return 'audio';
    if (mime === 'application/pdf' || mime.includes('document') || mime.includes('sheet')) {
        return 'document';
    }
    return 'other';
}
/**
 * Production form-field uploader: controlled attachments, environment camera
 * capture, bounded counts, reserved upload/finalize protocol, previews, and
 * removal. Storage policy remains an injected application boundary.
 */
export function ProductionFileUpload({ value, onChange, requestUpload, finalizeUpload, accept, multiple = true, maxFiles, onUploadingChange, variant = 'file', }) {
    const inputRef = React.useRef(null);
    const [pending, startTransition] = React.useTransition();
    const [error, setError] = React.useState(null);
    const uploadingCallback = React.useRef(onUploadingChange);
    React.useEffect(() => {
        uploadingCallback.current = onUploadingChange;
    }, [onUploadingChange]);
    React.useEffect(() => {
        uploadingCallback.current?.(pending);
    }, [pending]);
    React.useEffect(() => () => uploadingCallback.current?.(false), []);
    async function uploadOne(file) {
        const request = await requestUpload({
            kind: kindFromType(file.type),
            filename: file.name,
            contentType: file.type || 'application/octet-stream',
            sizeBytes: file.size,
        });
        if (!request.ok) {
            setError(request.error);
            return null;
        }
        let finalizeInput;
        try {
            finalizeInput = await uploadReservedFile(request, file);
        }
        catch (cause) {
            setError(cause instanceof Error ? cause.message : 'Upload failed.');
            return null;
        }
        const finalized = await finalizeUpload(finalizeInput);
        if (!finalized.ok) {
            setError(finalized.error);
            return null;
        }
        return {
            attachmentId: finalized.attachmentId,
            filename: file.name,
            contentType: file.type || 'application/octet-stream',
            url: finalized.url,
        };
    }
    function onFiles(files) {
        if (!files || files.length === 0)
            return;
        const remaining = maxFiles === undefined ? files.length : Math.max(0, maxFiles - value.length);
        if (remaining === 0) {
            setError(`Maximum ${maxFiles} file${maxFiles === 1 ? '' : 's'}.`);
            return;
        }
        setError(null);
        startTransition(async () => {
            const uploaded = [];
            for (const file of Array.from(files).slice(0, remaining)) {
                const result = await uploadOne(file);
                if (result)
                    uploaded.push(result);
            }
            onChange([...value, ...uploaded]);
            if (inputRef.current)
                inputRef.current.value = '';
        });
    }
    const acceptValue = accept ?? (variant === 'photo' ? 'image/*'
        : variant === 'video' ? 'video/*'
            : variant === 'audio' ? 'audio/*'
                : undefined);
    const atLimit = maxFiles !== undefined && value.length >= maxFiles;
    return (_jsxs("div", { className: "space-y-2", children: [_jsx("input", { ref: inputRef, type: "file", accept: acceptValue, multiple: multiple, capture: variant === 'photo' ? 'environment' : undefined, className: "hidden", onChange: (event) => onFiles(event.target.files) }), _jsxs("button", { type: "button", onClick: () => inputRef.current?.click(), disabled: pending || atLimit, className: "flex w-full items-center justify-center gap-2 rounded-md border border-dashed border-border-strong bg-bg-subtle px-3 py-6 text-sm text-fg-muted transition-colors hover:border-primary hover:bg-primary-subtle disabled:opacity-50", children: [pending ? _jsx(Loader2, { size: 16, className: "animate-spin" }) : variant === 'photo' ? _jsx(Camera, { size: 16 }) : _jsx(FileUp, { size: 16 }), atLimit ? `Maximum ${maxFiles} files` : pending ? 'Uploading…' : variant === 'photo' ? 'Add photo' : variant === 'video' ? 'Add video' : variant === 'audio' ? 'Add audio' : 'Add file'] }), error ? _jsx("p", { role: "alert", className: "text-xs text-danger", children: error }) : null, value.length > 0 ? (_jsx("ul", { className: "space-y-1.5", children: value.map((file) => (_jsxs("li", { className: "flex items-center justify-between gap-2 rounded-md border border-border bg-surface px-2 py-1.5 text-xs", children: [_jsxs("div", { className: "flex min-w-0 items-center gap-2", children: [file.contentType.startsWith('image/') ? (
                                // The host supplies access-controlled attachment URLs.
                                _jsx("img", { src: file.url, alt: "", className: "size-10 shrink-0 rounded object-cover" })) : (_jsx("span", { className: "grid size-10 shrink-0 place-items-center rounded bg-bg-subtle text-fg-subtle", children: _jsx(FileUp, { size: 14 }) })), _jsx("span", { className: "truncate font-medium text-fg", children: file.filename })] }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => onChange(value.filter((candidate) => candidate.attachmentId !== file.attachmentId)), children: _jsx(Trash2, { size: 12, className: "text-danger" }) })] }, file.attachmentId))) })) : null] }));
}
export function dataUrlToFile(dataUrl, filename) {
    const [metadata, encoded] = dataUrl.split(',');
    const mime = metadata?.match(/data:([^;]+)/)?.[1] ?? 'application/octet-stream';
    const binary = atob(encoded ?? '');
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1)
        bytes[index] = binary.charCodeAt(index);
    return new File([bytes], filename, { type: mime });
}
//# sourceMappingURL=production-file-upload.js.map