import * as React from 'react';
import type { AutomationGraph, TriggerData } from '@appkit/forms-core/safety-automation';
import type { RecordActionFlow, RecordActionFlowAdapter } from './record-config.js';
type ManualTrigger = Extract<TriggerData, {
    trigger: 'manual';
}>;
type ButtonVariant = NonNullable<ManualTrigger['variant']>;
declare const QUICK_ACTIONS: readonly ["flag_non_compliant", "start_monitored_session", "duplicate_record", "export_pdf"];
type QuickAction = (typeof QUICK_ACTIONS)[number];
export declare function manualTrigger(graph: AutomationGraph): ManualTrigger | null;
export declare function buildRecordButtonGraph(input: {
    label: string;
    icon?: string;
    variant: ButtonVariant;
    actionKind: QuickAction;
    order: number;
}): AutomationGraph;
export type RecordActionsPanelProps = {
    flows: RecordActionFlow[];
    adapter: RecordActionFlowAdapter;
    onChanged?: () => void | Promise<void>;
    confirmRemove?: (flow: RecordActionFlow) => boolean | Promise<boolean>;
    readOnly?: boolean;
    className?: string;
};
export declare function RecordActionsPanel({ flows, adapter, onChanged, confirmRemove, readOnly, className }: RecordActionsPanelProps): React.JSX.Element;
export {};
//# sourceMappingURL=record-actions-panel.d.ts.map