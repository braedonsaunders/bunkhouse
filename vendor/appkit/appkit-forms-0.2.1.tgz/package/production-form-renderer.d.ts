import { type ProductionRuntimeLabels } from './production-runtime-context.js';
import type { GeneratedCopyTranslator } from './generated-copy.js';
import { type AppLocale } from '@appkit/i18n';
import type { ProductionFormRuntimeAdapter, ProductionFormRuntimeInput } from './production-runtime-adapter.js';
export type ProductionFormRendererProps = ProductionFormRuntimeInput & {
    adapter: ProductionFormRuntimeAdapter;
    locale?: AppLocale;
    labels?: Partial<ProductionRuntimeLabels>;
    translateGenerated?: GeneratedCopyTranslator;
};
/**
 * Full production form runtime extracted behind application-owned persistence,
 * hierarchy, data-source, AI, and storage adapters plus application-owned links.
 */
export declare function ProductionFormRenderer({ adapter, locale, labels, translateGenerated, ...input }: ProductionFormRendererProps): import("react").JSX.Element;
//# sourceMappingURL=production-form-renderer.d.ts.map