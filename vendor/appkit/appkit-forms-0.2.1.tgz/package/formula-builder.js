'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useGeneratedTranslations, GeneratedValue, useGeneratedValueTranslations, } from './generated-copy.js';
import { GeneratedText } from './generated-copy.js';
// Guided builder for a FormulaExpression tree. Used by the designer's "Calc"
// tab on formula fields. Renders a small recursive editor that lets
// the user pick an operator, then either literals, field refs, repeating-row
// sums, or nested sub-expressions.
//
// The user is never asked to write JSON. A live "preview value" pane sits
// beneath the tree so the designer can sanity-check the formula against
// example data without leaving the screen.
import { useMemo, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button, Input, Label, Select } from '@appkit/ui';
import { ENTITY_ATTRS, evaluateFormulaTree, } from '@appkit/forms-core';
import { LogicBuilder } from './logic-builder.js';
const OPS = [
    // Value
    { kind: 'literal', label: 'Number / text', group: 'value', description: 'Constant value' },
    { kind: 'field_ref', label: 'Field value', group: 'value', description: 'Read another field' },
    // Math
    { kind: 'sum', label: 'Sum (a + b + …)', group: 'math', description: 'Add a list of values' },
    {
        kind: 'product',
        label: 'Product (a × b × …)',
        group: 'math',
        description: 'Multiply a list of values',
    },
    { kind: 'subtract', label: 'Subtract (a − b)', group: 'math', description: 'a minus b' },
    { kind: 'divide', label: 'Divide (a ÷ b)', group: 'math', description: 'a divided by b' },
    { kind: 'min', label: 'Minimum', group: 'math', description: 'Smallest of a list' },
    { kind: 'max', label: 'Maximum', group: 'math', description: 'Largest of a list' },
    { kind: 'power', label: 'Power (aᵇ)', group: 'math', description: 'Raise a base to an exponent' },
    {
        kind: 'root',
        label: 'Root (ⁿ√a)',
        group: 'math',
        description: 'nth root — degree 2 is a square root, 3 a cube root',
    },
    { kind: 'abs', label: 'Absolute value', group: 'math', description: 'Distance from zero' },
    { kind: 'round', label: 'Round', group: 'math', description: 'Round to N decimal places' },
    {
        kind: 'floor',
        label: 'Round down (floor)',
        group: 'math',
        description: 'Largest integer ≤ value',
    },
    {
        kind: 'ceil',
        label: 'Round up (ceil)',
        group: 'math',
        description: 'Smallest integer ≥ value',
    },
    // Section
    {
        kind: 'sum_section',
        label: 'Sum field across rows',
        group: 'section',
        description: 'Sum a field across every row of a repeating section',
    },
    {
        kind: 'count_section',
        label: 'Count rows in section',
        group: 'section',
        description: 'How many rows in a repeating section',
    },
    {
        kind: 'avg_section',
        label: 'Average field across rows',
        group: 'section',
        description: 'Average a field across every row of a repeating section',
    },
    {
        kind: 'min_section',
        label: 'Minimum field across rows',
        group: 'section',
        description: 'Smallest value of a field across the rows',
    },
    {
        kind: 'max_section',
        label: 'Maximum field across rows',
        group: 'section',
        description: 'Largest value of a field across the rows',
    },
    // String
    {
        kind: 'concat',
        label: 'Concatenate text',
        group: 'string',
        description: 'Join strings together',
    },
    // Conditional
    { kind: 'if', label: 'If / else', group: 'cond', description: 'Branch on a condition' },
    // Entity
    {
        kind: 'entity_attr',
        label: 'Entity attribute',
        group: 'entity',
        description: 'Read an attribute off the entity selected by a picker field',
    },
];
export function FormulaBuilder({ value, allFields, repeatingSections, pickerFields, onChange, }) {
    const tGenerated = useGeneratedTranslations();
    // The preview pane lets the user fill in example values for any field /
    // repeating-row field referenced in the formula and see what evaluates.
    const [preview, setPreview] = useState({
        values: {},
        rowCounts: {},
    });
    const previewCtx = useMemo(() => {
        const rows = {};
        for (const sec of repeatingSections) {
            const count = preview.rowCounts[sec.id] ?? 0;
            rows[sec.id] = Array.from({ length: count }, (_, i) => {
                const r = {};
                for (const f of sec.fields) {
                    const k = `${sec.id}.${i}.${f.id}`;
                    const v = preview.values[k];
                    // Best-effort numeric coercion so sum_section preview makes sense.
                    if (v !== undefined && v !== '') {
                        const n = Number(v);
                        r[f.id] = Number.isFinite(n) ? n : v;
                    }
                }
                return r;
            });
        }
        const values = {};
        for (const f of allFields) {
            const v = preview.values[f.id];
            if (v !== undefined && v !== '') {
                const n = Number(v);
                values[f.id] = Number.isFinite(n) ? n : v;
            }
        }
        return { values, rows };
    }, [allFields, preview, repeatingSections]);
    const previewValue = value ? evaluateFormulaTree(value, previewCtx) : null;
    return (_jsxs("div", { className: "space-y-3", children: [_jsx(Node, { value: value, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields ?? [], onChange: onChange, onClear: () => onChange(undefined) }), _jsxs("details", { className: "rounded-md border border-border bg-bg-subtle/50 p-2 text-xs", children: [_jsxs("summary", { className: "cursor-pointer font-semibold text-fg-muted", children: [_jsx(GeneratedText, { id: "m_07c67e89962d16" }), ' ', _jsx(GeneratedValue, { value: value ? renderPreviewValue(previewValue) : '—' })] }), _jsxs("div", { className: "mt-2 space-y-2", children: [_jsx(GeneratedValue, { value: allFields.length > 0 ? (_jsxs("div", { className: "space-y-1", children: [_jsx("div", { className: "font-semibold text-fg-muted", children: _jsx(GeneratedText, { id: "m_1e3a16a7c41097" }) }), _jsx(GeneratedValue, { value: allFields.map((f) => (_jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Label, { className: "w-32 truncate text-[10px]", children: _jsx(GeneratedValue, { value: f.label }) }), _jsx(Input, { className: "h-7 flex-1 text-xs", value: preview.values[f.id] ?? '', onChange: (e) => setPreview((p) => ({
                                                            ...p,
                                                            values: { ...p.values, [f.id]: e.target.value },
                                                        })) })] }, f.id))) })] })) : null }), _jsx(GeneratedValue, { value: repeatingSections.length > 0 ? (_jsxs("div", { className: "space-y-2", children: [_jsx("div", { className: "font-semibold text-fg-muted", children: _jsx(GeneratedText, { id: "m_04b7380779afc4" }) }), _jsx(GeneratedValue, { value: repeatingSections.map((sec) => {
                                                const rowCount = preview.rowCounts[sec.id] ?? 0;
                                                return (_jsxs("div", { className: "rounded border border-border bg-white p-2", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("span", { className: "font-semibold", children: _jsx(GeneratedValue, { value: sec.label }) }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx("button", { type: "button", className: "rounded border border-border px-1.5 py-0.5", onClick: () => setPreview((p) => ({
                                                                                ...p,
                                                                                rowCounts: {
                                                                                    ...p.rowCounts,
                                                                                    [sec.id]: Math.max(0, rowCount - 1),
                                                                                },
                                                                            })), children: "\u2212" }), _jsxs("span", { children: [_jsx(GeneratedValue, { value: rowCount }), ' ', _jsx(GeneratedText, { id: "m_19f38a950f87b6" })] }), _jsx("button", { type: "button", className: "rounded border border-border px-1.5 py-0.5", onClick: () => setPreview((p) => ({
                                                                                ...p,
                                                                                rowCounts: { ...p.rowCounts, [sec.id]: rowCount + 1 },
                                                                            })), children: "+" })] })] }), _jsx(GeneratedValue, { value: Array.from({ length: rowCount }, (_, i) => (_jsx("div", { className: "mt-1 grid grid-cols-2 gap-1 border-t border-border-subtle pt-1", children: _jsx(GeneratedValue, { value: sec.fields.map((f) => {
                                                                        const k = `${sec.id}.${i}.${f.id}`;
                                                                        return (_jsx(Input, { className: "h-7 text-xs", placeholder: tGenerated('m_14dac40a7e102a', {
                                                                                value0: i + 1,
                                                                                value1: f.label,
                                                                            }), value: preview.values[k] ?? '', onChange: (e) => setPreview((p) => ({
                                                                                ...p,
                                                                                values: { ...p.values, [k]: e.target.value },
                                                                            })) }, f.id));
                                                                    }) }) }, i))) })] }, sec.id));
                                            }) })] })) : null })] })] })] }));
}
function renderPreviewValue(v) {
    if (v === null || v === undefined)
        return '—';
    if (typeof v === 'number')
        return Number.isFinite(v) ? String(v) : '—';
    return String(v);
}
function Node({ value, allFields, repeatingSections, pickerFields, onChange, onClear, showClear = true, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const tGenerated = useGeneratedTranslations();
    if (!value) {
        return (_jsxs(Select, { className: "h-8 text-xs", value: "", onChange: (e) => onChange(makeDefault(e.target.value)), children: [_jsx("option", { value: "", children: '— pick an operator —' }), GROUPS.map((g) => (_jsx("optgroup", { label: tGeneratedValue(g.label), children: OPS.filter((op) => op.group === g.kind).map((op) => (_jsx("option", { value: op.kind, children: op.label }, op.kind))) }, g.label)))] }));
    }
    return (_jsxs("div", { className: "space-y-2 rounded-md border border-border bg-white p-2", children: [_jsxs("div", { className: "flex items-center justify-between gap-1", children: [_jsx(Select, { className: "h-7 flex-1 text-xs", value: value.kind, onChange: (e) => onChange(makeDefault(e.target.value)), children: GROUPS.map((g) => (_jsx("optgroup", { label: tGeneratedValue(g.label), children: OPS.filter((op) => op.group === g.kind).map((op) => (_jsx("option", { value: op.kind, children: op.label }, op.kind))) }, g.label))) }), _jsx(GeneratedValue, { value: showClear && onClear ? (_jsx("button", { type: "button", className: "rounded p-1 text-fg-subtle hover:text-danger", onClick: onClear, title: tGenerated('m_1e4d427e74e767'), children: _jsx(Trash2, { size: 12 }) })) : null })] }), _jsx(NodeBody, { value: value, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: onChange })] }));
}
function NodeBody({ value, allFields, repeatingSections, pickerFields, onChange, }) {
    switch (value.kind) {
        case 'literal':
            return (_jsx(Input, { className: "h-7 text-xs", value: String(value.value), onChange: (e) => {
                    const raw = e.target.value;
                    const asNum = Number(raw);
                    onChange({ kind: 'literal', value: raw !== '' && Number.isFinite(asNum) ? asNum : raw });
                } }));
        case 'field_ref':
            return (_jsxs(Select, { className: "h-7 text-xs", value: value.fieldKey, onChange: (e) => onChange({ kind: 'field_ref', fieldKey: e.target.value }), children: [_jsx("option", { value: "", children: '— pick field —' }), allFields.map((f) => (_jsxs("option", { value: f.id, children: [f.label, " (", f.id, ")"] }, f.id)))] }));
        case 'sum':
        case 'product':
        case 'min':
        case 'max':
        case 'concat':
            return (_jsx(NodeList, { items: value.of, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (of) => onChange({ ...value, of }), children: _jsx(GeneratedValue, { value: value.kind === 'concat' ? (_jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Label, { className: "text-[10px]", children: _jsx(GeneratedText, { id: "m_09a3fb77851262" }) }), _jsx(Input, { className: "h-7 flex-1 text-xs", value: value.separator ?? '', onChange: (e) => onChange({ ...value, separator: e.target.value }) })] })) : null }) }));
        case 'subtract':
        case 'divide':
            return (_jsxs("div", { className: "space-y-1", children: [_jsxs("div", { children: [_jsx("div", { className: "text-[10px] font-semibold text-fg-muted", children: _jsx(GeneratedText, { id: "m_146f7d831bfd96" }) }), _jsx(Node, { value: value.left, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange({ ...value, left: next }), showClear: false })] }), _jsxs("div", { children: [_jsx("div", { className: "text-[10px] font-semibold text-fg-muted", children: _jsx(GeneratedText, { id: "m_0d4127eb7af91b" }) }), _jsx(Node, { value: value.right, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange({ ...value, right: next }), showClear: false })] })] }));
        case 'power':
        case 'root': {
            const isPower = value.kind === 'power';
            const left = isPower ? value.base : value.of;
            const right = isPower ? value.exponent : value.degree;
            return (_jsxs("div", { className: "space-y-1", children: [_jsxs("div", { children: [_jsx("div", { className: "text-[10px] font-semibold text-fg-muted", children: _jsx(GeneratedValue, { value: isPower ? (_jsx(GeneratedText, { id: "m_0301e90977d549" })) : (_jsx(GeneratedText, { id: "m_1cc0e5e7b5f442" })) }) }), _jsx(Node, { value: left, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange(isPower ? { ...value, base: next } : { ...value, of: next }), showClear: false })] }), _jsxs("div", { children: [_jsx("div", { className: "text-[10px] font-semibold text-fg-muted", children: _jsx(GeneratedValue, { value: isPower ? (_jsx(GeneratedText, { id: "m_1979ef2713c627" })) : (_jsx(GeneratedText, { id: "m_10f4f461b6e849" })) }) }), _jsx(Node, { value: right, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange(isPower ? { ...value, exponent: next } : { ...value, degree: next }), showClear: false })] })] }));
        }
        case 'abs':
        case 'floor':
        case 'ceil':
            return (_jsx(Node, { value: value.of, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange({ ...value, of: next }), showClear: false }));
        case 'round':
            return (_jsxs("div", { className: "space-y-1", children: [_jsx(Node, { value: value.of, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange({ ...value, of: next }), showClear: false }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Label, { className: "text-[10px]", children: _jsx(GeneratedText, { id: "m_05b9318155a4da" }) }), _jsx(Input, { type: "number", min: "0", className: "h-7 w-20 text-xs", value: String(value.places ?? 0), onChange: (e) => onChange({ ...value, places: Math.max(0, Math.floor(Number(e.target.value) || 0)) }) })] })] }));
        case 'sum_section':
        case 'avg_section':
        case 'min_section':
        case 'max_section': {
            const sec = repeatingSections.find((s) => s.id === value.sectionKey);
            return (_jsxs("div", { className: "space-y-1", children: [_jsxs(Select, { className: "h-7 text-xs", value: value.sectionKey, onChange: (e) => onChange({ ...value, sectionKey: e.target.value, rowFieldKey: '' }), children: [_jsx("option", { value: "", children: '— pick section —' }), repeatingSections.map((s) => (_jsx("option", { value: s.id, children: s.label }, s.id)))] }), _jsxs(Select, { className: "h-7 text-xs", value: value.rowFieldKey, onChange: (e) => onChange({ ...value, rowFieldKey: e.target.value }), disabled: !sec, children: [_jsx("option", { value: "", children: '— pick row field —' }), sec?.fields.map((f) => (_jsx("option", { value: f.id, children: f.label }, f.id)))] })] }));
        }
        case 'count_section':
            return (_jsxs(Select, { className: "h-7 text-xs", value: value.sectionKey, onChange: (e) => onChange({ ...value, sectionKey: e.target.value }), children: [_jsx("option", { value: "", children: '— pick section —' }), repeatingSections.map((s) => (_jsx("option", { value: s.id, children: s.label }, s.id)))] }));
        case 'if':
            return (_jsxs("div", { className: "space-y-2", children: [_jsxs("div", { children: [_jsx("div", { className: "text-[10px] font-semibold text-fg-muted", children: _jsx(GeneratedText, { id: "m_0c75ca758719d2" }) }), _jsx(LogicBuilder, { rule: value.condition, availableFields: allFields, onChange: (rule) => onChange({ ...value, condition: rule ?? ALWAYS_TRUE }) })] }), _jsxs("div", { children: [_jsx("div", { className: "text-[10px] font-semibold text-fg-muted", children: _jsx(GeneratedText, { id: "m_1aea6765cbbb07" }) }), _jsx(Node, { value: value.then, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange({ ...value, then: next }), showClear: false })] }), _jsxs("div", { children: [_jsx("div", { className: "text-[10px] font-semibold text-fg-muted", children: _jsx(GeneratedText, { id: "m_196f872aa354d3" }) }), _jsx(Node, { value: value.else, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange({ ...value, else: next }), showClear: false })] })] }));
        case 'entity_attr': {
            // 2-step picker: choose a picker field, then choose an attribute from
            // its kind's ENTITY_ATTRS list. The available attrs change when the
            // picker selection changes, so we reset attrKey whenever the picker
            // does — keeps designers from accidentally bouncing an attr off a
            // mismatched kind.
            const picker = pickerFields.find((p) => p.id === value.pickerFieldKey);
            const attrs = picker ? ENTITY_ATTRS[picker.kind] : [];
            return (_jsxs("div", { className: "space-y-1", children: [_jsx(GeneratedValue, { value: pickerFields.length === 0 ? (_jsx("p", { className: "text-[10px] text-fg-muted italic", children: _jsx(GeneratedText, { id: "m_15ca343c0669d7" }) })) : (_jsxs(Select, { className: "h-7 text-xs", value: value.pickerFieldKey, onChange: (e) => onChange({
                                kind: 'entity_attr',
                                pickerFieldKey: e.target.value,
                                attrKey: '',
                            }), children: [_jsx("option", { value: "", children: '— pick picker field —' }), pickerFields.map((p) => (_jsxs("option", { value: p.id, children: [p.label, " (", p.kind, ")"] }, p.id)))] })) }), _jsxs(Select, { className: "h-7 text-xs", value: value.attrKey, onChange: (e) => onChange({ ...value, attrKey: e.target.value }), disabled: !picker, children: [_jsx("option", { value: "", children: '— pick attribute —' }), attrs.map((a) => (_jsx("option", { value: a.key, children: a.label }, a.key)))] })] }));
        }
    }
}
function NodeList({ items, allFields, repeatingSections, pickerFields, onChange, children, }) {
    return (_jsxs("div", { className: "space-y-1.5", children: [_jsx(GeneratedValue, { value: children }), _jsx(GeneratedValue, { value: items.map((it, i) => (_jsx("div", { className: "rounded border border-border-subtle bg-bg-subtle p-1", children: _jsx(Node, { value: it, allFields: allFields, repeatingSections: repeatingSections, pickerFields: pickerFields, onChange: (next) => onChange(items.map((x, j) => (j === i ? next : x))), onClear: () => onChange(items.filter((_, j) => j !== i)) }) }, i))) }), _jsxs(Button, { size: "sm", variant: "outline", onClick: () => onChange([...items, { kind: 'literal', value: 0 }]), children: [_jsx(Plus, { size: 12 }), " ", _jsx(GeneratedText, { id: "m_068bf7c4eb45a2" })] })] }));
}
const GROUPS = [
    { kind: 'value', label: 'Value' },
    { kind: 'math', label: 'Math' },
    { kind: 'section', label: 'Repeating section' },
    { kind: 'string', label: 'Text' },
    { kind: 'cond', label: 'Conditional' },
    { kind: 'entity', label: 'Entity attribute' },
];
// An empty conjunction is true and does not require an invented field id, so
// fresh conditional formulas remain valid under schema reference checks.
const ALWAYS_TRUE = { op: 'and', rules: [] };
function makeDefault(kind) {
    switch (kind) {
        case 'literal':
            return { kind: 'literal', value: 0 };
        case 'field_ref':
            return { kind: 'field_ref', fieldKey: '' };
        case 'sum':
        case 'product':
        case 'min':
        case 'max':
            return { kind, of: [{ kind: 'literal', value: 0 }] };
        case 'subtract':
        case 'divide':
            return {
                kind,
                left: { kind: 'literal', value: 0 },
                right: { kind: 'literal', value: 1 },
            };
        case 'power':
            return {
                kind: 'power',
                base: { kind: 'literal', value: 0 },
                exponent: { kind: 'literal', value: 2 },
            };
        case 'root':
            return {
                kind: 'root',
                of: { kind: 'literal', value: 0 },
                degree: { kind: 'literal', value: 2 },
            };
        case 'abs':
        case 'floor':
        case 'ceil':
            return { kind, of: { kind: 'literal', value: 0 } };
        case 'round':
            return { kind: 'round', of: { kind: 'literal', value: 0 }, places: 0 };
        case 'sum_section':
        case 'avg_section':
        case 'min_section':
        case 'max_section':
            return { kind, sectionKey: '', rowFieldKey: '' };
        case 'count_section':
            return { kind: 'count_section', sectionKey: '' };
        case 'concat':
            return { kind: 'concat', of: [{ kind: 'literal', value: '' }], separator: '' };
        case 'if':
            return {
                kind: 'if',
                condition: ALWAYS_TRUE,
                then: { kind: 'literal', value: 0 },
                else: { kind: 'literal', value: 0 },
            };
        case 'entity_attr':
            return { kind: 'entity_attr', pickerFieldKey: '', attrKey: '' };
    }
}
//# sourceMappingURL=formula-builder.js.map