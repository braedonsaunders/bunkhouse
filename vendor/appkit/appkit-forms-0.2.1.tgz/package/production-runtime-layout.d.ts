import * as React from 'react';
export type ProductionSectionTone = 'neutral' | 'info' | 'accent' | 'primary' | 'warning' | 'success' | 'danger' | 'teal' | 'blue' | 'purple' | 'amber' | 'indigo' | 'emerald' | 'rose' | 'slate';
export type ProductionSectionProps = {
    title: string;
    subtitle?: string;
    actions?: React.ReactNode;
    defaultOpen?: boolean;
    children: React.ReactNode;
};
/** Tokenized extraction of the production collapsible record section. */
export declare function ProductionSection({ title, subtitle, actions, defaultOpen, children, }: ProductionSectionProps): React.JSX.Element;
export type ProductionPremiumSectionProps = ProductionSectionProps & {
    icon?: React.ReactNode;
    tone?: ProductionSectionTone;
    count?: number;
    done?: boolean;
    doneLabel?: string;
};
/** Tokenized extraction of the production premium single-page section card. */
export declare function ProductionPremiumSection({ title, subtitle, actions, icon, tone, count, done, doneLabel, defaultOpen, children, }: ProductionPremiumSectionProps): React.JSX.Element;
//# sourceMappingURL=production-runtime-layout.d.ts.map