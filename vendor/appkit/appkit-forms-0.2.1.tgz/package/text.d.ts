import { type AppLocale } from '@appkit/i18n';
import type { I18nString } from '@appkit/forms-core';
export declare function readText(value: I18nString | undefined, locale?: AppLocale, fallback?: string): string;
export declare function writeText(previous: I18nString | undefined, value: string, locale: AppLocale): I18nString;
//# sourceMappingURL=text.d.ts.map