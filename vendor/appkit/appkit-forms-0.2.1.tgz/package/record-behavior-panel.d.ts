import * as React from 'react';
import type { RecordConfig } from './record-config.js';
export type RecordBehaviorPanelProps = {
    value?: RecordConfig;
    roles?: {
        key: string;
        name: string;
    }[];
    onChange: (config: RecordConfig) => void;
    onSave?: (config: RecordConfig) => void | Promise<void>;
    readOnly?: boolean;
    className?: string;
};
export declare function RecordBehaviorPanel({ value, roles, onChange, onSave, readOnly, className, }: RecordBehaviorPanelProps): React.JSX.Element;
//# sourceMappingURL=record-behavior-panel.d.ts.map