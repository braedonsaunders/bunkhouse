import { type EntityKind, type FormulaExpression } from '@appkit/forms-core';
type PickerFieldDesc = {
    id: string;
    label: string;
    kind: EntityKind;
};
export declare function FormulaBuilder({ value, allFields, repeatingSections, pickerFields, onChange, }: {
    value: FormulaExpression | undefined;
    allFields: {
        id: string;
        label: string;
    }[];
    repeatingSections: {
        id: string;
        label: string;
        fields: {
            id: string;
            label: string;
        }[];
    }[];
    pickerFields?: PickerFieldDesc[];
    onChange: (next: FormulaExpression | undefined) => void;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=formula-builder.d.ts.map