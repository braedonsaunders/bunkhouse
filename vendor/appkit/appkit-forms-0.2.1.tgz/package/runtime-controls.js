'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { MapPin, Plus, Trash2 } from 'lucide-react';
import { Button, Checkbox, Input } from '@appkit/ui';
import { SignaturePad } from '@appkit/ui';
import { RiskMatrixField, RiskMatrixProvider } from './risk-matrix.js';
import { SketchPad } from './sketch-pad.js';
export function GpsField({ value, onChange, disabled }) {
    const location = isRecord(value) && typeof value.lat === 'number' && typeof value.lng === 'number'
        ? value
        : null;
    return _jsxs("div", { className: "space-y-1.5", children: [_jsxs(Button, { type: "button", variant: "outline", size: "sm", disabled: disabled, onClick: () => navigator.geolocation?.getCurrentPosition((position) => onChange({ lat: position.coords.latitude, lng: position.coords.longitude, accuracy: position.coords.accuracy, capturedAt: new Date().toISOString() }), undefined, { enableHighAccuracy: true, timeout: 10_000 }), children: [_jsx(MapPin, { size: 14 }), location ? 'Update location' : 'Capture location'] }), location ? _jsxs("p", { className: "text-xs text-fg-muted", children: [location.lat.toFixed(5), ", ", location.lng.toFixed(5), location.accuracy ? ` · ±${Math.round(location.accuracy)} m` : ''] }) : null] });
}
export function MatrixField({ field, value, onChange, disabled }) {
    const config = (field.config ?? {});
    const rows = config.rows ?? [];
    const scale = config.scale ?? [];
    const current = isRecord(value) ? value : {};
    return _jsx("div", { className: "overflow-x-auto rounded-md border border-border", children: _jsxs("table", { className: "w-full border-collapse text-sm", children: [_jsx("thead", { children: _jsxs("tr", { className: "bg-surface-subtle", children: [_jsx("th", { className: "p-2" }), scale.map((item) => _jsx("th", { className: "p-2 text-center text-xs font-medium text-fg-muted", children: item.label }, item.value))] }) }), _jsx("tbody", { children: rows.map((row) => _jsxs("tr", { className: "border-t border-border", children: [_jsx("td", { className: "px-2 py-2 font-medium text-fg", children: row.label }), scale.map((item) => _jsx("td", { className: "p-2 text-center", children: _jsx("input", { type: "radio", name: `${field.id}_${row.key}`, disabled: disabled, checked: current[row.key] === item.value, onChange: () => onChange({ ...current, [row.key]: item.value }), "aria-label": `${row.label}: ${item.label}` }) }, item.value))] }, row.key)) })] }) });
}
export function TableField({ field, value, onChange, disabled }) {
    const config = (field.config ?? {});
    const columns = (config.columns ?? []);
    const fixed = config.rowMode === 'fixed';
    const stored = Array.isArray(value) ? value.filter(isRecord) : [];
    const rows = fixed ? (config.rows ?? []).map((_, index) => stored[index] ?? {}) : stored;
    const minRows = config.minRows ?? 0;
    function setCell(rowIndex, key, next) { onChange(rows.map((row, index) => index === rowIndex ? { ...row, [key]: next } : row)); }
    function addRow() { if (config.maxRows == null || rows.length < config.maxRows)
        onChange([...rows, {}]); }
    function removeRow(rowIndex) { if (rows.length > minRows)
        onChange(rows.filter((_, index) => index !== rowIndex)); }
    return _jsxs("div", { className: "space-y-2", children: [_jsx("div", { className: "overflow-x-auto rounded-md border border-border", children: _jsxs("table", { className: "w-full border-collapse text-sm", children: [_jsx("thead", { children: _jsxs("tr", { className: "bg-surface-subtle", children: [fixed ? _jsx("th", { className: "border-b border-border p-2" }) : null, columns.map((column) => _jsx("th", { className: "border-b border-border p-2 text-left text-xs font-semibold text-fg-muted", children: column.label }, column.key)), !fixed ? _jsx("th", { className: "w-10 border-b border-border" }) : null] }) }), _jsx("tbody", { children: rows.length === 0 ? _jsx("tr", { children: _jsx("td", { colSpan: columns.length + 1, className: "p-4 text-center text-xs text-fg-muted", children: "No rows yet." }) }) : rows.map((row, rowIndex) => _jsxs("tr", { className: "border-b border-border last:border-b-0", children: [fixed ? _jsx("td", { className: "p-2 text-xs font-medium text-fg", children: config.rows?.[rowIndex]?.label }) : null, columns.map((column) => _jsx("td", { className: "min-w-32 p-1.5", children: _jsx(TableCell, { column: column, value: row[column.key], disabled: disabled, onChange: (next) => setCell(rowIndex, column.key, next) }) }, column.key)), !fixed ? _jsx("td", { className: "p-1", children: _jsx(Button, { type: "button", variant: "ghost", size: "icon", disabled: disabled || rows.length <= minRows, "aria-label": `Remove row ${rowIndex + 1}`, onClick: () => removeRow(rowIndex), children: _jsx(Trash2, { size: 14 }) }) }) : null] }, rowIndex)) })] }) }), !fixed ? _jsxs(Button, { type: "button", variant: "outline", size: "sm", disabled: disabled || (config.maxRows != null && rows.length >= config.maxRows), onClick: addRow, children: [_jsx(Plus, { size: 14 }), "Add row"] }) : null] });
}
function TableCell({ column, value, disabled, onChange }) {
    if (column.type === 'checkbox')
        return _jsx(Checkbox, { checked: value === true, disabled: disabled, onChange: (event) => onChange(event.currentTarget.checked), "aria-label": column.label });
    if (column.type === 'select')
        return _jsxs("select", { className: "h-9 w-full rounded-md border border-border bg-surface px-2 text-sm text-fg", value: typeof value === 'string' ? value : '', disabled: disabled, onChange: (event) => onChange(event.currentTarget.value || undefined), children: [_jsx("option", { value: "", children: "Select\u2026" }), column.options?.map((option) => _jsx("option", { value: option.value, children: option.label }, option.value))] });
    return _jsx(Input, { className: "h-9", type: column.type === 'number' ? 'number' : column.type === 'date' ? 'date' : 'text', value: column.type === 'number' ? typeof value === 'number' ? value : '' : typeof value === 'string' ? value : '', disabled: disabled, onChange: (event) => onChange(column.type === 'number' ? event.currentTarget.value === '' ? undefined : Number(event.currentTarget.value) : event.currentTarget.value) });
}
export function AddressField({ value, onChange, disabled }) {
    const current = isRecord(value) ? value : {};
    const set = (patch) => onChange({ ...current, ...patch });
    return _jsxs("div", { className: "grid gap-2 sm:grid-cols-2", children: [_jsx(Input, { className: "sm:col-span-2", value: stringValue(current.line1), placeholder: "Street address", disabled: disabled, onChange: (event) => set({ line1: event.currentTarget.value }) }), _jsx(Input, { value: stringValue(current.city), placeholder: "City", disabled: disabled, onChange: (event) => set({ city: event.currentTarget.value }) }), _jsx(Input, { value: stringValue(current.region), placeholder: "State / province", disabled: disabled, onChange: (event) => set({ region: event.currentTarget.value }) }), _jsx(Input, { value: stringValue(current.postal), placeholder: "Postal code", disabled: disabled, onChange: (event) => set({ postal: event.currentTarget.value }) }), _jsx(Input, { value: stringValue(current.country), placeholder: "Country", disabled: disabled, onChange: (event) => set({ country: event.currentTarget.value }) })] });
}
export function SignatureField({ value, onChange, disabled }) {
    const stored = typeof value === 'string' ? value : isRecord(value) && typeof value.url === 'string' ? value.url : null;
    return _jsx(SignaturePad, { value: stored, onChange: onChange, disabled: disabled });
}
export function SketchField({ value, onChange, disabled }) {
    const stored = isRecord(value) ? value : {};
    return _jsx(SketchPad, { initialScene: stored.scene ?? null, readOnly: disabled, onChange: (dataUrl, scene) => onChange(dataUrl ? { dataUrl, scene } : null) });
}
export function RiskField({ field, value, onChange, disabled, matrix }) {
    const current = isRecord(value) ? value : {};
    return _jsx(RiskMatrixProvider, { matrix: matrix, children: _jsx(RiskMatrixField, { label: typeof field.label === 'string' ? field.label : 'Risk', likelihoodName: `${field.id}.likelihood`, severityName: `${field.id}.severity`, defaultLikelihood: typeof current.likelihood === 'number' ? current.likelihood : undefined, defaultSeverity: typeof current.severity === 'number' ? current.severity : undefined, disabled: disabled, onChange: (next) => onChange(next.likelihood == null || next.severity == null || next.score == null ? {} : next) }) });
}
function isRecord(value) { return typeof value === 'object' && value !== null && !Array.isArray(value); }
function stringValue(value) { return typeof value === 'string' ? value : ''; }
//# sourceMappingURL=runtime-controls.js.map