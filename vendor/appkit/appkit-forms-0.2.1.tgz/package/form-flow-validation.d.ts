import { type AutomationGraph, type FlowSubjectProfile, type FormSchemaV1 } from '@appkit/forms-core';
import { type AppLocale } from '@appkit/i18n';
export declare function formFlowProfile(templateId: string, label: string, schema: FormSchemaV1, locale?: AppLocale, defaultLocale?: AppLocale): FlowSubjectProfile;
export declare function lintFormFlowGraph(graph: AutomationGraph, templateId: string, label: string, schema: FormSchemaV1): string[];
//# sourceMappingURL=form-flow-validation.d.ts.map