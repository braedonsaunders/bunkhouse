import type { LogicRule } from '@appkit/forms-core';
export type LogicBuilderLabels = {
    noFields: string;
    heading: string;
    alwaysVisible: string;
    allOf: string;
    anyOf: string;
    addClause: string;
    removeClause: string;
};
/**
 * Two-mode logic editor:
 *   - "all"/"any" combinator over a flat list of clauses (simple, covers ~90%)
 *   - "raw JSON" fallback for nested/advanced rules
 */
export declare function LogicBuilder({ rule, availableFields, onChange, labels: labelsProp, className, disabled, }: {
    rule: LogicRule | undefined;
    availableFields: {
        id: string;
        label: string;
    }[];
    onChange: (rule: LogicRule | undefined) => void;
    labels?: Partial<LogicBuilderLabels>;
    className?: string;
    disabled?: boolean;
}): import("react").JSX.Element;
//# sourceMappingURL=logic-builder.d.ts.map