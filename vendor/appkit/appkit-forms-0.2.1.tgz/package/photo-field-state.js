/** True only when the ordered attachment identities are unchanged. */
export function attachmentIdsEqual(current, next) {
    return (current.length === next.length &&
        current.every((attachment, index) => attachment.attachmentId === next[index]?.attachmentId));
}
/** Photo annotation intentionally owns exactly one primary photo. */
export function singlePrimaryPhoto(files) {
    const primary = files.at(-1);
    return primary ? [primary] : [];
}
//# sourceMappingURL=photo-field-state.js.map