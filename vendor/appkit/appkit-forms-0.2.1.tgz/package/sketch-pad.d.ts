export type SketchScene = {
    elements?: readonly unknown[];
    appState?: Record<string, unknown>;
    files?: Record<string, unknown>;
};
export type SketchPadProps = {
    initialScene?: SketchScene | null;
    onChange: (dataUrl: string | null, scene: SketchScene) => void;
    height?: number;
    readOnly?: boolean;
};
export declare function SketchPad(props: SketchPadProps): import("react").JSX.Element;
//# sourceMappingURL=sketch-pad.d.ts.map