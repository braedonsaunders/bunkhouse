type AttachmentIdentity = {
    attachmentId: string;
};
/** True only when the ordered attachment identities are unchanged. */
export declare function attachmentIdsEqual(current: readonly AttachmentIdentity[], next: readonly AttachmentIdentity[]): boolean;
/** Photo annotation intentionally owns exactly one primary photo. */
export declare function singlePrimaryPhoto<T extends AttachmentIdentity>(files: readonly T[]): T[];
export {};
//# sourceMappingURL=photo-field-state.d.ts.map