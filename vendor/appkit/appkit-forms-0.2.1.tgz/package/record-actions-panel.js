'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ExternalLink, MousePointerClick, Plus, Trash2 } from 'lucide-react';
import { Button, Input, Label, Select, cn } from '@appkit/ui';
const ACTION_LABEL = {
    send_email: 'Send email',
    create_capa: 'Create corrective action',
    create_incident: 'Create incident',
    notify_role: 'Notify role',
    set_field: 'Set field',
    flag_non_compliant: 'Flag non-compliant',
    webhook: 'Webhook',
    create_response: 'Start another form',
    analyze_photos: 'Analyze photos (AI)',
    start_monitored_session: 'Start monitored session',
    change_status: 'Change status',
    duplicate_record: 'Duplicate record',
    export_pdf: 'Generate PDF',
};
const VARIANTS = [
    { value: 'default', label: 'Primary' },
    { value: 'outline', label: 'Outline' },
    { value: 'secondary', label: 'Secondary' },
    { value: 'destructive', label: 'Destructive' },
];
const QUICK_ACTIONS = ['flag_non_compliant', 'start_monitored_session', 'duplicate_record', 'export_pdf'];
function defaultAction(kind) {
    switch (kind) {
        case 'flag_non_compliant': return { action: 'flag_non_compliant' };
        case 'start_monitored_session': return { action: 'start_monitored_session', intervalMinutes: 30, graceMinutes: 10, durationMinutes: 120, requireGeo: false };
        case 'duplicate_record': return { action: 'duplicate_record' };
        case 'export_pdf': return { action: 'export_pdf' };
    }
}
function slugify(value) {
    return value.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 64);
}
function buttonIdFromLabel(label) {
    const base = slugify(label);
    return `btn_${base || globalThis.crypto.randomUUID().slice(0, 8)}`;
}
export function manualTrigger(graph) {
    for (const node of graph.nodes) {
        if (node.data.kind === 'trigger' && node.data.trigger.trigger === 'manual')
            return node.data.trigger;
    }
    return null;
}
function firstActionLabel(graph) {
    const node = graph.nodes.find((candidate) => candidate.data.kind === 'action');
    if (node?.data.kind === 'action')
        return ACTION_LABEL[node.data.action.action];
    return 'No action yet';
}
export function buildRecordButtonGraph(input) {
    const trigger = {
        trigger: 'manual',
        buttonId: buttonIdFromLabel(input.label),
        label: input.label.trim(),
        variant: input.variant,
        order: input.order,
        ...(input.icon?.trim() ? { icon: input.icon.trim() } : {}),
    };
    return {
        schemaVersion: 1,
        nodes: [
            { id: 'trg', position: { x: 80, y: 80 }, data: { kind: 'trigger', trigger } },
            { id: 'act', position: { x: 400, y: 80 }, data: { kind: 'action', action: defaultAction(input.actionKind) } },
        ],
        edges: [{ id: 'e1', source: 'trg', target: 'act', sourceHandle: 'next' }],
    };
}
export function RecordActionsPanel({ flows, adapter, onChanged, confirmRemove, readOnly = false, className }) {
    const buttons = React.useMemo(() => flows
        .map((flow) => ({ flow, trigger: manualTrigger(flow.graph) }))
        .filter((entry) => entry.trigger !== null)
        .sort((left, right) => (left.trigger.order ?? 0) - (right.trigger.order ?? 0) || left.flow.name.localeCompare(right.flow.name)), [flows]);
    return (_jsxs("div", { className: cn('space-y-4', className), children: [_jsx("p", { className: "text-xs text-fg-muted", children: "Add the buttons people can run from a record. Each button is a manual workflow that can be expanded into conditions, approvals, and multi-step branches in the workflow studio." }), _jsx(ButtonList, { buttons: buttons, adapter: adapter, onChanged: onChanged, confirmRemove: confirmRemove, readOnly: readOnly }), _jsx(AddButtonForm, { adapter: adapter, nextOrder: buttons.length, onChanged: onChanged, readOnly: readOnly })] }));
}
function ButtonList({ buttons, adapter, onChanged, confirmRemove, readOnly }) {
    const [busyId, setBusyId] = React.useState(null);
    const [error, setError] = React.useState(null);
    async function run(flow, task) {
        setBusyId(flow.id);
        setError(null);
        try {
            await task();
            await onChanged?.();
        }
        catch (cause) {
            setError(cause instanceof Error ? cause.message : 'The record action could not be updated.');
        }
        finally {
            setBusyId(null);
        }
    }
    async function remove(flow) {
        if (confirmRemove ? !(await confirmRemove(flow)) : !globalThis.confirm(`Delete the “${manualTrigger(flow.graph)?.label || flow.name}” button? Its workflow is removed too.`))
            return;
        await run(flow, () => adapter.remove(flow.id));
    }
    if (buttons.length === 0)
        return _jsx("p", { className: "rounded-md border border-dashed border-border px-3 py-4 text-center text-xs text-fg-subtle", children: "No record buttons yet." });
    return (_jsxs("div", { className: "space-y-2", children: [_jsx("ul", { className: "space-y-2", children: buttons.map(({ flow, trigger }) => (_jsxs("li", { className: "rounded-md border border-border p-3", children: [_jsxs("div", { className: "flex items-start justify-between gap-2", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex items-center gap-1.5 text-sm font-medium text-fg", children: [_jsx(MousePointerClick, { size: 13, className: "shrink-0 text-fg-subtle" }), _jsx("span", { className: "truncate", children: trigger.label || 'Untitled button' })] }), _jsxs("div", { className: "mt-0.5 text-xs text-fg-muted", children: [firstActionLabel(flow.graph), !flow.enabled ? _jsx("span", { className: "ml-2 rounded bg-bg-subtle px-1.5 py-0.5 text-[10px] font-medium", children: "Disabled" }) : null] })] }), _jsxs("label", { className: "flex shrink-0 cursor-pointer items-center gap-1 text-[11px] text-fg-muted", children: [_jsx("input", { type: "checkbox", checked: flow.enabled, disabled: readOnly || busyId === flow.id, onChange: (event) => run(flow, () => adapter.setEnabled(flow.id, event.target.checked)) }), "Enabled"] })] }), _jsxs("div", { className: "mt-2 flex items-center gap-2", children: [adapter.open ? _jsxs("button", { type: "button", disabled: readOnly, onClick: () => adapter.open?.(flow.id), className: "inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline disabled:opacity-50", children: [_jsx(ExternalLink, { size: 12 }), "Open workflow"] }) : null, _jsxs("button", { type: "button", disabled: readOnly || busyId === flow.id, onClick: () => remove(flow), className: "ml-auto inline-flex items-center gap-1 text-xs font-medium text-danger hover:underline disabled:opacity-50", children: [_jsx(Trash2, { size: 12 }), "Delete"] })] })] }, flow.id))) }), error ? _jsx("p", { role: "alert", className: "text-xs text-danger", children: error }) : null] }));
}
function AddButtonForm({ adapter, nextOrder, onChanged, readOnly }) {
    const [label, setLabel] = React.useState('');
    const [actionKind, setActionKind] = React.useState('export_pdf');
    const [icon, setIcon] = React.useState('');
    const [variant, setVariant] = React.useState('default');
    const [pending, startTransition] = React.useTransition();
    const [error, setError] = React.useState(null);
    function add() {
        const trimmed = label.trim();
        if (trimmed.length < 2) {
            setError('Enter a button label with at least two characters.');
            return;
        }
        setError(null);
        startTransition(async () => {
            try {
                const graph = buildRecordButtonGraph({ label: trimmed, icon, variant, actionKind, order: nextOrder });
                await adapter.create(trimmed, graph);
                setLabel('');
                setIcon('');
                await onChanged?.();
            }
            catch (cause) {
                setError(cause instanceof Error ? cause.message : 'The record button could not be created.');
            }
        });
    }
    return (_jsxs("div", { className: "space-y-3 rounded-md border border-border p-3", children: [_jsx("div", { className: "text-sm font-medium text-fg", children: "Add record button" }), _jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-xs", children: "Label" }), _jsx(Input, { value: label, disabled: readOnly, placeholder: "Generate PDF", onChange: (event) => setLabel(event.target.value) })] }), _jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-xs", children: "First action" }), _jsx(Select, { value: actionKind, disabled: readOnly, onChange: (event) => setActionKind(event.target.value), children: QUICK_ACTIONS.map((action) => _jsx("option", { value: action, children: ACTION_LABEL[action] }, action)) })] }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-xs", children: "Style" }), _jsx(Select, { value: variant, disabled: readOnly, onChange: (event) => setVariant(event.target.value), children: VARIANTS.map((option) => _jsx("option", { value: option.value, children: option.label }, option.value)) })] }), _jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-xs", children: "Icon" }), _jsx(Input, { value: icon, disabled: readOnly, placeholder: "download", onChange: (event) => setIcon(event.target.value) })] })] }), _jsx("p", { className: "text-[11px] text-fg-subtle", children: "The workflow opens with one trigger and one action. Add conditions, approvals, notifications, and branches in the workflow studio." }), error ? _jsx("p", { role: "alert", className: "text-xs text-danger", children: error }) : null, _jsxs(Button, { type: "button", disabled: pending || readOnly, className: "w-full", onClick: add, children: [_jsx(Plus, { size: 14 }), pending ? 'Adding…' : 'Add button'] })] }));
}
//# sourceMappingURL=record-actions-panel.js.map