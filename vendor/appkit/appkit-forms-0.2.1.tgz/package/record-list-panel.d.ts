import * as React from 'react';
import type { ListColumnConfig, ListConfig } from './record-config.js';
export declare const DEFAULT_RECORD_LIST_COLUMNS: ListColumnConfig[];
export type RecordListPanelProps = {
    value?: ListConfig;
    fields: {
        id: string;
        label: string;
    }[];
    onChange: (config: ListConfig) => void;
    onSave?: (config: ListConfig) => void | Promise<void>;
    readOnly?: boolean;
    className?: string;
};
export declare function RecordListPanel({ value, fields, onChange, onSave, readOnly, className }: RecordListPanelProps): React.JSX.Element;
//# sourceMappingURL=record-list-panel.d.ts.map