'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Check, ChevronDown } from 'lucide-react';
import { cn } from '@appkit/ui';
const TONE = {
    neutral: 'bg-bg-subtle text-fg-muted',
    info: 'bg-info-subtle text-info',
    accent: 'bg-accent-subtle text-accent',
    primary: 'bg-primary-subtle text-primary',
    warning: 'bg-warning-subtle text-warning',
    success: 'bg-success-subtle text-success',
    danger: 'bg-danger-subtle text-danger',
    teal: 'bg-primary-subtle text-primary',
    blue: 'bg-info-subtle text-info',
    purple: 'bg-accent-subtle text-accent',
    amber: 'bg-warning-subtle text-warning',
    indigo: 'bg-accent-subtle text-accent',
    emerald: 'bg-success-subtle text-success',
    rose: 'bg-danger-subtle text-danger',
    slate: 'bg-bg-subtle text-fg-muted',
};
/** Tokenized extraction of the production collapsible record section. */
export function ProductionSection({ title, subtitle, actions, defaultOpen = true, children, }) {
    const [open, setOpen] = React.useState(defaultOpen);
    return (_jsxs("section", { className: "overflow-hidden rounded-lg border border-border bg-surface", children: [_jsxs("div", { className: "flex items-center gap-3 pr-5", children: [_jsx("button", { type: "button", onClick: () => setOpen((value) => !value), className: "flex min-w-0 flex-1 items-center gap-3 px-5 py-3 text-left hover:bg-surface-hover", "aria-expanded": open, children: _jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex items-center gap-2 text-base font-semibold text-fg", children: [_jsx(ChevronDown, { size: 16, className: cn('text-fg-subtle transition-transform', !open && '-rotate-90') }), title] }), subtitle ? _jsx("div", { className: "ml-6 text-xs text-fg-muted", children: subtitle }) : null] }) }), actions ? _jsx("div", { className: "shrink-0", children: actions }) : null] }), open ? _jsx("div", { className: "border-t border-border-subtle px-5 py-4", children: children }) : null] }));
}
/** Tokenized extraction of the production premium single-page section card. */
export function ProductionPremiumSection({ title, subtitle, actions, icon, tone = 'neutral', count, done, doneLabel = 'Done', defaultOpen = true, children, }) {
    const [open, setOpen] = React.useState(defaultOpen);
    return (_jsxs("section", { className: "overflow-hidden rounded-2xl border border-border bg-surface shadow-sm transition-shadow hover:shadow-md", children: [_jsxs("div", { className: "flex items-center gap-3 p-4 sm:gap-4 sm:p-5", children: [icon ? (_jsx("span", { className: cn('flex size-11 shrink-0 items-center justify-center rounded-xl', TONE[tone]), children: icon })) : null, _jsxs("button", { type: "button", onClick: () => setOpen((value) => !value), className: "flex min-w-0 flex-1 items-center justify-between gap-3 text-left", "aria-expanded": open, children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("h2", { className: "truncate text-base font-semibold text-fg sm:text-[17px]", children: title }), typeof count === 'number' ? (_jsx("span", { className: "rounded-full bg-bg-subtle px-2 py-0.5 text-xs font-medium text-fg-muted", children: count })) : null, done ? (_jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-success-subtle px-2 py-0.5 text-xs font-medium text-success", children: [_jsx(Check, { size: 11 }), " ", doneLabel] })) : null] }), subtitle ? _jsx("p", { className: "mt-0.5 truncate text-sm text-fg-muted", children: subtitle }) : null] }), _jsx(ChevronDown, { size: 18, className: cn('shrink-0 text-fg-subtle transition-transform', !open && '-rotate-90') })] }), actions ? _jsx("div", { className: "shrink-0", children: actions }) : null] }), open ? _jsx("div", { className: "border-t border-border-subtle p-4 sm:p-5", children: children }) : null] }));
}
//# sourceMappingURL=production-runtime-layout.js.map