import * as React from 'react';
import { type FinalizeUploadAction, type RequestUploadAction } from '@appkit/ui';
export type ProductionAttachedFile = {
    attachmentId: string;
    filename: string;
    contentType: string;
    url: string;
};
export type ProductionFileUploadProps = {
    value: ProductionAttachedFile[];
    onChange: (files: ProductionAttachedFile[]) => void;
    requestUpload: RequestUploadAction;
    finalizeUpload: FinalizeUploadAction;
    accept?: string;
    multiple?: boolean;
    maxFiles?: number;
    onUploadingChange?: (uploading: boolean) => void;
    variant?: 'photo' | 'file' | 'video' | 'audio';
};
/**
 * Production form-field uploader: controlled attachments, environment camera
 * capture, bounded counts, reserved upload/finalize protocol, previews, and
 * removal. Storage policy remains an injected application boundary.
 */
export declare function ProductionFileUpload({ value, onChange, requestUpload, finalizeUpload, accept, multiple, maxFiles, onUploadingChange, variant, }: ProductionFileUploadProps): React.JSX.Element;
export declare function dataUrlToFile(dataUrl: string, filename: string): File;
//# sourceMappingURL=production-file-upload.d.ts.map