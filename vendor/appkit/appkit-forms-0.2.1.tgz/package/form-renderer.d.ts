import * as React from 'react';
import { type EntityAttrsByField, type EvalContext, type FieldType, type FormField, type FormSchemaV1 } from '@appkit/forms-core';
import { type AppLocale } from '@appkit/i18n';
import type { RiskMatrixConfig } from './risk-matrix.js';
export type FormValues = Record<string, unknown>;
export type FormOption = {
    value: string;
    label: string;
    hint?: string;
};
export type FormFieldAdapterProps = {
    field: FormField;
    value: unknown;
    onChange: (value: unknown) => void;
    error?: string;
    disabled: boolean;
    locale: AppLocale;
};
export type FormFieldAdapter = (props: FormFieldAdapterProps) => React.ReactNode;
export type FormRendererProps = {
    schema: FormSchemaV1;
    values?: FormValues;
    defaultValues?: FormValues;
    onChange?: (values: FormValues) => void;
    onSubmit?: (values: FormValues) => void | Promise<void>;
    locale?: AppLocale;
    disabled?: boolean;
    submitLabel?: string;
    optionsByField?: Readonly<Record<string, readonly FormOption[]>>;
    fieldAdapters?: Partial<Record<FieldType, FormFieldAdapter>>;
    className?: string;
    requestContext?: EvalContext['requestContext'];
    entities?: EntityAttrsByField;
    riskMatrix?: RiskMatrixConfig;
};
export declare function FormRenderer({ schema, values: controlledValues, defaultValues, onChange, onSubmit, locale, disabled, submitLabel, optionsByField, fieldAdapters, className, requestContext, entities, riskMatrix, }: FormRendererProps): React.JSX.Element;
//# sourceMappingURL=form-renderer.d.ts.map