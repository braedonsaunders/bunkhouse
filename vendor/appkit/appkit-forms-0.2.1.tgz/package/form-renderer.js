'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowDown, ArrowUp, Plus, Trash2 } from 'lucide-react';
import { evaluateLogicRule, evaluateFormulaTree, resolveDefaultValue, validateResponse, } from '@appkit/forms-core';
import { DEFAULT_LOCALE } from '@appkit/i18n';
import { Alert, AlertDescription, Button, Checkbox, Input, Label, Textarea, cn, } from '@appkit/ui';
import { RichTextEditor } from '@appkit/editor';
import { readText } from './text.js';
import { AddressField, GpsField, MatrixField, RiskField, SignatureField, SketchField, TableField } from './runtime-controls.js';
const ADAPTER_FIELD_TYPES = new Set([
    'photo',
    'photo_upload',
    'photo_ai',
    'photo_annotated',
    'file',
    'video',
    'audio',
    'lookup',
    'data_table',
    'metric',
]);
export function FormRenderer({ schema, values: controlledValues, defaultValues = {}, onChange, onSubmit, locale = DEFAULT_LOCALE, disabled = false, submitLabel = 'Submit', optionsByField = {}, fieldAdapters = {}, className, requestContext, entities = {}, riskMatrix, }) {
    const initialValues = React.useMemo(() => applySchemaDefaults(schema, defaultValues, requestContext, entities), [defaultValues, entities, requestContext, schema]);
    const [internalValues, setInternalValues] = React.useState(initialValues);
    const [errors, setErrors] = React.useState([]);
    const [submitting, setSubmitting] = React.useState(false);
    const [stepIndex, setStepIndex] = React.useState(0);
    const [activeTabId, setActiveTabId] = React.useState(schema.tabs?.[0]?.id ?? '');
    const values = controlledValues ?? internalValues;
    const errorMap = new Map(errors.map((error) => [error.fieldId, error.message]));
    const rows = Object.fromEntries(schema.sections.filter((section) => section.repeating).map((section) => [section.id, Array.isArray(values[section.id]) ? values[section.id] : []]));
    const evalContext = { values, rows, entities, requestContext };
    const steps = schema.workflow?.steps ?? [];
    const currentStep = steps[Math.min(stepIndex, Math.max(0, steps.length - 1))];
    const stepSections = currentStep
        ? schema.sections.filter((section) => (section.step ?? steps[0]?.key) === currentStep.key)
        : schema.sections;
    const tabs = schema.tabs ?? [];
    const visibleSections = tabs.length > 1 && steps.length <= 1
        ? stepSections.filter((section) => (section.tabId ?? tabs[0]?.id) === activeTabId)
        : stepSections;
    function update(fieldId, next) {
        const updated = { ...values, [fieldId]: next };
        if (controlledValues === undefined)
            setInternalValues(updated);
        onChange?.(updated);
        if (errorMap.has(fieldId))
            setErrors((current) => current.filter((error) => error.fieldId !== fieldId));
    }
    async function submit(event) {
        event.preventDefault();
        const nextErrors = validateResponse(schema, values, 'submit');
        setErrors(nextErrors);
        if (nextErrors.length > 0 || !onSubmit)
            return;
        setSubmitting(true);
        try {
            await onSubmit(values);
        }
        finally {
            setSubmitting(false);
        }
    }
    function nextStep() {
        const sectionIds = new Set(stepSections.map((section) => section.id));
        const fieldIds = new Set(stepSections.flatMap((section) => section.fields.map((field) => field.id)));
        const nextErrors = validateResponse(schema, values, 'submit').filter((error) => {
            if (error.fieldId.startsWith('__section_'))
                return sectionIds.has(error.fieldId.slice(10));
            if (fieldIds.has(error.fieldId))
                return true;
            return [...sectionIds].some((sectionId) => error.fieldId.startsWith(`${sectionId}.`));
        });
        setErrors(nextErrors);
        if (nextErrors.length === 0)
            setStepIndex((current) => Math.min(steps.length - 1, current + 1));
    }
    return (_jsxs("form", { onSubmit: submit, className: cn('space-y-6', className), noValidate: true, children: [_jsxs("header", { className: "space-y-1", children: [_jsx("h1", { className: "text-2xl font-semibold tracking-tight text-fg", children: readText(schema.title, locale, 'Untitled form') }), schema.description ? _jsx("p", { className: "text-sm text-fg-muted", children: readText(schema.description, locale) }) : null] }), steps.length > 1 ? _jsx("nav", { "aria-label": "Form progress", className: "grid gap-2", style: { gridTemplateColumns: `repeat(${steps.length}, minmax(0, 1fr))` }, children: steps.map((step, index) => _jsx("button", { type: "button", onClick: () => index <= stepIndex && setStepIndex(index), disabled: index > stepIndex, className: cn('rounded-md border px-3 py-2 text-left text-xs', index === stepIndex ? 'border-primary bg-primary-subtle text-primary' : index < stepIndex ? 'border-success bg-success-subtle text-success' : 'border-border bg-surface text-fg-muted'), children: _jsxs("span", { className: "block font-semibold", children: [index + 1, ". ", readText(step.title, locale, step.key)] }) }, step.key)) }) : null, tabs.length > 1 && steps.length <= 1 ? _jsx("div", { role: "tablist", className: "flex gap-1 overflow-x-auto border-b border-border", children: tabs.map((tab) => _jsx("button", { type: "button", role: "tab", "aria-selected": activeTabId === tab.id, onClick: () => setActiveTabId(tab.id), className: cn('border-b-2 px-3 py-2 text-sm font-medium', activeTabId === tab.id ? 'border-primary text-primary' : 'border-transparent text-fg-muted hover:text-fg'), children: readText(tab.title, locale, tab.id) }, tab.id)) }) : null, errors.length > 0 ? (_jsx(Alert, { variant: "destructive", role: "alert", children: _jsxs(AlertDescription, { children: ["Review ", errors.length, " field", errors.length === 1 ? '' : 's', " before submitting."] }) })) : null, visibleSections.map((section) => {
                const visible = !section.showIf || evaluateLogicRule(section.showIf, evalContext);
                if (!visible)
                    return null;
                if (section.repeating) {
                    const rows = Array.isArray(values[section.id])
                        ? values[section.id]
                        : [];
                    return (_jsx(RepeatingSection, { section: section, rows: rows, onChange: (next) => update(section.id, next), errorMap: errorMap, disabled: disabled || submitting, locale: locale, optionsByField: optionsByField, fieldAdapters: fieldAdapters, evalContext: evalContext, riskMatrix: riskMatrix }, section.id));
                }
                return (_jsxs("section", { className: "rounded-xl border border-border bg-surface shadow-sm", children: [(section.title || section.description) ? (_jsxs("div", { className: "border-b border-border bg-bg-subtle px-5 py-4", children: [section.title ? _jsx("h2", { className: "font-semibold text-fg", children: readText(section.title, locale) }) : null, section.description ? _jsx("p", { className: "mt-1 text-sm text-fg-muted", children: readText(section.description, locale) }) : null] })) : null, _jsx("div", { className: cn('grid gap-5 p-5', section.canvas ? 'grid-cols-12 auto-rows-[40px]' : section.layout?.columns === 2 ? 'sm:grid-cols-2' : section.layout?.columns === 3 ? 'sm:grid-cols-2 lg:grid-cols-3' : section.layout?.columns === 4 ? 'sm:grid-cols-2 lg:grid-cols-4' : ''), children: section.fields.map((field) => {
                                const fieldVisible = !field.showIf || evaluateLogicRule(field.showIf, evalContext);
                                if (!fieldVisible)
                                    return null;
                                const canvasItem = section.canvas?.items.find((item) => item.i === field.id);
                                const fieldValue = field.type === 'formula' && field.formula
                                    ? evaluateFormulaTree(field.formula, evalContext)
                                    : values[field.id];
                                return (_jsx("div", { className: cn(!canvasItem && field.config?.width === 'full' && 'col-span-full'), style: canvasItem ? { gridColumn: `${canvasItem.x + 1} / span ${canvasItem.w}`, gridRow: `${canvasItem.y + 1} / span ${canvasItem.h}` } : undefined, children: _jsx(FieldControl, { field: field, value: fieldValue, onChange: (next) => update(field.id, next), error: errorMap.get(field.id), disabled: disabled || submitting, locale: locale, options: optionsByField[field.id] ?? [], adapter: fieldAdapters[field.type], riskMatrix: riskMatrix }) }, field.id));
                            }) })] }, section.id));
            }), onSubmit ? _jsxs("div", { className: "flex justify-between gap-2", children: [steps.length > 1 && stepIndex > 0 ? _jsx(Button, { type: "button", variant: "outline", disabled: disabled || submitting, onClick: () => setStepIndex((current) => Math.max(0, current - 1)), children: "Back" }) : _jsx("span", {}), steps.length > 1 && stepIndex < steps.length - 1 ? _jsx(Button, { type: "button", disabled: disabled || submitting, onClick: nextStep, children: "Next" }) : _jsx(Button, { type: "submit", disabled: disabled || submitting, children: submitting ? 'Submitting…' : submitLabel })] }) : null] }));
}
function RepeatingSection({ section, rows, onChange, errorMap, disabled, locale, optionsByField, fieldAdapters, evalContext, riskMatrix }) {
    const canAdd = section.maxRows === undefined || rows.length < section.maxRows;
    const canRemove = rows.length > (section.minRows ?? 0);
    function patchRow(rowIndex, fieldId, value) {
        const next = rows.map((row, index) => index === rowIndex ? { ...row, [fieldId]: value } : row);
        onChange(next);
    }
    return (_jsxs("section", { className: "rounded-xl border border-border bg-surface shadow-sm", children: [_jsxs("div", { className: "flex items-start justify-between gap-4 border-b border-border bg-bg-subtle px-5 py-4", children: [_jsxs("div", { children: [section.title ? _jsx("h2", { className: "font-semibold text-fg", children: readText(section.title, locale) }) : null, section.description ? _jsx("p", { className: "mt-1 text-sm text-fg-muted", children: readText(section.description, locale) }) : null] }), _jsxs(Button, { type: "button", size: "sm", variant: "outline", disabled: disabled || !canAdd, onClick: () => onChange([...rows, {}]), children: [_jsx(Plus, { size: 15 }), "Add row"] })] }), _jsxs("div", { className: "space-y-4 p-5", children: [errorMap.get(`__section_${section.id}`) ? _jsx("p", { className: "text-sm text-danger", children: errorMap.get(`__section_${section.id}`) }) : null, rows.length === 0 ? _jsx("p", { className: "rounded-lg border border-dashed border-border-strong px-4 py-6 text-center text-sm text-fg-muted", children: "No rows yet." }) : null, rows.map((row, rowIndex) => (_jsxs("div", { className: "rounded-lg border border-border bg-bg p-4", children: [_jsxs("div", { className: "mb-4 flex items-center justify-between gap-3", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: rowLabel(section.rowLabelTemplate, rowIndex, row) }), _jsx(Button, { type: "button", size: "icon", variant: "ghost", "aria-label": `Remove row ${rowIndex + 1}`, disabled: disabled || !canRemove, onClick: () => onChange(rows.filter((_, index) => index !== rowIndex)), children: _jsx(Trash2, { size: 15 }) })] }), _jsx("div", { className: "grid gap-5 sm:grid-cols-2", children: section.fields.map((field) => {
                                    const rowContext = { ...evalContext, values: { ...evalContext.values, ...row } };
                                    const visible = !field.showIf || evaluateLogicRule(field.showIf, rowContext);
                                    if (!visible)
                                        return null;
                                    const fieldValue = field.type === 'formula' && field.formula ? evaluateFormulaTree(field.formula, rowContext) : row[field.id];
                                    return _jsx(FieldControl, { field: field, value: fieldValue, onChange: (next) => patchRow(rowIndex, field.id, next), error: errorMap.get(`${section.id}.${rowIndex}.${field.id}`), disabled: disabled, locale: locale, options: optionsByField[field.id] ?? [], adapter: fieldAdapters[field.type], riskMatrix: riskMatrix }, field.id);
                                }) })] }, rowIndex)))] })] }));
}
function rowLabel(template, index, row) {
    if (!template)
        return `Row ${index + 1}`;
    return template
        .replaceAll('{index+1}', String(index + 1))
        .replaceAll('{index}', String(index))
        .replace(/\{([A-Za-z0-9_-]+)\}/g, (_, key) => String(row[key] ?? ''));
}
function FieldControl({ field, value, onChange, error, disabled, locale, options, adapter, riskMatrix }) {
    if (adapter)
        return _jsxs("div", { className: "space-y-2", children: [fieldLabel(field, locale), adapter({ field, value, onChange, error, disabled, locale }), fieldHelp(field, locale, error)] });
    if (field.type === 'heading')
        return _jsx("h3", { className: "col-span-full text-lg font-semibold text-fg", children: readText(field.label, locale) });
    if (field.type === 'paragraph')
        return _jsx("p", { className: "col-span-full text-sm text-fg-muted", children: readText(field.helpText ?? field.label, locale) });
    if (field.type === 'divider')
        return _jsx("hr", { className: "col-span-full border-border" });
    if (field.type === 'formula')
        return _jsx(OutputField, { field: field, value: value, locale: locale });
    const nativeProps = { field, value, onChange, disabled };
    if (field.type === 'gps')
        return _jsx(FieldFrame, { field: field, locale: locale, error: error, children: _jsx(GpsField, { ...nativeProps }) });
    if (field.type === 'address')
        return _jsx(FieldFrame, { field: field, locale: locale, error: error, children: _jsx(AddressField, { ...nativeProps }) });
    if (field.type === 'table')
        return _jsx(FieldFrame, { field: field, locale: locale, error: error, children: _jsx(TableField, { ...nativeProps }) });
    if (field.type === 'matrix')
        return _jsx(FieldFrame, { field: field, locale: locale, error: error, children: _jsx(MatrixField, { ...nativeProps }) });
    if (field.type === 'risk_matrix')
        return _jsx(FieldFrame, { field: field, locale: locale, error: error, hideLabel: true, children: _jsx(RiskField, { ...nativeProps, matrix: riskMatrix }) });
    if (field.type === 'signature')
        return _jsx(FieldFrame, { field: field, locale: locale, error: error, children: _jsx(SignatureField, { ...nativeProps }) });
    if (field.type === 'sketch')
        return _jsx(FieldFrame, { field: field, locale: locale, error: error, children: _jsx(SketchField, { ...nativeProps }) });
    if (ADAPTER_FIELD_TYPES.has(field.type))
        throw new Error(`Form field ${field.id} (${field.type}) requires a field adapter`);
    const common = { id: field.id, disabled, 'aria-invalid': Boolean(error), 'aria-describedby': `${field.id}-help` };
    const choiceOptions = field.validation?.options?.map((option) => ({ value: option.value, label: readText(option.label, locale) })) ?? options;
    let control;
    switch (field.type) {
        case 'long_text':
            control = _jsx(Textarea, { ...common, value: typeof value === 'string' ? value : '', onChange: (event) => onChange(event.target.value) });
            break;
        case 'rich_text':
            control = _jsx(RichTextEditor, { value: typeof value === 'string' ? value : '', disabled: disabled, onChange: onChange, normalizeLink: safeLink });
            break;
        case 'number':
        case 'currency':
        case 'percentage':
            control = _jsx(Input, { ...common, type: "number", inputMode: "decimal", value: typeof value === 'number' ? value : '', min: numberConfig(field, 'min'), max: numberConfig(field, 'max'), step: numberConfig(field, 'step') ?? (field.type === 'currency' ? 0.01 : 'any'), onChange: (event) => onChange(event.target.value === '' ? undefined : Number(event.target.value)) });
            break;
        case 'slider': {
            const min = numberConfig(field, 'min') ?? 0;
            const max = numberConfig(field, 'max') ?? 10;
            control = _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("input", { ...common, className: "h-2 flex-1 accent-primary", type: "range", min: min, max: max, step: numberConfig(field, 'step') ?? 1, value: typeof value === 'number' ? value : min, onChange: (event) => onChange(Number(event.target.value)) }), _jsx("output", { className: "w-10 text-right text-sm tabular-nums text-fg", children: typeof value === 'number' ? value : min })] });
            break;
        }
        case 'rating': {
            const max = numberConfig(field, 'max') ?? 5;
            control = _jsx("div", { className: "flex flex-wrap gap-2", children: Array.from({ length: max }, (_, index) => index + 1).map((rating) => _jsx(Button, { type: "button", size: "icon", variant: value === rating ? 'default' : 'outline', disabled: disabled, onClick: () => onChange(rating), "aria-label": `Rate ${rating} of ${max}`, children: rating }, rating)) });
            break;
        }
        case 'radio':
        case 'pass_fail_na':
        case 'traffic_light': {
            const items = field.type === 'pass_fail_na' ? [{ value: 'pass', label: 'Pass' }, { value: 'fail', label: 'Fail' }, { value: 'n_a', label: 'N/A' }] : field.type === 'traffic_light' ? [{ value: 'green', label: 'Green' }, { value: 'yellow', label: 'Yellow' }, { value: 'red', label: 'Red' }] : choiceOptions;
            control = _jsx("div", { className: "flex flex-wrap gap-2", children: items.map((option) => _jsx(Button, { type: "button", size: "sm", variant: value === option.value ? 'default' : 'outline', disabled: disabled, onClick: () => onChange(option.value), children: option.label }, option.value)) });
            break;
        }
        case 'checkbox_group':
        case 'multi_select':
        case 'multi_person_picker': {
            const selected = Array.isArray(value) ? value.filter((item) => typeof item === 'string') : [];
            control = _jsx("div", { className: "space-y-2", children: choiceOptions.map((option) => _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { disabled: disabled, checked: selected.includes(option.value), onChange: (event) => onChange(event.target.checked ? [...selected, option.value] : selected.filter((entry) => entry !== option.value)) }), option.label] }, option.value)) });
            break;
        }
        case 'ranking': {
            const ordered = Array.isArray(value) && value.length > 0
                ? value.filter((item) => typeof item === 'string')
                : choiceOptions.map((option) => option.value);
            control = _jsx("div", { className: "space-y-1", children: ordered.map((entry, index) => { const option = choiceOptions.find((item) => item.value === entry); return _jsxs("div", { className: "flex items-center gap-2 rounded-md border border-border bg-bg-subtle px-2 py-1.5", children: [_jsx("span", { className: "w-5 text-center text-xs tabular-nums text-fg-muted", children: index + 1 }), _jsx("span", { className: "min-w-0 flex-1 truncate text-sm text-fg", children: option?.label ?? entry }), _jsx(Button, { type: "button", size: "icon", variant: "ghost", "aria-label": `Move ${option?.label ?? entry} up`, disabled: disabled || index === 0, onClick: () => onChange(move(ordered, index, index - 1)), children: _jsx(ArrowUp, { size: 14 }) }), _jsx(Button, { type: "button", size: "icon", variant: "ghost", "aria-label": `Move ${option?.label ?? entry} down`, disabled: disabled || index === ordered.length - 1, onClick: () => onChange(move(ordered, index, index + 1)), children: _jsx(ArrowDown, { size: 14 }) })] }, entry); }) });
            break;
        }
        case 'select':
        case 'person_picker':
        case 'customer_picker':
        case 'project_picker':
        case 'site_picker':
        case 'area_picker':
        case 'gl_account':
        case 'party':
            control = _jsxs("select", { ...common, className: "h-10 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/40", value: typeof value === 'string' ? value : '', onChange: (event) => onChange(event.target.value || undefined), children: [_jsx("option", { value: "", children: "Select\u2026" }), choiceOptions.map((option) => _jsx("option", { value: option.value, children: option.label }, option.value))] });
            break;
        case 'yes_no_comment': {
            const current = typeof value === 'object' && value !== null ? value : {};
            control = _jsxs("div", { className: "space-y-3", children: [_jsx("div", { className: "flex gap-2", children: ['yes', 'no'].map((answer) => _jsx(Button, { type: "button", size: "sm", variant: current.answer === answer ? 'default' : 'outline', disabled: disabled, onClick: () => onChange({ ...current, answer }), children: answer === 'yes' ? 'Yes' : 'No' }, answer)) }), current.answer === 'no' ? _jsx(Textarea, { value: current.comment ?? '', placeholder: "Add a comment\u2026", disabled: disabled, onChange: (event) => onChange({ ...current, comment: event.target.value }) }) : null] });
            break;
        }
        case 'typed_attestation': {
            const current = typeof value === 'object' && value !== null ? value : {};
            control = _jsxs("div", { className: "space-y-2", children: [_jsx(Input, { ...common, value: current.name ?? '', placeholder: "Type your full name", onChange: (event) => onChange({ ...current, name: event.target.value }) }), _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { disabled: disabled, checked: current.agreed ?? false, onChange: (event) => onChange({ ...current, agreed: event.target.checked }) }), "I confirm this attestation."] })] });
            break;
        }
        default: {
            const inputType = field.type === 'email' ? 'email' : field.type === 'phone' ? 'tel' : field.type === 'url' ? 'url' : field.type === 'date' ? 'date' : field.type === 'datetime' ? 'datetime-local' : field.type === 'time' ? 'time' : 'text';
            control = _jsx(Input, { ...common, type: inputType, value: typeof value === 'string' ? value : '', onChange: (event) => onChange(event.target.value) });
        }
    }
    return _jsxs("div", { className: cn('space-y-2', (field.colSpan ?? 1) > 1 && 'sm:col-span-2'), children: [fieldLabel(field, locale), control, fieldHelp(field, locale, error)] });
}
function FieldFrame({ field, locale, error, hideLabel = false, children }) {
    return _jsxs("div", { className: cn('space-y-2', (field.colSpan ?? 1) > 1 && 'sm:col-span-2'), children: [hideLabel ? null : fieldLabel(field, locale), children, fieldHelp(field, locale, error)] });
}
function fieldLabel(field, locale) {
    return _jsxs(Label, { htmlFor: field.id, children: [readText(field.label, locale), field.required || field.validation?.required ? _jsx("span", { className: "ml-1 text-danger", "aria-hidden": "true", children: "*" }) : null] });
}
function fieldHelp(field, locale, error) {
    return _jsx("p", { id: `${field.id}-help`, className: cn('text-xs', error ? 'text-danger' : 'text-fg-muted'), children: error ?? readText(field.helpText, locale) });
}
function OutputField({ field, value, locale }) {
    return _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: readText(field.label, locale) }), _jsx("output", { className: "block rounded-md border border-border bg-bg-subtle px-3 py-2 text-sm font-medium text-fg", children: value === undefined || value === null ? '—' : String(value) })] });
}
function numberConfig(field, key) {
    const value = field.config?.[key];
    return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}
function move(values, from, to) {
    if (to < 0 || to >= values.length)
        return values;
    const next = [...values];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    return next;
}
function safeLink(value) {
    try {
        const url = new URL(value, window.location.origin);
        return ['http:', 'https:', 'mailto:'].includes(url.protocol) ? url.href : null;
    }
    catch {
        return null;
    }
}
function applySchemaDefaults(schema, supplied, requestContext, entities) {
    const values = structuredClone(supplied);
    const rows = Object.fromEntries(schema.sections
        .filter((section) => section.repeating)
        .map((section) => [
        section.id,
        Array.isArray(values[section.id]) ? values[section.id] : [],
    ]));
    const context = { values, rows, entities, requestContext };
    for (const section of schema.sections) {
        if (section.repeating)
            continue;
        for (const field of section.fields) {
            if (values[field.id] !== undefined || !field.defaultValue)
                continue;
            const resolved = resolveDefaultValue(field.defaultValue, context);
            if (resolved !== undefined && resolved !== null)
                values[field.id] = resolved;
        }
    }
    return values;
}
//# sourceMappingURL=form-renderer.js.map