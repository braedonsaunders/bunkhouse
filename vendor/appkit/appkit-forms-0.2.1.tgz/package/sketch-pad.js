'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { lazy, Suspense, useEffect, useState } from 'react';
import { GeneratedText } from './generated-copy.js';
// Keep both the browser-only drawing engine and its package stylesheet behind
// the mounted boundary. Importing @appkit/forms therefore stays safe in Node,
// while applications that actually render a sketch receive the complete UI.
const SketchPadClient = lazy(() => import('./sketch-pad-client.js'));
export function SketchPad(props) {
    const [mounted, setMounted] = useState(false);
    useEffect(() => setMounted(true), []);
    return (_jsx("div", { style: { height: props.height ?? 440 }, className: "overflow-hidden rounded-md border border-border", children: mounted ? (_jsx(Suspense, { fallback: _jsx(SketchLoading, {}), children: _jsx(SketchPadClient, { ...props }) })) : _jsx(SketchLoading, {}) }));
}
function SketchLoading() {
    return _jsx("div", { className: "flex h-full w-full items-center justify-center text-sm text-fg-muted", children: _jsx(GeneratedText, { id: "m_0839e554b28c58" }) });
}
//# sourceMappingURL=sketch-pad.js.map