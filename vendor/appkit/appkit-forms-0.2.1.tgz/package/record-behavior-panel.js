'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Check } from 'lucide-react';
import { Button, Checkbox, Label, cn } from '@appkit/ui';
const EDITING_MODES = [
    {
        value: 'guided_fill',
        title: 'Guided fill',
        description: 'A step-by-step wizard ending in Submit. Best for one-off captures in the field.',
    },
    {
        value: 'inline_record',
        title: 'Inline record',
        description: 'A living record edited in place — every field autosaves as you type.',
    },
    {
        value: 'both',
        title: 'Both',
        description: 'An inline record that can also be completed through the guided wizard.',
    },
];
const LOCK_TRIGGERS = [
    { value: 'manual', label: 'Manually, with a Lock button' },
    { value: 'on_finalize', label: 'When the record is finalised' },
    { value: 'on_signoff', label: 'When all sign-off steps are complete' },
];
export function RecordBehaviorPanel({ value, roles = [], onChange, onSave, readOnly = false, className, }) {
    const [pending, startTransition] = React.useTransition();
    const config = value ?? {};
    const editingMode = config.editingMode ?? 'guided_fill';
    const locking = config.locking ?? {};
    const tabs = config.tabs ?? {};
    const patch = React.useCallback((next) => {
        onChange({ ...config, ...next });
    }, [config, onChange]);
    const patchLocking = React.useCallback((next) => {
        patch({ locking: { ...locking, ...next } });
    }, [locking, patch]);
    const toggleRole = (key, role) => {
        const selected = new Set(locking[key] ?? []);
        if (selected.has(role))
            selected.delete(role);
        else
            selected.add(role);
        patchLocking({ [key]: [...selected] });
    };
    return (_jsxs("div", { className: cn('space-y-4', className), children: [_jsx("p", { className: "text-xs text-fg-muted", children: "Choose how people edit records, when records lock, and which review tabs are available." }), _jsxs("section", { className: "space-y-2", children: [_jsx(Label, { className: "text-xs", children: "Editing mode" }), _jsx("div", { className: "space-y-2", children: EDITING_MODES.map((mode) => {
                            const active = editingMode === mode.value;
                            return (_jsxs("button", { type: "button", disabled: readOnly, onClick: () => patch({ editingMode: mode.value }), "aria-pressed": active, className: cn('flex w-full items-start gap-2 rounded-md border px-3 py-2 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-50', active ? 'border-primary bg-primary-subtle' : 'border-border hover:bg-surface-hover'), children: [_jsx("span", { className: cn('mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-full border', active ? 'border-primary bg-primary text-primary-fg' : 'border-border-strong'), children: active ? _jsx(Check, { size: 11 }) : null }), _jsxs("span", { children: [_jsx("span", { className: "block text-sm font-medium text-fg", children: mode.title }), _jsx("span", { className: "block text-xs text-fg-muted", children: mode.description })] })] }, mode.value));
                        }) })] }), _jsxs("section", { className: "space-y-3 rounded-md border border-border p-3", children: [_jsxs("label", { className: "flex items-start gap-2 text-sm", children: [_jsx(Checkbox, { checked: locking.enabled ?? false, disabled: readOnly, onChange: (event) => patchLocking({ enabled: event.currentTarget.checked }), className: "mt-0.5" }), _jsxs("span", { children: [_jsx("span", { className: "font-medium text-fg", children: "Allow record locking" }), _jsx("span", { className: "block text-xs text-fg-muted", children: "Locked records become read-only until an authorised person unlocks them." })] })] }), locking.enabled ? (_jsxs("div", { className: "space-y-3 border-t border-border-subtle pt-3", children: [_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-xs", children: "Lock trigger" }), _jsx("div", { className: "space-y-1", children: LOCK_TRIGGERS.map((option) => (_jsxs("label", { className: "flex cursor-pointer items-center gap-2 rounded-md border border-border px-3 py-1.5 text-sm hover:bg-surface-hover", children: [_jsx("input", { type: "radio", name: "record-lock-trigger", checked: (locking.trigger ?? 'manual') === option.value, disabled: readOnly, onChange: () => patchLocking({ trigger: option.value }) }), _jsx("span", { className: "text-fg", children: option.label })] }, option.value))) })] }), _jsx(RoleMultiSelect, { label: "Who can lock records", help: "Leave empty to allow anyone with edit access. Administrators can always lock.", roles: roles, selected: new Set(locking.lockRoles ?? []), disabled: readOnly, onToggle: (key) => toggleRole('lockRoles', key) }), _jsx(RoleMultiSelect, { label: "Who can unlock records", help: "Leave empty to allow anyone with edit access. Administrators can always unlock.", roles: roles, selected: new Set(locking.unlockRoles ?? []), disabled: readOnly, onToggle: (key) => toggleRole('unlockRoles', key) }), _jsxs("label", { className: "flex items-start gap-2 text-sm", children: [_jsx(Checkbox, { checked: locking.autoLockOnFinalize ?? false, disabled: readOnly, onChange: (event) => patchLocking({ autoLockOnFinalize: event.currentTarget.checked }), className: "mt-0.5" }), _jsxs("span", { children: [_jsx("span", { className: "font-medium text-fg", children: "Automatically lock final records" }), _jsx("span", { className: "block text-xs text-fg-muted", children: "Prevent further edits as soon as the record is finalised." })] })] })] })) : null] }), _jsxs("section", { className: "space-y-3 rounded-md border border-border p-3", children: [_jsxs("div", { className: "space-y-0.5", children: [_jsx(Label, { className: "text-xs", children: "Record tabs" }), _jsx("p", { className: "text-xs text-fg-muted", children: "Choose the system tabs shown beside the record form." })] }), _jsx(TabToggle, { label: "Review", help: "Compliance scoring and sign-off.", checked: tabs.review ?? false, disabled: readOnly, onChange: (review) => patch({ tabs: { ...tabs, review } }) }), _jsx(TabToggle, { label: "Comments", help: "Let reviewers discuss a record.", checked: tabs.comments ?? true, disabled: readOnly, onChange: (comments) => patch({ tabs: { ...tabs, comments } }) }), _jsx(TabToggle, { label: "Audit", help: "Show the complete change history.", checked: tabs.audit ?? true, disabled: readOnly, onChange: (audit) => patch({ tabs: { ...tabs, audit } }) })] }), onSave ? (_jsx(Button, { type: "button", disabled: pending || readOnly, className: "w-full", onClick: () => startTransition(async () => onSave(config)), children: pending ? 'Saving…' : 'Save record behavior' })) : null] }));
}
function TabToggle({ label, help, checked, disabled, onChange }) {
    return (_jsxs("label", { className: "flex items-start gap-2 text-sm", children: [_jsx(Checkbox, { checked: checked, disabled: disabled, onChange: (event) => onChange(event.currentTarget.checked), className: "mt-0.5" }), _jsxs("span", { children: [_jsx("span", { className: "font-medium text-fg", children: label }), _jsx("span", { className: "block text-xs text-fg-muted", children: help })] })] }));
}
function RoleMultiSelect({ label, help, roles, selected, disabled, onToggle }) {
    return (_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-xs", children: label }), roles.length === 0 ? _jsx("p", { className: "text-xs text-fg-subtle", children: "No roles are available." }) : (_jsx("ul", { className: "space-y-1", children: roles.map((role) => (_jsx("li", { children: _jsxs("label", { className: "flex cursor-pointer items-center gap-2 rounded-md border border-border px-3 py-1.5 text-sm hover:bg-surface-hover", children: [_jsx(Checkbox, { checked: selected.has(role.key), disabled: disabled, onChange: () => onToggle(role.key) }), _jsx("span", { className: "flex-1 text-fg", children: role.name }), _jsx("span", { className: "text-[10px] text-fg-subtle", children: role.key })] }) }, role.key))) })), _jsx("p", { className: "text-[11px] text-fg-subtle", children: help })] }));
}
//# sourceMappingURL=record-behavior-panel.js.map