'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowDown, ArrowUp, Check, Plus, X } from 'lucide-react';
import { Button, Input, Label, Select, cn } from '@appkit/ui';
const BUILTIN_LABEL = {
    id: 'ID',
    subject: 'Subject',
    site: 'Site',
    status: 'Status',
    created_at: 'Started',
    submitted_at: 'Submitted',
    submittedBy: 'By',
    pdf: 'PDF',
};
const BUILTIN_KEYS = Object.keys(BUILTIN_LABEL);
export const DEFAULT_RECORD_LIST_COLUMNS = BUILTIN_KEYS.map((key) => ({ key, source: 'builtin' }));
const SORT_OPTIONS = [
    { key: 'submitted_at', label: 'Submitted' },
    { key: 'created_at', label: 'Started' },
    { key: 'status', label: 'Status' },
];
const STATUS_OPTIONS = [
    { value: '', label: 'None' },
    { value: 'draft', label: 'Draft' },
    { value: 'in_progress', label: 'In progress' },
    { value: 'submitted', label: 'Submitted' },
    { value: 'in_review', label: 'In review' },
    { value: 'closed', label: 'Closed' },
    { value: 'rejected', label: 'Rejected' },
];
function columnId(column) {
    return `${column.source}:${column.key}`;
}
export function RecordListPanel({ value, fields, onChange, onSave, readOnly = false, className }) {
    const configured = Boolean(value?.columns?.length);
    const columns = value?.columns?.length ? value.columns : DEFAULT_RECORD_LIST_COLUMNS;
    const [addKind, setAddKind] = React.useState('');
    const [pending, startTransition] = React.useTransition();
    const present = React.useMemo(() => new Set(columns.map(columnId)), [columns]);
    const fieldLabels = React.useMemo(() => new Map(fields.map((field) => [field.id, field.label])), [fields]);
    const addableBuiltins = BUILTIN_KEYS.filter((key) => !present.has(`builtin:${key}`));
    const addableFields = fields.filter((field) => !present.has(`field:${field.id}`));
    const canAdd = addableBuiltins.length + addableFields.length > 0;
    const commit = React.useCallback((patch) => {
        onChange({ ...value, ...patch });
    }, [onChange, value]);
    const setColumns = (next) => commit({ columns: next });
    function move(index, delta) {
        const target = index + delta;
        if (target < 0 || target >= columns.length)
            return;
        const next = columns.map((column) => ({ ...column }));
        const current = next[index];
        const replacement = next[target];
        if (!current || !replacement)
            return;
        next[index] = replacement;
        next[target] = current;
        setColumns(next);
    }
    function add() {
        if (!addKind)
            return;
        const separator = addKind.indexOf(':');
        const source = addKind.slice(0, separator);
        const key = addKind.slice(separator + 1);
        if (source === 'builtin' && BUILTIN_KEYS.includes(key))
            setColumns([...columns, { source, key }]);
        if (source === 'field' && fieldLabels.has(key))
            setColumns([...columns, { source, key }]);
        setAddKind('');
    }
    const displayLabel = (column) => column.source === 'builtin'
        ? BUILTIN_LABEL[column.key] ?? column.key
        : fieldLabels.get(column.key) ?? column.key;
    return (_jsxs("div", { className: cn('space-y-4', className), children: [_jsx("p", { className: "text-xs text-fg-muted", children: "Choose the columns, default sort, and initial status filter for the record list." }), _jsxs("section", { className: "space-y-2", children: [_jsxs("div", { className: "flex items-center justify-between gap-2", children: [_jsx(Label, { className: "text-xs", children: "Columns" }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", disabled: readOnly || !configured, onClick: () => setColumns(undefined), children: "Reset defaults" })] }), _jsx("ul", { className: "space-y-2", children: columns.map((column, index) => (_jsxs("li", { className: "rounded-md border border-border p-2", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "min-w-0 flex-1 truncate text-sm font-medium text-fg", children: displayLabel(column) }), _jsx("span", { className: "rounded bg-bg-subtle px-1.5 py-0.5 text-[10px] text-fg-muted", children: column.source }), _jsxs("div", { className: "flex items-center gap-0.5", children: [_jsx(IconButton, { label: "Move column up", disabled: readOnly || index === 0, onClick: () => move(index, -1), children: _jsx(ArrowUp, { size: 14 }) }), _jsx(IconButton, { label: "Move column down", disabled: readOnly || index === columns.length - 1, onClick: () => move(index, 1), children: _jsx(ArrowDown, { size: 14 }) }), _jsx(IconButton, { label: "Remove column", danger: true, disabled: readOnly, onClick: () => setColumns(columns.filter((_, candidate) => candidate !== index)), children: _jsx(X, { size: 14 }) })] })] }), _jsx(Input, { value: column.label ?? '', disabled: readOnly, onChange: (event) => {
                                        const next = columns.map((candidate) => ({ ...candidate }));
                                        next[index] = { ...column, label: event.target.value.trim() || undefined };
                                        setColumns(next);
                                    }, placeholder: `Custom label (default: ${displayLabel(column)})`, className: "mt-1.5 h-7 text-xs" })] }, columnId(column)))) }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Select, { value: addKind, onChange: (event) => setAddKind(event.target.value), disabled: readOnly || !canAdd, className: "flex-1", children: [_jsx("option", { value: "", children: canAdd ? 'Add a column…' : 'All columns added' }), addableBuiltins.length ? _jsx("optgroup", { label: "Record columns", children: addableBuiltins.map((key) => _jsx("option", { value: `builtin:${key}`, children: BUILTIN_LABEL[key] }, key)) }) : null, addableFields.length ? _jsx("optgroup", { label: "Form fields", children: addableFields.map((field) => _jsx("option", { value: `field:${field.id}`, children: field.label }, field.id)) }) : null] }), _jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: add, disabled: readOnly || !addKind, "aria-label": "Add column", children: _jsx(Plus, { size: 14 }) })] }), _jsx("p", { className: "text-[11px] text-fg-subtle", children: "Drag-free ordering keeps the list editor keyboard accessible; use the arrow controls to set exact order." })] }), _jsxs("section", { className: "space-y-2", children: [_jsx(Label, { className: "text-xs", children: "Default sort" }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Select, { value: value?.defaultSort?.key ?? 'submitted_at', onChange: (event) => commit({ defaultSort: { key: event.target.value, dir: value?.defaultSort?.dir ?? 'desc' } }), disabled: readOnly, className: "flex-1", children: SORT_OPTIONS.map((option) => _jsx("option", { value: option.key, children: option.label }, option.key)) }), _jsxs(Button, { type: "button", variant: "outline", size: "sm", disabled: readOnly, onClick: () => commit({ defaultSort: { key: value?.defaultSort?.key ?? 'submitted_at', dir: value?.defaultSort?.dir === 'asc' ? 'desc' : 'asc' } }), children: [value?.defaultSort?.dir === 'asc' ? _jsx(ArrowUp, { size: 13 }) : _jsx(ArrowDown, { size: 13 }), value?.defaultSort?.dir === 'asc' ? 'Ascending' : 'Descending'] })] })] }), _jsxs("section", { className: "space-y-2", children: [_jsx(Label, { className: "text-xs", children: "Default status" }), _jsx(Select, { value: value?.defaultStatus ?? '', disabled: readOnly, onChange: (event) => commit({ defaultStatus: event.target.value || undefined }), children: STATUS_OPTIONS.map((option) => _jsx("option", { value: option.value, children: option.label }, option.value || 'none')) }), _jsx("p", { className: "text-[11px] text-fg-subtle", children: "People can still change the filter after the list opens." })] }), onSave ? _jsxs(Button, { type: "button", disabled: pending || readOnly, className: "w-full", onClick: () => startTransition(async () => onSave(value ?? {})), children: [_jsx(Check, { size: 14 }), pending ? 'Saving…' : 'Save list settings'] }) : null] }));
}
function IconButton({ label, disabled, danger = false, onClick, children }) {
    return _jsx("button", { type: "button", "aria-label": label, title: label, disabled: disabled, onClick: onClick, className: cn('rounded p-1 text-fg-subtle hover:bg-surface-hover hover:text-fg disabled:opacity-30', danger && 'hover:bg-danger-subtle hover:text-danger'), children: children });
}
//# sourceMappingURL=record-list-panel.js.map