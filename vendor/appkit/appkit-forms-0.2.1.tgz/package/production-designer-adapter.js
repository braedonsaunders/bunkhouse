export {};
//# sourceMappingURL=production-designer-adapter.js.map