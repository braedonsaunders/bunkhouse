'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { DEFAULT_LOCALE } from '@appkit/i18n';
import { GeneratedCopyProvider, } from './generated-copy.js';
const DEFAULT_LABELS = {
    lookingUp: 'Looking up…',
    searchRecords: ({ field }) => `Search ${field}…`,
};
const ProductionRuntimeContext = React.createContext(null);
export function ProductionFormRuntimeProvider({ adapter, locale = DEFAULT_LOCALE, labels, translateGenerated, children, }) {
    const value = React.useMemo(() => ({
        adapter,
        locale,
        labels: { ...DEFAULT_LABELS, ...labels },
    }), [adapter, labels, locale]);
    return (_jsx(ProductionRuntimeContext.Provider, { value: value, children: _jsx(GeneratedCopyProvider, { translate: translateGenerated, children: children }) }));
}
export function useProductionFormRuntime() {
    const value = React.useContext(ProductionRuntimeContext);
    if (!value) {
        throw new Error('Production form runtime requires ProductionFormRuntimeProvider.');
    }
    return value;
}
export function useProductionLocale() {
    return useProductionFormRuntime().locale;
}
export function useProductionTranslations(_namespace) {
    const { labels } = useProductionFormRuntime();
    return (key, values) => key === 'lookingUp'
        ? labels.lookingUp
        : labels.searchRecords({ field: values?.field ?? 'records' });
}
//# sourceMappingURL=production-runtime-context.js.map