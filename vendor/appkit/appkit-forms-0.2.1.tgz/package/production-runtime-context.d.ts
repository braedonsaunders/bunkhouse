import * as React from 'react';
import { type AppLocale } from '@appkit/i18n';
import type { ProductionFormRuntimeAdapter } from './production-runtime-adapter.js';
import { type GeneratedCopyTranslator } from './generated-copy.js';
export type ProductionRuntimeLabels = {
    lookingUp: string;
    searchRecords: (input: {
        field: string;
    }) => string;
};
type ProductionRuntimeContextValue = {
    adapter: ProductionFormRuntimeAdapter;
    locale: AppLocale;
    labels: ProductionRuntimeLabels;
};
export declare function ProductionFormRuntimeProvider({ adapter, locale, labels, translateGenerated, children, }: {
    adapter: ProductionFormRuntimeAdapter;
    locale?: AppLocale;
    labels?: Partial<ProductionRuntimeLabels>;
    translateGenerated?: GeneratedCopyTranslator;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function useProductionFormRuntime(): ProductionRuntimeContextValue;
export declare function useProductionLocale(): AppLocale;
export declare function useProductionTranslations(_namespace?: string): (key: 'lookingUp' | 'searchRecords', values?: {
    field?: string;
}) => string;
export {};
//# sourceMappingURL=production-runtime-context.d.ts.map