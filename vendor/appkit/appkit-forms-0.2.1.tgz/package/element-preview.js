'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { GeneratedText, useGeneratedTranslations, GeneratedValue } from './generated-copy.js';
// A representative, read-only preview of ONE element — how it looks in the
// shipped product. Used by the canvas blocks (WYSIWYG building) and the Preview
// drawer. Uses the element's real label / options / config, not placeholders.
import { AlertTriangle, BarChart3, MapPin, ScanLine, Sparkles, Star } from 'lucide-react';
import { Input, Select, Textarea } from '@appkit/ui';
import { localizeText } from '@appkit/i18n';
function cfg(field) {
    return field.config ?? {};
}
function optionLabels(field, locale, defaultLocale) {
    const opts = field.validation?.options ??
        cfg(field).options ??
        [];
    return opts.map((o) => localizeText(o.label, locale, o.value, defaultLocale));
}
export function ElementPreview({ field, locale, defaultLocale, compact = false, }) {
    const label = localizeText(field.label, locale, field.id, defaultLocale);
    const helpText = localizeText(field.helpText, locale, '', defaultLocale);
    const t = field.type;
    // Content elements ARE their content — no separate field label.
    if (t === 'heading')
        return (_jsx("h3", { className: "text-base font-semibold text-fg", children: _jsx(GeneratedValue, { value: label }) }));
    if (t === 'paragraph')
        return (_jsx("p", { className: "text-sm leading-snug text-fg-muted", children: _jsx(GeneratedValue, { value: label }) }));
    if (t === 'divider')
        return _jsx("hr", { className: "my-1 border-border" });
    return (_jsxs("div", { className: "space-y-1", children: [_jsxs("div", { className: "text-xs font-medium text-fg-muted", children: [_jsx(GeneratedValue, { value: label }), _jsx(GeneratedValue, { value: field.required ? _jsx("span", { className: "text-danger", children: " *" }) : null })] }), _jsx(ElementInput, { field: field, locale: locale, defaultLocale: defaultLocale, compact: compact }), _jsx(GeneratedValue, { value: helpText ? (_jsx("p", { className: "text-[10px] text-fg-subtle", children: _jsx(GeneratedValue, { value: helpText }) })) : null })] }));
}
function ElementInput({ field, locale, defaultLocale, compact, }) {
    const tGenerated = useGeneratedTranslations();
    const t = field.type;
    const labels = optionLabels(field, locale, defaultLocale);
    const choices = labels.length ? labels : ['Option A', 'Option B'];
    switch (t) {
        case 'long_text':
            return _jsx(Textarea, { rows: compact ? 2 : 3, disabled: true, placeholder: "", className: "bg-white" });
        case 'number':
            return _jsx(Input, { type: "number", disabled: true, placeholder: "0", className: "bg-white" });
        case 'date':
            return _jsx(Input, { type: "date", disabled: true, className: "bg-white" });
        case 'datetime':
            return _jsx(Input, { type: "datetime-local", disabled: true, className: "bg-white" });
        case 'time':
            return _jsx(Input, { type: "time", disabled: true, className: "bg-white" });
        case 'email':
            return (_jsx(Input, { type: "email", disabled: true, placeholder: tGenerated('m_1b781270c0d2f5'), className: "bg-white" }));
        case 'phone':
            return _jsx(Input, { disabled: true, placeholder: "(555) 555-5555", className: "bg-white" });
        case 'url':
            return _jsx(Input, { disabled: true, placeholder: "https://", className: "bg-white" });
        case 'select':
        case 'customer_picker':
        case 'site_picker':
        case 'project_picker':
        case 'area_picker':
        case 'person_picker':
        case 'multi_person_picker':
            return (_jsx(Select, { disabled: true, className: "bg-white", children: _jsx("option", { children: labels[0] ?? 'Select…' }) }));
        case 'radio':
            return (_jsx("div", { className: "space-y-1", children: _jsx(GeneratedValue, { value: choices.slice(0, 4).map((l, i) => (_jsxs("label", { className: "flex items-center gap-2 text-xs text-fg-muted", children: [_jsx("input", { type: "radio", disabled: true }), " ", _jsx(GeneratedValue, { value: l })] }, i))) }) }));
        case 'checkbox_group':
        case 'multi_select':
            return (_jsx("div", { className: "space-y-1", children: _jsx(GeneratedValue, { value: choices.slice(0, 4).map((l, i) => (_jsxs("label", { className: "flex items-center gap-2 text-xs text-fg-muted", children: [_jsx("input", { type: "checkbox", disabled: true }), " ", _jsx(GeneratedValue, { value: l })] }, i))) }) }));
        case 'yes_no_comment':
            return (_jsx("div", { className: "flex gap-2", children: _jsx(GeneratedValue, { value: ['Yes', 'No'].map((v) => (_jsx("span", { className: "rounded-md border border-border px-3 py-1 text-xs text-fg-muted", children: _jsx(GeneratedValue, { value: v }) }, v))) }) }));
        case 'pass_fail_na':
            return (_jsx("div", { className: "flex gap-1", children: _jsx(GeneratedValue, { value: ['PASS', 'FAIL', 'N/A'].map((v) => (_jsx("span", { className: "rounded border border-border px-2 py-1 text-[10px] text-fg-muted", children: _jsx(GeneratedValue, { value: v }) }, v))) }) }));
        case 'traffic_light':
            return (_jsx("div", { className: "flex gap-1.5", children: _jsx(GeneratedValue, { value: ['bg-success', 'bg-warning', 'bg-danger'].map((tone) => (_jsx("span", { className: `h-5 w-5 rounded-full ${tone}` }, tone))) }) }));
        case 'rating':
            return (_jsx("div", { className: "flex gap-0.5 text-warning", children: _jsx(GeneratedValue, { value: [1, 2, 3, 4, 5].map((i) => (_jsx(Star, { size: 16, fill: "currentColor", strokeWidth: 0 }, i))) }) }));
        case 'signature':
            return (_jsx("div", { className: "flex h-16 items-center justify-center rounded border border-dashed border-border-strong bg-bg-subtle text-xs text-fg-subtle italic", children: _jsx(GeneratedText, { id: "m_05a0e2d38bded7" }) }));
        case 'photo':
        case 'photo_upload':
        case 'file':
        case 'video':
        case 'audio':
            return (_jsx("div", { className: "flex h-16 items-center justify-center rounded border border-dashed border-border-strong bg-bg-subtle text-xs text-fg-subtle", children: _jsx(GeneratedText, { id: "m_10e50435ff2693" }) }));
        case 'sketch':
            return (_jsx("div", { className: "flex h-20 items-center justify-center rounded border border-dashed border-border-strong bg-[repeating-linear-gradient(45deg,transparent,transparent_9px,rgba(148,163,184,0.12)_9px,rgba(148,163,184,0.12)_10px)] text-xs text-fg-subtle italic", children: _jsx(GeneratedText, { id: "m_1abf555859c0a8" }) }));
        case 'photo_ai':
            return (_jsxs("div", { className: "space-y-1.5", children: [_jsx("div", { className: "flex h-14 items-center justify-center rounded border border-dashed border-border-strong bg-bg-subtle text-xs text-fg-subtle", children: _jsx(GeneratedText, { id: "m_18010438ac7907" }) }), _jsxs("span", { className: "inline-flex items-center gap-1 rounded-md border border-info bg-info-subtle px-2 py-1 text-[11px] text-info", children: [_jsx(Sparkles, { size: 12 }), " ", _jsx(GeneratedText, { id: "m_0fec93e95858fc" })] }), _jsxs("div", { className: "flex items-center gap-1 text-[10px] text-fg-subtle", children: [_jsx(AlertTriangle, { size: 11, className: "text-warning" }), ' ', _jsx(GeneratedText, { id: "m_0289ca8aa7b891" })] })] }));
        case 'typed_attestation':
            return _jsx(Input, { disabled: true, placeholder: tGenerated('m_0d0facbd71aa6a'), className: "bg-white" });
        case 'formula':
            return _jsx(Input, { disabled: true, value: "= computed", className: "bg-bg-subtle italic" });
        case 'slider': {
            const c = cfg(field);
            const min = c.min ?? 0;
            const max = c.max ?? 10;
            return (_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("input", { type: "range", min: min, max: max, defaultValue: (min + max) / 2, disabled: true, className: "h-2 flex-1 rounded-full bg-border accent-primary" }), _jsx("span", { className: "text-xs text-fg-subtle", children: _jsx(GeneratedValue, { value: Math.round((min + max) / 2) }) })] }));
        }
        case 'gps':
            return (_jsxs("div", { className: "flex items-center gap-1.5 rounded border border-border bg-white px-2 py-1.5 text-xs text-fg-muted", children: [_jsx(MapPin, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_07cd022cc38d60" })] }));
        case 'matrix': {
            const c = cfg(field);
            const rows = c.rows ?? [
                { key: 'r1', label: 'Item 1' },
                { key: 'r2', label: 'Item 2' },
            ];
            const scale = c.scale ?? [
                { value: '1', label: '1' },
                { value: '2', label: '2' },
                { value: '3', label: '3' },
            ];
            return (_jsxs("table", { className: "w-full text-[10px]", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", {}), _jsx(GeneratedValue, { value: scale.map((s) => (_jsx("th", { className: "px-1 text-center font-normal text-fg-subtle", children: _jsx(GeneratedValue, { value: s.label }) }, s.value))) })] }) }), _jsx("tbody", { children: _jsx(GeneratedValue, { value: rows.slice(0, 3).map((r) => (_jsxs("tr", { children: [_jsx("td", { className: "pr-1 text-fg-muted", children: _jsx(GeneratedValue, { value: r.label }) }), _jsx(GeneratedValue, { value: scale.map((s) => (_jsx("td", { className: "text-center", children: _jsx("input", { type: "radio", disabled: true }) }, s.value))) })] }, r.key))) }) })] }));
        }
        case 'risk_matrix':
            return (_jsx("div", { className: "grid w-fit grid-cols-5 gap-0.5", children: _jsx(GeneratedValue, { value: Array.from({ length: 25 }).map((_, i) => {
                        const sev = (i % 5) + Math.floor(i / 5);
                        const tone = sev >= 6
                            ? 'bg-danger'
                            : sev >= 4
                                ? 'bg-warning'
                                : sev >= 2
                                    ? 'bg-warning-subtle'
                                    : 'bg-success-subtle';
                        return _jsx("span", { className: `h-3.5 w-3.5 rounded-sm ${tone}` }, i);
                    }) }) }));
        case 'photo_annotated':
            return (_jsxs("div", { className: "space-y-1", children: [_jsxs("div", { className: "relative flex h-24 items-center justify-center rounded border border-dashed border-border-strong bg-bg-subtle text-xs text-fg-subtle", children: [_jsx(GeneratedText, { id: "m_18010438ac7907" }), _jsx("span", { className: "absolute top-1/3 left-1/3 flex h-5 w-5 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-danger text-[10px] font-bold text-danger-fg ring-2 ring-surface", children: "1" }), _jsx("span", { className: "absolute top-1/2 left-2/3 flex h-5 w-5 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-danger text-[10px] font-bold text-white ring-2 ring-white", children: "2" })] }), _jsx("div", { className: "text-[10px] text-fg-subtle", children: _jsx(GeneratedText, { id: "m_18c006b02858b9" }) })] }));
        case 'qr_scanner':
            return (_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Input, { disabled: true, placeholder: tGenerated('m_0a43fb83c91fdf'), className: "flex-1 bg-white" }), _jsxs("span", { className: "inline-flex items-center gap-1 rounded border border-border px-1.5 py-1 text-[11px] text-fg-muted", children: [_jsx(ScanLine, { size: 12 }), " ", _jsx(GeneratedText, { id: "m_198b8dba5a829c" })] })] }));
        case 'ranking': {
            const ls = optionLabels(field, locale, defaultLocale);
            const itemsR = ls.length ? ls : ['Option A', 'Option B', 'Option C'];
            return (_jsx("ol", { className: "space-y-1", children: _jsx(GeneratedValue, { value: itemsR.slice(0, 4).map((l, i) => (_jsxs("li", { className: "flex items-center gap-2 rounded border border-border bg-white px-2 py-1 text-xs", children: [_jsx("span", { className: "w-4 text-center font-semibold text-fg-subtle", children: _jsx(GeneratedValue, { value: i + 1 }) }), _jsx("span", { className: "flex-1 truncate text-fg-muted", children: _jsx(GeneratedValue, { value: l }) }), _jsx("span", { className: "text-fg-subtle", children: "\u21C5" })] }, i))) }) }));
        }
        case 'rich_text':
            return (_jsxs("div", { className: "rounded border border-border", children: [_jsxs("div", { className: "flex gap-2 border-b border-border bg-bg-subtle px-1.5 py-1 text-[11px] text-fg-subtle", children: [_jsx("span", { className: "font-bold", children: _jsx(GeneratedText, { id: "m_03d716fddcdd92" }) }), _jsx("span", { className: "italic", children: _jsx(GeneratedText, { id: "m_01f47383f19f8c" }) }), _jsx("span", { children: _jsx(GeneratedText, { id: "m_1287c1049195af" }) })] }), _jsxs("div", { className: "space-y-1 p-2", children: [_jsx("div", { className: "h-1.5 w-3/4 rounded bg-surface-hover" }), _jsx("div", { className: "h-1.5 w-1/2 rounded bg-surface-hover" })] })] }));
        case 'address':
            return (_jsxs("div", { className: "space-y-1.5", children: [_jsxs("div", { className: "flex items-center gap-1 rounded border border-border bg-white px-2 py-1.5 text-xs text-fg-subtle", children: [_jsx(MapPin, { size: 12 }), " ", _jsx(GeneratedText, { id: "m_178de0c94da150" })] }), _jsxs("div", { className: "grid grid-cols-2 gap-1.5", children: [_jsx("div", { className: "col-span-2 h-7 rounded border border-border bg-white" }), _jsx("div", { className: "h-7 rounded border border-border bg-white" }), _jsx("div", { className: "h-7 rounded border border-border bg-white" })] })] }));
        case 'table':
            return _jsx(MiniTable, { field: field });
        case 'lookup':
            return (_jsxs("div", { className: "space-y-1", children: [_jsx(Select, { disabled: true, className: "bg-white", children: _jsx("option", { children: 'Select…' }) }), _jsx(GeneratedValue, { value: field.binding?.autofill?.length ? (_jsxs("p", { className: "text-[10px] text-info", children: [_jsx(GeneratedText, { id: "m_011434db59926f" }), ' ', _jsx(GeneratedValue, { value: field.binding.autofill.length }), ' ', _jsx(GeneratedText, { id: "m_1d6aa8702d3fac" }), _jsx(GeneratedValue, { value: field.binding.autofill.length === 1 ? ('') : (_jsx(GeneratedText, { id: "m_00ded356f0f424" })) })] })) : null })] }));
        case 'data_table': {
            const keys = field.binding?.columns ?? [];
            const headers = keys.length ? keys : ['Column A', 'Column B', 'Column C'];
            const sel = field.binding?.selectable;
            return (_jsxs("div", { className: "overflow-hidden rounded border border-border text-[10px]", children: [_jsx("div", { className: "flex bg-bg-subtle", children: _jsx(GeneratedValue, { value: headers.slice(0, 5).map((h, i) => (_jsx("div", { className: "flex-1 truncate border-r border-border px-1.5 py-1 font-medium text-fg-muted last:border-0", children: _jsx(GeneratedValue, { value: h }) }, i))) }) }), _jsx(GeneratedValue, { value: [0, 1, 2].map((r) => (_jsx("div", { className: "flex border-t border-border-subtle", children: _jsx(GeneratedValue, { value: headers.slice(0, 5).map((_, i) => (_jsx("div", { className: "flex-1 border-r border-border-subtle px-1.5 py-1 text-fg-subtle last:border-0", children: "\u2014" }, i))) }) }, r))) }), _jsx(GeneratedValue, { value: sel && sel !== 'none' ? (_jsx("div", { className: "bg-bg-subtle px-1.5 py-0.5 text-[9px] text-fg-subtle", children: _jsx(GeneratedValue, { value: sel === 'single' ? (_jsx(GeneratedText, { id: "m_1d33f094c621dc" })) : (_jsx(GeneratedText, { id: "m_1a1dcc7d0b9e8a" })) }) })) : null })] }));
        }
        case 'metric': {
            const agg = field.binding?.aggregate;
            const grouped = !!agg?.groupBy || (!!field.binding?.display && field.binding.display !== 'number');
            if (grouped) {
                return (_jsx("div", { className: "flex h-14 items-end gap-1", children: _jsx(GeneratedValue, { value: [8, 14, 10, 16, 6].map((h, i) => (_jsx("span", { className: "w-3 rounded-t bg-primary", style: { height: h * 3 } }, i))) }) }));
            }
            return (_jsxs("div", { className: "inline-flex items-center gap-2 rounded-lg border border-border bg-white px-3 py-2", children: [_jsx(BarChart3, { size: 18, className: "text-primary" }), _jsxs("div", { children: [_jsx("div", { className: "text-2xl leading-none font-semibold text-fg", children: "\u2014" }), _jsxs("div", { className: "mt-0.5 text-[10px] tracking-wide text-fg-subtle uppercase", children: [_jsx(GeneratedValue, { value: agg?.fn ?? _jsx(GeneratedText, { id: "m_15f748343d3956" }) }), _jsx(GeneratedValue, { value: agg?.column ? ` · ${agg.column}` : '' })] })] })] }));
        }
        default:
            return _jsx(Input, { disabled: true, placeholder: "", className: "bg-white" });
    }
}
function MiniTable({ field }) {
    const cols = cfg(field).columns ?? [];
    if (cols.length === 0) {
        return (_jsx("div", { className: "rounded border border-dashed border-border-strong p-2 text-center text-[11px] text-fg-subtle", children: _jsx(GeneratedText, { id: "m_0d90d1eceb566b" }) }));
    }
    const shown = cols.slice(0, 5);
    return (_jsxs("div", { className: "overflow-hidden rounded border border-border text-[10px]", children: [_jsx("div", { className: "flex bg-bg-subtle", children: _jsx(GeneratedValue, { value: shown.map((c) => (_jsx("div", { className: "flex-1 truncate border-r border-border px-1.5 py-1 font-medium text-fg-muted last:border-0", children: _jsx(GeneratedValue, { value: c.label || c.key }) }, c.key))) }) }), _jsx(GeneratedValue, { value: [0, 1].map((r) => (_jsx("div", { className: "flex border-t border-border-subtle", children: _jsx(GeneratedValue, { value: shown.map((c) => (_jsx("div", { className: "flex-1 border-r border-border-subtle px-1.5 py-1 text-fg-subtle last:border-0", children: "\u2014" }, c.key))) }) }, r))) })] }));
}
//# sourceMappingURL=element-preview.js.map