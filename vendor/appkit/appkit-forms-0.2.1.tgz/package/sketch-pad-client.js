'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import '@excalidraw/excalidraw/index.css';
// SketchPad — a comprehensive freehand drawing / diagram canvas built on
// Excalidraw (shapes, arrows, text, freehand, images). Used by the form
// `sketch` element (e.g. a lift-plan diagram). Outputs a PNG data-url plus the
// editable Excalidraw scene so the drawing can be re-opened and amended.
//
// Excalidraw touches `window` at module scope, so it is mounted lazily on the
// client. The heavy bundle only downloads when a sketch element renders.
import { useCallback, useRef } from 'react';
import { Excalidraw, exportToBlob } from '@excalidraw/excalidraw';
function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}
export default function SketchPadClient({ initialScene, onChange, readOnly = false, }) {
    const debounceRef = useRef(null);
    const handleChange = useCallback((elements, appState, files) => {
        if (debounceRef.current)
            clearTimeout(debounceRef.current);
        debounceRef.current = setTimeout(async () => {
            const live = elements.filter((el) => !el.isDeleted);
            const scene = {
                elements: live,
                appState: { viewBackgroundColor: appState.viewBackgroundColor },
                files,
            };
            if (live.length === 0) {
                onChange(null, scene);
                return;
            }
            try {
                const blob = await exportToBlob({
                    elements: live,
                    appState: { ...appState, exportBackground: true, exportWithDarkMode: false },
                    files,
                    mimeType: 'image/png',
                    quality: 0.92,
                });
                onChange(await blobToDataUrl(blob), scene);
            }
            catch (err) {
                console.warn('[sketch] export failed', err);
            }
        }, 700);
    }, [onChange]);
    return _jsx(Excalidraw, { initialData: initialScene ? initialScene : undefined, viewModeEnabled: readOnly, onChange: handleChange, UIOptions: { canvasActions: { loadScene: false, saveToActiveFile: false, export: false, saveAsImage: false } } });
}
//# sourceMappingURL=sketch-pad-client.js.map