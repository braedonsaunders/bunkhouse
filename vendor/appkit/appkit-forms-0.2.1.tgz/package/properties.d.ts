import * as React from 'react';
import { type FormField, type FormSchemaV1, type FormSection } from '@appkit/forms-core';
import { type AppLocale } from '@appkit/i18n';
export type FormDataSourceColumn = {
    key: string;
    label: string;
    type: 'text' | 'number' | 'date' | 'boolean';
};
export type FormDataSource = {
    id: string;
    key: string;
    name: string;
    kind?: string;
    columns: FormDataSourceColumn[];
};
export type FieldPropertiesProps = {
    sectionId: string;
    field: FormField;
    schema: FormSchemaV1;
    locale: AppLocale;
    defaultLocale?: AppLocale;
    dataSources?: readonly FormDataSource[];
    dataSourcesLoading?: boolean;
    onRefreshDataSources?: () => void | Promise<void>;
    readOnly?: boolean;
    onChange: (patch: Partial<FormField>) => void;
};
export declare function FieldProperties({ sectionId, field, schema, locale, defaultLocale, dataSources, dataSourcesLoading, onRefreshDataSources, readOnly, onChange }: FieldPropertiesProps): React.JSX.Element;
export declare function SectionProperties({ section, schema, locale, readOnly, onChange }: {
    section: FormSection;
    schema: FormSchemaV1;
    locale: AppLocale;
    readOnly?: boolean;
    onChange: (patch: Partial<FormSection>) => void;
}): React.JSX.Element;
//# sourceMappingURL=properties.d.ts.map