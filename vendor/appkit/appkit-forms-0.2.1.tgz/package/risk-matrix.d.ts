export type RiskMatrixConfig = {
    axes: {
        severity: {
            values: string[];
        };
        likelihood: {
            values: string[];
        };
    };
    cells: Record<string, {
        score: number;
        label: string;
        color: string;
    }>;
};
type RiskMatrixSelection = {
    likelihood: number | null;
    severity: number | null;
    score: number | null;
    label: string | null;
};
/** A risk band: every cell scoring ≥ `minScore` (and below the next band) wears
 *  this label + colour. */
export type RiskBandDef = {
    label: string;
    color: string;
    minScore: number;
};
export declare const MIN_AXIS = 3;
export declare const MAX_AXIS = 6;
/** Build a full per-cell matrix from axis labels + bands (score = sev × lik). */
export declare function buildMatrix(severityLabels: string[], likelihoodLabels: string[], bands: RiskBandDef[]): RiskMatrixConfig;
/** Recover the editable band list from a stored matrix — one band per distinct
 *  (label, colour), keyed to the lowest score that wears it. Round-trips any
 *  band-by-score matrix, including legacy seeds. */
export declare function bandsFromMatrix(matrix: RiskMatrixConfig): RiskBandDef[];
export declare const DEFAULT_RISK_MATRIX: RiskMatrixConfig;
export declare function RiskMatrixProvider({ matrix, children, }: {
    matrix: RiskMatrixConfig | null | undefined;
    children: React.ReactNode;
}): import("react").JSX.Element;
/** Chip for a precomputed 1-based score (e.g. an aggregated "worst risk"). */
export declare function RiskScoreChip({ score, prefix }: {
    score: number | null;
    prefix?: string;
}): import("react").JSX.Element;
/** Chip showing the score + band for a likelihood × severity pair. */
export declare function RiskScoreBadge({ likelihood, severity, prefix, }: {
    likelihood?: number | null;
    severity?: number | null;
    prefix?: string;
}): import("react").JSX.Element;
/** Pre-control → post-control residual indicator: two score chips + an arrow. */
export declare function RiskDelta({ preLikelihood, preSeverity, postLikelihood, postSeverity, }: {
    preLikelihood?: number | null;
    preSeverity?: number | null;
    postLikelihood?: number | null;
    postSeverity?: number | null;
}): import("react").JSX.Element;
/**
 * The colour-banded matrix grid: severity → across the top (S1…Sn), likelihood ↑
 * down the left (Ln at top, L1 at bottom). Shared by the interactive picker
 * (`RiskMatrixField`) and the editor preview so they can never drift apart.
 */
export declare function RiskMatrixGrid({ matrix, selected, onSelect, disabled, className, }: {
    matrix: RiskMatrixConfig;
    /** 1-based current selection, when interactive. */
    selected?: {
        likelihood: number | null;
        severity: number | null;
    };
    /** Omit for a read-only preview. */
    onSelect?: (likelihood: number, severity: number) => void;
    disabled?: boolean;
    className?: string;
}): import("react").JSX.Element;
/**
 * Interactive risk-matrix picker driven by the tenant's matrix. Exposes the
 * chosen 1-based likelihood/severity pair through hidden inputs so it drops into
 * a plain <form action={…}>.
 */
export declare function RiskMatrixField({ label, likelihoodName, severityName, defaultLikelihood, defaultSeverity, disabled, onChange, }: {
    label: string;
    likelihoodName: string;
    severityName: string;
    defaultLikelihood?: number | null;
    defaultSeverity?: number | null;
    disabled?: boolean;
    /** Lifts the chosen pair for drawer bodies that build FormData manually. */
    onChange?: (next: RiskMatrixSelection) => void;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=risk-matrix.d.ts.map