import type { FormField } from '@appkit/forms-core';
import { type AppLocale } from '@appkit/i18n';
export declare function ElementPreview({ field, locale, defaultLocale, compact, }: {
    field: FormField;
    locale: AppLocale;
    defaultLocale: AppLocale;
    compact?: boolean;
}): import("react").JSX.Element;
//# sourceMappingURL=element-preview.d.ts.map