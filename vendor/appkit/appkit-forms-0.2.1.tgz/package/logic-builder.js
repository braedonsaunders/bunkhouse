'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Plus, Trash2 } from 'lucide-react';
import { Button, Input, Select, cn } from '@appkit/ui';
const DEFAULT_LABELS = {
    noFields: 'No other fields to reference.',
    heading: 'Show when',
    alwaysVisible: 'Always visible.',
    allOf: 'all of',
    anyOf: 'any of',
    addClause: 'Add clause',
    removeClause: 'Remove clause',
};
const OPS = [
    { value: 'eq', label: 'equals', takesValue: true },
    { value: 'ne', label: 'does not equal', takesValue: true },
    { value: 'gt', label: 'greater than', takesValue: true },
    { value: 'lt', label: 'less than', takesValue: true },
    { value: 'gte', label: '≥', takesValue: true },
    { value: 'lte', label: '≤', takesValue: true },
    { value: 'in', label: 'is one of (comma-sep)', takesValue: true },
    { value: 'notIn', label: 'is none of', takesValue: true },
    { value: 'isSet', label: 'has any value', takesValue: false },
    { value: 'isNotSet', label: 'is empty', takesValue: false },
];
// The forms-core schema requires `in`/`notIn` values to be ARRAYS (the
// evaluator does `rule.value.includes(v)`; a raw string would silently give
// substring semantics and fail schema validation on publish). The editor keeps
// the comma-separated affordance but stores the split array.
function coerceClauseValue(op, raw) {
    if (op === 'in' || op === 'notIn') {
        const text = Array.isArray(raw) ? raw.map((v) => String(v)).join(', ') : String(raw ?? '');
        return text.split(',').map((s) => s.trim());
    }
    return Array.isArray(raw) ? raw.map((v) => String(v)).join(', ') : (raw ?? '');
}
function displayClauseValue(raw) {
    if (Array.isArray(raw))
        return raw.map((v) => String(v)).join(', ');
    return String(raw ?? '');
}
/**
 * Two-mode logic editor:
 *   - "all"/"any" combinator over a flat list of clauses (simple, covers ~90%)
 *   - "raw JSON" fallback for nested/advanced rules
 */
export function LogicBuilder({ rule, availableFields, onChange, labels: labelsProp, className, disabled = false, }) {
    const labels = { ...DEFAULT_LABELS, ...labelsProp };
    const { combinator, clauses } = normalize(rule);
    function setCombinator(next) {
        if (clauses.length === 0)
            onChange(undefined);
        else if (clauses.length === 1)
            onChange(clauses[0]);
        else
            onChange({ op: next, rules: clauses });
    }
    function updateClause(i, patch) {
        const next = clauses.map((c, j) => j === i ? { ...c, ...patch } : c);
        emit(combinator, next);
    }
    function addClause() {
        const first = availableFields[0]?.id ?? '';
        if (!first)
            return;
        emit(combinator, [...clauses, { op: 'eq', field: first, value: '' }]);
    }
    function removeClause(i) {
        emit(combinator, clauses.filter((_, j) => j !== i));
    }
    function emit(comb, list) {
        if (list.length === 0)
            onChange(undefined);
        else if (list.length === 1)
            onChange(list[0]);
        else
            onChange({ op: comb, rules: list });
    }
    if (availableFields.length === 0) {
        return (_jsx("p", { className: "text-xs text-fg-muted", children: labels.noFields }));
    }
    return (_jsxs("div", { className: cn('space-y-2 rounded-md border border-border bg-bg-subtle p-2', className), children: [_jsxs("div", { className: "flex items-center justify-between gap-2", children: [_jsx("span", { className: "text-xs font-semibold text-fg-muted", children: labels.heading }), _jsxs(Select, { className: "h-7 w-24 text-xs", value: combinator, disabled: disabled, onChange: (e) => setCombinator(e.target.value), children: [_jsx("option", { value: "and", children: labels.allOf }), _jsx("option", { value: "or", children: labels.anyOf })] })] }), clauses.length === 0 ? (_jsx("p", { className: "text-xs text-fg-muted", children: labels.alwaysVisible })) : (_jsx("ul", { className: "space-y-1.5", children: clauses.map((c, i) => {
                    const clause = c;
                    const opMeta = OPS.find((o) => o.value === clause.op);
                    return (_jsxs("li", { className: "flex items-center gap-1", children: [_jsx(Select, { className: "h-8 flex-1 text-xs", value: clause.field, disabled: disabled, onChange: (e) => updateClause(i, { field: e.target.value }), children: availableFields.map((f) => (_jsxs("option", { value: f.id, children: [f.label, " (", f.id, ")"] }, f.id))) }), _jsx(Select, { className: "h-8 w-28 text-xs", value: clause.op, disabled: disabled, onChange: (e) => {
                                    const nextOp = e.target.value;
                                    updateClause(i, {
                                        op: nextOp,
                                        value: OPS.find((o) => o.value === nextOp)?.takesValue
                                            ? coerceClauseValue(nextOp, clause.value)
                                            : undefined,
                                    });
                                }, children: OPS.map((o) => (_jsx("option", { value: o.value, children: o.label }, o.value))) }), opMeta?.takesValue ? (_jsx(Input, { className: "h-8 flex-1 text-xs", value: displayClauseValue(clause.value), disabled: disabled, onChange: (e) => updateClause(i, {
                                    value: coerceClauseValue(clause.op, e.target.value),
                                }) })) : null, _jsx("button", { type: "button", disabled: disabled, onClick: () => removeClause(i), "aria-label": labels.removeClause, className: "text-fg-subtle hover:text-danger disabled:cursor-not-allowed disabled:opacity-50", children: _jsx(Trash2, { size: 12 }) })] }, i));
                }) })), _jsxs(Button, { size: "sm", variant: "outline", disabled: disabled, onClick: addClause, children: [_jsx(Plus, { size: 12 }), " ", labels.addClause] })] }));
}
function normalize(rule) {
    if (!rule)
        return { combinator: 'and', clauses: [] };
    if ('rules' in rule && (rule.op === 'and' || rule.op === 'or')) {
        return { combinator: rule.op, clauses: rule.rules };
    }
    return { combinator: 'and', clauses: [rule] };
}
//# sourceMappingURL=logic-builder.js.map