import * as React from 'react';
import type { FormSchemaV1, FormWorkflowStep } from '@appkit/forms-core';
import type { AppLocale } from '@appkit/i18n';
export declare function FormWorkflowEditor({ schema, locale, readOnly, onChange }: {
    schema: FormSchemaV1;
    locale: AppLocale;
    readOnly?: boolean;
    onChange: (steps: FormWorkflowStep[]) => void;
}): React.JSX.Element;
export declare function FormTabsEditor({ schema, locale, readOnly, onChange }: {
    schema: FormSchemaV1;
    locale: AppLocale;
    readOnly?: boolean;
    onChange: (tabs: NonNullable<FormSchemaV1['tabs']> | undefined, sectionTabs: Record<string, string | undefined>) => void;
}): React.JSX.Element;
//# sourceMappingURL=workflow-properties.d.ts.map