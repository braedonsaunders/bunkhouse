import '@excalidraw/excalidraw/index.css';
import type { SketchPadProps } from './sketch-pad.js';
export default function SketchPadClient({ initialScene, onChange, readOnly, }: SketchPadProps): import("react").JSX.Element;
//# sourceMappingURL=sketch-pad-client.d.ts.map