'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { GeneratedText, GeneratedValue, useGeneratedValueTranslations } from './generated-copy.js';
// Tenant-configurable risk model, shared across the Hazard Assessments module
// (and anywhere else that scores risk). The single source of truth is the
// tenant's saved `RiskMatrixConfig` — axis labels, per-cell score/label/colour —
// edited at /hazard-assessments/risk-matrix and injected here through
// <RiskMatrixProvider> at the app shell. Every component below reads the active
// matrix from context, so renaming an axis or recolouring a band in the editor
// flows straight through to the live picker, the score chips and the list.
//
// Authoring model: a cell's score is severity × likelihood (1-based), and a cell
// inherits the label + colour of the highest risk BAND whose threshold its score
// meets. That keeps the editor ergonomic (tune a handful of bands, not N×M
// cells) while the stored shape stays a flat per-cell map the renderers can read
// without recomputing anything.
import { Fragment, createContext, useContext, useMemo, useState } from 'react';
import { cn } from '@appkit/ui';
import { hexColor } from '@appkit/tokens';
// Axis sizes the editor allows. The stored 1-based ratings are plain integers,
// so this only bounds the UI; resizing a populated matrix degrades gracefully
// (out-of-range historical ratings simply stop matching a cell).
export const MIN_AXIS = 3;
export const MAX_AXIS = 6;
// --- Default matrix --------------------------------------------------------
// Reproduces the platform's long-standing 5×5 AS/NZS-style matrix. Used whenever
// a tenant has no saved matrix (or a malformed one), so unconfigured tenants see
// exactly what they saw before this became editable.
const SEVERITY_LABELS = ['Negligible', 'Minor', 'Moderate', 'Major', 'Severe'];
const LIKELIHOOD_LABELS = ['Rare', 'Unlikely', 'Possible', 'Likely', 'Almost certain'];
const DEFAULT_BANDS = [
    { label: 'Low', color: hexColor('success'), minScore: 1 },
    { label: 'Moderate', color: hexColor('warning'), minScore: 5 },
    { label: 'High', color: hexColor('primary'), minScore: 10 },
    { label: 'Critical', color: hexColor('danger'), minScore: 16 },
];
/** The risk band a score falls into (highest band whose threshold it meets;
 *  the lowest band catches anything beneath the first threshold). */
function resolveBand(bands, score) {
    const sorted = [...bands].sort((a, b) => a.minScore - b.minScore);
    let chosen = sorted[0] ?? { label: '', color: hexColor('fg-subtle'), minScore: 1 };
    for (const b of sorted)
        if (score >= b.minScore)
            chosen = b;
    return chosen;
}
/** Build a full per-cell matrix from axis labels + bands (score = sev × lik). */
export function buildMatrix(severityLabels, likelihoodLabels, bands) {
    const severity = severityLabels.map((s, i) => s.trim() || `S${i + 1}`);
    const likelihood = likelihoodLabels.map((s, i) => s.trim() || `L${i + 1}`);
    const cells = {};
    for (let s = 0; s < severity.length; s++) {
        for (let l = 0; l < likelihood.length; l++) {
            const score = (s + 1) * (l + 1);
            const band = resolveBand(bands, score);
            cells[`${s}:${l}`] = { score, label: band.label, color: band.color };
        }
    }
    return { axes: { severity: { values: severity }, likelihood: { values: likelihood } }, cells };
}
/** Recover the editable band list from a stored matrix — one band per distinct
 *  (label, colour), keyed to the lowest score that wears it. Round-trips any
 *  band-by-score matrix, including legacy seeds. */
export function bandsFromMatrix(matrix) {
    const byKey = new Map();
    for (const cell of Object.values(matrix.cells)) {
        const key = `${cell.label}|${cell.color}`;
        const existing = byKey.get(key);
        if (!existing)
            byKey.set(key, { label: cell.label, color: cell.color, minScore: cell.score });
        else
            existing.minScore = Math.min(existing.minScore, cell.score);
    }
    const bands = [...byKey.values()].sort((a, b) => a.minScore - b.minScore);
    if (bands.length > 0 && bands[0])
        bands[0].minScore = 1; // lowest band catches everything beneath it
    return bands.length > 0 ? bands : [...DEFAULT_BANDS];
}
export const DEFAULT_RISK_MATRIX = buildMatrix(SEVERITY_LABELS, LIKELIHOOD_LABELS, DEFAULT_BANDS);
// --- Lookups ---------------------------------------------------------------
/** The cell for a 1-based likelihood × severity pair, or null when unrated /
 *  out of range. */
function cellFor(matrix, likelihood, severity) {
    if (!likelihood || !severity)
        return null;
    return matrix.cells[`${severity - 1}:${likelihood - 1}`] ?? null;
}
/** Plain severity × likelihood product — the fallback score with no matrix. */
function riskScore(likelihood, severity) {
    if (!likelihood || !severity)
        return null;
    return likelihood * severity;
}
/** Map a precomputed score (e.g. an aggregated "worst residual") onto a band by
 *  matching, then bracketing, the matrix's cell scores. */
function bandForScore(matrix, score) {
    const cells = Object.values(matrix.cells);
    if (cells.length === 0)
        return null;
    const exact = cells.find((c) => c.score === score);
    if (exact)
        return exact;
    const sorted = [...cells].sort((a, b) => a.score - b.score);
    let below = null;
    for (const c of sorted)
        if (c.score <= score)
            below = c;
    return below ?? sorted[sorted.length - 1] ?? null;
}
/** Guard against malformed/empty saved configs — fall back to the default. */
function normalizeMatrix(matrix) {
    if (!matrix ||
        !matrix.axes?.severity?.values?.length ||
        !matrix.axes?.likelihood?.values?.length ||
        !matrix.cells ||
        Object.keys(matrix.cells).length === 0) {
        return DEFAULT_RISK_MATRIX;
    }
    return matrix;
}
// --- Context ---------------------------------------------------------------
const RiskMatrixContext = createContext(DEFAULT_RISK_MATRIX);
/** The tenant's active risk matrix (falls back to the default outside a provider). */
function useRiskMatrix() {
    return useContext(RiskMatrixContext);
}
export function RiskMatrixProvider({ matrix, children, }) {
    const value = useMemo(() => normalizeMatrix(matrix), [matrix]);
    return (_jsx(RiskMatrixContext.Provider, { value: value, children: _jsx(GeneratedValue, { value: children }) }));
}
// --- Colour helpers --------------------------------------------------------
function hexToRgb(hex) {
    let h = hex.replace('#', '').trim();
    if (h.length === 3)
        h = h
            .split('')
            .map((c) => c + c)
            .join('');
    const n = Number.parseInt(h, 16);
    if (!Number.isFinite(n) || h.length !== 6)
        return { r: 148, g: 163, b: 184 }; // slate-400
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}
/** Black or white text, whichever reads on the given background. */
function readableTextColor(hex) {
    const { r, g, b } = hexToRgb(hex);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.62 ? hexColor('fg') : hexColor('primary-fg');
}
// --- Chips -----------------------------------------------------------------
function NotRated({ prefix }) {
    return (_jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-surface-muted px-2 py-0.5 text-[11px] font-medium text-fg-muted ring-1 ring-border ring-inset", children: [_jsx(GeneratedValue, { value: prefix ? `${prefix} · ` : '' }), _jsx(GeneratedText, { id: "m_13e61f4185333d" })] }));
}
function RiskChip({ color, score, label, prefix, }) {
    return (_jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full bg-surface-muted px-2 py-0.5 text-[11px] font-medium text-fg-muted ring-1 ring-border ring-inset", children: [_jsx("span", { "aria-hidden": true, className: "size-2 shrink-0 rounded-full ring-1 ring-black/10", style: { background: color } }), _jsx(GeneratedValue, { value: prefix ? (_jsx("span", { className: "opacity-70", children: _jsx(GeneratedValue, { value: prefix }) })) : null }), _jsxs("span", { className: "font-semibold tabular-nums", children: [_jsx(GeneratedValue, { value: score }), _jsx(GeneratedValue, { value: label ? ` · ${label}` : '' })] })] }));
}
/** Chip for a precomputed 1-based score (e.g. an aggregated "worst risk"). */
export function RiskScoreChip({ score, prefix }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const matrix = useRiskMatrix();
    if (score == null)
        return _jsx(NotRated, { prefix: prefix });
    const cell = bandForScore(matrix, score);
    return (_jsx(RiskChip, { color: cell?.color ?? hexColor('fg-subtle'), score: score, label: tGeneratedValue(cell?.label ?? ''), prefix: prefix }));
}
/** Chip showing the score + band for a likelihood × severity pair. */
export function RiskScoreBadge({ likelihood, severity, prefix, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const matrix = useRiskMatrix();
    const cell = cellFor(matrix, likelihood, severity);
    if (!cell)
        return _jsx(NotRated, { prefix: prefix });
    return (_jsx(RiskChip, { color: cell.color, score: cell.score, label: tGeneratedValue(cell.label), prefix: prefix }));
}
/** Pre-control → post-control residual indicator: two score chips + an arrow. */
export function RiskDelta({ preLikelihood, preSeverity, postLikelihood, postSeverity, }) {
    const pre = riskScore(preLikelihood, preSeverity);
    const post = riskScore(postLikelihood, postSeverity);
    if (pre == null && post == null)
        return _jsx(RiskScoreBadge, {});
    return (_jsxs("span", { className: "inline-flex flex-wrap items-center gap-1.5", children: [_jsx(RiskScoreBadge, { likelihood: preLikelihood, severity: preSeverity, prefix: "Initial" }), _jsx("span", { "aria-hidden": true, className: "text-fg-muted", children: "\u2192" }), _jsx(RiskScoreBadge, { likelihood: postLikelihood, severity: postSeverity, prefix: "Residual" })] }));
}
// --- Grid ------------------------------------------------------------------
/**
 * The colour-banded matrix grid: severity → across the top (S1…Sn), likelihood ↑
 * down the left (Ln at top, L1 at bottom). Shared by the interactive picker
 * (`RiskMatrixField`) and the editor preview so they can never drift apart.
 */
export function RiskMatrixGrid({ matrix, selected, onSelect, disabled, className, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const sev = matrix.axes.severity.values;
    const lik = matrix.axes.likelihood.values;
    const interactive = Boolean(onSelect);
    // Likelihood rows render high → low so the most likely sits at the top.
    const rows = lik.map((_, i) => i).reverse();
    return (_jsx("div", { className: cn('overflow-x-auto', className), children: _jsxs("div", { className: "inline-grid w-full gap-0.5 text-center", style: { gridTemplateColumns: `auto repeat(${sev.length}, minmax(2.25rem, 1fr))` }, children: [_jsx("div", {}), _jsx(GeneratedValue, { value: sev.map((label, i) => (_jsxs("div", { title: tGeneratedValue(label), className: "truncate px-1 pb-0.5 text-[10px] font-medium text-fg-muted", children: [_jsx(GeneratedText, { id: "m_16a715c725d406" }), _jsx(GeneratedValue, { value: i + 1 })] }, `sev-${i}`))) }), _jsx(GeneratedValue, { value: rows.map((li) => (_jsxs(Fragment, { children: [_jsxs("div", { title: tGeneratedValue(lik[li]), className: "flex items-center justify-end pr-1.5 text-[10px] font-medium text-fg-muted", children: [_jsx(GeneratedText, { id: "m_182c889ab6dd96" }), _jsx(GeneratedValue, { value: li + 1 })] }), _jsx(GeneratedValue, { value: sev.map((_, si) => {
                                    const cell = matrix.cells[`${si}:${li}`];
                                    const color = cell?.color ?? hexColor('fg-subtle');
                                    const isSelected = selected?.severity === si + 1 && selected?.likelihood === li + 1;
                                    const shared = 'flex h-11 items-center justify-center rounded-sm text-xs font-semibold transition sm:h-9 sm:text-[11px]';
                                    const style = { background: color, color: readableTextColor(color) };
                                    const title = `${lik[li]} × ${sev[si]} = ${cell?.score ?? ''}${cell?.label ? ` · ${cell.label}` : ''}`;
                                    if (!interactive) {
                                        return (_jsx("div", { title: tGeneratedValue(title), className: shared, style: style, children: _jsx(GeneratedValue, { value: cell?.score ?? '' }) }, `c-${si}-${li}`));
                                    }
                                    return (_jsx("button", { type: "button", disabled: disabled, title: tGeneratedValue(title), "aria-pressed": isSelected, onClick: () => onSelect?.(li + 1, si + 1), className: cn(shared, 'hover:brightness-110 active:brightness-95', isSelected && 'font-bold ring-2 ring-fg ring-inset', disabled && 'cursor-not-allowed opacity-60'), style: style, children: _jsx(GeneratedValue, { value: cell?.score ?? '' }) }, `c-${si}-${li}`));
                                }) })] }, `row-${li}`))) })] }) }));
}
// --- Interactive field -----------------------------------------------------
/**
 * Interactive risk-matrix picker driven by the tenant's matrix. Exposes the
 * chosen 1-based likelihood/severity pair through hidden inputs so it drops into
 * a plain <form action={…}>.
 */
export function RiskMatrixField({ label, likelihoodName, severityName, defaultLikelihood, defaultSeverity, disabled, onChange, }) {
    const matrix = useRiskMatrix();
    const [likelihood, setLikelihood] = useState(defaultLikelihood ?? null);
    const [severity, setSeverity] = useState(defaultSeverity ?? null);
    const sevLabel = severity ? matrix.axes.severity.values[severity - 1] : null;
    const likLabel = likelihood ? matrix.axes.likelihood.values[likelihood - 1] : null;
    function setPair(l, s) {
        setLikelihood(l);
        setSeverity(s);
        const cell = cellFor(matrix, l, s);
        onChange?.({
            likelihood: l,
            severity: s,
            score: cell?.score ?? null,
            label: cell?.label ?? null,
        });
    }
    return (_jsxs("fieldset", { className: "space-y-1.5", disabled: disabled, children: [_jsxs("div", { className: "flex items-center justify-between gap-2", children: [_jsx("legend", { className: "text-xs font-medium tracking-wide text-fg-muted uppercase", children: _jsx(GeneratedValue, { value: label }) }), _jsx(RiskScoreBadge, { likelihood: likelihood, severity: severity })] }), _jsx("input", { type: "hidden", name: likelihoodName, value: likelihood ?? '' }), _jsx("input", { type: "hidden", name: severityName, value: severity ?? '' }), _jsx(RiskMatrixGrid, { matrix: matrix, selected: { likelihood, severity }, disabled: disabled, onSelect: (l, s) => {
                    if (likelihood === l && severity === s)
                        setPair(null, null);
                    else
                        setPair(l, s);
                } }), _jsx("p", { className: "text-[11px] text-fg-muted", children: _jsx(GeneratedValue, { value: likLabel && sevLabel ? (_jsxs(_Fragment, { children: [_jsx(GeneratedValue, { value: likLabel }), " ", _jsx(GeneratedText, { id: "m_033fc0f555f2d1" }), ' ', _jsx(GeneratedValue, { value: sevLabel }), " ", _jsx(GeneratedText, { id: "m_013e7516f5d2ac" })] })) : (_jsx(GeneratedText, { id: "m_1a4be3846f6837" })) }) })] }));
}
//# sourceMappingURL=risk-matrix.js.map