import { DEFAULT_LOCALE, localizeText } from '@appkit/i18n';
export function readText(value, locale = DEFAULT_LOCALE, fallback = '') {
    return localizeText(value, locale, fallback);
}
export function writeText(previous, value, locale) {
    return typeof previous === 'string' || previous === undefined
        ? value
        : { ...previous, [locale]: value };
}
//# sourceMappingURL=text.js.map