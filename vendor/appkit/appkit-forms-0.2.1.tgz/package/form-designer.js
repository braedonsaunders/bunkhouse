'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowDown, ArrowUp, GitBranch, GripVertical, List, MousePointerClick, Plus, Search, Settings2, Trash2, Wrench } from 'lucide-react';
import { CHOICE_FIELD_TYPES, FIELD_TYPES, } from '@appkit/forms-core';
import { DEFAULT_LOCALE } from '@appkit/i18n';
import { Badge, Button, Card, CardContent, CardHeader, CardTitle, Drawer, Input, cn, } from '@appkit/ui';
import { readText, writeText } from './text.js';
import { CanvasEditor, defaultBox } from './canvas-editor.js';
import { RecordBehaviorPanel } from './record-behavior-panel.js';
import { RecordListPanel } from './record-list-panel.js';
import { RecordActionsPanel } from './record-actions-panel.js';
import { FieldProperties, SectionProperties } from './properties.js';
import { FormTabsEditor, FormWorkflowEditor } from './workflow-properties.js';
const CATEGORY_ORDER = ['standard', 'choice', 'scoring', 'picker', 'media', 'identity', 'computed', 'data', 'display'];
function newId(prefix, existing) {
    let index = 1;
    let candidate = prefix;
    while (existing.has(candidate))
        candidate = `${prefix}_${++index}`;
    return candidate;
}
export function createFormField(type, existing = new Set()) {
    const meta = FIELD_TYPES[type];
    const field = {
        id: newId(type, existing),
        type,
        label: meta.label,
    };
    if (CHOICE_FIELD_TYPES.has(type)) {
        field.validation = {
            options: [
                { value: 'option_1', label: 'Option 1' },
                { value: 'option_2', label: 'Option 2' },
            ],
        };
    }
    if (type === 'rating')
        field.config = { max: 5 };
    if (type === 'slider')
        field.config = { min: 0, max: 10, step: 1 };
    if (type === 'table') {
        field.config = {
            columns: [{ key: 'column_1', label: 'Column 1', type: 'text' }],
            rowMode: 'addable',
        };
    }
    if (type === 'matrix') {
        field.config = {
            rows: [{ key: 'row_1', label: 'Row 1' }],
            scale: [
                { value: '1', label: 'Low' },
                { value: '2', label: 'High' },
            ],
        };
    }
    if (type === 'formula')
        field.formula = { kind: 'literal', value: 0 };
    if (type === 'lookup')
        field.binding = { sourceKey: 'source' };
    if (type === 'data_table')
        field.binding = { sourceKey: 'source', selectable: 'multi' };
    if (type === 'metric') {
        field.binding = { sourceKey: 'source', aggregate: { fn: 'count' }, display: 'number' };
    }
    return field;
}
export function FormDesigner({ value, onChange, locale = DEFAULT_LOCALE, availableFieldTypes, className, readOnly = false, recordConfig, onRecordConfigChange, onRecordConfigSave, roles, recordActionFlows, recordActionAdapter, onRecordActionsChanged, dataSources, dataSourcesLoading, onRefreshDataSources, }) {
    const [query, setQuery] = React.useState('');
    const [rail, setRail] = React.useState('fields');
    const [selected, setSelected] = React.useState(() => ({
        sectionId: value.sections[0]?.id ?? '',
    }));
    const [propertiesOpen, setPropertiesOpen] = React.useState(false);
    const dragTypeRef = React.useRef(null);
    const types = availableFieldTypes ?? Object.keys(FIELD_TYPES);
    const normalizedQuery = query.trim().toLowerCase();
    const palette = types.filter((type) => {
        const meta = FIELD_TYPES[type];
        return !normalizedQuery || `${meta.label} ${meta.description} ${meta.category}`.toLowerCase().includes(normalizedQuery);
    });
    const sectionIndex = value.sections.findIndex((section) => section.id === selected.sectionId);
    const section = value.sections[sectionIndex];
    const fieldIndex = section?.fields.findIndex((field) => field.id === selected.fieldId) ?? -1;
    const field = section?.fields[fieldIndex];
    const recordFields = React.useMemo(() => value.sections.flatMap((itemSection) => itemSection.fields.map((itemField) => ({ id: itemField.id, label: readText(itemField.label, locale, itemField.id) }))), [locale, value.sections]);
    const railItems = React.useMemo(() => [
        { id: 'fields', label: 'Fields', icon: Wrench, available: true },
        { id: 'workflow', label: 'Pages', icon: GitBranch, available: true },
        { id: 'record', label: 'Record', icon: Settings2, available: Boolean(onRecordConfigChange) },
        { id: 'list', label: 'List', icon: List, available: Boolean(onRecordConfigChange) },
        { id: 'actions', label: 'Actions', icon: MousePointerClick, available: Boolean(recordActionAdapter) },
    ].filter((item) => item.available), [onRecordConfigChange, recordActionAdapter]);
    const commit = React.useCallback((mutate) => {
        const draft = structuredClone(value);
        mutate(draft);
        onChange(draft);
    }, [onChange, value]);
    function addField(type) {
        const targetIndex = sectionIndex >= 0 ? sectionIndex : 0;
        const existing = new Set(value.sections.flatMap((item) => item.fields.map((itemField) => itemField.id)));
        const next = createFormField(type, existing);
        commit((draft) => {
            const target = draft.sections[targetIndex];
            target.fields.push(next);
            if (target.canvas) {
                const box = defaultBox(type);
                const bottom = target.canvas.items.reduce((max, item) => Math.max(max, item.y + item.h), 0);
                target.canvas.items.push({ i: next.id, x: 0, y: bottom, ...box });
            }
        });
        setSelected({ sectionId: value.sections[targetIndex].id, fieldId: next.id });
        setPropertiesOpen(true);
    }
    function addSection() {
        const existing = new Set(value.sections.map((item) => item.id));
        const id = newId('section', existing);
        commit((draft) => draft.sections.push({ id, title: 'New section', fields: [] }));
        setSelected({ sectionId: id });
        setPropertiesOpen(true);
    }
    return (_jsxs("div", { className: cn('flex h-full min-h-0 flex-col overflow-hidden bg-bg', className), children: [_jsxs("div", { className: "flex min-h-0 flex-1 flex-col overflow-hidden lg:flex-row", children: [_jsxs("aside", { className: "flex h-64 w-full shrink-0 flex-col border-b border-border bg-surface lg:h-auto lg:w-80 lg:border-r lg:border-b-0", children: [railItems.length > 1 ? (_jsx("div", { className: "flex shrink-0 border-b border-border p-1", children: railItems.map((item) => {
                                    const Icon = item.icon;
                                    return _jsxs("button", { type: "button", "aria-pressed": rail === item.id, onClick: () => setRail(item.id), className: cn('flex min-w-0 flex-1 flex-col items-center gap-0.5 rounded px-1 py-1.5 text-[10px] font-medium transition-colors', rail === item.id ? 'bg-primary-subtle text-primary' : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx(Icon, { size: 14 }), _jsx("span", { className: "truncate", children: item.label })] }, item.id);
                                }) })) : null, rail === 'fields' ? _jsxs(_Fragment, { children: [_jsxs("div", { className: "flex shrink-0 items-center justify-between border-b border-border px-3 py-2.5", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-sm font-semibold text-fg", children: "Field library" }), _jsx("p", { className: "text-xs text-fg-muted", children: "Choose a field to add it." })] }), _jsx(Badge, { variant: "secondary", children: types.length })] }), _jsx("div", { className: "shrink-0 border-b border-border p-3", children: _jsxs("div", { className: "relative", children: [_jsx(Search, { className: "pointer-events-none absolute top-2.5 left-3 size-4 text-fg-subtle" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Find a field\u2026", className: "pl-9" })] }) }), _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto p-3", children: CATEGORY_ORDER.map((category) => {
                                            const items = palette.filter((type) => FIELD_TYPES[type].category === category);
                                            if (items.length === 0)
                                                return null;
                                            return (_jsxs("section", { className: "mb-3", children: [_jsx("h3", { className: "px-1 pb-1 text-[10px] font-semibold tracking-wider text-fg-subtle uppercase", children: category }), _jsx("div", { className: "grid grid-cols-1 gap-1", children: items.map((type) => (_jsxs("button", { type: "button", disabled: readOnly, draggable: !readOnly, onDragStart: (event) => {
                                                                dragTypeRef.current = type;
                                                                event.dataTransfer.effectAllowed = 'copy';
                                                                event.dataTransfer.setData('application/x-appkit-form-field', type);
                                                            }, onDragEnd: () => { dragTypeRef.current = null; }, onClick: () => addField(type), className: "flex items-center gap-2 rounded border border-border px-2 py-1.5 text-left text-xs text-fg hover:border-primary hover:bg-primary-subtle disabled:cursor-not-allowed disabled:opacity-50", title: `Add ${FIELD_TYPES[type].label}`, children: [_jsx(Plus, { className: "size-3 shrink-0" }), _jsx("span", { className: "truncate", children: FIELD_TYPES[type].label })] }, type))) })] }, category));
                                        }) })] }) : null, rail === 'workflow' ? _jsxs("div", { className: "app-scroll min-h-0 flex-1 space-y-4 overflow-y-auto p-3", children: [_jsx(FormTabsEditor, { schema: value, locale: locale, readOnly: readOnly, onChange: (tabs, sectionTabs) => commit((draft) => { draft.tabs = tabs; for (const itemSection of draft.sections)
                                            itemSection.tabId = sectionTabs[itemSection.id]; }) }), _jsx(FormWorkflowEditor, { schema: value, locale: locale, readOnly: readOnly, onChange: (steps) => commit((draft) => { draft.workflow = { ...(draft.workflow ?? {}), steps }; }) })] }) : null, rail === 'record' && onRecordConfigChange ? _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto p-3", children: _jsx(RecordBehaviorPanel, { value: recordConfig, roles: roles, onChange: onRecordConfigChange, onSave: onRecordConfigSave, readOnly: readOnly }) }) : null, rail === 'list' && onRecordConfigChange ? _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto p-3", children: _jsx(RecordListPanel, { value: recordConfig?.list, fields: recordFields, onChange: (list) => onRecordConfigChange({ ...recordConfig, list }), onSave: onRecordConfigSave ? async (list) => onRecordConfigSave({ ...recordConfig, list }) : undefined, readOnly: readOnly }) }) : null, rail === 'actions' && recordActionAdapter ? _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto p-3", children: _jsx(RecordActionsPanel, { flows: recordActionFlows ?? [], adapter: recordActionAdapter, onChanged: onRecordActionsChanged, readOnly: readOnly }) }) : null] }), _jsxs("div", { className: "flex min-w-0 flex-1 flex-col bg-bg-subtle", children: [_jsxs("div", { className: "flex shrink-0 items-center gap-2 border-b border-border bg-surface px-3 py-2", children: [_jsx("span", { className: "text-xs font-semibold text-fg", children: "Build" }), _jsxs("span", { className: "text-xs text-fg-muted", children: [value.sections.length, " section", value.sections.length === 1 ? '' : 's'] }), _jsx("div", { className: "ml-auto w-full max-w-sm", children: _jsx(Input, { id: "form-title", "aria-label": "Form title", className: "h-8 text-sm font-semibold", value: readText(value.title, locale), disabled: readOnly, onChange: (event) => commit((draft) => { draft.title = writeText(draft.title, event.target.value, locale); }) }) })] }), _jsx("main", { className: "app-scroll min-h-0 flex-1 overflow-y-auto p-4 lg:p-6", children: _jsxs("div", { className: "w-full space-y-3", children: [value.sections.map((itemSection, itemSectionIndex) => {
                                            const sectionActive = selected.sectionId === itemSection.id && !selected.fieldId;
                                            return (_jsxs(Card, { className: cn('border transition-colors', sectionActive ? 'border-primary ring-1 ring-ring' : 'border-border'), children: [_jsxs(CardHeader, { className: "flex flex-row items-center justify-between gap-2 p-4 pb-2", children: [_jsxs("button", { type: "button", onClick: () => {
                                                                    setSelected({ sectionId: itemSection.id });
                                                                    setPropertiesOpen(true);
                                                                }, className: "min-w-0 flex-1 text-left", children: [_jsx(CardTitle, { className: "truncate text-base", children: readText(itemSection.title, locale, 'Untitled section') }), _jsxs("span", { className: "text-xs text-fg-muted", children: [itemSection.fields.length, " field", itemSection.fields.length === 1 ? '' : 's'] })] }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(IconButton, { label: "Move section up", disabled: readOnly || itemSectionIndex === 0, onClick: () => commit((draft) => { const [moved] = draft.sections.splice(itemSectionIndex, 1); draft.sections.splice(itemSectionIndex - 1, 0, moved); }), children: _jsx(ArrowUp, { size: 14 }) }), _jsx(IconButton, { label: "Move section down", disabled: readOnly || itemSectionIndex === value.sections.length - 1, onClick: () => commit((draft) => { const [moved] = draft.sections.splice(itemSectionIndex, 1); draft.sections.splice(itemSectionIndex + 1, 0, moved); }), children: _jsx(ArrowDown, { size: 14 }) }), _jsx(IconButton, { label: "Delete section", disabled: readOnly || value.sections.length === 1, onClick: () => {
                                                                            const nextSection = value.sections[itemSectionIndex === 0 ? 1 : itemSectionIndex - 1];
                                                                            commit((draft) => draft.sections.splice(itemSectionIndex, 1));
                                                                            if (nextSection)
                                                                                setSelected({ sectionId: nextSection.id });
                                                                        }, children: _jsx(Trash2, { size: 14, className: "text-danger" }) })] })] }), _jsx(CardContent, { className: "p-4 pt-0", children: itemSection.canvas ? (_jsx(CanvasEditor, { section: itemSection, locale: locale, defaultLocale: locale, selectedFieldId: selected.sectionId === itemSection.id ? selected.fieldId ?? null : null, dragTypeRef: dragTypeRef, onLayout: (items) => {
                                                                if (readOnly)
                                                                    return;
                                                                commit((draft) => { draft.sections[itemSectionIndex].canvas = { ...draft.sections[itemSectionIndex].canvas, items }; });
                                                            }, onAddWidget: (type, box) => {
                                                                if (readOnly)
                                                                    return;
                                                                const existing = new Set(value.sections.flatMap((candidate) => candidate.fields.map((candidateField) => candidateField.id)));
                                                                const next = createFormField(type, existing);
                                                                commit((draft) => {
                                                                    const target = draft.sections[itemSectionIndex];
                                                                    target.fields.push(next);
                                                                    target.canvas.items.push({ i: next.id, ...box });
                                                                });
                                                                setSelected({ sectionId: itemSection.id, fieldId: next.id });
                                                                setPropertiesOpen(true);
                                                            }, onSelect: (fieldId) => {
                                                                setSelected({ sectionId: itemSection.id, fieldId });
                                                                setPropertiesOpen(true);
                                                            }, onDelete: (fieldId) => {
                                                                if (readOnly)
                                                                    return;
                                                                commit((draft) => {
                                                                    const target = draft.sections[itemSectionIndex];
                                                                    target.fields = target.fields.filter((candidate) => candidate.id !== fieldId);
                                                                    target.canvas.items = target.canvas.items.filter((item) => item.i !== fieldId);
                                                                });
                                                                setSelected({ sectionId: itemSection.id });
                                                            } })) : itemSection.fields.length === 0 ? (_jsx("button", { type: "button", onClick: () => {
                                                                setSelected({ sectionId: itemSection.id });
                                                                setPropertiesOpen(true);
                                                            }, className: "w-full rounded-md border border-dashed border-border-strong p-4 text-center text-xs text-fg-subtle", children: "Select this section, then add a field from the library." })) : (_jsx("ul", { className: "divide-y divide-border-subtle", children: itemSection.fields.map((itemField, itemFieldIndex) => (_jsx("li", { children: _jsxs("button", { type: "button", onClick: () => {
                                                                        setSelected({ sectionId: itemSection.id, fieldId: itemField.id });
                                                                        setPropertiesOpen(true);
                                                                    }, className: cn('flex w-full items-center gap-2 rounded px-2 py-2 text-left transition-colors hover:bg-surface-hover', selected.fieldId === itemField.id && 'bg-primary-subtle text-primary'), children: [_jsx(GripVertical, { className: "size-4 shrink-0 text-fg-subtle" }), _jsx("span", { className: "min-w-0 flex-1 truncate text-sm font-medium", children: readText(itemField.label, locale, FIELD_TYPES[itemField.type].label) }), _jsx(Badge, { variant: "secondary", className: "text-[10px]", children: FIELD_TYPES[itemField.type].label }), itemField.required || itemField.validation?.required ? _jsx(Badge, { variant: "warning", className: "text-[10px]", children: "Required" }) : null, _jsx("span", { className: "w-5 text-right text-xs tabular-nums text-fg-subtle", children: itemFieldIndex + 1 })] }) }, itemField.id))) })) })] }, itemSection.id));
                                        }), _jsxs(Button, { type: "button", variant: "outline", onClick: addSection, disabled: readOnly, className: "w-full", children: [_jsx(Plus, { size: 14 }), "Add section"] })] }) })] })] }), _jsx(Drawer, { open: propertiesOpen, onClose: () => setPropertiesOpen(false), title: field ? 'Field properties' : 'Section properties', size: "sm", children: field && section ? (_jsx(FieldInspector, { field: field, sections: value.sections, availableFields: value.sections.flatMap((itemSection) => itemSection.fields
                        .filter((itemField) => itemField.id !== field.id)
                        .map((itemField) => ({
                        id: itemField.id,
                        label: readText(itemField.label, locale, itemField.id),
                    }))), locale: locale, schema: value, sectionId: section.id, dataSources: dataSources, dataSourcesLoading: dataSourcesLoading, onRefreshDataSources: onRefreshDataSources, readOnly: readOnly, onPatch: (patch) => {
                        commit((draft) => Object.assign(draft.sections[sectionIndex].fields[fieldIndex], patch));
                        if (patch.id && patch.id !== field.id) {
                            setSelected({ sectionId: section.id, fieldId: patch.id });
                        }
                    }, onMove: (offset) => commit((draft) => {
                        const fields = draft.sections[sectionIndex].fields;
                        const target = fieldIndex + offset;
                        if (target < 0 || target >= fields.length)
                            return;
                        const [moved] = fields.splice(fieldIndex, 1);
                        fields.splice(target, 0, moved);
                    }), onDelete: () => {
                        commit((draft) => draft.sections[sectionIndex].fields.splice(fieldIndex, 1));
                        setSelected({ sectionId: section.id });
                    }, canMoveUp: fieldIndex > 0, canMoveDown: fieldIndex < section.fields.length - 1 })) : section ? (_jsx(SectionInspector, { section: section, schema: value, locale: locale, readOnly: readOnly, onChange: (patch) => commit((draft) => Object.assign(draft.sections[sectionIndex], patch)), onDelete: value.sections.length > 1 ? () => {
                        commit((draft) => draft.sections.splice(sectionIndex, 1));
                        setSelected({ sectionId: value.sections[sectionIndex === 0 ? 1 : sectionIndex - 1].id });
                    } : undefined })) : _jsx("p", { className: "text-sm text-fg-muted", children: "Select a section or field to edit it." }) })] }));
}
function IconButton({ label, onClick, disabled, children }) {
    return _jsx("button", { type: "button", title: label, "aria-label": label, onClick: onClick, disabled: disabled, className: "rounded p-1 text-fg-muted hover:bg-surface-hover hover:text-fg disabled:cursor-not-allowed disabled:opacity-40", children: children });
}
function SectionInspector({ section, schema, locale, readOnly, onChange, onDelete }) {
    return _jsxs("div", { className: "space-y-4", children: [_jsx(SectionProperties, { section: section, schema: schema, locale: locale, readOnly: readOnly, onChange: onChange }), onDelete ? _jsxs(Button, { variant: "destructive", size: "sm", onClick: onDelete, disabled: readOnly, children: [_jsx(Trash2, { size: 15 }), "Delete section"] }) : null] });
}
function FieldInspector({ field, schema, sectionId, locale, readOnly, dataSources, dataSourcesLoading, onRefreshDataSources, onPatch, onMove, onDelete, canMoveUp, canMoveDown }) {
    return (_jsxs("div", { className: "space-y-4", children: [_jsx(FieldProperties, { sectionId: sectionId, field: field, schema: schema, locale: locale, dataSources: dataSources, dataSourcesLoading: dataSourcesLoading, onRefreshDataSources: onRefreshDataSources, readOnly: readOnly, onChange: onPatch }), _jsxs("div", { className: "flex flex-wrap gap-1", children: [_jsx(Button, { type: "button", size: "icon", variant: "outline", "aria-label": "Move field up", disabled: readOnly || !canMoveUp, onClick: () => onMove(-1), children: _jsx(ArrowUp, { size: 15 }) }), _jsx(Button, { type: "button", size: "icon", variant: "outline", "aria-label": "Move field down", disabled: readOnly || !canMoveDown, onClick: () => onMove(1), children: _jsx(ArrowDown, { size: 15 }) }), _jsxs(Button, { type: "button", size: "sm", variant: "destructive", disabled: readOnly, onClick: onDelete, children: [_jsx(Trash2, { size: 15 }), "Delete"] })] })] }));
}
//# sourceMappingURL=form-designer.js.map