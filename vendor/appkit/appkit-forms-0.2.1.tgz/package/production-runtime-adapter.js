export {};
//# sourceMappingURL=production-runtime-adapter.js.map