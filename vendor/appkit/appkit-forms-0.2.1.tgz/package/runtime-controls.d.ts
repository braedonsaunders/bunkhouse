import type { FormField } from '@appkit/forms-core';
import { type RiskMatrixConfig } from './risk-matrix.js';
export declare function GpsField({ value, onChange, disabled }: ControlProps): import("react").JSX.Element;
export declare function MatrixField({ field, value, onChange, disabled }: ControlProps): import("react").JSX.Element;
export declare function TableField({ field, value, onChange, disabled }: ControlProps): import("react").JSX.Element;
export declare function AddressField({ value, onChange, disabled }: ControlProps): import("react").JSX.Element;
export declare function SignatureField({ value, onChange, disabled }: ControlProps): import("react").JSX.Element;
export declare function SketchField({ value, onChange, disabled }: ControlProps): import("react").JSX.Element;
export declare function RiskField({ field, value, onChange, disabled, matrix }: ControlProps & {
    matrix?: RiskMatrixConfig;
}): import("react").JSX.Element;
type ControlProps = {
    field: FormField;
    value: unknown;
    onChange: (value: unknown) => void;
    disabled?: boolean;
};
export {};
//# sourceMappingURL=runtime-controls.d.ts.map