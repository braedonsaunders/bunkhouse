import { type RefObject } from 'react';
import { type CanvasItem, type FieldType, type FormSection } from '@appkit/forms-core';
import type { AppLocale } from '@appkit/i18n';
export declare function defaultBox(type: FieldType): {
    w: number;
    h: number;
};
export declare function CanvasEditor({ section, locale, defaultLocale, selectedFieldId, dragTypeRef, onLayout, onAddWidget, onSelect, onDelete, }: {
    section: FormSection;
    locale: AppLocale;
    defaultLocale: AppLocale;
    selectedFieldId: string | null;
    dragTypeRef: RefObject<FieldType | null>;
    onLayout: (items: CanvasItem[]) => void;
    onAddWidget: (type: FieldType, box: {
        x: number;
        y: number;
        w: number;
        h: number;
    }) => void;
    onSelect: (fieldId: string) => void;
    onDelete: (fieldId: string) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=canvas-editor.d.ts.map