import * as React from 'react';
import { type FieldType, type FormField, type FormSchemaV1 } from '@appkit/forms-core';
import { type AppLocale } from '@appkit/i18n';
import type { RecordActionFlow, RecordActionFlowAdapter, RecordConfig } from './record-config.js';
import { type FormDataSource } from './properties.js';
export type FormDesignerProps = {
    value: FormSchemaV1;
    onChange: (schema: FormSchemaV1) => void;
    locale?: AppLocale;
    availableFieldTypes?: readonly FieldType[];
    className?: string;
    readOnly?: boolean;
    recordConfig?: RecordConfig;
    onRecordConfigChange?: (config: RecordConfig) => void;
    onRecordConfigSave?: (config: RecordConfig) => void | Promise<void>;
    roles?: {
        key: string;
        name: string;
    }[];
    recordActionFlows?: RecordActionFlow[];
    recordActionAdapter?: RecordActionFlowAdapter;
    onRecordActionsChanged?: () => void | Promise<void>;
    dataSources?: readonly FormDataSource[];
    dataSourcesLoading?: boolean;
    onRefreshDataSources?: () => void | Promise<void>;
};
export declare function createFormField(type: FieldType, existing?: ReadonlySet<string>): FormField;
export declare function FormDesigner({ value, onChange, locale, availableFieldTypes, className, readOnly, recordConfig, onRecordConfigChange, onRecordConfigSave, roles, recordActionFlows, recordActionAdapter, onRecordActionsChanged, dataSources, dataSourcesLoading, onRefreshDataSources, }: FormDesignerProps): React.JSX.Element;
//# sourceMappingURL=form-designer.d.ts.map