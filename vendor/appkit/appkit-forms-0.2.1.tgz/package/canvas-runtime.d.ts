import type { CanvasItem } from '@appkit/forms-core';
export declare function gridClass(sectionId: string): string;
export declare function resolveCanvas(fieldIds: string[], items: CanvasItem[], cols: number): {
    order: string[];
    byId: Map<string, CanvasItem>;
};
export declare function columnsCss(cls: string, cols: number, spans: {
    id: string;
    span: number;
}[]): string;
export declare function canvasCss(cls: string, cols: number, rowHeight: number, byId: Map<string, CanvasItem>): string;
//# sourceMappingURL=canvas-runtime.d.ts.map