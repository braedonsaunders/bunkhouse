/** Structurally identical to @appkit/ai's AiConfig — pass it straight in. */
export type ImageAiConfig = {
    provider: string;
    apiKey: string;
    baseUrl?: string | null;
};
export type ImageModelId = string;
/**
 * FALLBACK catalog only — the authoritative source is `listImageModels`,
 * which queries the provider's live model API with the tenant's key.
 * Providers retire image models without notice (Google's Imagen models, for
 * example, return "no longer available to new users"), so callers should
 * present the live list and reach for this catalog only when the live fetch
 * fails — and it is the caller's decision to fall back, ideally while
 * surfacing the provider's error.
 */
export declare const IMAGE_MODELS: {
    id: ImageModelId;
    name: string;
    provider: 'openai' | 'google';
}[];
/** Provider kinds (as named by @appkit/ai) that can generate images. */
export declare const IMAGE_CAPABLE_PROVIDERS: readonly ["openai", "google"];
export type ImageModelListing = {
    id: ImageModelId;
    /** Provider display name, when the provider supplies one. */
    name?: string;
};
/**
 * List the image-generation models the tenant's key can actually use, straight
 * from the provider's model API. This is the authoritative list — prefer it
 * over the static {@link IMAGE_MODELS} fallback catalog.
 */
export declare function listImageModels(config: ImageAiConfig): Promise<ImageModelListing[]>;
export type GenerateImagesRequest = {
    prompt: string;
    model: ImageModelId;
    count?: number;
};
export type GenerateImagesResult = {
    /** data: URIs (base64). */
    images: string[];
    model: ImageModelId;
};
export declare function generateImages(config: ImageAiConfig, request: GenerateImagesRequest): Promise<GenerateImagesResult>;
/**
 * A consistent portrait prompt for staff avatars: one flat-illustration
 * head-and-shoulders portrait per subject, uniform style across a roster.
 */
export declare function buildPortraitPrompt(subject: {
    description: string;
    tone?: string[];
}): string;
//# sourceMappingURL=generate.d.ts.map