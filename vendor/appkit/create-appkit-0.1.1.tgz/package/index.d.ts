#!/usr/bin/env node
import { type FeatureName, type PackageManager } from './scaffold.js';
type CliOptions = {
    directory?: string;
    features: FeatureName[];
    packageManager: PackageManager;
    install: boolean;
    initializeGit: boolean;
    yes: boolean;
    help: boolean;
    version: boolean;
};
export declare function parseArguments(argv: string[]): CliOptions;
export {};
//# sourceMappingURL=index.d.ts.map