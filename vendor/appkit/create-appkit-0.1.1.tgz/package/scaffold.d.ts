export declare const FEATURE_PACKAGES: {
    readonly ai: readonly ["@appkit/ai"];
    readonly analytics: readonly ["@appkit/analytics", "@appkit/dashboard", "@appkit/reports"];
    readonly communications: readonly ["@appkit/email-render", "@appkit/emails", "@appkit/notifications", "@appkit/sms"];
    readonly customization: readonly ["@appkit/customization"];
    readonly documents: readonly ["@appkit/design-studio", "@appkit/forms-documents", "@appkit/forms-pdf", "@appkit/pdf"];
    readonly extensions: readonly ["@appkit/apps", "@appkit/endpoints", "@appkit/sandbox", "@appkit/scripts"];
    readonly forms: readonly ["@appkit/editor", "@appkit/forms", "@appkit/forms-core", "@appkit/i18n"];
    readonly integrations: readonly ["@appkit/integrations", "@appkit/sync"];
    readonly identity: readonly ["@appkit/auth", "@appkit/db", "@appkit/iam", "@appkit/tenant"];
    readonly platform: readonly ["@appkit/api", "@appkit/auth", "@appkit/crypto", "@appkit/events"];
    readonly storage: readonly ["@appkit/storage"];
    readonly tenancy: readonly ["@appkit/db", "@appkit/tenant"];
    readonly workflows: readonly ["@appkit/jobs", "@appkit/workflows"];
};
export type FeatureName = keyof typeof FEATURE_PACKAGES;
export type PackageManager = 'pnpm' | 'npm' | 'yarn' | 'bun';
export type ScaffoldOptions = {
    directory: string;
    features?: FeatureName[];
    packageManager?: PackageManager;
    install?: boolean;
    initializeGit?: boolean;
};
export declare function scaffoldProject(options: ScaffoldOptions): Promise<{
    directory: string;
    packages: string[];
}>;
export declare function readGeneratedPackage(directory: string): Promise<Record<string, unknown>>;
//# sourceMappingURL=scaffold.d.ts.map