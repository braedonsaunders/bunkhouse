export type SealedSecret = {
    ciphertext: string;
    nonce: string;
};
export type Sealer = {
    sealSecret: (plain: string) => SealedSecret;
    unsealSecret: (sealed: SealedSecret) => string | null;
};
/** Build a sealer from an explicit source secret (HKDF-derived AES-256 key). */
export declare function createSealer(sourceSecret: string, options?: {
    hkdfInfo?: string;
}): Sealer;
export declare function sealSecret(plain: string): SealedSecret;
export declare function unsealSecret(sealed: SealedSecret): string | null;
//# sourceMappingURL=index.d.ts.map