/** The slice of a GrapesJS editor the designer needs to snapshot a design. */
export type EmailEditorSnapshot = {
    getHtml: () => string;
    getCss?: () => string | undefined;
};
/**
 * GrapesJS keeps authored rules in `getCss()` — keyed by generated ids like
 * `#iltl` — separately from the component markup in `getHtml()`. Persisting one
 * without the other silently drops styling, so the two are always serialized
 * together. The `<style>` block survives sanitizing and is inlined at compile.
 */
export declare function serializeEmailEditor(editor: EmailEditorSnapshot): string;
//# sourceMappingURL=serialize.d.ts.map