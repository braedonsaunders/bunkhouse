import type { EmailDesignerCopy } from './copy.js';
/** The shape `@grapesjs/react`'s BlocksProvider hands each block. */
export type PaletteBlock = {
    getId: () => string;
    getLabel: () => unknown;
};
export type EmailBlockPaletteProps<T extends PaletteBlock> = {
    mapCategoryBlocks: Map<string, T[]>;
    dragStart: (block: T, event: DragEvent) => void;
    dragStop: () => void;
    copy?: Partial<EmailDesignerCopy>;
};
export declare function EmailBlockPalette<T extends PaletteBlock>({ mapCategoryBlocks, dragStart, dragStop, copy, }: EmailBlockPaletteProps<T>): import("react").JSX.Element;
//# sourceMappingURL=palette.d.ts.map