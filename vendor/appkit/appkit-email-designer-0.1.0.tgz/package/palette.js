'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { resolveEmailDesignerCopy } from './copy.js';
function blockLabel(block) {
    const value = block.getLabel();
    const label = typeof value === 'string' ? value.trim() : '';
    return label || block.getId();
}
/** Icons are glyphs rather than an icon-library dependency. */
function blockGlyph(id) {
    if (id.startsWith('token:'))
        return '{ }';
    if (id.startsWith('table:'))
        return '▤';
    return '◻';
}
export function EmailBlockPalette({ mapCategoryBlocks, dragStart, dragStop, copy, }) {
    const t = resolveEmailDesignerCopy(copy);
    const categories = Array.from(mapCategoryBlocks.entries()).filter(([, blocks]) => blocks.length > 0);
    if (categories.length === 0) {
        return _jsx("p", { className: "ak-ed-palette__empty", children: t.noBlocks });
    }
    return (_jsx("div", { className: "ak-ed-palette", children: categories.map(([category, blocks]) => (_jsxs("div", { className: "ak-ed-palette__group", children: [_jsx("p", { className: "ak-ed-palette__heading", children: category || t.generalCategory }), _jsx("div", { className: "ak-ed-palette__grid", children: blocks.map((block) => {
                        const id = block.getId();
                        const label = blockLabel(block);
                        return (_jsxs("div", { draggable: true, role: "button", tabIndex: 0, title: label, className: "ak-ed-palette__block", onDragStart: (event) => dragStart(block, event.nativeEvent), onDragEnd: dragStop, children: [_jsx("span", { className: "ak-ed-palette__glyph", "aria-hidden": "true", children: blockGlyph(id) }), _jsx("span", { className: "ak-ed-palette__label", children: label })] }, id));
                    }) })] }, category || 'general'))) }));
}
//# sourceMappingURL=palette.js.map