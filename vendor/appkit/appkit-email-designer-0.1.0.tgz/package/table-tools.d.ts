import type { Editor } from 'grapesjs';
import type { EmailDesignerCopy } from './copy.js';
export declare function addTableColumn(editor: Editor): void;
export declare function removeTableColumn(editor: Editor): void;
export declare function addTableRow(editor: Editor): void;
export declare function removeTableRow(editor: Editor): void;
/**
 * Apply a width to every cell in the selected column (px, or `null` to clear).
 * Widths are captured by the design serialization and inlined at compile, so
 * they survive to the delivered message.
 */
export declare function setTableColumnWidth(editor: Editor, px: number | null): void;
/** Floats over the canvas whenever a table cell is selected. */
export declare function EmailTableToolbar({ editor, copy, }: {
    editor: Editor | null;
    copy?: Partial<EmailDesignerCopy>;
}): import("react").JSX.Element | null;
//# sourceMappingURL=table-tools.d.ts.map