import type { EmailCollection, EmailMergeField } from './types.js';
export type RenderedEmailDesign = {
    html: string;
    text: string;
};
/**
 * Render `compiledHtml` with `{{token}}` and `{{#each}}` blocks resolved against
 * `values`. Substituted values are HTML-escaped, so untrusted data cannot inject
 * markup into the already-sanitized design.
 */
export declare function renderEmailDesign(compiledHtml: string, values: Record<string, unknown>): RenderedEmailDesign;
/**
 * Build a placeholder value map from the field catalog. Dotted keys become
 * nested objects so `{{agent.name}}` resolves the way it will at send time.
 */
export declare function sampleMergeValues(fields?: EmailMergeField[], collections?: EmailCollection[], rows?: number): Record<string, unknown>;
//# sourceMappingURL=preview.d.ts.map