// Client entry: the GrapesJS authoring surface. Import behind a lazy/dynamic
// import with SSR disabled, and load `@appkit/email-designer/styles.css` once.
export * from './designer.js';
export * from './palette.js';
export * from './table-tools.js';
//# sourceMappingURL=react.js.map