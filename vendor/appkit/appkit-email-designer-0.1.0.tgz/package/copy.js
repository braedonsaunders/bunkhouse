// Every user-visible string in the designer, in one overridable map. The package
// ships English and takes no i18n dependency; hosts with a translation layer
// pass their own strings through the `copy` prop.
export const DEFAULT_EMAIL_DESIGNER_COPY = {
    generalCategory: 'General',
    fieldsCategory: 'Fields',
    tablesCategory: 'Tables',
    noBlocks: 'No blocks available.',
    tableLabel: 'Table',
    addColumn: '+ Col',
    addColumnTitle: 'Add column',
    removeColumn: '− Col',
    removeColumnTitle: 'Remove column',
    addRow: '+ Row',
    addRowTitle: 'Add row',
    removeRow: '− Row',
    removeRowTitle: 'Remove row',
    columnWidth: 'Width',
    columnWidthUnit: 'px',
    columnWidthPlaceholder: 'auto',
};
export function resolveEmailDesignerCopy(copy) {
    return copy ? { ...DEFAULT_EMAIL_DESIGNER_COPY, ...copy } : DEFAULT_EMAIL_DESIGNER_COPY;
}
//# sourceMappingURL=copy.js.map