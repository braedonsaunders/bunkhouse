// The vocabulary the host app speaks to the designer: what can be merged, what
// repeats, and how the authored blocks should look. Everything here is plain
// data so it can cross a server/client boundary and be persisted as-is.
export {};
//# sourceMappingURL=types.js.map