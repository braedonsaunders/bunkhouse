/**
 * Inline a design's `<style>` rules onto each element's `style` attribute.
 *
 * Must run on raw authored HTML BEFORE repeat markers are expanded — juice
 * parses with cheerio and would mangle `{{#each}}` blocks. `juice()` inlines
 * embedded styles only and performs no network or file access (that is
 * `juiceResources`/`juiceFile`), so it is safe and synchronous.
 */
export declare function inlineEmailCss(html: string): string;
//# sourceMappingURL=inline.d.ts.map