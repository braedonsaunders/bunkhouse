'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// The authoring surface: a block palette on the left, the live canvas on the
// right. GrapesJS runs in plain-HTML mode (no MJML plugin) so every element —
// including generated collection tables — stays a real, editable component and
// the markup on the canvas is the markup that ships.
//
// Client-only: GrapesJS touches `window`, so hosts must mount this behind a
// lazy/dynamic import with SSR disabled.
import { useEffect, useRef, useState } from 'react';
import GjsEditor, { BlocksProvider, Canvas } from '@grapesjs/react';
import grapesjs, {} from 'grapesjs';
import { blocksForPreset, collectionTableBlockHtml, mergeFieldBlockHtml, starterHtml } from './blocks.js';
import { resolveEmailDesignerCopy } from './copy.js';
import { EmailBlockPalette } from './palette.js';
import { EmailTableToolbar } from './table-tools.js';
import { serializeEmailEditor } from './serialize.js';
// GrapesJS ships dark chrome; these variables put it in a light key that sits
// closer to a settings page. Hosts can override any of them via `chromeStyle`.
const LIGHT_CHROME = {
    '--gjs-primary-color': '#f1f5f9',
    '--gjs-secondary-color': '#334155',
    '--gjs-tertiary-color': '#0d9488',
    '--gjs-quaternary-color': '#0f766e',
    '--gjs-font-color': '#334155',
    '--gjs-font-color-active': '#0f172a',
    '--gjs-main-dark-color': '#e2e8f0',
};
export function EmailDesigner({ initialHtml, preset = 'email', theme, mergeFields = [], collections = [], extraBlocks = [], copy, onReady, onChange, className, chromeStyle, }) {
    const [editor, setEditor] = useState(null);
    const t = resolveEmailDesignerCopy(copy);
    // Read through refs inside the editor callbacks so a host re-render with new
    // handlers never needs to tear the editor down and lose canvas state.
    const onChangeRef = useRef(onChange);
    const onReadyRef = useRef(onReady);
    useEffect(() => {
        onChangeRef.current = onChange;
        onReadyRef.current = onReady;
    }, [onChange, onReady]);
    return (_jsx("div", { className: ['ak-ed', className].filter(Boolean).join(' '), style: { ...LIGHT_CHROME, ...chromeStyle }, children: _jsx(GjsEditor, { grapesjs: grapesjs, options: {
                height: '100%',
                storageManager: false,
                fromElement: false,
            }, onEditor: (instance) => {
                registerBlocks(instance, { preset, theme, mergeFields, collections, extraBlocks, copy: t });
                seedCanvas(instance, initialHtml, preset, theme);
                instance.on('update', () => onChangeRef.current?.(serializeEmailEditor(instance)));
                setEditor(instance);
                onReadyRef.current?.(instance);
            }, children: _jsxs("div", { className: "ak-ed__layout", children: [_jsx("aside", { className: "ak-ed__rail", children: _jsx(BlocksProvider, { children: (props) => _jsx(EmailBlockPalette, { ...props, copy: copy }) }) }), _jsxs("div", { className: "ak-ed__canvas", children: [_jsx(EmailTableToolbar, { editor: editor, copy: copy }), _jsx(Canvas, { className: "ak-ed__frame" })] })] }) }) }));
}
function registerBlocks(editor, config) {
    const blocks = editor.BlockManager;
    for (const block of [...blocksForPreset(config.preset, config.theme), ...config.extraBlocks]) {
        blocks.add(block.id, {
            label: block.label,
            category: block.category,
            content: block.content,
        });
    }
    for (const field of config.mergeFields) {
        const content = mergeFieldBlockHtml(field);
        if (!content)
            continue;
        blocks.add(`token:${field.key}`, {
            label: field.label || field.key,
            category: field.group || config.copy.fieldsCategory,
            content,
        });
    }
    for (const collection of config.collections) {
        const content = collectionTableBlockHtml(collection, config.theme);
        if (!content)
            continue;
        blocks.add(`table:${collection.key}`, {
            label: `${collection.label} table`,
            category: config.copy.tablesCategory,
            content,
        });
    }
}
function seedCanvas(editor, initialHtml, preset, theme) {
    const starter = starterHtml(preset, theme);
    try {
        editor.setComponents(initialHtml?.trim() ? initialHtml : starter);
    }
    catch {
        // A saved design that no longer parses must not leave a blank editor.
        try {
            editor.setComponents(starter);
        }
        catch {
            /* nothing further to try */
        }
    }
}
//# sourceMappingURL=designer.js.map