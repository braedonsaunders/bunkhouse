'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Tables carry the layout in email, so they need real structural editing —
// add/remove columns and rows, set a per-column width — which GrapesJS does not
// expose out of the box. These helpers walk the selected cell's table in the
// component tree; the toolbar appears whenever a cell is selected.
import { useEffect, useState } from 'react';
import { resolveEmailDesignerCopy } from './copy.js';
const CELL_TAGS = new Set(['td', 'th']);
function closestCell(cmp) {
    let c = cmp;
    while (c) {
        if (CELL_TAGS.has(String(c.get('tagName'))))
            return c;
        c = c.parent();
    }
    return null;
}
function closestTable(cmp) {
    let c = cmp;
    while (c) {
        if (String(c.get('tagName')) === 'table')
            return c;
        c = c.parent();
    }
    return null;
}
function collectRows(node, out) {
    node.components().forEach((child) => {
        const tag = String(child.get('tagName'));
        if (tag === 'tr')
            out.push(child);
        else if (tag === 'thead' || tag === 'tbody' || tag === 'tfoot')
            collectRows(child, out);
    });
}
function cellContext(editor) {
    const cell = closestCell(editor.getSelected());
    if (!cell)
        return null;
    const row = cell.parent();
    if (!row || String(row.get('tagName')) !== 'tr')
        return null;
    const table = closestTable(row);
    if (!table)
        return null;
    const rows = [];
    collectRows(table, rows);
    return { cell, row, table, colIndex: cell.index(), rows };
}
// Copy a reference cell's resolved style onto a freshly inserted one. GrapesJS
// keeps styles in CSS rules keyed by id rather than inline, so a bare new cell
// would otherwise render unstyled next to its neighbours.
function copyStyle(from, to) {
    if (!from || !to || typeof to.setStyle !== 'function')
        return;
    const style = { ...from.getStyle() };
    delete style.width; // per-column, set explicitly
    to.setStyle(style);
}
function firstAdded(added) {
    return Array.isArray(added) ? added[0] : added;
}
export function addTableColumn(editor) {
    const ctx = cellContext(editor);
    if (!ctx)
        return;
    const at = ctx.colIndex + 1;
    ctx.rows.forEach((row) => {
        const cells = row.components();
        const ref = cells.at(Math.min(ctx.colIndex, cells.length - 1));
        const tag = String(ref?.get('tagName')) === 'th' ? 'th' : 'td';
        const label = tag === 'th' ? 'Column' : '&nbsp;';
        // component.append() parses the HTML into a real component; the collection's
        // own .add() does not parse an HTML string.
        const created = firstAdded(row.append(`<${tag}>${label}</${tag}>`, { at: Math.min(at, cells.length) }));
        copyStyle(ref, created);
    });
    editor.trigger('change:canvasOffset');
}
export function removeTableColumn(editor) {
    const ctx = cellContext(editor);
    if (!ctx)
        return;
    if (ctx.rows.every((row) => row.components().length <= 1))
        return; // keep one column
    ctx.rows.forEach((row) => row.components().at(ctx.colIndex)?.remove());
    editor.trigger('change:canvasOffset');
}
export function addTableRow(editor) {
    const ctx = cellContext(editor);
    if (!ctx)
        return;
    const parent = ctx.row.parent();
    if (!parent)
        return;
    const at = ctx.row.index() + 1;
    const cellsHtml = ctx.row
        .components()
        .map((c) => {
        const tag = String(c.get('tagName')) === 'th' ? 'th' : 'td';
        return `<${tag}>&nbsp;</${tag}>`;
    })
        .join('');
    // New rows are static — repeating rows come from a collection's data-each.
    const newRow = firstAdded(parent.append(`<tr>${cellsHtml}</tr>`, { at }));
    if (newRow) {
        const source = ctx.row.components();
        const target = newRow.components();
        source.forEach((c, i) => copyStyle(c, target.at(i)));
    }
    editor.trigger('change:canvasOffset');
}
export function removeTableRow(editor) {
    const ctx = cellContext(editor);
    if (!ctx)
        return;
    if (ctx.rows.length <= 1)
        return;
    ctx.row.remove();
    editor.trigger('change:canvasOffset');
}
/**
 * Apply a width to every cell in the selected column (px, or `null` to clear).
 * Widths are captured by the design serialization and inlined at compile, so
 * they survive to the delivered message.
 */
export function setTableColumnWidth(editor, px) {
    const ctx = cellContext(editor);
    if (!ctx)
        return;
    ctx.rows.forEach((row) => {
        const cell = row.components().at(ctx.colIndex);
        if (!cell || typeof cell.setStyle !== 'function')
            return;
        const style = { ...cell.getStyle() };
        if (px && px > 0)
            style.width = `${px}px`;
        else
            delete style.width;
        cell.setStyle(style);
    });
    editor.trigger('change:canvasOffset');
}
function currentColumnWidthPx(editor) {
    const ctx = cellContext(editor);
    if (!ctx)
        return '';
    const width = String(ctx.cell.getStyle().width ?? '');
    return width.match(/^(\d+(?:\.\d+)?)px$/)?.[1] ?? '';
}
/** Floats over the canvas whenever a table cell is selected. */
export function EmailTableToolbar({ editor, copy, }) {
    const t = resolveEmailDesignerCopy(copy);
    const [active, setActive] = useState(false);
    const [width, setWidth] = useState('');
    useEffect(() => {
        if (!editor)
            return;
        const sync = () => {
            setActive(!!cellContext(editor));
            setWidth(currentColumnWidthPx(editor));
        };
        editor.on('component:selected', sync);
        editor.on('component:deselected', sync);
        editor.on('component:update', sync);
        return () => {
            editor.off('component:selected', sync);
            editor.off('component:deselected', sync);
            editor.off('component:update', sync);
        };
    }, [editor]);
    if (!editor || !active)
        return null;
    const applyWidth = (raw) => {
        const value = Number(raw);
        setTableColumnWidth(editor, Number.isFinite(value) && value > 0 ? value : null);
    };
    return (_jsxs("div", { className: "ak-ed-tabletools", children: [_jsx("span", { className: "ak-ed-tabletools__label", children: t.tableLabel }), _jsx("button", { type: "button", className: "ak-ed-tabletools__btn", onClick: () => addTableColumn(editor), title: t.addColumnTitle, children: t.addColumn }), _jsx("button", { type: "button", className: "ak-ed-tabletools__btn", onClick: () => removeTableColumn(editor), title: t.removeColumnTitle, children: t.removeColumn }), _jsx("span", { className: "ak-ed-tabletools__sep" }), _jsx("button", { type: "button", className: "ak-ed-tabletools__btn", onClick: () => addTableRow(editor), title: t.addRowTitle, children: t.addRow }), _jsx("button", { type: "button", className: "ak-ed-tabletools__btn", onClick: () => removeTableRow(editor), title: t.removeRowTitle, children: t.removeRow }), _jsx("span", { className: "ak-ed-tabletools__sep" }), _jsxs("label", { className: "ak-ed-tabletools__width", children: [t.columnWidth, _jsx("input", { type: "number", min: 0, value: width, onChange: (event) => setWidth(event.target.value), onBlur: (event) => applyWidth(event.target.value), onKeyDown: (event) => {
                            if (event.key === 'Enter')
                                applyWidth(event.target.value);
                        }, placeholder: t.columnWidthPlaceholder }), t.columnWidthUnit] })] }));
}
//# sourceMappingURL=table-tools.js.map