export type EmailDesignerCopy = {
    /** Palette category shown for blocks registered without one. */
    generalCategory: string;
    /** Category the palette uses for merge-field tokens. */
    fieldsCategory: string;
    /** Category the palette uses for collection tables. */
    tablesCategory: string;
    /** Empty state when a preset registers no blocks. */
    noBlocks: string;
    /** Table toolbar. */
    tableLabel: string;
    addColumn: string;
    addColumnTitle: string;
    removeColumn: string;
    removeColumnTitle: string;
    addRow: string;
    addRowTitle: string;
    removeRow: string;
    removeRowTitle: string;
    columnWidth: string;
    columnWidthUnit: string;
    columnWidthPlaceholder: string;
};
export declare const DEFAULT_EMAIL_DESIGNER_COPY: EmailDesignerCopy;
export declare function resolveEmailDesignerCopy(copy?: Partial<EmailDesignerCopy>): EmailDesignerCopy;
//# sourceMappingURL=copy.d.ts.map