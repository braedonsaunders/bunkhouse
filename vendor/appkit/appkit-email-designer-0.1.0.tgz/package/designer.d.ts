import { type CSSProperties } from 'react';
import { type Editor } from 'grapesjs';
import type { EmailBlock, EmailCollection, EmailDesignerPreset, EmailDesignerTheme, EmailMergeField } from './types.js';
import { type EmailDesignerCopy } from './copy.js';
export type EmailDesignerProps = {
    /** Saved `sourceHtml` to reopen. When empty the preset's starter is seeded. */
    initialHtml?: string | null;
    /** Selects the starter document and which block groups the palette offers. */
    preset?: EmailDesignerPreset;
    /** Visual defaults baked into newly inserted blocks. */
    theme?: Partial<EmailDesignerTheme>;
    /** Scalar tokens offered as draggable blocks. */
    mergeFields?: EmailMergeField[];
    /** Repeating lists offered as draggable editable tables. */
    collections?: EmailCollection[];
    /** Extra host-specific blocks appended to the palette. */
    extraBlocks?: EmailBlock[];
    /** Override any user-visible string. */
    copy?: Partial<EmailDesignerCopy>;
    /** Called once the editor exists — keep the ref to snapshot on save. */
    onReady?: (editor: Editor) => void;
    /** Called with the serialized design (`<style>` + markup) on every edit. */
    onChange?: (html: string) => void;
    className?: string;
    /** Merged over the light chrome variables. */
    chromeStyle?: CSSProperties;
};
export declare function EmailDesigner({ initialHtml, preset, theme, mergeFields, collections, extraBlocks, copy, onReady, onChange, className, chromeStyle, }: EmailDesignerProps): import("react").JSX.Element;
//# sourceMappingURL=designer.d.ts.map