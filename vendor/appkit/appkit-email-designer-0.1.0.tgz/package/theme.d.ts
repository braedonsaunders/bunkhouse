import type { EmailDesignerTheme } from './types.js';
/**
 * A neutral slate/teal palette. Hosts override the parts they brand — usually
 * just `accent` — and inherit the rest.
 */
export declare const DEFAULT_EMAIL_DESIGNER_THEME: EmailDesignerTheme;
/** Merge a partial host theme over the defaults. */
export declare function resolveEmailDesignerTheme(theme?: Partial<EmailDesignerTheme>): EmailDesignerTheme;
/**
 * Colors reach inline `style="…"` attributes, so anything that is not a plain
 * hex literal is refused rather than concatenated into markup.
 */
export declare function safeColor(value: string, fallback: string): string;
//# sourceMappingURL=theme.d.ts.map