// Server-safe entry: types, block catalogs, the save-time compile pipeline, and
// render/preview helpers. The GrapesJS authoring surface lives behind
// `@appkit/email-designer/react`; the juice inliner behind `/inline`.
export * from './types.js';
export * from './theme.js';
export * from './blocks.js';
export * from './serialize.js';
export * from './compile.js';
export * from './preview.js';
export * from './copy.js';
//# sourceMappingURL=index.js.map