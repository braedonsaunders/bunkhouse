import type { EmailBlock, EmailCollection, EmailDesignerPreset, EmailDesignerTheme, EmailMergeField } from './types.js';
export declare function safeTemplateKey(value: string): string | null;
/** A single token, ready to drag onto the canvas. */
export declare function mergeFieldBlockHtml(field: EmailMergeField): string | null;
/**
 * One editable repeating-row table. The body row carries `data-each="<key>"`,
 * which compiles to a `{{#each}}` block; the header row stays static. Returns
 * `null` rather than emitting markup when any key is unsafe.
 */
export declare function collectionTableBlockHtml(collection: EmailCollection, theme?: Partial<EmailDesignerTheme>): string | null;
/** Layout and content blocks for authoring a whole message. */
export declare function baseEmailBlocks(theme?: Partial<EmailDesignerTheme>): EmailBlock[];
/**
 * Blocks for authoring a signature. Deliberately table-based and narrow —
 * Outlook renders floats and flex unpredictably inside a quoted reply chain.
 */
export declare function signatureEmailBlocks(theme?: Partial<EmailDesignerTheme>): EmailBlock[];
/** The palette for a preset: signature blocks stay out of full-message authoring. */
export declare function blocksForPreset(preset: EmailDesignerPreset, theme?: Partial<EmailDesignerTheme>): EmailBlock[];
/** Seeded onto the canvas when a design has no saved source yet. */
export declare function starterHtml(preset: EmailDesignerPreset, theme?: Partial<EmailDesignerTheme>): string;
//# sourceMappingURL=blocks.d.ts.map