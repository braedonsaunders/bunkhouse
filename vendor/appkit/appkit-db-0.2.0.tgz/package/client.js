import { AsyncLocalStorage } from 'node:async_hooks';
import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
export function createDb(opts) {
    const orgContext = new AsyncLocalStorage();
    const basePool = new pg.Pool({
        connectionString: opts.url,
        max: 10,
        keepAlive: true,
        ...opts.poolConfig,
    });
    basePool.on('error', (e) => console.error('[appkit/db pool] transient client error (ignored):', e.message));
    const superPool = new pg.Pool({ connectionString: opts.superUrl ?? opts.url, max: 4, keepAlive: true });
    superPool.on('error', (e) => console.error('[appkit/db superPool] transient client error (ignored):', e.message));
    const rawConnect = () => pg.Pool.prototype.connect.call(basePool);
    async function applyTenant(client, ctx) {
        await client.query("select set_config('app.tenant_id', $1, false)", [ctx?.tenantId ?? '']);
    }
    // Wrap the pool so every drizzle query/transaction carries the RLS GUC from the
    // active AsyncLocalStorage context on a dedicated client.
    ;
    basePool.query = async (text, params) => {
        const ctx = orgContext.getStore();
        const client = await rawConnect();
        try {
            await applyTenant(client, ctx);
            return await client.query(text, params);
        }
        finally {
            client.release();
        }
    };
    basePool.connect = async (cb) => {
        const client = await rawConnect();
        await applyTenant(client, orgContext.getStore());
        if (typeof cb === 'function') {
            ;
            cb(null, client, client.release.bind(client));
            return;
        }
        return client;
    };
    const poolDb = drizzle(basePool, { schema: opts.schema });
    const superDb = drizzle(superPool, { schema: opts.schema });
    const db = new Proxy(poolDb, {
        get(target, prop, receiver) {
            const active = orgContext.getStore()?.txDb ?? target;
            const value = Reflect.get(active, prop, receiver);
            return typeof value === 'function' ? value.bind(active) : value;
        },
    });
    function withTenantContext(tenantId, fn) {
        // Await INSIDE the ALS scope: a lazily-executed query (e.g. a drizzle
        // QueryPromise the caller returns without awaiting) would otherwise run
        // after run() exits — unscoped, so app.tenant_id would be '' and RLS would
        // deny every row. Awaiting here keeps the query's execution in-context.
        return orgContext.run({ tenantId }, async () => await fn());
    }
    async function withTenant(tenantId, fn) {
        const client = await rawConnect();
        try {
            await client.query('begin');
            await client.query("select set_config('app.tenant_id', $1, true)", [tenantId]);
            const txDb = drizzle(client, { schema: opts.schema });
            const result = await orgContext.run({ tenantId, txDb }, fn);
            await client.query('commit');
            return result;
        }
        catch (err) {
            try {
                await client.query('rollback');
            }
            catch {
                /* connection already broken */
            }
            throw err;
        }
        finally {
            client.release();
        }
    }
    function withSuperAdmin(fn) {
        return fn(superDb);
    }
    return { db, superDb, pool: basePool, superPool, withTenantContext, withTenant, withSuperAdmin, orgContext };
}
//# sourceMappingURL=client.js.map