# @appkit/db

Multi-tenant Postgres RLS engine, schema helpers, and canonical identity persistence.

## Install

```bash
pnpm add @appkit/db
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
