/** Primary key. `gen_random_uuid()` is built-in (pgcrypto); swap the default for
 *  a `uuid_generate_v7()` function if you want time-ordered, index-friendly ids. */
export declare const id: () => import("drizzle-orm").HasDefault<import("drizzle-orm").IsPrimaryKey<import("drizzle-orm").NotNull<import("drizzle-orm/pg-core").PgUUIDBuilderInitial<"id">>>>;
/** Every tenant-owned row carries this; RLS policies key off it. */
export declare const tenantRef: () => import("drizzle-orm").NotNull<import("drizzle-orm/pg-core").PgUUIDBuilderInitial<"tenant_id">>;
/** Money in a currency. 4 decimals covers all ISO minor units. */
export declare const money: (name: string) => import("drizzle-orm/pg-core").PgNumericBuilderInitial<string>;
/** FX rates need more precision than money. */
export declare const fxRate: (name: string) => import("drizzle-orm/pg-core").PgNumericBuilderInitial<string>;
/** ISO 4217 alpha code, e.g. 'CAD'. */
export declare const currencyCode: (name?: string) => import("drizzle-orm/pg-core").PgTextBuilderInitial<string, [string, ...string[]]>;
/** Standard created/updated audit columns. */
export declare const auditColumns: {
    createdAt: import("drizzle-orm").HasDefault<import("drizzle-orm").NotNull<import("drizzle-orm/pg-core").PgTimestampBuilderInitial<"created_at">>>;
    createdBy: import("drizzle-orm/pg-core").PgUUIDBuilderInitial<"created_by">;
    updatedAt: import("drizzle-orm").HasDefault<import("drizzle-orm").NotNull<import("drizzle-orm/pg-core").PgTimestampBuilderInitial<"updated_at">>>;
    updatedBy: import("drizzle-orm/pg-core").PgUUIDBuilderInitial<"updated_by">;
};
//# sourceMappingURL=helpers.d.ts.map