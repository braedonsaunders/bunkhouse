import { AsyncLocalStorage } from 'node:async_hooks';
import pg from 'pg';
import { type NodePgDatabase } from 'drizzle-orm/node-postgres';
export type TenantCtx = {
    tenantId: string | null;
    txDb?: NodePgDatabase<any>;
};
export type AppkitDb<TSchema extends Record<string, unknown>> = {
    /** Tenant-scoped handle. Inside `withTenant` routes to the pinned tx; otherwise
     *  the pool, which applies `app.tenant_id` from the active context per query. */
    db: NodePgDatabase<TSchema>;
    /** BYPASSRLS handle for super-admin / system work that must span tenants. */
    superDb: NodePgDatabase<TSchema>;
    pool: pg.Pool;
    superPool: pg.Pool;
    /** Scope pooled queries in `fn` to a tenant (no pinned transaction). */
    withTenantContext: <T>(tenantId: string, fn: () => Promise<T>) => Promise<T>;
    /** One atomic transaction pinned to a tenant (RLS GUC set LOCAL). */
    withTenant: <T>(tenantId: string, fn: () => Promise<T>) => Promise<T>;
    /** Run `fn` with the BYPASSRLS handle. Use intentionally. */
    withSuperAdmin: <T>(fn: (db: NodePgDatabase<TSchema>) => Promise<T>) => Promise<T>;
    orgContext: AsyncLocalStorage<TenantCtx>;
};
export declare function createDb<TSchema extends Record<string, unknown>>(opts: {
    url: string;
    /** Connection string for a BYPASSRLS role (super-admin / system). Defaults to `url`. */
    superUrl?: string;
    schema: TSchema;
    poolConfig?: pg.PoolConfig;
}): AppkitDb<TSchema>;
//# sourceMappingURL=client.d.ts.map