import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { RoleScope } from './schema/identity.js';
type Db = NodePgDatabase<Record<string, never>>;
/**
 * Provisioning helpers to seed a fresh install — a tenant, a (possibly
 * super-admin) user, memberships, and built-in roles. Password hashing is the
 * caller's job (pass a hash produced by the configured authentication runtime)
 * so this package stays dependency-clean. Run these with the BYPASSRLS
 * `superDb` (tenant rows don't exist yet to scope to).
 */
export declare function createTenant(db: Db, input: {
    name: string;
    slug: string;
}): Promise<{
    id: string;
}>;
export declare function createUser(db: Db, input: {
    email: string;
    name: string;
    credentialHash?: string;
    isSuperAdmin?: boolean;
}): Promise<{
    id: string;
}>;
export declare function addMembership(db: Db, input: {
    tenantId: string;
    userId: string;
    displayName: string;
}): Promise<{
    id: string;
}>;
/** Upsert built-in roles for a tenant by their stable `key`. */
export declare function seedRoles(db: Db, tenantId: string, defs: {
    key: string;
    name: string;
    permissions: string[];
}[]): Promise<Record<string, string>>;
export declare function assignRole(db: Db, input: {
    tenantId: string;
    membershipId: string;
    roleId: string;
    scope?: RoleScope;
}): Promise<void>;
/** Look up a user by email (case-insensitive not applied here — pass lowercased). */
export declare function findUserByEmail(db: Db, email: string): Promise<{
    id: string;
} | null>;
export {};
//# sourceMappingURL=seed.d.ts.map