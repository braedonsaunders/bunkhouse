/** SQL to install RLS on one tenant-scoped table. Idempotent (drops + recreates).
 *  `globallyReadable`: rows with `tenant_id IS NULL` are readable by any tenant
 *  (e.g. built-in templates), but never writable by runtime roles. */
export declare function rlsPolicySql(table: string, opts?: {
    globallyReadable?: boolean;
}): string;
/** Install RLS across a set of tenant-scoped tables. Run after migrations. */
export declare function installRlsSql(tables: readonly (string | {
    table: string;
    globallyReadable?: boolean;
})[]): string;
//# sourceMappingURL=rls.d.ts.map