import { type ChildProcess, type StdioOptions } from 'node:child_process';
export declare const DEFAULT_BUBBLEWRAP_PATH = "/usr/bin/bwrap";
export declare const DEFAULT_PRLIMIT_PATH = "/usr/bin/prlimit";
export declare const DEFAULT_PROCESS_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin";
export declare const DEFAULT_READ_ONLY_PATHS: readonly ["/usr", "/etc", "/opt", "/app"];
export declare const DEFAULT_MASKED_PATHS: readonly ["/data", "/home", "/root", "/var"];
/**
 * Whether the child shares the host network namespace.
 *
 * `'none'` unshares it, leaving the child with only a loopback interface: no
 * DNS, no outbound sockets, no access to services the application container can
 * reach. `'host'` keeps today's behavior and is the default so that existing
 * network-dependent workers (package installs, coding agents calling an API)
 * keep working when this package is upgraded. Callers running untrusted or
 * merely untrusted-input-handling commands should pass `'none'` explicitly.
 */
export type ProcessSandboxNetwork = 'none' | 'host';
/**
 * Kernel resource ceilings applied to the child. These are enforced by
 * `prlimit(1)` inside the sandbox rather than by bubblewrap, so a host that
 * requests them without util-linux present fails closed instead of running the
 * command unbounded.
 */
export interface ProcessSandboxLimits {
    /** RLIMIT_CPU — CPU seconds before the kernel sends SIGKILL. */
    cpuSeconds?: number;
    /** RLIMIT_AS — maximum address space in bytes. */
    addressSpaceBytes?: number;
    /** RLIMIT_FSIZE — largest file the child may create, in bytes. */
    fileSizeBytes?: number;
    /** RLIMIT_NPROC — maximum processes/threads, which bounds fork bombs. */
    processes?: number;
    /** RLIMIT_NOFILE — maximum open file descriptors. */
    openFiles?: number;
}
export interface ProcessSandboxLauncherIdentity {
    /** Host/container UID used to invoke the setuid bubblewrap executable. */
    uid: number;
    /** Host/container GID used to invoke the setuid bubblewrap executable. */
    gid: number;
}
export interface ProcessSandboxOptions {
    command: string;
    args?: readonly string[];
    /** Absolute working directory inside the sandbox. It must be covered by an exposed bind. */
    cwd: string;
    /** Absolute host paths mounted read/write at the same path inside the sandbox. */
    writablePaths: readonly string[];
    /** Read-only system/application roots exposed to the child. */
    readOnlyPaths?: readonly string[];
    /** Host roots replaced with empty tmpfs mounts before writable binds are layered on top. */
    maskedPaths?: readonly string[];
    /**
     * Mount a fresh procfs for the sandbox's private PID namespace. Disabled by
     * default because some container hosts prohibit nested procfs mounts.
     */
    mountProc?: boolean;
    /**
     * Absolute approved executable exposed as a synthetic `/proc/self/exe`
     * symlink when procfs is unavailable. This supports native runtimes that use
     * `current_exe()` without exposing any process metadata.
     */
    syntheticSelfExecutable?: string;
    /** The complete child environment. Host process variables are never inherited implicitly. */
    environment?: Readonly<Record<string, string | undefined>>;
    bubblewrapPath?: string;
    /**
     * Whether the child keeps the host network namespace. Defaults to `'host'`,
     * which preserves the behavior of every release before network policy
     * existed; pass `'none'` for commands that have no business reaching out.
     */
    network?: ProcessSandboxNetwork;
    /** Kernel resource ceilings for the child. Requires prlimit on the host. */
    limits?: ProcessSandboxLimits;
    /** Absolute prlimit executable used when `limits` are requested. */
    prlimitPath?: string;
    /**
     * Optional unprivileged identity used only to invoke bubblewrap. This lets a
     * root application process use Debian's setuid bubblewrap safely without
     * granting CAP_SYS_ADMIN to the application container.
     */
    launcherIdentity?: ProcessSandboxLauncherIdentity;
    stdio?: StdioOptions;
}
export interface BubblewrapPlan {
    command: string;
    args: string[];
    /** Complete sanitized wrapper/child environment; never serialized into argv. */
    environment: Record<string, string>;
    cwd: string;
    writablePaths: string[];
    readOnlyPaths: string[];
    maskedPaths: string[];
    mountProc: boolean;
    network: ProcessSandboxNetwork;
    /** The ceilings actually applied, after validation. Empty when none were requested. */
    limits: ProcessSandboxLimits;
    syntheticSelfExecutable?: string;
    launcherIdentity?: ProcessSandboxLauncherIdentity;
}
export interface ProcessSandboxVerification {
    supported: true;
    bubblewrapPath: string;
    /** Whether prlimit is present, and so whether `limits` can be enforced. */
    resourceLimitsSupported: boolean;
    /** Whether the host permitted `--unshare-net` during verification. */
    networkIsolationSupported: boolean;
}
export declare class ProcessSandboxError extends Error {
    readonly name = "ProcessSandboxError";
}
/** Whether this host can run the Linux bubblewrap implementation. */
export declare function isProcessSandboxSupported(options?: {
    platform?: NodeJS.Platform;
    bubblewrapPath?: string;
    pathExists?: (path: string) => boolean;
}): boolean;
/**
 * Build the deterministic bubblewrap invocation without spawning it. This is
 * useful for audit logs, deployment readiness checks, tests, and admin UIs.
 */
export declare function buildBubblewrapPlan(options: ProcessSandboxOptions, dependencies?: {
    pathExists?: (path: string) => boolean;
}): BubblewrapPlan;
/**
 * Spawn a process under the shared Linux isolation policy. This function is
 * deliberately fail-closed: unsupported platforms, missing binaries, and
 * missing bind sources throw instead of silently running the command directly.
 */
export declare function spawnBubblewrappedProcess(options: ProcessSandboxOptions): ChildProcess;
/**
 * Execute a minimal child in the real sandbox. Use this during service startup
 * to catch deployment failures that an existence check cannot detect, such as
 * blocked namespace/mount syscalls or an unusable setuid bubblewrap install.
 */
export declare function verifyProcessSandbox(options?: {
    bubblewrapPath?: string;
    prlimitPath?: string;
    launcherIdentity?: ProcessSandboxLauncherIdentity;
    timeoutMs?: number;
}): Promise<ProcessSandboxVerification>;
//# sourceMappingURL=index.d.ts.map