export type DesignUnit = 'in';
/**
 * Canonical persistence/rendering limits for design documents. Read-time
 * normalization and strict write validators share these values so a document
 * accepted at a save boundary is never later truncated by a different cap.
 */
export declare const DESIGN_DOCUMENT_LIMITS: {
    readonly maxJsonBytes: 512000;
    readonly maxArtboards: 12;
    readonly maxElementsPerArtboard: 240;
    readonly documentNameLength: 120;
    readonly artboardNameLength: 80;
    readonly elementNameLength: 80;
    readonly idLength: 80;
    readonly textLength: 4000;
    readonly fieldFallbackLength: 200;
    readonly fieldAffixLength: 40;
    readonly imageUrlLength: 2000;
    readonly fontFamilyLength: 120;
    readonly sealTextLength: 80;
};
export type ArtboardFormat = 'letter-landscape' | 'letter-portrait' | 'cr80-front' | 'cr80-back' | 'label-4x6' | 'custom';
export type DesignDocumentKind = 'training-credential' | 'training-slides' | 'equipment-label' | 'person-badge' | 'generic' | (string & {});
export type DesignDocument = {
    version: 1;
    engine: 'fabric';
    kind: DesignDocumentKind;
    name: string;
    unit: DesignUnit;
    dpi: number;
    artboards: DesignArtboard[];
};
export type DesignArtboard = {
    id: string;
    name: string;
    format: ArtboardFormat;
    width: number;
    height: number;
    background: string;
    bleed?: number;
    printProfile?: PrintProfile;
    elements: DesignElement[];
};
export type PrintProvider = 'browser-pdf' | 'cardpresso-wps' | 'zebra-browser-print' | 'evolis-sdk' | 'hid-fargo-sdk' | (string & {});
export type PrintProfile = {
    provider: PrintProvider;
    media: 'letter' | 'cr80' | 'custom';
    duplex?: boolean;
    edgeToEdge?: boolean;
    orientation?: 'portrait' | 'landscape';
};
export type CredentialDataField = 'tenant.name' | 'tenant.logo' | 'recipient.fullName' | 'recipient.employeeNo' | 'recipient.photo' | 'credential.name' | 'credential.code' | 'authority.name' | 'completedOn' | 'expiresOn' | 'instructor' | 'grade' | 'verify.url' | 'verify.token' | 'verify.qr' | 'issuedAt';
export type EquipmentDataField = 'tenant.name' | 'equipment.name' | 'equipment.assetTag' | 'equipment.serial' | 'equipment.class' | 'equipment.division' | 'equipment.lastInspection' | 'equipment.nextInspectionDue' | 'verify.qr' | 'verify.url';
export type PersonDataField = 'tenant.name' | 'tenant.logo' | 'recipient.fullName' | 'recipient.employeeNo' | 'recipient.photo' | 'person.title' | 'person.department' | 'verify.url' | 'verify.qr' | 'issuedAt';
export type DesignDataField = CredentialDataField | EquipmentDataField | PersonDataField | (string & {});
export type DesignData = Record<string, unknown>;
export type DesignFieldDefinition = {
    key: DesignDataField;
    label: string;
    group?: string;
    semanticType?: 'text' | 'number' | 'date' | 'image' | 'qr';
    example?: string;
};
export type DesignFieldCatalog = {
    fields: DesignFieldDefinition[];
};
export type BaseElement = {
    id: string;
    name: string;
    x: number;
    y: number;
    width: number;
    height: number;
    rotation?: number;
    opacity?: number;
    visible?: boolean;
    locked?: boolean;
};
export type TextStyle = {
    fontFamily?: string;
    fontSize?: number;
    fontWeight?: '400' | '500' | '600' | '700' | '800';
    fontStyle?: 'normal' | 'italic';
    color?: string;
    align?: 'left' | 'center' | 'right';
    letterSpacing?: number;
    lineHeight?: number;
};
export type FillStroke = {
    fill?: string;
    stroke?: string;
    strokeWidth?: number;
    radius?: number;
};
export type TextElement = BaseElement & TextStyle & {
    kind: 'text';
    text: string;
};
export type DataFieldElement = BaseElement & TextStyle & {
    kind: 'field';
    field: DesignDataField;
    fallback?: string;
    prefix?: string;
    suffix?: string;
    transform?: 'none' | 'uppercase' | 'date-long' | 'date-short';
};
export type ShapeElement = BaseElement & FillStroke & {
    kind: 'rect' | 'ellipse';
};
export type LineElement = BaseElement & FillStroke & {
    kind: 'line';
};
export type ImageElement = BaseElement & {
    kind: 'image';
    source?: 'tenant.logo' | 'recipient.photo' | 'field' | 'upload' | 'url';
    field?: DesignDataField;
    url?: string;
    fit?: 'cover' | 'contain';
    radius?: number;
};
export type QrElement = BaseElement & {
    kind: 'qr';
    field: DesignDataField;
    background?: string;
    foreground?: string;
};
export type SealElement = BaseElement & {
    kind: 'seal';
    text?: string;
    fill?: string;
    stroke?: string;
};
export type DesignElement = TextElement | DataFieldElement | ShapeElement | LineElement | ImageElement | QrElement | SealElement;
export type CredentialDesignData = {
    tenantName: string;
    tenantLogoUrl?: string | null;
    recipientFullName: string;
    recipientEmployeeNo?: string | null;
    recipientPhotoUrl?: string | null;
    credentialName: string;
    credentialCode?: string | null;
    authorityName?: string | null;
    completedOn?: string | null;
    expiresOn?: string | null;
    instructor?: string | null;
    grade?: number | null;
    verifyUrl?: string | null;
    verifyToken?: string | null;
    qrDataUrl?: string | null;
    issuedAt?: string | Date | null;
};
export type EquipmentLabelDesignData = {
    tenantName: string;
    tenantLogoUrl?: string | null;
    equipmentName: string;
    equipmentAssetTag?: string | null;
    equipmentSerial?: string | null;
    /** "Category • Type" — pre-joined by the caller. */
    equipmentClass?: string | null;
    /** Site / org-unit name shown in the header band. */
    equipmentDivision?: string | null;
    /** ISO dates (YYYY-MM-DD) so field date transforms apply. */
    lastInspection?: string | null;
    nextInspectionDue?: string | null;
    verifyUrl?: string | null;
    qrDataUrl?: string | null;
};
export type PersonBadgeDesignData = {
    tenantName: string;
    tenantLogoUrl?: string | null;
    recipientFullName: string;
    recipientEmployeeNo?: string | null;
    recipientPhotoUrl?: string | null;
    personTitle?: string | null;
    personDepartment?: string | null;
    /** Public live-transcript URL the badge QR points at. */
    verifyUrl?: string | null;
    qrDataUrl?: string | null;
    issuedAt?: string | Date | null;
};
/** Any data shape a design document can be rendered against. */
export type DesignDocumentData = CredentialDesignData | EquipmentLabelDesignData | PersonBadgeDesignData | DesignData;
export declare function isDesignDocument(value: unknown): value is DesignDocument;
export declare function artboardSizeForFormat(format: ArtboardFormat): {
    width: number;
    height: number;
};
export declare function normalizeDesignDocument(input: unknown, fallback: DesignDocument): DesignDocument;
export declare function safeColor(value: string | null | undefined, fallback: string): string;
export declare function slugId(value: string | null | undefined, fallback: string): string;
export declare function clampNumber(value: number | null | undefined, min: number, max: number, fallback: number): number;
export declare function validateDesignDocument(document: DesignDocument, catalog?: DesignFieldCatalog): string[];
//# sourceMappingURL=schema.d.ts.map