/**
 * Canonical persistence/rendering limits for design documents. Read-time
 * normalization and strict write validators share these values so a document
 * accepted at a save boundary is never later truncated by a different cap.
 */
export const DESIGN_DOCUMENT_LIMITS = {
    maxJsonBytes: 512_000,
    maxArtboards: 12,
    maxElementsPerArtboard: 240,
    documentNameLength: 120,
    artboardNameLength: 80,
    elementNameLength: 80,
    idLength: 80,
    textLength: 4_000,
    fieldFallbackLength: 200,
    fieldAffixLength: 40,
    imageUrlLength: 2_000,
    fontFamilyLength: 120,
    sealTextLength: 80,
};
export function isDesignDocument(value) {
    const doc = value;
    return (!!doc &&
        doc.version === 1 &&
        doc.engine === 'fabric' &&
        doc.unit === 'in' &&
        typeof doc.name === 'string' &&
        typeof doc.dpi === 'number' &&
        Array.isArray(doc.artboards));
}
export function artboardSizeForFormat(format) {
    switch (format) {
        case 'letter-portrait':
            return { width: 8.5, height: 11 };
        case 'cr80-front':
        case 'cr80-back':
            return { width: 3.375, height: 2.125 };
        case 'label-4x6':
            return { width: 4, height: 6 };
        case 'letter-landscape':
            return { width: 11, height: 8.5 };
        case 'custom':
            return { width: 11, height: 8.5 };
    }
}
export function normalizeDesignDocument(input, fallback) {
    if (!isDesignDocument(input))
        return fallback;
    const artboards = input.artboards
        .filter((artboard) => artboard && typeof artboard.id === 'string')
        .slice(0, DESIGN_DOCUMENT_LIMITS.maxArtboards)
        .map((artboard, index) => normalizeArtboard(artboard, fallback.artboards[index]));
    return {
        version: 1,
        engine: 'fabric',
        kind: input.kind ?? fallback.kind,
        name: input.name.trim().slice(0, DESIGN_DOCUMENT_LIMITS.documentNameLength) || fallback.name,
        unit: 'in',
        dpi: clampNumber(input.dpi, 72, 300, fallback.dpi),
        artboards: artboards.length ? artboards : fallback.artboards,
    };
}
function normalizeArtboard(input, fallback) {
    const fallbackSize = fallback
        ? { width: fallback.width, height: fallback.height }
        : artboardSizeForFormat(input.format);
    const format = [
        'letter-landscape',
        'letter-portrait',
        'cr80-front',
        'cr80-back',
        'label-4x6',
        'custom',
    ].includes(input.format)
        ? input.format
        : (fallback?.format ?? 'letter-landscape');
    const size = format === 'custom' ? fallbackSize : artboardSizeForFormat(format);
    return {
        id: slugId(input.id, fallback?.id ?? 'artboard'),
        name: input.name?.trim().slice(0, DESIGN_DOCUMENT_LIMITS.artboardNameLength) ||
            fallback?.name ||
            'Artboard',
        format,
        width: format === 'custom' ? clampNumber(input.width, 1, 40, size.width) : size.width,
        height: format === 'custom' ? clampNumber(input.height, 1, 40, size.height) : size.height,
        background: safeColor(input.background, fallback?.background ?? '#ffffff'),
        bleed: clampNumber(input.bleed, 0, 0.25, fallback?.bleed ?? 0),
        printProfile: normalizePrintProfile(input.printProfile, fallback?.printProfile),
        elements: Array.isArray(input.elements)
            ? input.elements
                .slice(0, DESIGN_DOCUMENT_LIMITS.maxElementsPerArtboard)
                .map((element, index) => normalizeElement(element, index))
            : (fallback?.elements ?? []),
    };
}
function normalizePrintProfile(input, fallback) {
    if (!input)
        return fallback;
    const provider = [
        'browser-pdf',
        'cardpresso-wps',
        'zebra-browser-print',
        'evolis-sdk',
        'hid-fargo-sdk',
    ].includes(input.provider)
        ? input.provider
        : (fallback?.provider ?? 'browser-pdf');
    const media = ['letter', 'cr80', 'custom'].includes(input.media)
        ? input.media
        : (fallback?.media ?? 'letter');
    return {
        provider,
        media,
        duplex: typeof input.duplex === 'boolean' ? input.duplex : (fallback?.duplex ?? false),
        edgeToEdge: typeof input.edgeToEdge === 'boolean' ? input.edgeToEdge : (fallback?.edgeToEdge ?? true),
        orientation: ['portrait', 'landscape'].includes(input.orientation ?? '')
            ? input.orientation
            : fallback?.orientation,
    };
}
function normalizeElement(input, index) {
    const base = {
        id: slugId(input.id, `element-${index + 1}`),
        name: input.name?.trim().slice(0, DESIGN_DOCUMENT_LIMITS.elementNameLength) ||
            `Element ${index + 1}`,
        x: clampNumber(input.x, -40, 40, 0.25),
        y: clampNumber(input.y, -40, 40, 0.25),
        width: clampNumber(input.width, 0.05, 40, 1),
        height: clampNumber(input.height, 0.001, 40, 0.4),
        rotation: clampNumber(input.rotation, -360, 360, 0),
        opacity: clampNumber(input.opacity, 0, 1, 1),
        visible: input.visible !== false,
        locked: input.locked === true,
    };
    switch (input.kind) {
        case 'text':
            return {
                ...base,
                kind: 'text',
                text: (input.text ?? '').slice(0, DESIGN_DOCUMENT_LIMITS.textLength),
                ...normalizeText(input),
            };
        case 'field':
            return {
                ...base,
                kind: 'field',
                field: input.field,
                fallback: input.fallback?.slice(0, DESIGN_DOCUMENT_LIMITS.fieldFallbackLength),
                prefix: input.prefix?.slice(0, DESIGN_DOCUMENT_LIMITS.fieldAffixLength),
                suffix: input.suffix?.slice(0, DESIGN_DOCUMENT_LIMITS.fieldAffixLength),
                transform: ['none', 'uppercase', 'date-long', 'date-short'].includes(input.transform ?? '')
                    ? input.transform
                    : 'none',
                ...normalizeText(input),
            };
        case 'ellipse':
            return { ...base, kind: 'ellipse', ...normalizeFillStroke(input) };
        case 'line':
            return { ...base, kind: 'line', ...normalizeFillStroke(input) };
        case 'image':
            return {
                ...base,
                kind: 'image',
                source: ['tenant.logo', 'recipient.photo', 'field', 'upload', 'url'].includes(input.source ?? '')
                    ? input.source
                    : input.field
                        ? 'field'
                        : 'url',
                field: input.field?.slice(0, DESIGN_DOCUMENT_LIMITS.imageUrlLength),
                url: input.url?.slice(0, DESIGN_DOCUMENT_LIMITS.imageUrlLength),
                fit: input.fit === 'cover' ? 'cover' : 'contain',
                radius: clampNumber(input.radius, 0, 1, 0),
            };
        case 'qr':
            return {
                ...base,
                kind: 'qr',
                field: input.field || 'verify.qr',
                background: safeColor(input.background, '#ffffff'),
                foreground: safeColor(input.foreground, '#0f172a'),
            };
        case 'seal':
            return {
                ...base,
                kind: 'seal',
                text: input.text?.slice(0, DESIGN_DOCUMENT_LIMITS.sealTextLength),
                fill: safeColor(input.fill, '#c2a05c'),
                stroke: safeColor(input.stroke, '#7a5f2b'),
            };
        case 'rect':
        default:
            return { ...base, kind: 'rect', ...normalizeFillStroke(input) };
    }
}
function normalizeText(input) {
    return {
        fontFamily: input.fontFamily?.slice(0, DESIGN_DOCUMENT_LIMITS.fontFamilyLength) ||
            "'Archivo', Arial, sans-serif",
        fontSize: clampNumber(input.fontSize, 3, 120, 14),
        fontWeight: ['400', '500', '600', '700', '800'].includes(input.fontWeight ?? '')
            ? input.fontWeight
            : '600',
        fontStyle: input.fontStyle === 'italic' ? 'italic' : 'normal',
        color: safeColor(input.color, '#0f172a'),
        align: ['left', 'center', 'right'].includes(input.align ?? '') ? input.align : 'left',
        letterSpacing: clampNumber(input.letterSpacing, 0, 0.25, 0),
        lineHeight: clampNumber(input.lineHeight, 0.8, 2, 1.15),
    };
}
function normalizeFillStroke(input) {
    return {
        fill: safeColor(input.fill, '#ffffff'),
        stroke: safeColor(input.stroke, '#cbd5e1'),
        strokeWidth: clampNumber(input.strokeWidth, 0, 0.2, 0.01),
        radius: clampNumber(input.radius, 0, 1, 0),
    };
}
export function safeColor(value, fallback) {
    return value && (value === 'transparent' || /^#[0-9a-fA-F]{6}$/.test(value)) ? value : fallback;
}
export function slugId(value, fallback) {
    let id = '';
    let separatorPending = false;
    for (const character of (value ?? fallback).toLowerCase()) {
        const code = character.charCodeAt(0);
        const isAsciiLetter = code >= 97 && code <= 122;
        const isDigit = code >= 48 && code <= 57;
        if (isAsciiLetter || isDigit) {
            if (separatorPending && id.length > 0 && id.length < DESIGN_DOCUMENT_LIMITS.idLength) {
                id += '-';
            }
            if (id.length < DESIGN_DOCUMENT_LIMITS.idLength)
                id += character;
            separatorPending = false;
            if (id.length >= DESIGN_DOCUMENT_LIMITS.idLength)
                break;
        }
        else if (id.length > 0) {
            separatorPending = true;
        }
    }
    return id || fallback.slice(0, DESIGN_DOCUMENT_LIMITS.idLength);
}
export function clampNumber(value, min, max, fallback) {
    return typeof value === 'number' && Number.isFinite(value)
        ? Math.max(min, Math.min(max, value))
        : fallback;
}
export function validateDesignDocument(document, catalog) {
    const errors = [];
    if (new TextEncoder().encode(JSON.stringify(document)).byteLength > DESIGN_DOCUMENT_LIMITS.maxJsonBytes) {
        errors.push('Design document exceeds the maximum serialized size');
    }
    if (document.artboards.length === 0)
        errors.push('A design requires at least one artboard');
    if (document.artboards.length > DESIGN_DOCUMENT_LIMITS.maxArtboards) {
        errors.push(`A design supports at most ${DESIGN_DOCUMENT_LIMITS.maxArtboards} artboards`);
    }
    const knownFields = catalog ? new Set(catalog.fields.map((field) => field.key)) : null;
    const ids = new Set();
    for (const artboard of document.artboards) {
        if (ids.has(artboard.id))
            errors.push(`Duplicate id: ${artboard.id}`);
        ids.add(artboard.id);
        if (artboard.elements.length > DESIGN_DOCUMENT_LIMITS.maxElementsPerArtboard) {
            errors.push(`${artboard.name} exceeds the element limit`);
        }
        for (const element of artboard.elements) {
            if (ids.has(element.id))
                errors.push(`Duplicate id: ${element.id}`);
            ids.add(element.id);
            const field = element.kind === 'field' || element.kind === 'qr'
                ? element.field
                : element.kind === 'image' && element.source === 'field'
                    ? element.field
                    : undefined;
            if (field && knownFields && !knownFields.has(field))
                errors.push(`Unknown data field: ${field}`);
        }
    }
    return errors;
}
//# sourceMappingURL=schema.js.map