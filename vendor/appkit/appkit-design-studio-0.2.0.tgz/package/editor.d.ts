import { type ReactNode } from 'react';
import { type DesignArtboard, type DesignDataField, type DesignElement } from './index.js';
import type { DesignFieldCatalog as SchemaFieldCatalog } from './schema.js';
import type { DesignStudioTheme } from './defaults.js';
type ImageSource = Extract<DesignElement, {
    kind: 'image';
}>['source'];
/** What a studio's data fields bind to: options, sample values, image slots. */
export type DesignFieldCatalog = {
    options: {
        value: DesignDataField;
        label: string;
    }[];
    sample: Partial<Record<DesignDataField, string>>;
    defaultField: DesignDataField;
    imageSources: {
        value: ImageSource;
        label: string;
    }[];
};
export declare function useDesignZoom({ artboard, reattachKey, }: {
    artboard: {
        width: number;
        height: number;
    } | null;
    reattachKey: unknown;
}): {
    viewportRef: import("react").RefObject<HTMLDivElement | null>;
    zoom: number;
    fitMode: boolean;
    fullscreen: boolean;
    setFullscreen: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    zoomBy: (factor: number) => void;
    zoomTo: (value: number) => void;
    fitToWindow: () => void;
};
export declare function CanvasZoomControls({ zoom, fitMode, fullscreen, zoomBy, zoomTo, fitToWindow, setFullscreen, }: Pick<ReturnType<typeof useDesignZoom>, 'zoom' | 'fitMode' | 'fullscreen' | 'zoomBy' | 'zoomTo' | 'fitToWindow' | 'setFullscreen'>): import("react").JSX.Element;
export declare function ArtboardCanvas({ artboard, zoom, sample, selectedElementId, onSelect, onModify, }: {
    artboard: DesignArtboard;
    zoom: number;
    /** Sample values shown inside data-field elements while editing. */
    sample: Partial<Record<DesignDataField, string>>;
    selectedElementId: string | null;
    onSelect: (id: string | null, userInitiated: boolean) => void;
    onModify: (id: string, patch: Partial<DesignElement>) => void;
}): import("react").JSX.Element;
export declare function InsertPanel({ onAdd }: {
    onAdd: (kind: DesignElement['kind']) => void;
}): import("react").JSX.Element;
export declare function LayersPanel({ artboard, selectedElementId, onSelect, onDuplicate, onDelete, onFront, onBack, }: {
    artboard: DesignArtboard;
    selectedElementId: string | null;
    onSelect: (id: string) => void;
    onDuplicate: () => void;
    onDelete: () => void;
    onFront: () => void;
    onBack: () => void;
}): import("react").JSX.Element;
export declare function InspectorPanel({ artboard, selectedElement, catalog, onPatchArtboard, onPatchElement, onDelete, }: {
    artboard: DesignArtboard;
    selectedElement: DesignElement | null;
    catalog: DesignFieldCatalog;
    onPatchArtboard: (patch: Partial<DesignArtboard>) => void;
    onPatchElement: (patch: Partial<DesignElement>) => void;
    onDelete: () => void;
}): import("react").JSX.Element;
export declare function PrintPanel({ artboard, onPatchArtboard, }: {
    artboard: DesignArtboard;
    onPatchArtboard: (patch: Partial<DesignArtboard>) => void;
}): import("react").JSX.Element;
export declare function RailTabButton({ active, label, icon, onClick, }: {
    active: boolean;
    label: string;
    icon: ReactNode;
    onClick: () => void;
}): import("react").JSX.Element;
export declare function RailLabel({ icon, label }: {
    icon: ReactNode;
    label: string;
}): import("react").JSX.Element;
export declare function Field({ label, children }: {
    label: string;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function LayerToggle({ checked, label, onChange, icon, }: {
    checked: boolean;
    label: string;
    onChange: (checked: boolean) => void;
    icon?: ReactNode;
}): import("react").JSX.Element;
export declare function newElement(kind: DesignElement['kind'], existing: DesignElement[], defaultField: DesignDataField): DesignElement;
/**
 * Construct an element from the package-level field catalogue. This keeps the
 * document editor API and the lower-level production artboard API aligned.
 */
export declare function createDesignElement(kind: DesignElement['kind'], existing: DesignElement[], catalog: SchemaFieldCatalog, theme: DesignStudioTheme): DesignElement;
/** Compatibility name for applications that used the document-level editor API. */
export declare const uniqueDesignElementId: typeof uniqueElementId;
export declare function uniqueElementId(base: string, elements: DesignElement[]): string;
export {};
//# sourceMappingURL=editor.d.ts.map