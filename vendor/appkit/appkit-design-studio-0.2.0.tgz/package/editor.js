'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { GeneratedText, useGeneratedTranslations, GeneratedValue, useGeneratedValueTranslations, } from './generated-copy.js';
// Shared design-studio editor core — the Fabric canvas, zoom/viewport
// machinery, and the Insert / Layers / Inspector / Print rail panels used by
// every design-document studio (record document, label
// QR-label designer). Studios differ only in their shell (how many documents
// they manage, size presets, preview endpoint) and the DATA CATALOG they
// bind fields to — everything here is subject-agnostic and driven by a
// `DesignFieldCatalog`.
import { useCallback, useEffect, useRef, useState } from 'react';
import { AlignCenter, AlignLeft, AlignRight, BadgeCheck, BringToFront, Copy, Grid3X3, Image as ImageIcon, Layers3, Lock, Maximize2, Minimize2, Printer, QrCode, RectangleHorizontal, Scan, SendToBack, Sparkles, Trash2, Type, Unlock, ZoomIn, ZoomOut, } from 'lucide-react';
import { DESIGN_DOCUMENT_LIMITS, PRINT_PROVIDERS, slugId, } from './index.js';
import { loadFabric } from './fabric.js';
import { Badge, Button, Input, Select, Textarea, cn } from '@appkit/ui';
import { hexColor } from '@appkit/tokens';
const PPI = 96;
const ZOOM_MIN = 0.1;
const ZOOM_MAX = 4;
const clampZoom = (z) => Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, Math.round(z * 1000) / 1000));
// Shown at the top of the inspector so a selected element explains itself.
const KIND_META = {
    text: {
        label: 'Text box',
        hint: 'Fixed text — prints exactly what you type. Double-click it on the canvas to edit inline, or use the Text field below.',
    },
    field: {
        label: 'Data field',
        hint: 'Live placeholder — filled with the record’s data each time a document is generated.',
    },
    rect: {
        label: 'Rectangle',
        hint: 'Decorative shape — use for frames, bands, and panels.',
    },
    ellipse: {
        label: 'Ellipse',
        hint: 'Decorative shape — use for circles and ovals.',
    },
    line: {
        label: 'Line',
        hint: 'Decorative rule — use for dividers and signature lines.',
    },
    image: {
        label: 'Image',
        hint: 'Placeholder box — replaced with the bound image when the document is generated.',
    },
    qr: {
        label: 'QR code',
        hint: 'Generated per record — scanning it opens that record’s public link.',
    },
    seal: {
        label: 'Seal',
        hint: 'Round badge — stamps your text (or the issuer’s initials when left blank).',
    },
};
// --- Zoom / fit / fullscreen viewport ---------------------------------------
export function useDesignZoom({ artboard, reattachKey, }) {
    const viewportRef = useRef(null);
    const [zoom, setZoom] = useState(1);
    const [fitMode, setFitMode] = useState(true); // recompute zoom to fit on resize
    const [fullscreen, setFullscreen] = useState(false);
    const artboardWidth = artboard?.width;
    const artboardHeight = artboard?.height;
    // Fit the artboard to the visible viewport (the chrome around the canvas —
    // outer p-5 + checkered p-8 — is ~120px per axis). ResizeObserver fires once
    // on observe, so switching artboards/fullscreen re-fits immediately.
    const computeFit = useCallback(() => {
        const vp = viewportRef.current;
        if (!vp || !artboardWidth || !artboardHeight)
            return 1;
        const availW = Math.max(vp.clientWidth - 120, 80);
        const availH = Math.max(vp.clientHeight - 120, 80);
        return clampZoom(Math.min(availW / (artboardWidth * PPI), availH / (artboardHeight * PPI)));
    }, [artboardHeight, artboardWidth]);
    useEffect(() => {
        if (!fitMode)
            return;
        const vp = viewportRef.current;
        if (!vp)
            return;
        const ro = new ResizeObserver(() => setZoom(computeFit()));
        ro.observe(vp);
        return () => ro.disconnect();
    }, [fitMode, computeFit, fullscreen]);
    const zoomBy = useCallback((factor) => {
        setFitMode(false);
        setZoom((z) => clampZoom(z * factor));
    }, []);
    const zoomTo = useCallback((value) => {
        setFitMode(false);
        setZoom(clampZoom(value));
    }, []);
    const fitToWindow = useCallback(() => setFitMode(true), []);
    // Ctrl/⌘ + scroll (and trackpad pinch) zooms the canvas — native listener
    // because React's synthetic wheel handlers are passive.
    useEffect(() => {
        const vp = viewportRef.current;
        if (!vp)
            return;
        const onWheel = (e) => {
            if (!e.ctrlKey && !e.metaKey)
                return;
            e.preventDefault();
            setFitMode(false);
            setZoom((z) => clampZoom(z * (e.deltaY < 0 ? 1.08 : 1 / 1.08)));
        };
        vp.addEventListener('wheel', onWheel, { passive: false });
        return () => vp.removeEventListener('wheel', onWheel);
    }, [reattachKey]);
    useEffect(() => {
        if (!fullscreen)
            return;
        const onKey = (e) => {
            if (e.key === 'Escape')
                setFullscreen(false);
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [fullscreen]);
    return { viewportRef, zoom, fitMode, fullscreen, setFullscreen, zoomBy, zoomTo, fitToWindow };
}
export function CanvasZoomControls({ zoom, fitMode, fullscreen, zoomBy, zoomTo, fitToWindow, setFullscreen, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const tGenerated = useGeneratedTranslations();
    return (_jsxs(_Fragment, { children: [_jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => zoomBy(1 / 1.2), disabled: zoom <= ZOOM_MIN, "aria-label": tGenerated('m_00a262469a10eb'), title: tGenerated('m_0dc23dde86c8b5'), children: _jsx(ZoomOut, { size: 14 }) }), _jsxs("button", { type: "button", onClick: () => zoomTo(1), title: tGenerated('m_0f91231303cad9'), className: "w-12 rounded px-1 py-1 text-center text-xs font-medium text-fg-muted tabular-nums hover:bg-surface-muted-subtle", children: [_jsx(GeneratedValue, { value: Math.round(zoom * 100) }), "%"] }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => zoomBy(1.2), disabled: zoom >= ZOOM_MAX, "aria-label": tGenerated('m_12713157ff4ed0'), title: tGenerated('m_11077f6d324dbc'), children: _jsx(ZoomIn, { size: 14 }) }), _jsx(Button, { type: "button", variant: fitMode ? 'secondary' : 'ghost', size: "sm", onClick: fitToWindow, "aria-label": tGenerated('m_0289ca594569dc'), title: tGenerated('m_0289ca594569dc'), children: _jsx(Scan, { size: 14 }) }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => setFullscreen(!fullscreen), "aria-label": tGeneratedValue(fullscreen ? tGenerated('m_13170d34c93b7d') : tGenerated('m_11f08bcd4894cb')), title: tGeneratedValue(fullscreen ? tGenerated('m_1a44c3eb34ab88') : tGenerated('m_11f08bcd4894cb')), children: _jsx(GeneratedValue, { value: fullscreen ? _jsx(Minimize2, { size: 14 }) : _jsx(Maximize2, { size: 14 }) }) })] }));
}
// --- Fabric canvas -----------------------------------------------------------
export function ArtboardCanvas({ artboard, zoom, sample, selectedElementId, onSelect, onModify, }) {
    const canvasRef = useRef(null);
    const fabricRef = useRef(null);
    const canvasInstanceRef = useRef(null);
    // Latest zoom for the async Fabric mount + post-rebuild re-asserts.
    const zoomRef = useRef(zoom);
    useEffect(() => {
        zoomRef.current = zoom;
    }, [zoom]);
    // URL-backed images (backgrounds, logos) render live on the canvas so the
    // builder matches the PDF instead of showing blank placeholders. Bitmaps load
    // async, so we cache the decoded <img> per URL and bump a tick to re-render
    // once each finishes. Decoded elements are reused across zoom/select rebuilds.
    const imageCacheRef = useRef(new Map());
    const imageLoadingRef = useRef(new Set());
    const [imageTick, setImageTick] = useState(0);
    const getImage = useCallback((src) => {
        const cached = imageCacheRef.current.get(src);
        if (cached)
            return cached;
        if (!imageLoadingRef.current.has(src)) {
            imageLoadingRef.current.add(src);
            const img = new Image();
            img.onload = () => {
                imageCacheRef.current.set(src, img);
                imageLoadingRef.current.delete(src);
                setImageTick((t) => t + 1);
            };
            img.onerror = () => imageLoadingRef.current.delete(src);
            img.src = src;
        }
        return undefined;
    }, []);
    // Fabric listeners must remain attached for the lifetime of one artboard,
    // while their callbacks and the async initial render must observe the latest
    // React props. Refs provide that separation without stale closures or canvas
    // teardown on every parent render.
    const onSelectRef = useRef(onSelect);
    const onModifyRef = useRef(onModify);
    const initialRenderRef = useRef({ artboard, sample, selectedElementId, getImage });
    useEffect(() => {
        onSelectRef.current = onSelect;
        onModifyRef.current = onModify;
        initialRenderRef.current = { artboard, sample, selectedElementId, getImage };
    }, [artboard, getImage, onModify, onSelect, sample, selectedElementId]);
    useEffect(() => {
        let disposed = false;
        loadFabric().then((fabric) => {
            if (disposed || !canvasRef.current)
                return;
            fabricRef.current = fabric;
            const initial = initialRenderRef.current;
            const canvas = new fabric.Canvas(canvasRef.current, {
                preserveObjectStacking: true,
                backgroundColor: initial.artboard.background,
                selection: true,
            });
            canvasInstanceRef.current = canvas;
            canvas.on('selection:created', (event) => onSelectRef.current(idForObject(event.selected?.[0]), !!event.e));
            canvas.on('selection:updated', (event) => onSelectRef.current(idForObject(event.selected?.[0]), !!event.e));
            canvas.on('selection:cleared', (event) => onSelectRef.current(null, !!event.e));
            canvas.on('object:modified', (event) => {
                const object = event.target;
                const id = idForObject(object);
                if (!id || !object)
                    return;
                onModifyRef.current(id, objectPatch(object, PPI * zoomRef.current));
            });
            // Inline canvas text editing (double-click on a text box) — persist the
            // typed text back into the element, or it reverts on the next rebuild.
            canvas.on('text:editing:exited', (event) => {
                const object = event.target;
                const id = idForObject(object);
                if (!id || !object)
                    return;
                onModifyRef.current(id, {
                    ...objectPatch(object, PPI * zoomRef.current),
                    text: object.text ?? '',
                });
            });
            renderFabricArtboard(fabric, canvas, initial.artboard, initial.sample, initial.selectedElementId, zoomRef.current, initial.getImage);
        });
        return () => {
            disposed = true;
            canvasInstanceRef.current?.dispose();
            canvasInstanceRef.current = null;
        };
    }, [artboard.id]);
    useEffect(() => {
        const fabric = fabricRef.current;
        const canvas = canvasInstanceRef.current;
        if (!fabric || !canvas)
            return;
        renderFabricArtboard(fabric, canvas, artboard, sample, selectedElementId, zoom, getImage);
    }, [artboard, sample, selectedElementId, zoom, getImage, imageTick]);
    return (_jsx("div", { className: "rounded-md bg-surface-muted p-8 shadow-inner", style: {
            backgroundImage: 'linear-gradient(45deg, rgba(148,163,184,.22) 25%, transparent 25%), linear-gradient(-45deg, rgba(148,163,184,.22) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, rgba(148,163,184,.22) 75%), linear-gradient(-45deg, transparent 75%, rgba(148,163,184,.22) 75%)',
            backgroundSize: '24px 24px',
            backgroundPosition: '0 0, 0 12px, 12px -12px, -12px 0px',
        }, children: _jsx("div", { className: "overflow-hidden shadow-2xl ring-1 ring-black/20", children: _jsx("canvas", { ref: canvasRef }) }) }));
}
function renderFabricArtboard(fabric, canvas, artboard, sample, selectedElementId, zoom, getImage) {
    // Zoom is baked into object coordinates (px-per-inch × zoom) rather than
    // Fabric's viewport transform — re-rendering ~30 simple objects per zoom
    // step is cheap, stays vector-crisp at any zoom, and keeps selection
    // handles at constant screen size.
    const k = PPI * zoom;
    canvas.clear();
    canvas.setDimensions({ width: artboard.width * k, height: artboard.height * k });
    canvas.backgroundColor = artboard.background;
    artboard.elements.forEach((element) => {
        if (element.visible === false)
            return;
        const object = fabricObject(fabric, element, sample, k, getImage);
        if (!object)
            return;
        object.set('appkitElementId', element.id);
        object.set({
            lockMovementX: element.locked,
            lockMovementY: element.locked,
            lockScalingX: element.locked,
            lockScalingY: element.locked,
            lockRotation: element.locked,
            selectable: !element.locked,
            evented: !element.locked,
        });
        canvas.add(object);
    });
    const active = canvas
        .getObjects()
        .find((object) => idForObject(object) === selectedElementId);
    if (active)
        canvas.setActiveObject(active);
    canvas.requestRenderAll();
}
/** Resolve an image element to a concrete <img> src the canvas can draw. */
function imageSrcForElement(element) {
    if (element.source === 'url')
        return element.url?.trim() || null;
    return null;
}
/** Build the Fabric object for an element at `k` device px per inch (PPI × zoom). */
function fabricObject(fabric, element, sample, k, getImage) {
    const base = {
        left: element.x * k,
        top: element.y * k,
        // Fabric v7 defaults to CENTER origin — without these, every object draws
        // shifted by half its size (large frames/titles clip off-canvas).
        originX: 'left',
        originY: 'top',
        angle: element.rotation ?? 0,
        opacity: element.opacity ?? 1,
    };
    const width = element.width * k;
    const height = element.height * k;
    if (element.kind === 'text' || element.kind === 'field') {
        return new fabric.Textbox(displayTextForElement(element, sample), {
            ...base,
            width,
            height,
            fontFamily: element.fontFamily ?? 'Arial',
            fontSize: (element.fontSize ?? 12) * (k / 72),
            fontWeight: element.fontWeight ?? '600',
            fontStyle: element.fontStyle ?? 'normal',
            fill: element.color ?? hexColor('fg'),
            textAlign: element.align ?? 'left',
            editable: element.kind === 'text',
        });
    }
    if (element.kind === 'ellipse') {
        return new fabric.Ellipse({
            ...base,
            rx: width / 2,
            ry: height / 2,
            fill: element.fill ?? 'transparent',
            stroke: element.stroke ?? hexColor('border-strong'),
            strokeWidth: (element.strokeWidth ?? 0.01) * k,
        });
    }
    if (element.kind === 'line') {
        return new fabric.Line([0, 0, width, 0], {
            ...base,
            stroke: element.stroke ?? hexColor('fg'),
            strokeWidth: Math.max(1, (element.strokeWidth ?? 0.01) * k),
        });
    }
    if (element.kind === 'qr') {
        return new fabric.Rect({
            ...base,
            width,
            height,
            fill: element.background ?? hexColor('surface'),
            stroke: hexColor('fg'),
            strokeWidth: 1,
        });
    }
    if (element.kind === 'seal') {
        return new fabric.Circle({
            ...base,
            radius: Math.min(width, height) / 2,
            fill: element.fill ?? hexColor('warning'),
            stroke: element.stroke ?? hexColor('primary'),
            strokeWidth: 2,
        });
    }
    if (element.kind === 'image') {
        const src = imageSrcForElement(element);
        const loaded = src ? getImage(src) : undefined;
        if (loaded && loaded.naturalWidth > 0) {
            // Stretch the bitmap to the element box so its bounding box stays exactly
            // the element rect — keeps drag/resize mapping (objectPatch) correct.
            // Backgrounds are authored at the artboard aspect, so no visible distortion.
            const ImageCtor = fabric.FabricImage ?? fabric.Image;
            return new ImageCtor(loaded, {
                ...base,
                scaleX: width / loaded.naturalWidth,
                scaleY: height / loaded.naturalHeight,
            });
        }
        return new fabric.Rect({
            ...base,
            width,
            height,
            fill: element.source === 'recipient.photo' ? hexColor('info-subtle') : hexColor('bg-subtle'),
            stroke: hexColor('fg-subtle'),
            strokeDashArray: [6, 4],
            strokeWidth: 1,
            rx: (element.radius ?? 0) * k,
            ry: (element.radius ?? 0) * k,
        });
    }
    return new fabric.Rect({
        ...base,
        width,
        height,
        fill: element.fill ?? 'transparent',
        stroke: element.stroke ?? hexColor('border-strong'),
        strokeWidth: (element.strokeWidth ?? 0.01) * k,
        rx: (element.radius ?? 0) * k,
        ry: (element.radius ?? 0) * k,
    });
}
function objectPatch(object, k) {
    return {
        x: roundInches((object.left ?? 0) / k),
        y: roundInches((object.top ?? 0) / k),
        width: roundInches(object.getScaledWidth() / k),
        height: roundInches(object.getScaledHeight() / k),
        rotation: Math.round(object.angle ?? 0),
    };
}
function idForObject(object) {
    return object?.appkitElementId ?? object?.get?.('appkitElementId') ?? null;
}
function displayTextForElement(element, sample) {
    if (element.kind === 'text')
        return element.text;
    if (element.kind === 'field') {
        const raw = sample[element.field] ?? element.fallback ?? element.field;
        const value = element.transform === 'uppercase' ? raw.toUpperCase() : raw;
        return `${element.prefix ?? ''}${value}${element.suffix ?? ''}`;
    }
    return element.name;
}
// --- Rail panels --------------------------------------------------------------
export function InsertPanel({ onAdd }) {
    const tGenerated = useGeneratedTranslations();
    return (_jsxs("div", { className: "space-y-3", children: [_jsx(RailLabel, { label: tGenerated('m_16f99327318dfb'), icon: _jsx(Sparkles, { size: 14 }) }), _jsx(ElementButton, { label: tGenerated('m_1c7e7e07a32853'), icon: _jsx(Type, { size: 15 }), onClick: () => onAdd('text') }), _jsx(ElementButton, { label: tGenerated('m_138222fc315717'), icon: _jsx(BadgeCheck, { size: 15 }), onClick: () => onAdd('field') }), _jsx(ElementButton, { label: tGenerated('m_1849b2d387c738'), icon: _jsx(RectangleHorizontal, { size: 15 }), onClick: () => onAdd('rect') }), _jsx(ElementButton, { label: tGenerated('m_0f020b4cd561e6'), icon: _jsx(BadgeCheck, { size: 15 }), onClick: () => onAdd('ellipse') }), _jsx(ElementButton, { label: tGenerated('m_13ea99a078fa96'), icon: _jsx(ImageIcon, { size: 15 }), onClick: () => onAdd('image') }), _jsx(ElementButton, { label: tGenerated('m_02316e48e168d8'), icon: _jsx(QrCode, { size: 15 }), onClick: () => onAdd('qr') }), _jsx(ElementButton, { label: tGenerated('m_13312cc3ff1e8a'), icon: _jsx(BadgeCheck, { size: 15 }), onClick: () => onAdd('seal') }), _jsx("div", { className: "rounded-md border border-border bg-surface-subtle p-3 text-xs leading-5 text-fg-muted", children: _jsx(GeneratedText, { id: "m_1623eb9979e59c" }) })] }));
}
export function LayersPanel({ artboard, selectedElementId, onSelect, onDuplicate, onDelete, onFront, onBack, }) {
    const tGenerated = useGeneratedTranslations();
    return (_jsxs("div", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx(RailLabel, { label: tGenerated('m_1065741cf2a494'), icon: _jsx(Layers3, { size: 14 }) }), _jsx(Badge, { variant: "secondary", children: _jsx(GeneratedValue, { value: artboard.elements.length }) })] }), _jsxs("div", { className: "flex gap-1", children: [_jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: onDuplicate, disabled: !selectedElementId, title: tGenerated('m_13fa26360f0fe9'), children: _jsx(Copy, { size: 14 }) }), _jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: onFront, disabled: !selectedElementId, title: tGenerated('m_0beb88c08048c3'), children: _jsx(BringToFront, { size: 14 }) }), _jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: onBack, disabled: !selectedElementId, title: tGenerated('m_081ec96d0986e6'), children: _jsx(SendToBack, { size: 14 }) }), _jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: onDelete, disabled: !selectedElementId, title: tGenerated('m_11773f3c3f7558'), children: _jsx(Trash2, { size: 14 }) })] }), _jsx("div", { className: "space-y-1.5", children: _jsx(GeneratedValue, { value: [...artboard.elements].reverse().map((element) => (_jsxs("button", { type: "button", onClick: () => onSelect(element.id), className: cn('flex w-full items-center gap-2 rounded-md border px-2.5 py-2 text-left text-sm', element.id === selectedElementId
                            ? 'border-primary bg-primary-subtle text-primary'
                            : 'border-border bg-surface text-fg-muted hover:bg-surface-subtle'), children: [_jsx(GeneratedValue, { value: iconForElement(element) }), _jsx("span", { className: "min-w-0 flex-1 truncate", children: _jsx(GeneratedValue, { value: element.name }) }), _jsx(GeneratedValue, { value: element.locked ? (_jsx(Lock, { size: 12, className: "text-fg-subtle" })) : null })] }, element.id))) }) })] }));
}
export function InspectorPanel({ artboard, selectedElement, catalog, onPatchArtboard, onPatchElement, onDelete, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const tGenerated = useGeneratedTranslations();
    if (!selectedElement) {
        return (_jsxs("div", { className: "space-y-3", children: [_jsx(RailLabel, { label: tGenerated('m_1604ec41b6c59b'), icon: _jsx(Grid3X3, { size: 14 }) }), _jsx(Field, { label: tGenerated('m_02b18d5c7f6f2d'), children: _jsx(Input, { value: artboard.name, maxLength: DESIGN_DOCUMENT_LIMITS.artboardNameLength, onChange: (e) => onPatchArtboard({ name: e.currentTarget.value }) }) }), _jsx(ColorField, { label: tGenerated('m_197c46ade6d75f'), value: artboard.background, onChange: (background) => onPatchArtboard({ background }) }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(NumberField, { label: tGenerated('m_13260774b3499b'), value: artboard.width, onChange: (width) => onPatchArtboard({ width, format: 'custom' }) }), _jsx(NumberField, { label: tGenerated('m_0e936e6e874290'), value: artboard.height, onChange: (height) => onPatchArtboard({ height, format: 'custom' }) })] }), _jsx("div", { className: "rounded-md border border-border bg-surface-subtle p-3 text-xs text-fg-muted", children: _jsx(GeneratedText, { id: "m_12b9991889a2c8" }) })] }));
    }
    const meta = KIND_META[selectedElement.kind];
    return (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "rounded-md border border-border bg-surface-subtle p-3", children: [_jsxs("div", { className: "flex items-center justify-between gap-2", children: [_jsxs("span", { className: "flex min-w-0 items-center gap-1.5 text-sm font-semibold text-fg", children: [_jsx(GeneratedValue, { value: iconForElement(selectedElement) }), _jsx(GeneratedValue, { value: meta.label })] }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: onDelete, "aria-label": tGenerated('m_175a029083c608'), children: _jsx(Trash2, { size: 14, className: "text-danger" }) })] }), _jsx("p", { className: "mt-1 text-xs leading-5 text-fg-muted-subtle", children: _jsx(GeneratedValue, { value: meta.hint }) })] }), _jsx(Field, { label: tGenerated('m_0568217366722b'), children: _jsx(Input, { value: selectedElement.name, maxLength: DESIGN_DOCUMENT_LIMITS.elementNameLength, onChange: (e) => onPatchElement({ name: e.currentTarget.value }) }) }), _jsx(GeneratedValue, { value: selectedElement.kind === 'text' ? (_jsx(Field, { label: tGenerated('m_1ca9a0811729da'), children: _jsx(Textarea, { rows: 3, value: selectedElement.text, maxLength: DESIGN_DOCUMENT_LIMITS.textLength, onChange: (e) => onPatchElement({ text: e.currentTarget.value }) }) })) : null }), _jsx(GeneratedValue, { value: selectedElement.kind === 'field' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_138222fc315717'), children: _jsx(Select, { value: selectedElement.field, onChange: (e) => onPatchElement({
                                    field: e.currentTarget.value,
                                }), children: catalog.options.map((field) => (_jsx("option", { value: field.value, children: field.label }, field.value))) }) }), _jsxs("div", { className: "rounded-md border border-primary bg-primary-subtle/60 px-2.5 py-2 text-xs text-primary", children: [_jsx("span", { className: "font-semibold", children: _jsx(GeneratedText, { id: "m_1dd2ac78e8c792" }) }), _jsx(GeneratedValue, { value: ' ' }), _jsx(GeneratedValue, { value: `${selectedElement.prefix ?? ''}${selectedElement.transform === 'uppercase'
                                        ? (catalog.sample[selectedElement.field] ?? '').toUpperCase()
                                        : (catalog.sample[selectedElement.field] ?? '')}${selectedElement.suffix ?? ''}` })] }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(Field, { label: tGenerated('m_00adfbfb276db4'), children: _jsx(Input, { value: selectedElement.prefix ?? '', maxLength: DESIGN_DOCUMENT_LIMITS.fieldAffixLength, onChange: (e) => onPatchElement({ prefix: e.currentTarget.value }) }) }), _jsx(Field, { label: tGenerated('m_09b4b90bca1cb7'), children: _jsx(Input, { value: selectedElement.suffix ?? '', maxLength: DESIGN_DOCUMENT_LIMITS.fieldAffixLength, onChange: (e) => onPatchElement({ suffix: e.currentTarget.value }) }) }), _jsx(Field, { label: tGenerated('m_0079cd733e75d4'), children: _jsx(Input, { value: selectedElement.fallback ?? '', maxLength: DESIGN_DOCUMENT_LIMITS.fieldFallbackLength, placeholder: tGenerated('m_0dbb83eaf1e96a'), onChange: (e) => onPatchElement({ fallback: e.currentTarget.value }) }) }), _jsx(Field, { label: tGenerated('m_1f6288d5ae6aab'), children: _jsxs(Select, { value: selectedElement.transform ?? 'none', onChange: (e) => onPatchElement({
                                            transform: e.currentTarget.value,
                                        }), children: [_jsx("option", { value: "none", children: 'As is' }), _jsx("option", { value: "uppercase", children: 'UPPERCASE' }), _jsx("option", { value: "date-long", children: 'Date — June 11, 2026' }), _jsx("option", { value: "date-short", children: 'Date — Jun 11, 2026' })] }) })] })] })) : null }), _jsx(GeneratedValue, { value: selectedElement.kind === 'image' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_17d5e70f58b666'), children: _jsx(Select, { value: selectedElement.source, onChange: (e) => onPatchElement({
                                    source: e.currentTarget.value,
                                }), children: catalog.imageSources.map((source) => (_jsx("option", { value: source.value, children: source.label }, source.value))) }) }), _jsx(GeneratedValue, { value: selectedElement.source === 'url' ? (_jsx(Field, { label: tGenerated('m_1febb31a01f5e7'), children: _jsx(Input, { value: selectedElement.url ?? '', maxLength: DESIGN_DOCUMENT_LIMITS.imageUrlLength, placeholder: "https://\u2026", onChange: (e) => onPatchElement({ url: e.currentTarget.value }) }) })) : null })] })) : null }), _jsx(GeneratedValue, { value: selectedElement.kind === 'seal' ? (_jsx(Field, { label: tGenerated('m_020e4445dee967'), children: _jsx(Input, { value: selectedElement.text ?? '', maxLength: DESIGN_DOCUMENT_LIMITS.sealTextLength, placeholder: tGenerated('m_17413c3fbf4b8e'), onChange: (e) => onPatchElement({ text: e.currentTarget.value }) }) })) : null }), _jsx(GeneratedValue, { value: selectedElement.kind === 'qr' ? (_jsxs("div", { className: "grid grid-cols-1 gap-2", children: [_jsx(ColorField, { label: tGenerated('m_0570e24c85cf95'), value: selectedElement.foreground ?? hexColor('fg'), onChange: (foreground) => onPatchElement({ foreground }) }), _jsx(ColorField, { label: tGenerated('m_0a5bcbdd19d2fe'), value: selectedElement.background ?? hexColor('surface'), onChange: (background) => onPatchElement({ background }) })] })) : null }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(NumberField, { label: tGenerated('m_1fd44044202a6a'), value: selectedElement.x, onChange: (x) => onPatchElement({ x }) }), _jsx(NumberField, { label: tGenerated('m_1211a6d4c9ccc9'), value: selectedElement.y, onChange: (y) => onPatchElement({ y }) }), _jsx(NumberField, { label: tGenerated('m_01c1568339229c'), value: selectedElement.width, onChange: (width) => onPatchElement({ width }) }), _jsx(NumberField, { label: tGenerated('m_1987fe754d02dc'), value: selectedElement.height, onChange: (height) => onPatchElement({ height }) }), _jsx(NumberField, { label: tGenerated('m_02bf057e3c5db8'), value: selectedElement.rotation ?? 0, onChange: (rotation) => onPatchElement({ rotation }) }), _jsx(NumberField, { label: tGenerated('m_1c646d8dbbfc57'), value: selectedElement.opacity ?? 1, step: 0.05, onChange: (opacity) => onPatchElement({ opacity }) })] }), _jsx(GeneratedValue, { value: 'color' in selectedElement ? (_jsx(ColorField, { label: tGenerated('m_1d84613a5c9677'), value: selectedElement.color ?? hexColor('fg'), onChange: (color) => onPatchElement({ color }) })) : null }), _jsx(GeneratedValue, { value: 'fill' in selectedElement ? (_jsx(ColorField, { label: tGenerated('m_1c8876b26b038d'), value: selectedElement.fill ?? hexColor('surface'), onChange: (fill) => onPatchElement({ fill }) })) : null }), _jsx(GeneratedValue, { value: 'stroke' in selectedElement ? (_jsx(ColorField, { label: tGenerated('m_1283da4b0e20fd'), value: selectedElement.stroke ?? hexColor('border-strong'), onChange: (stroke) => onPatchElement({ stroke }) })) : null }), _jsx(GeneratedValue, { value: 'fontSize' in selectedElement ? (_jsxs(_Fragment, { children: [_jsx(NumberField, { label: tGenerated('m_148c58241fd1d4'), value: selectedElement.fontSize ?? 12, onChange: (fontSize) => onPatchElement({ fontSize }) }), _jsxs("div", { className: "grid grid-cols-3 gap-1", children: [_jsx(Button, { type: "button", variant: selectedElement.align === 'left' ? 'secondary' : 'outline', size: "sm", onClick: () => onPatchElement({ align: 'left' }), children: _jsx(AlignLeft, { size: 14 }) }), _jsx(Button, { type: "button", variant: selectedElement.align === 'center' ? 'secondary' : 'outline', size: "sm", onClick: () => onPatchElement({ align: 'center' }), children: _jsx(AlignCenter, { size: 14 }) }), _jsx(Button, { type: "button", variant: selectedElement.align === 'right' ? 'secondary' : 'outline', size: "sm", onClick: () => onPatchElement({ align: 'right' }), children: _jsx(AlignRight, { size: 14 }) })] })] })) : null }), _jsx(LayerToggle, { checked: !selectedElement.locked, label: tGeneratedValue(selectedElement.locked ? tGenerated('m_0e259fa0babc2d') : tGenerated('m_16508b5ee9cd07')), onChange: (unlocked) => onPatchElement({ locked: !unlocked }), icon: selectedElement.locked ? _jsx(Lock, { size: 14 }) : _jsx(Unlock, { size: 14 }) })] }));
}
export function PrintPanel({ artboard, onPatchArtboard, }) {
    const tGenerated = useGeneratedTranslations();
    const profile = artboard.printProfile ?? {
        provider: 'browser-pdf',
        media: artboard.format === 'cr80-front' || artboard.format === 'cr80-back' ? 'cr80' : 'letter',
        duplex: artboard.format === 'cr80-front' || artboard.format === 'cr80-back',
        edgeToEdge: true,
        orientation: 'landscape',
    };
    return (_jsxs("div", { className: "space-y-4", children: [_jsx(RailLabel, { label: tGenerated('m_06fbf5dca19848'), icon: _jsx(Printer, { size: 14 }) }), _jsx(Field, { label: tGenerated('m_1c4d663fc7d77f'), children: _jsx(Select, { value: profile.provider, onChange: (e) => onPatchArtboard({
                        printProfile: { ...profile, provider: e.currentTarget.value },
                    }), children: PRINT_PROVIDERS.map((provider) => (_jsx("option", { value: provider.id, children: provider.label }, provider.id))) }) }), _jsx(Field, { label: tGenerated('m_09db70b9dfd3ed'), children: _jsxs(Select, { value: profile.media, onChange: (e) => onPatchArtboard({
                        printProfile: { ...profile, media: e.currentTarget.value },
                    }), children: [_jsx("option", { value: "letter", children: 'Letter' }), _jsx("option", { value: "cr80", children: 'CR80 card' }), _jsx("option", { value: "custom", children: 'Custom' })] }) }), _jsx(LayerToggle, { checked: profile.duplex === true, label: tGenerated('m_09cdda4df8e928'), onChange: (duplex) => onPatchArtboard({ printProfile: { ...profile, duplex } }) }), _jsx(LayerToggle, { checked: profile.edgeToEdge !== false, label: tGenerated('m_10f5cd6acb899b'), onChange: (edgeToEdge) => onPatchArtboard({ printProfile: { ...profile, edgeToEdge } }) }), _jsx("div", { className: "space-y-2", children: _jsx(GeneratedValue, { value: PRINT_PROVIDERS.map((provider) => (_jsxs("div", { className: cn('rounded-md border p-2 text-xs leading-5', provider.id === profile.provider
                            ? 'border-primary bg-primary-subtle text-primary'
                            : 'border-border bg-surface text-fg-muted'), children: [_jsx("div", { className: "font-semibold", children: _jsx(GeneratedValue, { value: provider.label }) }), _jsx("div", { children: _jsx(GeneratedValue, { value: provider.notes }) }), _jsx(GeneratedValue, { value: provider.requiresLocalBridge ? (_jsx("div", { className: "mt-1 font-medium", children: _jsx(GeneratedText, { id: "m_1618e6c010fa0a" }) })) : null })] }, provider.id))) }) })] }));
}
// --- Small rail atoms ----------------------------------------------------------
export function RailTabButton({ active, label, icon, onClick, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    return (_jsx("button", { type: "button", onClick: onClick, title: tGeneratedValue(label), className: cn('grid h-9 place-items-center rounded-md border text-xs', active
            ? 'border-primary bg-primary-subtle text-primary'
            : 'border-border bg-surface text-fg-muted hover:bg-surface-subtle'), children: _jsx(GeneratedValue, { value: icon }) }));
}
export function RailLabel({ icon, label }) {
    return (_jsxs("div", { className: "flex items-center gap-1.5 text-[11px] font-semibold tracking-wider text-fg-muted uppercase-subtle", children: [_jsx(GeneratedValue, { value: icon }), _jsx(GeneratedValue, { value: label })] }));
}
export function Field({ label, children }) {
    return (_jsxs("label", { className: "block space-y-1.5", children: [_jsx("span", { className: "text-xs font-medium text-fg-muted-subtle", children: _jsx(GeneratedValue, { value: label }) }), _jsx(GeneratedValue, { value: children })] }));
}
function ElementButton({ label, icon, onClick, }) {
    return (_jsxs("button", { type: "button", onClick: onClick, className: "flex w-full items-center gap-2 rounded-md border border-border bg-surface px-3 py-2 text-left text-sm font-medium text-fg-muted transition-colors hover:bg-surface-subtle", children: [_jsx(GeneratedValue, { value: icon }), _jsx(GeneratedValue, { value: label })] }));
}
export function LayerToggle({ checked, label, onChange, icon, }) {
    return (_jsxs("label", { className: "flex cursor-pointer items-center justify-between rounded-md border border-border bg-surface px-2.5 py-2 text-sm", children: [_jsxs("span", { className: "flex min-w-0 items-center gap-2 text-fg-muted", children: [_jsx(GeneratedValue, { value: icon }), _jsx("span", { className: "truncate", children: _jsx(GeneratedValue, { value: label }) })] }), _jsx("input", { type: "checkbox", checked: checked, onChange: (e) => onChange(e.currentTarget.checked), className: "h-4 w-4 accent-teal-700" })] }));
}
function ColorField({ label, value, onChange, }) {
    return (_jsxs("label", { className: "flex items-center gap-2", children: [_jsx("span", { className: "w-20 text-xs font-medium text-fg-muted-subtle", children: _jsx(GeneratedValue, { value: label }) }), _jsx("input", { type: "color", value: value, onChange: (e) => onChange(e.currentTarget.value), className: "h-8 w-10 rounded border border-border bg-surface p-0.5" }), _jsx(Input, { value: value, maxLength: 11, onChange: (e) => onChange(e.currentTarget.value), className: "h-8" })] }));
}
function NumberField({ label, value, step = 0.01, onChange, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    return (_jsx(Field, { label: tGeneratedValue(label), children: _jsx(Input, { type: "number", step: step, value: Number.isFinite(value) ? value : 0, onChange: (e) => onChange(Number(e.currentTarget.value)) }) }));
}
function iconForElement(element) {
    if (element.kind === 'text')
        return _jsx(Type, { size: 14 });
    if (element.kind === 'field')
        return _jsx(BadgeCheck, { size: 14 });
    if (element.kind === 'image')
        return _jsx(ImageIcon, { size: 14 });
    if (element.kind === 'qr')
        return _jsx(QrCode, { size: 14 });
    return _jsx(RectangleHorizontal, { size: 14 });
}
// --- Element construction --------------------------------------------------------
export function newElement(kind, existing, defaultField) {
    const id = uniqueElementId(kind, existing);
    const base = {
        id,
        name: titleCase(kind),
        x: 0.55,
        y: 0.55,
        width: kind === 'qr' || kind === 'seal' ? 0.8 : 2.2,
        height: kind === 'qr' || kind === 'seal' ? 0.8 : 0.45,
        visible: true,
        opacity: 1,
    };
    if (kind === 'text') {
        return {
            ...base,
            kind,
            text: 'New text',
            fontFamily: "'Archivo', Arial, sans-serif",
            fontSize: 16,
            fontWeight: '700',
            color: hexColor('fg'),
            align: 'left',
        };
    }
    if (kind === 'field') {
        return {
            ...base,
            kind,
            field: defaultField,
            fontFamily: "'Archivo', Arial, sans-serif",
            fontSize: 16,
            fontWeight: '700',
            color: hexColor('fg'),
            align: 'left',
            transform: 'none',
        };
    }
    if (kind === 'image')
        return { ...base, kind, source: 'tenant.logo', fit: 'contain', radius: 0.04 };
    if (kind === 'qr')
        return { ...base, kind, field: 'verify.qr', background: hexColor('surface'), foreground: hexColor('fg') };
    if (kind === 'seal')
        return { ...base, kind, fill: hexColor('warning'), stroke: hexColor('primary'), text: '' };
    if (kind === 'ellipse')
        return { ...base, kind, fill: hexColor('surface'), stroke: hexColor('primary'), strokeWidth: 0.01 };
    if (kind === 'line')
        return {
            ...base,
            kind,
            height: 0.01,
            fill: 'transparent',
            stroke: hexColor('fg'),
            strokeWidth: 0.01,
        };
    return {
        ...base,
        kind: 'rect',
        fill: hexColor('surface'),
        stroke: hexColor('primary'),
        strokeWidth: 0.01,
        radius: 0.03,
    };
}
/**
 * Construct an element from the package-level field catalogue. This keeps the
 * document editor API and the lower-level production artboard API aligned.
 */
export function createDesignElement(kind, existing, catalog, theme) {
    const defaultField = catalog.fields[0]?.key ?? 'record.name';
    const defaultImage = catalog.fields.find((field) => field.semanticType === 'image')?.key;
    const defaultQr = catalog.fields.find((field) => field.semanticType === 'qr')?.key ?? defaultField;
    const element = newElement(kind, existing, kind === 'qr' ? defaultQr : defaultField);
    if (element.kind === 'text') {
        return { ...element, fontFamily: theme.typeface ?? element.fontFamily, color: theme.ink ?? element.color };
    }
    if (element.kind === 'field') {
        return { ...element, fontFamily: theme.typeface ?? element.fontFamily, color: theme.ink ?? element.color };
    }
    if (element.kind === 'image')
        return { ...element, source: defaultImage ? 'field' : element.source, field: defaultImage };
    if (element.kind === 'qr')
        return { ...element, field: defaultQr, background: theme.paper, foreground: theme.ink };
    if (element.kind === 'seal')
        return { ...element, fill: theme.accent, stroke: theme.primary };
    if (element.kind === 'ellipse' || element.kind === 'rect')
        return { ...element, fill: theme.paper, stroke: theme.primary };
    if (element.kind === 'line')
        return { ...element, stroke: theme.ink };
    return element;
}
/** Compatibility name for applications that used the document-level editor API. */
export const uniqueDesignElementId = uniqueElementId;
export function uniqueElementId(base, elements) {
    const used = new Set(elements.map((element) => element.id));
    const clean = slugId(base, 'element').slice(0, DESIGN_DOCUMENT_LIMITS.idLength);
    let id = clean;
    let i = 2;
    while (used.has(id)) {
        const suffix = `-${i}`;
        id = `${clean.slice(0, DESIGN_DOCUMENT_LIMITS.idLength - suffix.length)}${suffix}`;
        i += 1;
    }
    return id;
}
function titleCase(value) {
    return value.replace(/(^|-)([a-z])/g, (_, space, letter) => `${space ? ' ' : ''}${letter.toUpperCase()}`);
}
function roundInches(value) {
    return Math.round(value * 1000) / 1000;
}
//# sourceMappingURL=editor.js.map