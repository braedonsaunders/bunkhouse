import type { ArtboardFormat, DesignDocument } from './schema.js';
export declare const DESIGN_STUDIO_DPI = 96;
export declare const LETTER_LANDSCAPE: {
    width: number;
    height: number;
};
export declare const LETTER_PORTRAIT: {
    width: number;
    height: number;
};
export declare const CR80: {
    width: number;
    height: number;
};
export declare const LABEL_4X6: {
    width: number;
    height: number;
};
export type DesignStudioTheme = {
    primary: string;
    accent: string;
    paper: string;
    ink?: string;
    muted?: string;
    typeface?: 'classic' | 'modern' | 'technical' | (string & {});
};
export declare function createDesignDocument(input: {
    name: string;
    kind?: DesignDocument['kind'];
    format?: ArtboardFormat;
    theme?: Partial<DesignStudioTheme>;
}): DesignDocument;
export declare const DEFAULT_DESIGN_STUDIO_THEME: DesignStudioTheme;
export declare function createCertificateDesignDocument(theme?: DesignStudioTheme): DesignDocument;
export declare function createWalletDesignDocument(theme?: DesignStudioTheme): DesignDocument;
export declare function createEquipmentLabelDesignDocument(): DesignDocument;
export declare function createPersonBadgeDesignDocument(theme?: DesignStudioTheme): DesignDocument;
//# sourceMappingURL=defaults.d.ts.map