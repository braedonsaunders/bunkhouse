import type { ReactNode } from "react";
export declare function useGeneratedTranslations(): (key: string, values?: Record<string, unknown>) => string;
export declare function useGeneratedValueTranslations(): <Value>(value: Value) => Value;
export declare function GeneratedText({ id, values }: {
    id: string;
    values?: Record<string, unknown>;
}): import("react").JSX.Element;
export declare function GeneratedValue({ value }: {
    value: ReactNode;
}): import("react").JSX.Element;
//# sourceMappingURL=generated-copy.d.ts.map