import type { DesignDataField, DesignDocument, DesignDocumentData } from './schema.js';
export declare function renderDesignDocumentHtml(document: DesignDocument, data: DesignDocumentData, options?: {
    artboardId?: string | null;
    title?: string;
}): string;
/**
 * N documents printed back-to-back as one HTML document — every artboard of
 * every page rendered against that page's own data. All artboards are assumed
 * to share the first artboard's physical size (uniform label runs).
 */
export declare function renderDesignDocumentsHtml(pages: {
    document: DesignDocument;
    data: DesignDocumentData;
}[], options?: {
    title?: string;
}): string;
export declare function valueForField(field: DesignDataField, data: DesignDocumentData): string;
//# sourceMappingURL=html.d.ts.map