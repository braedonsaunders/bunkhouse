# @appkit/design-studio

Bounded print-design document schema, renderer, and interactive Fabric editor.

## Install

```bash
pnpm add @appkit/design-studio
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
