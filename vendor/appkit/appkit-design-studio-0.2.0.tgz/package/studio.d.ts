import { type ReactNode } from 'react';
import type { DesignData, DesignDocument, DesignFieldCatalog } from './schema.js';
import { type DesignStudioTheme } from './defaults.js';
export type DesignStudioEditorLabels = {
    inspector: string;
    insert: string;
    layers: string;
    print: string;
    artboards: string;
};
export type DesignStudioEditorProps = {
    document: DesignDocument;
    onChange: (document: DesignDocument) => void;
    catalog: DesignFieldCatalog;
    data?: DesignData;
    theme?: Partial<DesignStudioTheme>;
    locale?: string;
    labels?: Partial<DesignStudioEditorLabels>;
    actions?: ReactNode;
    className?: string;
};
/**
 * Controlled document studio composed from the production Fabric artboard,
 * rail, layer, inspector, and print implementations. Applications retain
 * persistence ownership and provide only a field catalogue and sample data.
 */
export declare function DesignStudioEditor({ document, onChange, catalog, data, theme: themeOverrides, labels: labelOverrides, actions, className, }: DesignStudioEditorProps): import("react").JSX.Element | null;
//# sourceMappingURL=studio.d.ts.map