import type { DesignDocument, PrintProvider, PrintProfile } from './schema.js';
export type DirectPrintProvider = Exclude<PrintProvider, 'browser-pdf'>;
export declare const PRINT_PROVIDERS: {
    id: PrintProvider;
    label: string;
    requiresLocalBridge: boolean;
    notes: string;
}[];
export declare function defaultPrintProfile(media: PrintProfile['media']): PrintProfile;
/** Resolve the direct-print provider selected by a design, if it has one. */
export declare function directPrintProvider(document: DesignDocument): DirectPrintProvider | null;
//# sourceMappingURL=print.d.ts.map