# @appkit/editor

Optional TipTap rich-text authoring for AppKit forms and documents.

## Install

```bash
pnpm add @appkit/editor
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
