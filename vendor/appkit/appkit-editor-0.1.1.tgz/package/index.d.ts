export { RichTextEditor } from './rich-text-editor.js';
export type { RichTextEditorProps } from './rich-text-editor.js';
//# sourceMappingURL=index.d.ts.map