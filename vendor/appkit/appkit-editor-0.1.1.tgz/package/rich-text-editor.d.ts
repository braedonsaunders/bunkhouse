export type RichTextEditorProps = {
    /** Controlled HTML content. */
    value?: string;
    /** Initial HTML content. */
    defaultValue?: string;
    /** Called on every edit with the latest HTML. */
    onChange?: (html: string) => void;
    /** Optional hidden input name so the editor works inside a <form>. */
    name?: string;
    /** Placeholder text shown when empty. */
    placeholder?: string;
    /** Disabled / read-only flag. */
    disabled?: boolean;
    /** Extra classes on the outer wrapper. */
    className?: string;
    /** Min editor height (default '160px'). */
    minHeight?: string;
    /** Canonical application policy for links inserted from the toolbar. */
    normalizeLink: (value: string) => string | null;
    /** Called when the entered link is rejected by normalizeLink. */
    onInvalidLink?: () => void;
};
export declare function RichTextEditor({ value, defaultValue, onChange, name, placeholder, disabled, className, minHeight, normalizeLink, onInvalidLink, }: RichTextEditorProps): import("react").JSX.Element;
//# sourceMappingURL=rich-text-editor.d.ts.map