export declare const DOC_FONT = "Georgia, \"Times New Roman\", serif";
export declare const DOC_FONT_SIZE_PX = 14;
export declare const DOC_LINE_HEIGHT = 1.6;
export declare const DOC_PAGE_MARGIN_PX = 96;
export declare function documentBodyCss(sel?: string): string;
//# sourceMappingURL=doc-style.d.ts.map