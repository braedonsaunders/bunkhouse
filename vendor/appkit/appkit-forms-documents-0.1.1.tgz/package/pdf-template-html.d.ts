import { type FormSchemaV1 } from '@appkit/forms-core';
import { type AppLocale } from '@appkit/i18n';
export type GeneratedFormPdfTemplate = {
    sourceHtml: string;
    headerHtml: string;
    footerHtml: string;
};
/**
 * Build the full generated document for a form template. Sections become
 * headed blocks of label/value rows; repeating sections and table fields
 * become collection tables; photo/file fields become photo grids; signature
 * and sketch fields embed their images. Uses only keys the form flow adapter's
 * loadValues() provides.
 */
export declare function generateFormPdfTemplate(schema: FormSchemaV1, formName: string, locale?: AppLocale): GeneratedFormPdfTemplate;
//# sourceMappingURL=pdf-template-html.d.ts.map