# @appkit/forms-documents

Optional form document styles and generated PDF templates over the shared companion-field contract.

## Install

```bash
pnpm add @appkit/forms-documents
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
