import * as React from 'react';
import { type SidebarNavGroup } from './sidebar-nav.js';
import { type LinkRender } from './link-context.js';
export declare function TopNav({ groups, pathname, linkRender, moreLabel, ariaLabel, className, }: {
    groups: SidebarNavGroup[];
    pathname: string;
    linkRender?: LinkRender;
    moreLabel?: string;
    ariaLabel?: string;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=top-nav.d.ts.map