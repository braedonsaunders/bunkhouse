/**
 * Schedule health: one pass over the plan that answers every question the
 * toolbar, quick filters and status badges ask.
 *
 * The probes are deliberately separate sets rather than a single "is this task
 * bad" flag, so a surface can explain WHY a row needs attention — missing
 * dates, a blown deadline, a violated constraint, an actual-date
 * contradiction, broken logic, or an overbooked resource.
 */
import { sortTasksByOrder } from './hierarchy.js';
import type { ScheduleCalendar, ScheduleDependency, ScheduleFilters, ScheduleInsightOptions, ScheduleInsights, ScheduleQuickFilter, ScheduleTask, ScheduleTaskVariance } from './types.js';
/** The working days a task actually occupies, on its effective calendar. */
export declare function getTaskWorkingDates(task: ScheduleTask, calendar?: ScheduleCalendar | null): Date[];
/** Drift against the baseline, in days. Positive finish variance = late. */
export declare function getTaskVariance(task: ScheduleTask): ScheduleTaskVariance;
/** Accept 0–1 or 0–100 and clamp; hosts differ on which they store. */
export declare function normalizeScheduleProgress(value: number | null | undefined): number;
export declare function isTaskOverdue(task: ScheduleTask, referenceDate?: Date): boolean;
/** Is the task live inside the next `lookaheadDays` window? */
export declare function isTaskInLookahead(task: ScheduleTask, lookaheadDays: number, referenceDate?: Date): boolean;
export declare function buildScheduleInsights(tasks: ScheduleTask[], dependencies: ScheduleDependency[], referenceDate?: Date, options?: ScheduleInsightOptions): ScheduleInsights;
/**
 * Narrow to a quick-filter set, keeping every matching row's ancestors so the
 * outline stays navigable instead of collapsing into orphaned children.
 */
export declare function applyQuickFilter(tasks: ScheduleTask[], quickFilter: ScheduleQuickFilter, insights: ScheduleInsights): ScheduleTask[];
export declare function filterTasks(tasks: ScheduleTask[], filters: ScheduleFilters): ScheduleTask[];
export { sortTasksByOrder };
//# sourceMappingURL=insights.d.ts.map