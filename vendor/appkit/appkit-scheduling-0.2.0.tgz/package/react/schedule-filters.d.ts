import type { SchedulePhase, ScheduleFilters } from '../types.js';
export interface ScheduleFiltersBarProps {
    filters: ScheduleFilters;
    onChange: (f: ScheduleFilters) => void;
    phases: SchedulePhase[];
    assignees: string[];
    className?: string;
}
export declare function ScheduleFiltersBar({ filters, onChange, phases, assignees, className, }: ScheduleFiltersBarProps): import("react").JSX.Element;
//# sourceMappingURL=schedule-filters.d.ts.map