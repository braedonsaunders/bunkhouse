import type { ScheduleDependency, ScheduleTask } from '../types.js';
export interface GanttDependenciesProps {
    dependencies: ScheduleDependency[];
    tasks: ScheduleTask[];
    /** Vertical centre (px) of each task row, keyed by task id. */
    taskRowCenters: Map<string, number>;
    timelineStartMs: number;
    timelineEndMs: number;
    timelineWidth: number;
    svgHeight: number;
    criticalTaskIds: Set<string>;
    violatingDependencyIds: Set<string>;
    showCriticalPath: boolean;
}
export declare function GanttDependencies({ dependencies, tasks, taskRowCenters, timelineStartMs, timelineEndMs, timelineWidth, svgHeight, criticalTaskIds, violatingDependencyIds, showCriticalPath, }: GanttDependenciesProps): import("react").JSX.Element | null;
//# sourceMappingURL=gantt-dependencies.d.ts.map