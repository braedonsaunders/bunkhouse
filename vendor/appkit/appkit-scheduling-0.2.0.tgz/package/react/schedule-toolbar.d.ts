import type { ScheduleBaseline, ScheduleInsights, ScheduleQuickFilter, ZoomLevel } from '../types.js';
export type ScheduleView = 'gantt' | 'list' | 'board';
export interface ScheduleToolbarProps {
    view: ScheduleView;
    onViewChange: (v: ScheduleView) => void;
    zoomLevel: ZoomLevel;
    onZoomChange: (z: ZoomLevel) => void;
    onZoomIn: () => void;
    onZoomOut: () => void;
    canZoomIn: boolean;
    canZoomOut: boolean;
    onScrollPrev: () => void;
    onScrollToday: () => void;
    onScrollNext: () => void;
    onAddTask: () => void;
    onToggleFilters: () => void;
    filtersActive: boolean;
    insights: ScheduleInsights;
    quickFilter: ScheduleQuickFilter;
    onQuickFilterChange: (filter: ScheduleQuickFilter) => void;
    showCriticalPath: boolean;
    onToggleCriticalPath: () => void;
    showBaseline: boolean;
    onToggleBaseline: () => void;
    hasBaseline: boolean;
    onSaveBaseline: () => void;
    onClearBaseline: () => void;
    baselines: ScheduleBaseline[];
    activeBaselineId: string;
    onActiveBaselineChange: (baselineId: string) => void;
    onOpenManage: () => void;
    calendarCount: number;
    resourceCount: number;
    dateStart: string | null;
    dateEnd: string | null;
    /** Optional host capabilities — the menu entry is hidden when omitted. */
    onOpenImport?: () => void;
    onExportPdf?: () => void;
    onOpenLeveling?: () => void;
}
export declare function ScheduleToolbar({ view, onViewChange, zoomLevel, onZoomChange, onZoomIn, onZoomOut, canZoomIn, canZoomOut, onScrollPrev, onScrollToday, onScrollNext, onAddTask, onToggleFilters, filtersActive, insights, quickFilter, onQuickFilterChange, showCriticalPath, onToggleCriticalPath, showBaseline, onToggleBaseline, hasBaseline, onSaveBaseline, onClearBaseline, baselines, activeBaselineId, onActiveBaselineChange, onOpenManage, calendarCount, resourceCount, dateStart, dateEnd, onOpenImport, onExportPdf, onOpenLeveling, }: ScheduleToolbarProps): import("react").JSX.Element;
//# sourceMappingURL=schedule-toolbar.d.ts.map