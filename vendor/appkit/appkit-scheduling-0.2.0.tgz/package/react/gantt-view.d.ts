import { phaseColor as phaseColorAt } from '../palette.js';
import type { ScheduleCalendar, ScheduleDependency, ScheduleInsights, SchedulePhase, ScheduleTask, ScheduleTaskPatchInput, ZoomLevel } from '../types.js';
export interface GanttViewProps {
    tasks: ScheduleTask[];
    dependencies: ScheduleDependency[];
    insights: ScheduleInsights;
    phases: SchedulePhase[];
    calendar: ScheduleCalendar | null;
    zoomLevel: ZoomLevel;
    /** Days the visible window is shifted from the plan's start. */
    scrollOffset: number;
    dateWorkStart: string | null;
    dateWorkEnd: string | null;
    criticalTaskIds: Set<string>;
    showCriticalPath: boolean;
    showBaseline: boolean;
    /** Return `false` to reject an edit and roll the bar back. */
    onUpdateTask: (taskId: string, patch: ScheduleTaskPatchInput) => void | boolean | Promise<boolean | void>;
    onReorderTask: (taskId: string, targetTaskId: string, placement: 'before' | 'after' | 'inside', depth?: number) => void | boolean | Promise<boolean | void>;
    onClickTask: (task: ScheduleTask) => void;
    onContextMenu?: (e: React.MouseEvent, task: ScheduleTask) => void;
}
export declare function GanttView({ tasks, dependencies, insights, phases, calendar, zoomLevel, scrollOffset, dateWorkStart, dateWorkEnd, criticalTaskIds, showCriticalPath, showBaseline, onUpdateTask, onReorderTask, onClickTask, onContextMenu, }: GanttViewProps): import("react").JSX.Element;
export { phaseColorAt as ganttPhaseColor };
//# sourceMappingURL=gantt-view.d.ts.map