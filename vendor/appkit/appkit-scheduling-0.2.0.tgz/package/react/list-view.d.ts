import type { SchedulePhase, ScheduleInsights, ScheduleResource, ScheduleTask, ScheduleTaskAssignment, ScheduleTaskPatchInput } from '../types.js';
export interface ListViewProps {
    tasks: ScheduleTask[];
    insights: ScheduleInsights;
    phases: SchedulePhase[];
    resources: ScheduleResource[];
    taskAssignmentsByTaskId: Map<string, ScheduleTaskAssignment[]>;
    onUpdateTask: (taskId: string, patch: ScheduleTaskPatchInput) => void | boolean | Promise<boolean | void>;
    onBatchUpdateTasks: (updates: Array<{
        id: string;
    } & ScheduleTaskPatchInput>) => void | boolean | Promise<boolean | void>;
    onDeleteTask: (taskId: string) => void | boolean | Promise<boolean | void>;
    onReorderTask: (taskId: string, targetTaskId: string, placement: 'before' | 'after' | 'inside', depth?: number) => void | boolean | Promise<boolean | void>;
    onClickTask: (task: ScheduleTask) => void;
    onContextMenu?: (e: React.MouseEvent, task: ScheduleTask) => void;
}
export declare function ListView({ tasks, insights, phases, resources, taskAssignmentsByTaskId, onUpdateTask, onBatchUpdateTasks, onDeleteTask, onReorderTask, onClickTask, onContextMenu, }: ListViewProps): import("react").JSX.Element;
//# sourceMappingURL=list-view.d.ts.map