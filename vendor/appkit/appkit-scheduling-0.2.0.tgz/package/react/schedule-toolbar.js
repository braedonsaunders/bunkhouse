'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * The schedule toolbar: view switch, timeline controls, health filter,
 * baselines, and the overflow actions.
 *
 * Everything lives in popover menus rather than a row of buttons, because a
 * schedule toolbar with every control exposed wraps into three lines on a
 * laptop and pushes the plan off screen. The health filter carries live counts
 * so the user can see WHERE the trouble is before opening anything.
 */
import { createContext, useContext, useState } from 'react';
import { Calendar, Check, ChevronDown, ChevronLeft, ChevronRight, Download, Eye, EyeOff, Filter, GitBranch, LayoutGrid, List, Minus, MoreHorizontal, Plus, Save, Scale, Settings2, SlidersHorizontal, Trash2, Upload, } from 'lucide-react';
import { Badge, Button, Popover, cn } from '@appkit/ui';
import { parseDate } from '../dates.js';
import { useScheduleFormatters, useSchedulingLabels } from './context.js';
const QUICK_FILTERS = [
    'all',
    'lookahead_14',
    'critical',
    'overdue',
    'variance',
    'issues',
];
const ZOOM_LEVELS = ['day', 'week', 'month'];
export function ScheduleToolbar({ view, onViewChange, zoomLevel, onZoomChange, onZoomIn, onZoomOut, canZoomIn, canZoomOut, onScrollPrev, onScrollToday, onScrollNext, onAddTask, onToggleFilters, filtersActive, insights, quickFilter, onQuickFilterChange, showCriticalPath, onToggleCriticalPath, showBaseline, onToggleBaseline, hasBaseline, onSaveBaseline, onClearBaseline, baselines, activeBaselineId, onActiveBaselineChange, onOpenManage, calendarCount, resourceCount, dateStart, dateEnd, onOpenImport, onExportPdf, onOpenLeveling, }) {
    const labels = useSchedulingLabels();
    const formatters = useScheduleFormatters();
    const parsedStart = parseDate(dateStart);
    const parsedEnd = parseDate(dateEnd);
    const activeBaseline = baselines.find((baseline) => baseline.id === activeBaselineId) ??
        baselines.find((baseline) => baseline.isPrimary) ??
        baselines[0] ??
        null;
    const formatCompactDate = (date) => (date ? formatters.shortDate(date) : labels.menu.tbd);
    const compactDateRange = `${formatCompactDate(parsedStart)}–${formatCompactDate(parsedEnd)}`;
    const healthCounts = {
        all: insights.totalTasks,
        lookahead_14: insights.lookahead14TaskIds.size,
        lookahead_28: insights.lookahead28TaskIds.size,
        critical: insights.criticalTaskIds.size,
        overdue: insights.overdueTaskIds.size,
        variance: insights.behindBaselineTaskIds.size,
        issues: insights.attentionTaskIds.size,
    };
    const viewIcon = { gantt: Calendar, list: List, board: LayoutGrid };
    return (_jsx("div", { className: "rounded-t-lg rounded-b-none border border-border bg-surface shadow-sm", "data-testid": "schedule-toolbar", children: _jsxs("div", { className: "flex w-full min-w-0 flex-wrap items-center gap-1.5 px-2 py-1.5", children: [_jsx(ScheduleMenu, { label: labels.view[view], icon: viewIcon[view], testId: "schedule-view-menu", title: labels.menu.viewTitle, children: ['gantt', 'list', 'board'].map((value) => (_jsx(ScheduleMenuItem, { icon: viewIcon[value], label: labels.view[value], selected: view === value, onClick: () => onViewChange(value), testId: `schedule-view-${value}` }, value))) }), view === 'gantt' ? (_jsxs(ScheduleMenu, { label: labels.zoom[zoomLevel], icon: SlidersHorizontal, testId: "schedule-timeline-menu", title: labels.menu.timelineTitle, children: [_jsx(MenuSectionLabel, { children: labels.menu.moveTimeline }), _jsxs("div", { className: "grid grid-cols-3 gap-1", children: [_jsx(ScheduleMenuIconButton, { icon: ChevronLeft, label: labels.menu.earlier, onClick: onScrollPrev, testId: "schedule-scroll-prev" }), _jsx(ScheduleMenuIconButton, { icon: Calendar, label: labels.toolbar.today, onClick: onScrollToday, testId: "schedule-scroll-today" }), _jsx(ScheduleMenuIconButton, { icon: ChevronRight, label: labels.menu.later, onClick: onScrollNext, testId: "schedule-scroll-next" })] }), _jsx(MenuSeparator, {}), _jsx(MenuSectionLabel, { children: labels.menu.zoom }), _jsxs("div", { className: "grid grid-cols-[28px_1fr_28px] gap-1", children: [_jsx(ScheduleMenuIconButton, { icon: Minus, label: labels.toolbar.zoomOut, onClick: onZoomOut, disabled: !canZoomOut, testId: "schedule-zoom-out" }), _jsx("div", { className: "grid grid-cols-3 gap-1", children: ZOOM_LEVELS.map((level) => (_jsx(ScheduleMenuPill, { label: labels.zoom[level], selected: zoomLevel === level, onClick: () => onZoomChange(level), testId: `schedule-zoom-${level}` }, level))) }), _jsx(ScheduleMenuIconButton, { icon: Plus, label: labels.toolbar.zoomIn, onClick: onZoomIn, disabled: !canZoomIn, testId: "schedule-zoom-in" })] }), _jsx(MenuSeparator, {}), _jsx(ScheduleMenuItem, { icon: GitBranch, label: labels.toolbar.criticalPath, selected: showCriticalPath, onClick: onToggleCriticalPath, testId: "schedule-toggle-critical" })] })) : null, _jsx(ScheduleMenu, { label: `${labels.quickFilterShort[quickFilter]} ${healthCounts[quickFilter]}`, icon: Filter, active: quickFilter !== 'all', testId: "schedule-health-menu", title: labels.menu.healthTitle, children: QUICK_FILTERS.map((value) => (_jsx(ScheduleMenuItem, { icon: Filter, label: labels.quickFilter[value], detail: labels.format.taskCount(healthCounts[value]), selected: quickFilter === value, 
                        // Baseline slip is meaningless without a baseline to slip from.
                        disabled: value === 'variance' && !hasBaseline, onClick: () => onQuickFilterChange(value), testId: `schedule-health-${value}` }, value))) }), _jsxs("div", { className: "hidden min-w-0 items-center gap-1 rounded-md bg-bg-subtle p-0.5 md:flex", children: [_jsxs(Badge, { variant: insights.deadlineMissTaskIds.size > 0 ? 'destructive' : 'secondary', className: "h-6 justify-center px-1.5 py-0 text-[10px]", title: `${insights.deadlineMissTaskIds.size} ${labels.menu.deadlineMisses}`, children: ["D ", insights.deadlineMissTaskIds.size] }), _jsxs(Badge, { variant: insights.resourceConflictTaskIds.size > 0 ? 'warning' : 'secondary', className: "h-6 justify-center px-1.5 py-0 text-[10px]", title: `${insights.resourceConflictTaskIds.size} ${labels.menu.resourceConflicts}`, children: ["R ", insights.resourceConflictTaskIds.size] }), _jsxs(Badge, { variant: insights.constraintViolationTaskIds.size > 0 ? 'warning' : 'secondary', className: "h-6 justify-center px-1.5 py-0 text-[10px]", title: `${insights.constraintViolationTaskIds.size} ${labels.menu.constraintViolations}`, children: ["C ", insights.constraintViolationTaskIds.size] }), _jsxs("div", { className: "min-w-0 rounded-md bg-surface px-2 py-1 text-[10px] leading-tight font-medium text-fg-muted", children: [_jsx("span", { className: "block truncate", children: compactDateRange }), _jsxs("span", { className: "block truncate", title: labels.menu.calendarsResources, children: [calendarCount, "C / ", resourceCount, "R"] })] })] }), _jsx("div", { className: "min-w-0 flex-1" }), _jsxs(Button, { variant: "secondary", size: "sm", title: labels.toolbar.addTask, "aria-label": labels.toolbar.addTask, onClick: onAddTask, "data-testid": "schedule-add-task", className: "h-7 shrink-0 rounded-md px-2 text-[11px]", children: [_jsx(Plus, { className: "h-3.5 w-3.5 shrink-0" }), _jsx("span", { className: "truncate", children: labels.columns.name })] }), _jsxs(ScheduleMenu, { label: labels.toolbar.baseline, icon: Save, active: showBaseline, align: "end", testId: "schedule-baseline-menu", title: `${labels.menu.baselineTitle}: ${activeBaseline?.name ?? labels.common.none}`, children: [_jsx(MenuSectionLabel, { children: labels.menu.activeBaseline }), baselines.length === 0 ? (_jsx("div", { className: "rounded-md px-2 py-2 text-[11px] text-fg-subtle", children: labels.menu.noBaselines })) : (baselines.map((baseline) => (_jsx(ScheduleMenuItem, { icon: Save, label: baseline.name, detail: baseline.isPrimary ? labels.menu.primary : labels.menu.snapshot, selected: baseline.id === activeBaseline?.id, onClick: () => onActiveBaselineChange(baseline.id) }, baseline.id)))), _jsx(MenuSeparator, {}), _jsx(ScheduleMenuItem, { icon: Save, label: labels.menu.saveBaseline, onClick: onSaveBaseline, testId: "schedule-save-baseline" }), _jsx(ScheduleMenuItem, { icon: showBaseline ? EyeOff : Eye, label: showBaseline ? labels.menu.hideBaseline : labels.menu.showBaseline, disabled: !hasBaseline, selected: showBaseline, onClick: onToggleBaseline, testId: "schedule-toggle-baseline" }), _jsx(ScheduleMenuItem, { icon: Trash2, label: labels.menu.clearBaseline, disabled: !hasBaseline, onClick: onClearBaseline, testId: "schedule-clear-baseline" }), onExportPdf ? (_jsx(ScheduleMenuItem, { icon: Download, label: labels.menu.exportPdf, onClick: onExportPdf })) : null] }), _jsxs(ScheduleMenu, { label: labels.menu.more, icon: MoreHorizontal, align: "end", testId: "schedule-actions-menu", title: labels.menu.actionsTitle, children: [onOpenLeveling ? (_jsx(ScheduleMenuItem, { icon: Scale, label: labels.toolbar.levelResources, onClick: onOpenLeveling, testId: "schedule-level-resources" })) : null, onOpenImport ? (_jsx(ScheduleMenuItem, { icon: Upload, label: labels.menu.importSchedule, onClick: onOpenImport })) : null, _jsx(ScheduleMenuItem, { icon: Filter, label: filtersActive ? labels.menu.hideFilters : labels.menu.showFilters, selected: filtersActive, onClick: onToggleFilters }), _jsx(ScheduleMenuItem, { icon: Settings2, label: labels.toolbar.manageSchedule, onClick: onOpenManage, testId: "schedule-manage" })] })] }) }));
}
/**
 * Menu shell. Items call `close()` through context so a selection dismisses
 * the popover without every call site having to thread state.
 */
const MenuCloseContext = createContext(() => { });
function ScheduleMenu({ label, icon: Icon, active = false, align = 'start', testId, title, children, }) {
    const [open, setOpen] = useState(false);
    return (_jsx(Popover, { open: open, onOpenChange: setOpen, align: align, className: "w-56 p-1.5", trigger: _jsxs(Button, { variant: active ? 'secondary' : 'ghost', size: "sm", "data-testid": testId, title: title ?? label, "aria-label": title ?? label, className: "h-7 min-w-0 shrink-0 gap-1.5 rounded-md px-2 text-[11px]", onClick: () => setOpen((current) => !current), children: [_jsx(Icon, { className: "h-3.5 w-3.5 shrink-0" }), _jsx("span", { className: "max-w-28 truncate", children: label }), _jsx(ChevronDown, { className: "h-3 w-3 text-fg-subtle" })] }), children: _jsx(MenuCloseContext.Provider, { value: () => setOpen(false), children: children }) }));
}
function useMenuClose() {
    return useContext(MenuCloseContext);
}
function ScheduleMenuItem({ icon: Icon, label, detail, selected = false, disabled = false, onClick, testId, }) {
    const close = useMenuClose();
    return (_jsxs("button", { type: "button", onClick: () => {
            onClick?.();
            close();
        }, disabled: disabled, "data-testid": testId, className: cn('flex h-8 w-full items-center gap-2 rounded-md px-2 text-left text-[11px] transition-colors disabled:pointer-events-none disabled:opacity-35', selected ? 'bg-primary-subtle text-primary' : 'text-fg-muted hover:bg-bg-subtle hover:text-fg'), children: [_jsx(Icon, { className: "h-3.5 w-3.5 shrink-0" }), _jsx("span", { className: "min-w-0 flex-1 truncate font-medium", children: label }), detail ? _jsx("span", { className: "shrink-0 text-[10px] text-fg-subtle", children: detail }) : null, selected ? _jsx(Check, { className: "h-3 w-3 shrink-0" }) : null] }));
}
function ScheduleMenuIconButton({ icon: Icon, label, disabled = false, onClick, testId, }) {
    const close = useMenuClose();
    return (_jsx("button", { type: "button", title: label, "aria-label": label, disabled: disabled, onClick: () => {
            onClick();
            close();
        }, "data-testid": testId, className: "flex h-7 items-center justify-center rounded-md text-fg-muted transition-colors hover:bg-bg-subtle hover:text-fg disabled:pointer-events-none disabled:opacity-35", children: _jsx(Icon, { className: "h-3.5 w-3.5" }) }));
}
function ScheduleMenuPill({ label, selected, onClick, testId, }) {
    const close = useMenuClose();
    return (_jsx("button", { type: "button", onClick: () => {
            onClick();
            close();
        }, "data-testid": testId, className: cn('h-7 rounded-md px-1 text-[10px] font-semibold uppercase transition-colors', selected ? 'bg-primary-subtle text-primary' : 'text-fg-muted hover:bg-bg-subtle hover:text-fg'), children: label }));
}
function MenuSectionLabel({ children }) {
    return (_jsx("p", { className: "px-2 py-1 text-[10px] font-semibold tracking-[0.14em] text-fg-subtle uppercase", children: children }));
}
function MenuSeparator() {
    return _jsx("div", { className: "my-1 h-px bg-border" });
}
//# sourceMappingURL=schedule-toolbar.js.map