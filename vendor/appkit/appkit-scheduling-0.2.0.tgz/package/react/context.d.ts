/**
 * The one place the scheduling surface gets its strings and date formatting.
 *
 * Without a provider every component falls back to English defaults and the
 * runtime locale, so a host can drop a Gantt in and see it work. With one, the
 * host's own i18n layer supplies labels and formatters and nothing inside the
 * package needs to know which library it uses.
 */
import { type ReactNode } from 'react';
import { type ScheduleDateFormatters } from '../dates.js';
import { type DeepPartial, type SchedulingLabels } from '../labels.js';
export interface SchedulingContextValue {
    labels: SchedulingLabels;
    formatters: ScheduleDateFormatters;
    locale?: string;
}
export declare function SchedulingProvider({ children, labels, formatters, locale, }: {
    children: ReactNode;
    /** Partial overrides merged over the English defaults. */
    labels?: DeepPartial<SchedulingLabels>;
    /** Complete formatter override; otherwise derived from `locale`. */
    formatters?: ScheduleDateFormatters;
    locale?: string;
}): import("react").JSX.Element;
export declare function useScheduling(): SchedulingContextValue;
export declare function useSchedulingLabels(): SchedulingLabels;
export declare function useScheduleFormatters(): ScheduleDateFormatters;
//# sourceMappingURL=context.d.ts.map