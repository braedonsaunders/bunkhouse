'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * The spreadsheet view of a schedule: every planning field on one row, sortable
 * columns, multi-select with bulk status changes, and the same outline drag as
 * the Gantt.
 *
 * Reordering is only offered while sorted by WBS. Dragging a row into a new
 * position under a *sorted* view would write an order the user can't see, so
 * the grip explains itself instead of silently doing the wrong thing.
 */
import { Fragment, useMemo, useRef, useState } from 'react';
import { ChevronDown, ChevronRight, GripVertical, Trash2 } from 'lucide-react';
import { Badge, Button, Checkbox, Progress, cn } from '@appkit/ui';
import { diffDays, parseDate } from '../dates.js';
import { buildTaskHierarchyInfo, getSummaryTaskIds, getVisibleTasks } from '../hierarchy.js';
import { getTaskVariance, normalizeScheduleProgress } from '../insights.js';
import { computePhaseDatesFromTasks, groupTasksByPhase } from '../timeline.js';
import { resolvePhaseColor, statusBadgeVariant } from '../palette.js';
import { useScheduleFormatters, useSchedulingLabels } from './context.js';
const TREE_INDENT = 18;
const TREE_DROP_OFFSET = 20;
const MAX_DROP_DEPTH = 12;
/** Resource chips shown inline before collapsing into a "+n" counter. */
const MAX_INLINE_RESOURCES = 3;
const COLUMN_COUNT = 17;
export function ListView({ tasks, insights, phases, resources, taskAssignmentsByTaskId, onUpdateTask, onBatchUpdateTasks, onDeleteTask, onReorderTask, onClickTask, onContextMenu, }) {
    const labels = useSchedulingLabels();
    const formatters = useScheduleFormatters();
    const [collapsedPhases, setCollapsedPhases] = useState(new Set());
    const [sortKey, setSortKey] = useState('order');
    const [sortDir, setSortDir] = useState('asc');
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [collapsedTaskIds, setCollapsedTaskIds] = useState(new Set());
    const [draggingTaskId, setDraggingTaskId] = useState(null);
    const [dropTarget, setDropTarget] = useState(null);
    const draggingTaskIdRef = useRef(null);
    const phaseDates = useMemo(() => computePhaseDatesFromTasks(tasks, phases), [tasks, phases]);
    const groups = useMemo(() => groupTasksByPhase(tasks, phases, phaseDates), [tasks, phases, phaseDates]);
    const resourceById = useMemo(() => new Map(resources.map((r) => [r.id, r])), [resources]);
    const visibleSummary = useMemo(() => ({
        critical: tasks.filter((task) => insights.criticalTaskIds.has(task.id)).length,
        overdue: tasks.filter((task) => insights.overdueTaskIds.has(task.id)).length,
        slip: tasks.filter((task) => insights.behindBaselineTaskIds.has(task.id)).length,
        issues: tasks.filter((task) => insights.attentionTaskIds.has(task.id)).length,
    }), [
        insights.attentionTaskIds,
        insights.behindBaselineTaskIds,
        insights.criticalTaskIds,
        insights.overdueTaskIds,
        tasks,
    ]);
    const sortedGroups = useMemo(() => groups.map((group) => ({
        ...group,
        tasks: sortKey === 'order'
            ? [...group.tasks]
            : [...group.tasks].sort((a, b) => {
                const aVariance = getTaskVariance(a);
                const bVariance = getTaskVariance(b);
                const aFloat = insights.totalFloatByTask.get(a.id) ?? Number.POSITIVE_INFINITY;
                const bFloat = insights.totalFloatByTask.get(b.id) ?? Number.POSITIVE_INFINITY;
                let cmp = 0;
                if (sortKey === 'name')
                    cmp = a.name.localeCompare(b.name);
                else if (sortKey === 'status')
                    cmp = a.status.localeCompare(b.status);
                else if (sortKey === 'startDate')
                    cmp = (a.startDate ?? '').localeCompare(b.startDate ?? '');
                else if (sortKey === 'endDate')
                    cmp = (a.endDate ?? '').localeCompare(b.endDate ?? '');
                else if (sortKey === 'progress')
                    cmp = a.progress - b.progress;
                else if (sortKey === 'assignee')
                    cmp = a.assignee.localeCompare(b.assignee);
                else if (sortKey === 'variance')
                    cmp =
                        Math.max(aVariance.finishDays ?? 0, aVariance.startDays ?? 0) -
                            Math.max(bVariance.finishDays ?? 0, bVariance.startDays ?? 0);
                else if (sortKey === 'float')
                    cmp = aFloat - bFloat;
                return sortDir === 'asc' ? cmp : -cmp;
            }),
        hierarchyInfo: buildTaskHierarchyInfo(group.tasks),
        summaryTaskIds: getSummaryTaskIds(group.tasks),
        visibleTasks: getVisibleTasks(group.tasks, collapsedTaskIds),
    })), [collapsedTaskIds, groups, insights.totalFloatByTask, sortDir, sortKey]);
    const toggleSort = (key) => {
        if (sortKey === key)
            setSortDir((current) => (current === 'asc' ? 'desc' : 'asc'));
        else {
            setSortKey(key);
            setSortDir('asc');
        }
    };
    const toggleIn = (setter) => (id) => {
        setter((prev) => {
            const next = new Set(prev);
            if (next.has(id))
                next.delete(id);
            else
                next.add(id);
            return next;
        });
    };
    const togglePhase = toggleIn(setCollapsedPhases);
    const toggleTask = toggleIn(setCollapsedTaskIds);
    const toggleSelect = toggleIn(setSelectedIds);
    const handleBulkStatusChange = async (status) => {
        const didUpdate = await onBatchUpdateTasks(Array.from(selectedIds).map((id) => ({
            id,
            status,
            // Marking complete without setting progress leaves the two disagreeing.
            ...(status === 'complete' ? { progress: 1 } : {}),
        })));
        if (didUpdate !== false)
            setSelectedIds(new Set());
    };
    const handleRowDragOver = (event, taskId, targetDepth) => {
        const activeTaskId = draggingTaskIdRef.current ?? draggingTaskId ?? event.dataTransfer.getData('text/plain') ?? null;
        if (!activeTaskId || activeTaskId === taskId || sortKey !== 'order')
            return;
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
        const rect = event.currentTarget.getBoundingClientRect();
        const relativeY = event.clientY - rect.top;
        const treeCell = event.currentTarget.querySelector('[data-schedule-tree-cell]');
        const treeRect = treeCell?.getBoundingClientRect() ?? rect;
        const relativeTreeX = Math.max(0, event.clientX - treeRect.left);
        const depth = Math.max(0, Math.min(MAX_DROP_DEPTH, Math.round((relativeTreeX - TREE_DROP_OFFSET) / TREE_INDENT)));
        const placement = relativeY > rect.height * 0.28 &&
            relativeY < rect.height * 0.72 &&
            relativeTreeX >= TREE_DROP_OFFSET + targetDepth * TREE_INDENT + 12
            ? 'inside'
            : relativeY < rect.height / 2
                ? 'before'
                : 'after';
        setDropTarget({ taskId, placement, depth });
    };
    const handleRowDrop = async (event, taskId) => {
        event.preventDefault();
        event.stopPropagation();
        const activeTaskId = draggingTaskIdRef.current ?? draggingTaskId ?? event.dataTransfer.getData('text/plain') ?? null;
        if (!activeTaskId || !dropTarget || dropTarget.taskId !== taskId || sortKey !== 'order')
            return;
        const didMove = await onReorderTask(activeTaskId, taskId, dropTarget.placement, dropTarget.depth);
        if (didMove !== false) {
            setDraggingTaskId(null);
            draggingTaskIdRef.current = null;
            setDropTarget(null);
        }
    };
    const SortHeader = ({ label, field }) => (_jsxs("th", { className: "cursor-pointer px-3 py-2 text-left text-xs font-medium text-fg-muted transition-colors select-none hover:text-fg", onClick: () => toggleSort(field), "aria-sort": sortKey === field ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none', children: [label, sortKey === field && _jsx("span", { className: "ml-1", children: sortDir === 'asc' ? '↑' : '↓' })] }));
    return (_jsxs("div", { className: "flex min-h-0 flex-1 flex-col overflow-hidden rounded-t-none rounded-b-lg border border-t-0 border-border bg-surface", "data-testid": "schedule-list", children: [_jsx("div", { className: "flex shrink-0 flex-wrap items-center justify-between gap-2 border-b border-border bg-bg-subtle/60 px-4 py-2", children: _jsxs("div", { className: "flex flex-wrap items-center gap-2 text-[11px] text-fg-muted", children: [_jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [tasks.length, " ", labels.list.visible] }), _jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [visibleSummary.critical, " ", labels.list.critical] }), _jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [visibleSummary.overdue, " ", labels.list.overdue] }), _jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [visibleSummary.slip, " ", labels.list.slip] }), _jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [visibleSummary.issues, " ", labels.list.issues] })] }) }), selectedIds.size > 0 && (_jsxs("div", { className: "flex shrink-0 items-center gap-2 border-b border-border bg-primary-subtle px-4 py-2", children: [_jsxs("span", { className: "text-xs text-fg-muted", children: [selectedIds.size, " ", labels.list.selected] }), _jsx(Button, { variant: "ghost", size: "sm", onClick: () => void handleBulkStatusChange('in_progress'), "data-testid": "schedule-list-bulk-in-progress", children: labels.list.markInProgress }), _jsx(Button, { variant: "ghost", size: "sm", onClick: () => void handleBulkStatusChange('complete'), "data-testid": "schedule-list-bulk-complete", children: labels.list.markComplete }), _jsx(Button, { variant: "ghost", size: "sm", onClick: () => setSelectedIds(new Set()), children: labels.list.clearSelection })] })), _jsx("div", { className: "sched-scroll min-h-0 flex-1 overflow-auto", children: _jsxs("table", { className: "w-full table-fixed", children: [_jsxs("colgroup", { children: [_jsx("col", { style: { width: 30 } }), _jsx("col", { style: { width: 34 } }), _jsx("col", { style: { width: 48 } }), _jsx("col", { style: { width: '22%' } }), _jsx("col", { style: { width: '9%' } }), _jsx("col", { style: { width: 92 } }), _jsx("col", { style: { width: 70 } }), _jsx("col", { style: { width: 70 } }), _jsx("col", { style: { width: 74 } }), _jsx("col", { style: { width: 70 } }), _jsx("col", { style: { width: 82 } }), _jsx("col", { style: { width: 54 } }), _jsx("col", { style: { width: '13%' } }), _jsx("col", { style: { width: 92 } }), _jsx("col", { style: { width: '8%' } }), _jsx("col", { style: { width: '12%' } }), _jsx("col", { style: { width: 92 } })] }), _jsx("thead", { className: "sticky top-0 z-20", children: _jsxs("tr", { className: "border-b border-border bg-bg-subtle", children: [_jsx("th", { className: "w-8 px-2 py-2" }), _jsx("th", { className: "w-8 px-3 py-2", children: _jsx(Checkbox, { "aria-label": labels.list.selectAll, checked: selectedIds.size === tasks.length && tasks.length > 0, onChange: () => {
                                                if (selectedIds.size === tasks.length)
                                                    setSelectedIds(new Set());
                                                else
                                                    setSelectedIds(new Set(tasks.map((task) => task.id)));
                                            } }) }), _jsx(SortHeader, { label: labels.list.wbs, field: "order" }), _jsx(SortHeader, { label: labels.columns.name, field: "name" }), _jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-fg-muted", children: labels.columns.phase }), _jsx(SortHeader, { label: labels.columns.status, field: "status" }), _jsx(SortHeader, { label: labels.columns.start, field: "startDate" }), _jsx(SortHeader, { label: labels.columns.finish, field: "endDate" }), _jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-fg-muted", children: labels.columns.deadline }), _jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-fg-muted", children: labels.columns.duration }), _jsx(SortHeader, { label: labels.list.variance, field: "variance" }), _jsx(SortHeader, { label: labels.columns.float, field: "float" }), _jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-fg-muted", children: labels.columns.resources }), _jsx(SortHeader, { label: labels.columns.progress, field: "progress" }), _jsx(SortHeader, { label: labels.columns.assignee, field: "assignee" }), _jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-fg-muted", children: labels.list.flags }), _jsx("th", { className: "w-10" })] }) }), _jsx("tbody", { children: sortedGroups.map((group, groupIndex) => {
                                const isCollapsed = group.phase ? collapsedPhases.has(group.phase.id) : false;
                                const groupColor = resolvePhaseColor(group.phase?.color, groupIndex);
                                return (_jsxs(Fragment, { children: [group.phase && (_jsx("tr", { className: "cursor-pointer border-b border-border/50 bg-bg-subtle/60 transition-colors hover:bg-bg-subtle", onClick: () => togglePhase(group.phase.id), children: _jsx("td", { colSpan: COLUMN_COUNT, className: "px-3 py-2", children: _jsxs("div", { className: "flex items-center gap-2", children: [isCollapsed ? (_jsx(ChevronRight, { className: "h-3.5 w-3.5 text-fg-subtle" })) : (_jsx(ChevronDown, { className: "h-3.5 w-3.5 text-fg-subtle" })), _jsx("div", { className: "h-2.5 w-2.5 rounded-full", style: { backgroundColor: groupColor } }), _jsxs("span", { className: "text-xs font-semibold text-fg", children: [group.phase.number ? `${group.phase.number}. ` : '', group.phase.name] }), _jsx("span", { className: "ml-2 text-[11px] text-fg-subtle", children: labels.format.taskCount(group.tasks.length) })] }) }) })), !isCollapsed &&
                                            group.visibleTasks.map((task) => {
                                                const start = parseDate(task.startDate);
                                                const end = parseDate(task.endDate);
                                                const deadline = parseDate(task.deadlineDate);
                                                const duration = start && end ? diffDays(end, start) : task.duration;
                                                const variance = getTaskVariance(task);
                                                const floatDays = insights.totalFloatByTask.get(task.id);
                                                const assignments = taskAssignmentsByTaskId.get(task.id) ?? [];
                                                const progress = normalizeScheduleProgress(task.progress);
                                                const hierarchy = group.hierarchyInfo.get(task.id);
                                                const depth = hierarchy?.depth ?? task.outlineLevel ?? 0;
                                                const isSummaryTask = group.summaryTaskIds.has(task.id);
                                                const isTaskCollapsed = collapsedTaskIds.has(task.id);
                                                const isDropBefore = dropTarget?.taskId === task.id && dropTarget.placement === 'before';
                                                const isDropAfter = dropTarget?.taskId === task.id && dropTarget.placement === 'after';
                                                const isDropInside = dropTarget?.taskId === task.id && dropTarget.placement === 'inside';
                                                return (_jsxs("tr", { "data-testid": `schedule-list-row-${task.id}`, className: cn('border-b border-border/40 transition-colors hover:bg-surface-hover', draggingTaskId === task.id && 'opacity-55', isDropBefore && 'border-t-2 border-t-primary', isDropAfter && 'border-b-2 border-b-primary', isDropInside && 'bg-primary-subtle shadow-[inset_3px_0_0_0_var(--color-primary)]'), onContextMenu: onContextMenu ? (event) => onContextMenu(event, task) : undefined, onDragOver: (event) => handleRowDragOver(event, task.id, depth), onDragEnter: (event) => handleRowDragOver(event, task.id, depth), onDragLeave: () => {
                                                        if (dropTarget?.taskId === task.id)
                                                            setDropTarget(null);
                                                    }, onDrop: (event) => void handleRowDrop(event, task.id), children: [_jsx("td", { className: "px-2 py-2 text-center", children: _jsx("button", { type: "button", draggable: sortKey === 'order', onDragStart: (event) => {
                                                                    event.dataTransfer.effectAllowed = 'move';
                                                                    event.dataTransfer.setData('text/plain', task.id);
                                                                    setDraggingTaskId(task.id);
                                                                    draggingTaskIdRef.current = task.id;
                                                                    setDropTarget(null);
                                                                }, onDragEnd: () => {
                                                                    setDraggingTaskId(null);
                                                                    draggingTaskIdRef.current = null;
                                                                    setDropTarget(null);
                                                                }, className: "text-fg-subtle transition-colors hover:text-fg-muted", "aria-label": `${labels.toolbar.indent}: ${task.name || labels.badges.untitled}`, title: sortKey === 'order'
                                                                    ? labels.badges.reorderHint
                                                                    : labels.list.reorderRequiresWbsSort, children: _jsx(GripVertical, { className: "h-3.5 w-3.5" }) }) }), _jsx("td", { className: "px-3 py-2", children: _jsx(Checkbox, { "data-testid": `schedule-list-select-${task.id}`, "aria-label": task.name || labels.badges.untitled, checked: selectedIds.has(task.id), onChange: () => toggleSelect(task.id) }) }), _jsx("td", { className: "truncate px-3 py-2 text-[11px] text-fg-subtle", children: depth === 0 ? `${task.order}` : `${task.order}.L${depth}` }), _jsx("td", { className: "min-w-0 px-3 py-2 text-xs text-fg transition-colors hover:text-primary", onClick: () => onClickTask(task), children: _jsxs("div", { "data-schedule-tree-cell": "true", className: "flex min-w-0 cursor-pointer items-start gap-2", style: { paddingLeft: `${depth * TREE_INDENT}px` }, children: [hierarchy?.hasChildren ? (_jsx("button", { type: "button", className: "mt-0.5 shrink-0 text-fg-subtle transition-colors hover:text-fg", onClick: (event) => {
                                                                            event.stopPropagation();
                                                                            toggleTask(task.id);
                                                                        }, "aria-label": `${isTaskCollapsed ? labels.badges.expand : labels.badges.collapse}: ${task.name || labels.badges.untitled}`, children: isTaskCollapsed ? (_jsx(ChevronRight, { className: "h-3.5 w-3.5" })) : (_jsx(ChevronDown, { className: "h-3.5 w-3.5" })) })) : (_jsx("div", { className: "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-fg-subtle" })), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("span", { className: "line-clamp-2", children: task.name || labels.badges.untitled }), _jsxs("div", { className: "mt-1 flex flex-wrap items-center gap-1.5 text-[10px] text-fg-subtle", children: [isSummaryTask ? _jsx(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: labels.badges.summary }) : null, hierarchy?.hasChildren ? (_jsx(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: labels.format.childCount(hierarchy.childCount) })) : null, _jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: ["L", depth] }), task.description ? (_jsx("span", { className: "line-clamp-1", children: task.description })) : null] })] })] }) }), _jsx("td", { className: "min-w-0 px-3 py-2", children: group.phase && (_jsxs("div", { className: "flex min-w-0 items-center gap-1.5", children: [_jsx("div", { className: "h-2 w-2 shrink-0 rounded-full", style: { backgroundColor: groupColor } }), _jsx("span", { className: "truncate text-[11px] text-fg-subtle", children: group.phase.name })] })) }), _jsx("td", { className: "px-3 py-2", children: _jsx(Badge, { variant: statusBadgeVariant[task.status], children: labels.status[task.status] }) }), _jsx("td", { className: "truncate px-3 py-2 text-xs text-fg-muted", children: start ? formatters.shortDate(start) : '—' }), _jsx("td", { className: "truncate px-3 py-2 text-xs text-fg-muted", children: end ? formatters.shortDate(end) : '—' }), _jsx("td", { className: "truncate px-3 py-2 text-xs text-fg-muted", children: deadline ? formatters.shortDate(deadline) : '—' }), _jsx("td", { className: "truncate px-3 py-2 text-xs text-fg-muted", children: duration > 0
                                                                ? labels.format.days(duration)
                                                                : task.taskType === 'milestone'
                                                                    ? labels.badges.milestone
                                                                    : '—' }), _jsx("td", { className: "px-3 py-2 text-xs text-fg-muted", children: variance.isBehind ? (_jsx(Badge, { variant: "warning", className: "px-2 py-0 text-[10px] font-medium", children: labels.format.slipDays(Math.max(variance.finishDays ?? 0, variance.startDays ?? 0)) })) : variance.isAhead ? (_jsx(Badge, { variant: "success", className: "px-2 py-0 text-[10px] font-medium", children: labels.format.aheadDays(Math.min(variance.finishDays ?? 0, variance.startDays ?? 0)) })) : variance.hasVariance ? (_jsx(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: labels.list.onBaseline })) : ('—') }), _jsx("td", { className: "px-3 py-2 text-xs text-fg-muted", children: typeof floatDays === 'number' && Number.isFinite(floatDays)
                                                                ? labels.format.days(Math.round(floatDays))
                                                                : '—' }), _jsx("td", { className: "min-w-0 px-3 py-2 text-xs text-fg-muted", children: assignments.length > 0 ? (_jsxs("div", { className: "flex max-h-7 min-w-0 flex-wrap gap-1 overflow-hidden", children: [assignments.slice(0, MAX_INLINE_RESOURCES).map((assignment) => (_jsx(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: resourceById.get(assignment.resourceId)?.name ??
                                                                            assignment.role ??
                                                                            labels.list.resource }, assignment.id))), assignments.length > MAX_INLINE_RESOURCES ? (_jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: ["+", assignments.length - MAX_INLINE_RESOURCES] })) : null] })) : ('—') }), _jsx("td", { className: "px-3 py-2", children: _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Progress, { value: progress * 100, "aria-label": labels.columns.progress, className: "h-1.5 w-16" }), _jsxs("span", { className: "text-[11px] text-fg-subtle", children: [Math.round(progress * 100), "%"] })] }) }), _jsx("td", { className: "truncate px-3 py-2 text-xs text-fg-muted", children: task.assignee || '—' }), _jsx("td", { className: "min-w-0 px-3 py-2", children: _jsxs("div", { className: "flex max-h-7 flex-wrap gap-1 overflow-hidden", children: [insights.criticalTaskIds.has(task.id) && (_jsx(Badge, { variant: "info", children: labels.badges.critical })), insights.overdueTaskIds.has(task.id) && (_jsx(Badge, { variant: "destructive", children: labels.badges.overdue })), insights.violatingTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.badges.logic })), insights.openEndedTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.list.openEnd })), insights.deadlineMissTaskIds.has(task.id) && (_jsx(Badge, { variant: "destructive", children: labels.badges.deadline })), insights.constraintViolationTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.badges.constraint })), insights.resourceConflictTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.badges.resource })), insights.actualDateGapTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.list.actuals }))] }) }), _jsx("td", { className: "px-3 py-2", children: _jsxs("div", { className: "flex items-center justify-end gap-1", children: [task.status !== 'in_progress' ? (_jsx(Button, { variant: "ghost", size: "sm", onClick: () => void onUpdateTask(task.id, { status: 'in_progress' }), className: "h-6 px-2 text-[10px]", children: labels.list.start })) : null, task.status !== 'complete' ? (_jsx(Button, { variant: "ghost", size: "sm", onClick: () => void onUpdateTask(task.id, { status: 'complete', progress: 1 }), className: "h-6 px-2 text-[10px]", children: labels.list.done })) : null, _jsx("button", { type: "button", onClick: () => void onDeleteTask(task.id), className: "text-fg-subtle transition-colors hover:text-danger", "aria-label": `${labels.editor.delete}: ${task.name || labels.badges.untitled}`, children: _jsx(Trash2, { className: "h-3.5 w-3.5" }) })] }) })] }, task.id));
                                            })] }, group.phase?.id ?? 'standalone'));
                            }) })] }) }), tasks.length === 0 && (_jsx("div", { className: "py-12 text-center text-sm text-fg-subtle", children: labels.list.noMatches }))] }));
}
//# sourceMappingURL=list-view.js.map