/**
 * @appkit/scheduling — the domain model.
 *
 * A schedule is a set of tasks arranged in a work-breakdown outline, linked by
 * typed dependencies, sized against working calendars, staffed by resources,
 * and measured against baselines. Everything here is dependency-free data: the
 * host owns persistence, identity, and authorization, and maps its own rows
 * into these shapes.
 *
 * Dates are calendar dates (`YYYY-MM-DD`) — never timestamps. A schedule is a
 * calendar-day instrument; carrying wall-clock time through it invites
 * timezone drift between the plan a user typed and the plan that is stored.
 */
export const emptySchedule = {
    tasks: [],
    dependencies: [],
    phases: [],
    calendars: [],
    resources: [],
    assignments: [],
    baselines: [],
    baselineTasks: [],
};
export const emptyFilters = {
    phaseIds: [],
    statuses: [],
    assignees: [],
    dateFrom: null,
    dateTo: null,
};
//# sourceMappingURL=types.js.map