/**
 * The work-breakdown outline: parent/child structure, indent/outdent/reorder,
 * and summary rollups.
 *
 * A summary task is never planned directly — its dates, duration, progress and
 * status are DERIVED from its children. That is why the network analysis and
 * the insight probes both exclude summary rows: scheduling a parent alongside
 * its children would double-count the same work.
 */
import type { ScheduleTask, TaskHierarchyInfo, TaskTreePlacement, TaskTreeUpdate } from './types.js';
/** Deepest outline level the tree tools will produce. */
export declare const MAX_OUTLINE_LEVEL = 12;
export declare function sortTasksByOrder(tasks: ScheduleTask[]): ScheduleTask[];
/** Explicit summaries plus any task that has acquired children. */
export declare function getSummaryTaskIds(tasks: ScheduleTask[]): Set<string>;
export declare function buildTaskHierarchyInfo(tasks: ScheduleTask[]): Map<string, TaskHierarchyInfo>;
/**
 * Return the task list with every parent replaced by its rolled-up summary.
 * Pure — the input rows are never mutated, so a host can render rollups
 * without writing derived values back to storage.
 */
export declare function rollupScheduleTasks(tasks: ScheduleTask[]): ScheduleTask[];
export declare function getTaskDescendantIds(tasks: ScheduleTask[], taskId: string): string[];
export declare function getTaskSubtreeIds(tasks: ScheduleTask[], taskId: string): string[];
export declare function getTaskAncestorIds(tasks: ScheduleTask[], taskId: string): string[];
/** Indent under the row above — the outline-editing gesture users expect. */
export declare function buildIndentTaskUpdates(tasks: ScheduleTask[], taskId: string): TaskTreeUpdate[];
export declare function buildOutdentTaskUpdates(tasks: ScheduleTask[], taskId: string): TaskTreeUpdate[];
/**
 * Move a task (with its whole subtree) relative to another row and return the
 * minimal set of patches. Dropping a task inside its own subtree is refused —
 * that would orphan the branch.
 */
export declare function buildReorderTaskUpdates(tasks: ScheduleTask[], taskId: string, targetTaskId: string, placement: TaskTreePlacement, depthHint?: number): TaskTreeUpdate[];
/** Depth-first display order, honouring collapsed parents. */
export declare function getVisibleTaskOrder(tasks: ScheduleTask[], collapsedTaskIds?: Set<string>): string[];
export declare function getVisibleTasks(tasks: ScheduleTask[], collapsedTaskIds?: Set<string>): ScheduleTask[];
//# sourceMappingURL=hierarchy.d.ts.map