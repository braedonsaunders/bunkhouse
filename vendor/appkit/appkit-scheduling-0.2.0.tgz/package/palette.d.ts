/**
 * The phase palette, as token references rather than colour literals.
 *
 * A phase without an explicit colour takes its hue from its index, so two
 * adjacent phases never collide and the same phase keeps its identity between
 * light and dark. Hosts restyle the whole schedule by redefining the
 * `--sched-phase-*` channels in `styles.css` — never by editing a component.
 */
export declare const PHASE_TOKEN_COUNT = 8;
/** CSS `rgb()` expression for phase index `index` at optional `alpha`. */
export declare function phaseColor(index: number, alpha?: number): string;
/** Resolve a phase's colour: an explicit override wins over the palette. */
export declare function resolvePhaseColor(explicit: string | null | undefined, index: number, alpha?: number): string;
/** Semantic colours the timeline chrome draws with. */
export declare const scheduleColors: {
    readonly critical: (alpha?: number) => string;
    readonly today: (alpha?: number) => string;
    readonly baseline: (alpha?: number) => string;
    readonly link: (alpha?: number) => string;
    readonly overload: (alpha?: number) => string;
    readonly progress: (alpha?: number) => string;
};
/** Status → `@appkit/ui` Badge variant. Never colour alone: the badge also
 *  carries the status text, so the meaning survives for colour-blind readers. */
export declare const statusBadgeVariant: {
    readonly not_started: "secondary";
    readonly in_progress: "info";
    readonly complete: "success";
    readonly on_hold: "warning";
};
//# sourceMappingURL=palette.d.ts.map