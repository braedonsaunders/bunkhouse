# @appkit/endpoints

Programmable endpoints — run user-defined handler(request) scripts in a QuickJS sandbox with a governance budget and injected host adapters.

## Install

```bash
pnpm add @appkit/endpoints
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
