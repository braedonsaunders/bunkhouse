import { forbidden, runSandbox } from '@appkit/sandbox';
export const DEFAULT_COSTS = {
    log: 1,
    storageGet: 5,
    storageList: 5,
    storageSet: 10,
    storageDelete: 10,
    recordsList: 10,
    recordsGet: 5,
};
/**
 * Execute `handler(request)` inside the shared QuickJS sandbox. Storage,
 * records, and application-specific functions exist only when supplied by the
 * host, keeping tenant scope and authorization outside authored code.
 */
export async function runEndpoint(options) {
    const globalName = options.globalName ?? 'app';
    const costs = { ...DEFAULT_COSTS, ...options.costs };
    const functions = {
        'storage.get': {
            cost: costs.storageGet,
            handler: ([key, namespace]) => options.adapters.storage.get(String(key), namespaceValue(namespace)),
        },
        'storage.set': {
            cost: costs.storageSet,
            handler: async ([key, value, namespace]) => {
                await options.adapters.storage.set(String(key), value ?? null, namespaceValue(namespace));
                return null;
            },
        },
        'storage.list': {
            cost: costs.storageList,
            handler: ([prefix, namespace]) => options.adapters.storage.list(String(prefix ?? ''), namespaceValue(namespace)),
        },
        'storage.delete': {
            cost: costs.storageDelete,
            handler: async ([key, namespace]) => {
                await options.adapters.storage.delete(String(key), namespaceValue(namespace));
                return null;
            },
        },
        'records.list': {
            cost: costs.recordsList,
            handler: ([typeKey, filters]) => {
                if (!options.adapters.records)
                    forbidden('record reads are not granted to this endpoint');
                return options.adapters.records.list(String(typeKey), isRecord(filters) ? filters : {});
            },
        },
        'records.get': {
            cost: costs.recordsGet,
            handler: ([typeKey, id]) => {
                if (!options.adapters.records)
                    forbidden('record reads are not granted to this endpoint');
                return options.adapters.records.get(String(typeKey), String(id));
            },
        },
        ...options.adapters.functions,
    };
    const result = await runSandbox({
        source: options.source,
        entrypoint: 'handler',
        input: options.request,
        globalName,
        values: { request: options.request },
        functions,
        timeoutMs: options.timeoutMs,
        unitBudget: options.unitBudget,
        memoryBytes: options.memoryBytes,
        stackBytes: options.stackBytes,
        logCost: costs.log,
    });
    if (result.status !== 'ok') {
        return {
            status: result.status === 'forbidden' ? 'forbidden' : result.status === 'timeout' ? 'timeout' : 'error',
            error: result.error,
            logs: result.logs,
            units: result.units,
            durationMs: result.durationMs,
        };
    }
    return {
        status: 'ok',
        response: normalizeResponse(result.value),
        logs: result.logs,
        units: result.units,
        durationMs: result.durationMs,
    };
}
function namespaceValue(value) {
    return value === null || value === undefined || value === '' ? 'default' : String(value);
}
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
function normalizeResponse(output) {
    if (output && typeof output === 'object' && 'status' in output && typeof output.status === 'number') {
        const response = output;
        return { status: response.status, body: 'body' in response ? response.body : null };
    }
    return { status: 200, body: output ?? null };
}
//# sourceMappingURL=index.js.map