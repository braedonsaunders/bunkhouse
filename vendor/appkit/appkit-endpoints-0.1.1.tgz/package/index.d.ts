import { type SandboxLimits } from '@appkit/sandbox';
export interface EndpointRequest {
    method: string;
    endpoint: string;
    path?: string;
    query: Record<string, string>;
    body: unknown;
    user: {
        id: string;
        name: string;
        role?: string;
    } | null;
}
export interface StorageAdapter {
    get(key: string, namespace: string): Promise<unknown>;
    set(key: string, value: unknown, namespace: string): Promise<void>;
    list(prefix: string, namespace: string): Promise<{
        key: string;
        value: unknown;
    }[]>;
    delete(key: string, namespace: string): Promise<void>;
}
export interface RecordsAdapter {
    list(typeKey: string, filters: Record<string, unknown>): Promise<unknown[]>;
    get(typeKey: string, id: string): Promise<unknown>;
}
export interface HostFunction {
    cost: number;
    handler: (args: unknown[]) => Promise<unknown> | unknown;
}
export interface HostAdapters {
    storage: StorageAdapter;
    records?: RecordsAdapter;
    /** Additional governed functions, including dotted names such as `journal.create`. */
    functions?: Record<string, HostFunction>;
}
export interface EndpointResult {
    status: 'ok' | 'error' | 'timeout' | 'forbidden';
    response?: {
        status: number;
        body: unknown;
    };
    error?: string;
    logs: string[];
    units: number;
    durationMs: number;
}
export declare const DEFAULT_COSTS: {
    readonly log: 1;
    readonly storageGet: 5;
    readonly storageList: 5;
    readonly storageSet: 10;
    readonly storageDelete: 10;
    readonly recordsList: 10;
    readonly recordsGet: 5;
};
/**
 * Execute `handler(request)` inside the shared QuickJS sandbox. Storage,
 * records, and application-specific functions exist only when supplied by the
 * host, keeping tenant scope and authorization outside authored code.
 */
export declare function runEndpoint(options: {
    source: string;
    request: EndpointRequest;
    adapters: HostAdapters;
    globalName?: string;
    costs?: Partial<typeof DEFAULT_COSTS>;
} & SandboxLimits): Promise<EndpointResult>;
//# sourceMappingURL=index.d.ts.map