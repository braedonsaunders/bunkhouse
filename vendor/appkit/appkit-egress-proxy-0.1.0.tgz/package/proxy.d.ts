/**
 * The egress chokepoint for agent sandboxes.
 *
 * One TCP listener accepts three connection shapes and treats them all the
 * same way — recover the destination, ask the policy port, audit the
 * decision, then either splice bytes or refuse:
 *
 * - **Explicit HTTP proxying** — absolute-form requests
 *   (`GET http://host/path`). The head is rewritten to origin form, proxy
 *   credentials are stripped, and the body is spliced through.
 * - **CONNECT tunneling** — the host check happens at CONNECT time; a denial
 *   is a 403 before any client byte reaches the destination. TLS is never
 *   terminated.
 * - **Transparent interception** — a DNAT'd flow where the client never knows
 *   a proxy exists. The destination hostname is recovered from the TLS
 *   ClientHello SNI, or from the Host header of a plain-HTTP request, using
 *   the pure parsers in `sniff.ts`.
 *
 * Everything fails closed: a policy exception, an unparseable destination, a
 * truncated preface, or a destination that resolves to a non-public address
 * all deny and audit. There is no TLS interception code path in this package;
 * MITM with a generated CA is deliberately not implemented (see the README).
 */
import { type Socket } from 'node:net';
import { type UpstreamAddress } from './host-policy.js';
export type EgressProtocol = 'http' | 'https' | 'tcp';
export type EgressDecision = 'allow' | 'deny';
export interface EgressPolicyRequest {
    /** Normalized destination hostname or IP literal. */
    host: string;
    port: number;
    /**
     * `https` for SNI-sniffed flows and CONNECT to port 443, `http` for plain
     * HTTP in either explicit or transparent form, `tcp` for CONNECT to any
     * other port (the tunnel is opaque, so the payload protocol is unknown).
     */
    protocol: EgressProtocol;
    principal: string | null;
}
/** May be synchronous or asynchronous; a thrown or rejected policy denies. */
export type EgressPolicy = (request: EgressPolicyRequest) => EgressDecision | Promise<EgressDecision>;
export type EgressAuditEvent = 'decision' | 'upstream-error' | 'flow-closed';
export interface EgressAuditEntry {
    /** ISO-8601 timestamp taken when the entry was produced. */
    at: string;
    /**
     * `decision` records every allow and deny. `upstream-error` records a
     * failure after an allow — either the upstream address was refused by host
     * policy (`decision: 'deny'`) or the connection itself failed
     * (`decision: 'allow'`). `flow-closed` records byte counts when an
     * established flow ends.
     */
    event: EgressAuditEvent;
    protocol: EgressProtocol;
    /** Null when the destination could not be parsed out of the flow. */
    host: string | null;
    port: number | null;
    principal: string | null;
    decision: EgressDecision;
    /** The denial reason or upstream error message; null on clean events. */
    reason: string | null;
    bytesToUpstream: number | null;
    bytesFromUpstream: number | null;
}
export interface EgressProxyStats {
    /** Client connections currently open. */
    active: number;
    /** Client connections accepted since the proxy started. */
    total: number;
    /** Flows refused before any byte reached a destination. */
    denied: number;
}
export interface EgressProxyHandle {
    /** Bind the listener; resolves with the bound address (useful with port 0). */
    listen(): Promise<{
        host: string;
        port: number;
    }>;
    /** Stop listening and destroy every open client and upstream socket. */
    close(): Promise<void>;
    stats(): EgressProxyStats;
}
export interface CreateEgressProxyOptions {
    policy: EgressPolicy;
    /**
     * Receives every audit entry. Must not throw; an entry whose sink throws is
     * lost, never the connection.
     */
    audit: (entry: EgressAuditEntry) => void;
    listen: {
        host: string;
        port: number;
    };
    /**
     * Attribute a principal to an inbound socket — typically by the source IP
     * of the guest tap that was DNAT'd here. Default: null. A hook that throws
     * yields a null principal; the policy still decides.
     */
    principalFor?: (socket: Socket) => string | null;
    /**
     * Map an allowed destination to the address actually dialled. The default
     * resolves through DNS and requires every answer to be public
     * ({@link resolvePublicUpstream}); override it to integrate a custom
     * resolver or, in tests, to point flows at loopback fixtures.
     */
    resolveUpstream?: (host: string, port: number) => UpstreamAddress | Promise<UpstreamAddress>;
    /**
     * Recover the pre-DNAT destination of a transparent flow (for example via
     * SO_ORIGINAL_DST). Only the port is used — the hostname always comes from
     * SNI or the Host header, because a name is what the policy reasons about.
     */
    originalDestinationFor?: (socket: Socket) => {
        host?: string;
        port: number;
    } | null;
    /** Port assumed for transparent TLS flows when the original one is unknown. Default 443. */
    transparentHttpsPort?: number;
    /** Port assumed for transparent plain-HTTP flows without a port in the Host header. Default 80. */
    transparentHttpPort?: number;
    /** How long a connection may take to reveal a parseable destination. Default 10 000 ms. */
    prefaceTimeoutMs?: number;
}
export declare function createEgressProxy(options: CreateEgressProxyOptions): EgressProxyHandle;
//# sourceMappingURL=proxy.d.ts.map