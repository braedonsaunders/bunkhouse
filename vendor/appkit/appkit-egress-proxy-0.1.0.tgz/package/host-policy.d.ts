/**
 * Host and address policy primitives for the egress chokepoint.
 *
 * The canonical treatment of outbound host policy in this repository lives in
 * `@appkit/sync`'s egress module (`packages/sync/src/egress.ts`). The rules
 * are mirrored here rather than imported because this proxy must remain a
 * zero-runtime-dependency stdlib package that a desk-runner can deploy on its
 * own, and pulling in `@appkit/sync` for three functions would drag a far
 * heavier surface across the trust boundary. Keep changes to the block lists
 * and hostname rules in step with that module.
 *
 * Everything in this file is fail-closed: an input that cannot be positively
 * classified as a valid public destination is rejected.
 */
/** Thrown when a destination is rejected by host policy rather than by the network. */
export declare class EgressHostPolicyError extends Error {
}
/**
 * Canonicalize a destination hostname: trim, strip IPv6 brackets and a
 * trailing dot, apply IDNA, lower-case, and validate label shape. Throws
 * {@link EgressHostPolicyError} when the input cannot be a hostname at all.
 */
export declare function normalizeOutboundHostname(raw: string): string;
/** True when the literal is a valid IPv4 or IPv6 address outside every blocked range. */
export declare function isPublicIpAddress(raw: string): boolean;
/**
 * True when an already-normalized hostname is not reserved for local or
 * private use. This is a name-level check only; the addresses a name resolves
 * to are checked separately by {@link resolvePublicUpstream}.
 */
export declare function isPublicHostname(hostname: string): boolean;
export interface UpstreamAddress {
    host: string;
    port: number;
}
/**
 * The default upstream resolver: refuse reserved names and non-public IP
 * literals, resolve names through the system resolver, and reject the whole
 * hostname if any answer is private or special. Answer-set rejection matters:
 * selecting only a public answer would still permit rebinding or round-robin
 * fallback to a private address. The connection is then made to the checked
 * address rather than re-resolving, closing the validate-then-connect gap.
 */
export declare function resolvePublicUpstream(host: string, port: number): Promise<UpstreamAddress>;
export interface HostPort {
    host: string;
    port: number | null;
}
/**
 * Split an `authority` such as a CONNECT target or a Host header value into
 * hostname and port. Bracketed IPv6 literals are supported; a bare colon-y
 * IPv6 literal without brackets is ambiguous and rejected. Returns null when
 * the authority cannot be parsed — callers must treat that as a denial.
 */
export declare function splitHostPort(authority: string): HostPort | null;
//# sourceMappingURL=host-policy.d.ts.map