/**
 * Pure destination sniffers for transparently intercepted TCP flows.
 *
 * Behind a DNAT redirect the client never speaks proxy protocol, so the only
 * way to learn the destination hostname without terminating the connection is
 * to read it out of the first bytes the client sends: the SNI extension of a
 * TLS ClientHello, or the request line and Host header of a plain-HTTP
 * request. Both parsers here are pure functions over a byte buffer — no I/O,
 * no state — so they can be tested exhaustively against fixtures.
 *
 * Every outcome is explicit. `need-more-bytes` means the buffer is a valid
 * prefix and the caller may keep reading; `malformed` means the bytes can
 * never become a parseable destination and the flow must be denied. Nothing
 * in this module ever guesses.
 */
export type SniffOutcome<T> = {
    readonly kind: 'ok';
    readonly value: T;
} | {
    readonly kind: 'need-more-bytes';
} | {
    readonly kind: 'malformed';
    readonly reason: string;
};
/**
 * Extract the SNI server name from the leading bytes of a TLS connection
 * without terminating TLS. Handles a ClientHello fragmented across several
 * handshake records. Returns `ok(null)` for a structurally valid ClientHello
 * that carries no server name — the caller cannot recover a hostname from
 * such a flow and must fail closed.
 */
export declare function readClientHelloSni(data: Uint8Array): SniffOutcome<string | null>;
export interface HttpRequestHead {
    method: string;
    /** The request target exactly as sent: origin-, absolute-, or authority-form. */
    target: string;
    /** Header fields in wire order with lower-cased names. */
    headers: ReadonlyArray<readonly [name: string, value: string]>;
    /** Offset just past the CRLFCRLF terminator; bytes beyond it belong to the body. */
    headEnd: number;
}
/**
 * Parse the head of an HTTP/1.x request from the first bytes of a connection.
 * Strict by design: CRLF line endings only, valid tokens only, no obs-fold,
 * no control bytes in field values. A transparent flow that cannot produce a
 * clean head cannot produce a trustworthy Host either.
 */
export declare function readHttpRequestHead(data: Uint8Array): SniffOutcome<HttpRequestHead>;
/** First value of a header field, or null when absent. */
export declare function headerValue(head: HttpRequestHead, name: string): string | null;
//# sourceMappingURL=sniff.d.ts.map