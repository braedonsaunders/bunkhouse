import { Buffer } from 'node:buffer';
import { type DeskLauncherIdentity } from './plan.js';
import { type DeskBackend } from './backend.js';
import type { A11yNode, DeskHandoverScope, DeskPoint, DeskPointerButton, DeskPorts, WindowInfo } from './events.js';
export declare const DEFAULT_CAPACITY = 4;
export declare const DEFAULT_IDLE_SUSPEND_MS: number;
export declare const DEFAULT_LEASE_MS: number;
export declare const DEFAULT_CID_BASE = 100;
export interface DeskHostOptions {
    /** Root of the golden base image and per-desk assets. */
    imageRoot: string;
    vmmPath?: string;
    kvmPath?: string;
    /** Guest kernel; defaults to `<imageRoot>/vmlinux`. */
    kernelPath?: string;
    /**
     * Initramfs the guest kernel boots with. A modular distro cloud kernel needs
     * one to mount root; omit only for a kernel with virtio/ext4 built in. When
     * unset it defaults to `<imageRoot>/initrd` if that file exists, else none.
     */
    initramfsPath?: string;
    /**
     * Kernel command line every desk boots with. Defaults to
     * `DEFAULT_KERNEL_CMDLINE`; override it for partitioned cloud images whose
     * root is not `/dev/vda` (e.g. `root=/dev/vda3 rw quiet`).
     */
    kernelCmdline?: string;
    /** Directory holding vsock and API control sockets. */
    runtimeDir?: string;
    launcherIdentity?: DeskLauncherIdentity;
    backend?: DeskBackend;
    ports: DeskPorts;
    /** Hard cap on concurrently resident desks; starts beyond it queue FIFO. */
    capacity?: number;
    idleSuspendMs?: number;
    defaultLeaseMs?: number;
    /** First guest vsock CID handed out; each boot takes the next one. */
    cidBase?: number;
    now?: () => number;
    pathExists?: (path: string) => boolean;
    deviceExists?: (path: string) => boolean;
}
export interface DeskStartOptions {
    deskId: string;
    /** Absolute path of the golden base image this desk boots from. */
    baseImage: string;
    /** Absolute path of this desk's copy-on-write overlay. */
    overlayPath: string;
    memoryMb?: number;
    vcpus?: number;
    leaseMs?: number;
    network?: {
        tapDevice?: string;
        macAddress?: string;
    };
}
export interface DeskExecOptions {
    command: string;
    args?: readonly string[];
    cwd?: string;
    env?: Readonly<Record<string, string>>;
    timeoutMs?: number;
    /** Survive the call as a background job; the job dies with the lease. */
    keepAlive?: boolean;
}
export interface DeskExecSnapshot {
    deskId: string;
    command: string;
    args: readonly string[];
    exitCode: number | null;
    signal: string | null;
    stdout: string;
    stderr: string;
    truncated: boolean;
    startedAt: string;
    finishedAt: string;
}
export interface DeskJob {
    jobId: string;
    deskId: string;
    command: string;
    args: readonly string[];
    startedAt: string;
    status: 'running' | 'exited';
    exitCode: number | null;
    signal: string | null;
}
export interface DeskObservation {
    png: Buffer;
    width: number;
    height: number;
    a11y: A11yNode | null;
    windows: readonly WindowInfo[];
    focused: WindowInfo | null;
}
export interface DeskFrame {
    seq: number;
    width: number;
    height: number;
    data: Buffer;
    at: string;
}
export interface DeskScreenInput {
    move(x: number, y: number): Promise<void>;
    click(x: number, y: number, button?: DeskPointerButton): Promise<void>;
    type(text: string): Promise<void>;
    key(combo: string): Promise<void>;
    scroll(x: number, y: number, dx: number, dy: number): Promise<void>;
    drag(from: DeskPoint, to: DeskPoint): Promise<void>;
}
export interface DeskScreenHandle {
    observe(): Promise<DeskObservation>;
    /**
     * Coordinate contract: all coordinates are in the pixel space of the most
     * recent `observe()`, one to one. Coordinate input before the first
     * `observe()` or outside its bounds throws.
     */
    input: DeskScreenInput;
    a11y: {
        invoke(nodeId: string, action: string): Promise<void>;
    };
    launch(appId: string, args?: readonly string[]): Promise<void>;
    clipboard: {
        read(): Promise<string>;
        write(text: string): Promise<void>;
    };
    frames(options?: {
        fps?: number;
        width?: number;
        height?: number;
    }): AsyncIterable<DeskFrame>;
    handover: {
        begin(options: {
            ttlMs: number;
            scope?: DeskHandoverScope;
            actor?: string;
        }): Promise<{
            url: string;
        }>;
        end(): Promise<void>;
        readonly active: boolean;
    };
}
export interface DeskScreenService {
    start(options: {
        width: number;
        height: number;
    }): Promise<DeskScreenHandle>;
    stop(): Promise<void>;
    readonly running: boolean;
}
export interface DeskHandle {
    readonly deskId: string;
    renewLease(ms: number): void;
    exec(options: DeskExecOptions & {
        keepAlive: true;
    }): Promise<DeskJob>;
    exec(options: DeskExecOptions): Promise<DeskExecSnapshot>;
    /** The keepAlive processes still running on this desk. */
    jobs(): DeskJob[];
    screen: DeskScreenService;
}
export interface DeskHostStats {
    /** Desks currently resident (booted or booting) against the capacity cap. */
    resident: number;
    /** Starts waiting in the FIFO queue for capacity. */
    queued: number;
    capacity: number;
    suspended: number;
    lastStartedAt: string | null;
    lastSuspendedAt: string | null;
    lastError: string | null;
}
export interface DeskHost {
    start(options: DeskStartOptions): Promise<DeskHandle>;
    resume(deskId: string): Promise<DeskHandle>;
    suspend(deskId: string): Promise<void>;
    destroy(deskId: string): Promise<void>;
    stats(): DeskHostStats;
    /**
     * Enforce every time-based rule now: expire handovers past their TTL and
     * suspend desks past their lease or idle deadline. Returns the number of
     * desks suspended. Timers call this automatically; tests with an injected
     * clock call it directly.
     */
    sweep(): Promise<number>;
}
export declare function createDeskHost(options: DeskHostOptions): DeskHost;
export interface VerifyDeskHostOptions {
    kernelPath: string;
    /** Initramfs for the probe VM; needed for a modular kernel, as at boot. */
    initramfsPath?: string;
    /**
     * Kernel command line for the probe VM. It must match what real desks boot
     * with: a probe that panics because its root is on another partition
     * reports a host that cannot run desks, which is indistinguishable from a
     * host that genuinely cannot.
     */
    kernelCmdline?: string;
    baseImagePath: string;
    vmmPath?: string;
    kvmPath?: string;
    /** Where the throwaway probe overlay is created; defaults to the OS tmpdir. */
    scratchDir?: string;
    runtimeDir?: string;
    backend?: DeskBackend;
    launcherIdentity?: DeskLauncherIdentity;
    platform?: NodeJS.Platform;
    pathExists?: (path: string) => boolean;
    deviceExists?: (path: string) => boolean;
    idFactory?: () => string;
}
export interface DeskHostVerification {
    /** Whether this host can serve desks: KVM present and the guest reachable. */
    supported: boolean;
    vmmPath: string;
    kvm: boolean;
    vsock: boolean;
    virtioGpu: boolean;
}
/**
 * Boot-time probe. Distinguishes a host that is unusable — wrong platform,
 * missing VMM, missing images — which throws, from capabilities that are
 * merely absent, which are reported as booleans: `kvm` (no boot possible
 * without it), `vsock` (the guest agent answered), and `virtioGpu` (a screen
 * would have hardware-backed rendering). It boots a throwaway microVM through
 * the backend, asks it two questions, and discards it.
 */
export declare function verifyDeskHost(options: VerifyDeskHostOptions): Promise<DeskHostVerification>;
//# sourceMappingURL=host.d.ts.map