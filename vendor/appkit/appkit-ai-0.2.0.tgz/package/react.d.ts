import * as React from 'react';
export type AgentMessage = {
    id: string;
    role: 'user' | 'assistant' | 'system';
    parts: unknown[];
};
export type AgentPanelLabels = {
    title: string;
    welcomeTitle: string;
    welcomeDescription: string;
    disabledTitle: string;
    disabledDescription: string;
    placeholder: string;
    send: string;
    stop: string;
    failed: string;
    input: string;
    result: string;
};
export type AgentPanelProps = {
    enabled: boolean;
    initialMessages?: AgentMessage[];
    suggestions?: string[];
    labels?: Partial<AgentPanelLabels>;
    send?: (prompt: string, signal: AbortSignal) => Promise<Response>;
    maxPromptCharacters?: number;
    toolLabels?: Record<string, string>;
};
/**
 * The streaming thread/composer extracted from the sibling assistant. The app
 * owns persistence and the HTTP transport; appkit owns UI-message decoding,
 * cancellation, ordered part rendering, and tool cards.
 */
export declare function AgentPanel({ enabled, initialMessages, suggestions, labels: labelOverrides, send, maxPromptCharacters, toolLabels, }: AgentPanelProps): React.JSX.Element;
export declare function ChatMarkdown({ children }: {
    children: string;
}): React.JSX.Element;
export declare function AgentToolCard({ name, label, state, input, output, inputLabel, resultLabel }: {
    name: string;
    label?: string;
    state: string;
    input?: unknown;
    output?: unknown;
    inputLabel?: string;
    resultLabel?: string;
}): React.JSX.Element;
//# sourceMappingURL=react.d.ts.map