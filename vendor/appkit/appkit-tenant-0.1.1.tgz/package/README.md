# @appkit/tenant

Request context, tenant-bound DB helper, and RBAC (permissions, roles, super-admin) on top of @appkit/db.

## Install

```bash
pnpm add @appkit/tenant
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
