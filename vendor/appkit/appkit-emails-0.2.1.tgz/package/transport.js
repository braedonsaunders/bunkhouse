// Email transport factory + provider implementations.
//
// `RawEmailConfig` is what an app persists per tenant (and per platform), with
// the single secret sealed by the app's own crypto. `resolveEmailTransport`
// unseals it (via an injected `unseal`) into an `EmailTransport` (plaintext
// secret); `buildTransport` does the same from already-plaintext values.
// `sendVia` performs the network send, switching on provider. HTTP providers go
// through `fetch` (no SDKs); SMTP uses nodemailer (dynamically imported).
//
// The `unsealSecret` dependency is injected, and the `resolvePublicHost` SSRF
// guard is isolated in ./egress.
import { resolvePublicHost } from './egress.js';
import { isEmailProvider } from './providers.js';
import { isValidEmailAddress, normalizeEmailDeliveryInput, } from './delivery-input.js';
export function isEmailPolicyMode(value) {
    return value === 'tenant_optional' || value === 'global_only' || value === 'disabled';
}
const MAILGUN_DOMAIN = /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;
const SMTP_HOST = /^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/i;
const MAX_FROM_NAME_LENGTH = 128;
const MAX_SMTP_USERNAME_LENGTH = 320;
const MAX_SEALED_SECRET_LENGTH = 8_192;
function validateEmailConfigFields(raw, requireComplete) {
    if (raw.provider !== undefined && !isEmailProvider(raw.provider)) {
        throw new Error('Select a valid email provider.');
    }
    if (raw.fromName && (raw.fromName.length > MAX_FROM_NAME_LENGTH || /[<>\r\n]/.test(raw.fromName))) {
        throw new Error('From name must be 128 characters or fewer and cannot contain angle brackets or line breaks.');
    }
    if (raw.fromEmail && !isValidEmailAddress(raw.fromEmail))
        throw new Error('Enter a valid From email address.');
    if (raw.replyTo && !isValidEmailAddress(raw.replyTo))
        throw new Error('Enter a valid Reply-to email address.');
    if (raw.mailgunDomain && !MAILGUN_DOMAIN.test(raw.mailgunDomain)) {
        throw new Error('Enter a valid Mailgun sending domain, such as mg.example.com.');
    }
    if (raw.smtpHost && !SMTP_HOST.test(raw.smtpHost)) {
        throw new Error('Enter a valid SMTP host without a protocol or path.');
    }
    if (raw.smtpUsername && raw.smtpUsername.length > MAX_SMTP_USERNAME_LENGTH) {
        throw new Error('SMTP username must be 320 characters or fewer.');
    }
    if (raw.mailgunRegion !== undefined && raw.mailgunRegion !== 'us' && raw.mailgunRegion !== 'eu') {
        throw new Error('Select a valid Mailgun region.');
    }
    if (raw.smtpSecure !== undefined && typeof raw.smtpSecure !== 'boolean') {
        throw new Error('SMTP TLS mode must be a boolean.');
    }
    if (raw.smtpPort !== undefined && (!Number.isInteger(raw.smtpPort) || raw.smtpPort < 1 || raw.smtpPort > 65_535)) {
        throw new Error('SMTP port must be a whole number from 1 to 65535.');
    }
    if (!requireComplete)
        return;
    if (!raw.provider)
        throw new Error('Select an email provider before enabling email delivery.');
    if (!raw.fromEmail)
        throw new Error('Enter a valid From email address before enabling email delivery.');
    if (raw.provider === 'smtp' && !raw.smtpHost) {
        throw new Error('Enter a valid SMTP host without a protocol or path.');
    }
    if (raw.provider === 'mailgun' && !raw.mailgunDomain) {
        throw new Error('Enter a valid Mailgun sending domain, such as mg.example.com.');
    }
    if (raw.provider === 'smtp' && 'secret' in raw) {
        const hasUsername = Boolean(raw.smtpUsername?.trim());
        const hasPassword = Boolean(raw.secret?.trim());
        if (hasUsername !== hasPassword) {
            throw new Error('SMTP username and password must both be provided, or both omitted for an unauthenticated relay.');
        }
    }
}
export function validateStoredEmailConfig(raw, options = {}) {
    if ('mode' in raw && raw.mode !== undefined && !isEmailPolicyMode(raw.mode)) {
        throw new Error('Select a valid platform email policy.');
    }
    const requireComplete = options.requireComplete ?? raw.enabled === true;
    validateEmailConfigFields(raw, requireComplete);
    const hasCiphertext = Boolean(raw.keyCiphertext?.trim());
    const hasNonce = Boolean(raw.keyNonce?.trim());
    if (hasCiphertext !== hasNonce) {
        throw new Error('The stored provider credential is incomplete; replace it before enabling email.');
    }
    if ((raw.keyCiphertext && raw.keyCiphertext.length > MAX_SEALED_SECRET_LENGTH) ||
        (raw.keyNonce && raw.keyNonce.length > MAX_SEALED_SECRET_LENGTH)) {
        throw new Error('The stored provider credential is invalid; replace it before enabling email.');
    }
    if (requireComplete && raw.enabled !== true) {
        throw new Error('Enable email delivery before selecting a live email policy.');
    }
    if (requireComplete && raw.provider !== 'smtp' && !(hasCiphertext && hasNonce)) {
        throw new Error("Enter this provider's credential before enabling email delivery.");
    }
    if (raw.provider === 'smtp') {
        const hasUsername = Boolean(raw.smtpUsername?.trim());
        const hasPassword = hasCiphertext && hasNonce;
        if (hasUsername !== hasPassword) {
            throw new Error('SMTP username and password must both be provided, or both omitted for an unauthenticated relay.');
        }
    }
}
function formatFrom(name, email) {
    const e = email?.trim();
    if (!e)
        return null;
    const n = name?.trim();
    return n ? `${n} <${e}>` : e;
}
/** Build a transport from already-plaintext config, or null when incomplete. */
export function buildTransport(c) {
    try {
        validateEmailConfigFields(c, true);
    }
    catch {
        return null;
    }
    const from = formatFrom(c.fromName, c.fromEmail);
    if (!from)
        return null;
    const replyTo = c.replyTo?.trim() || undefined;
    const secret = c.secret?.trim() || undefined;
    switch (c.provider) {
        case 'resend':
            return secret ? { provider: 'resend', apiKey: secret, from, replyTo } : null;
        case 'sendgrid':
            return secret ? { provider: 'sendgrid', apiKey: secret, from, replyTo } : null;
        case 'mailgun':
            if (!secret || !c.mailgunDomain?.trim())
                return null;
            return {
                provider: 'mailgun',
                apiKey: secret,
                domain: c.mailgunDomain.trim(),
                region: c.mailgunRegion === 'eu' ? 'eu' : 'us',
                from,
                replyTo,
            };
        case 'postmark':
            return secret ? { provider: 'postmark', serverToken: secret, from, replyTo } : null;
        case 'smtp': {
            if (!c.smtpHost?.trim())
                return null;
            const secure = c.smtpSecure === true;
            return {
                provider: 'smtp',
                mode: 'database',
                host: c.smtpHost.trim(),
                port: c.smtpPort ?? (secure ? 465 : 587),
                secure,
                username: c.smtpUsername?.trim() || undefined,
                password: secret,
                from,
                replyTo,
            };
        }
        default:
            return null;
    }
}
/** Unseal a stored config and build its transport, or null when not configured. */
export function resolveEmailTransport(raw, unseal) {
    if (!raw || !raw.provider || raw.enabled !== true)
        return null;
    try {
        validateStoredEmailConfig(raw, { requireComplete: true });
    }
    catch {
        return null;
    }
    let secret;
    if (raw.keyCiphertext && raw.keyNonce) {
        secret = unseal({ ciphertext: raw.keyCiphertext, nonce: raw.keyNonce }) ?? undefined;
    }
    return buildTransport({ ...raw, secret });
}
/**
 * The platform → tenant resolution policy, as a pure function (unit-testable):
 *   'disabled'        → suppressed (kill switch)
 *   'global_only'     → platform provider, else unconfigured
 *   'tenant_optional' → tenant provider (if scoped + configured), else platform.
 * `tenantScoped` is false for platform sends so a tenant provider never sends a
 * non-tenant email. A configured-but-broken tenant override fails closed.
 */
export function resolveEffectiveTransport(platform, tenant, opts) {
    const rawMode = platform?.mode;
    if (rawMode !== undefined && !isEmailPolicyMode(rawMode))
        return { kind: 'unconfigured' };
    const mode = rawMode ?? 'tenant_optional';
    if (mode === 'disabled')
        return { kind: 'suppressed' };
    const platformTransport = resolveEmailTransport(platform ?? null, opts.unseal);
    if (mode === 'global_only') {
        return platformTransport
            ? { kind: 'transport', transport: platformTransport, source: 'platform' }
            : { kind: 'unconfigured' };
    }
    if (opts.tenantScoped && tenant?.enabled === true) {
        const tenantTransport = resolveEmailTransport(tenant ?? null, opts.unseal);
        if (tenantTransport)
            return { kind: 'transport', transport: tenantTransport, source: 'tenant' };
        return { kind: 'unconfigured' };
    }
    if (platformTransport)
        return { kind: 'transport', transport: platformTransport, source: 'platform' };
    return { kind: 'unconfigured' };
}
// --- Send ------------------------------------------------------------------
function toArray(v) {
    return Array.isArray(v) ? v : [v];
}
function parseAddress(addr) {
    const trimmed = addr.trim();
    if (!trimmed.endsWith('>'))
        return { email: trimmed };
    const opening = trimmed.lastIndexOf('<');
    if (opening === -1)
        return { email: trimmed };
    const email = trimmed.slice(opening + 1, -1).trim();
    const name = trimmed.slice(0, opening).trim();
    return { email, name: name || undefined };
}
const TRANSPORT_TIMEOUT_MS = 30_000;
function sanitizedText(value, redactions = []) {
    let printable = '';
    for (const character of value) {
        const codePoint = character.codePointAt(0);
        printable += codePoint < 32 || codePoint === 127 ? ' ' : character;
    }
    for (const sensitiveValue of [...redactions].filter(Boolean).sort((a, b) => b.length - a.length)) {
        if (sensitiveValue)
            printable = printable.split(sensitiveValue).join('[redacted]');
    }
    return printable.replace(/\s+/g, ' ').trim().slice(0, 300);
}
function errorDetail(body, redactions) {
    if (typeof body === 'string')
        return sanitizedText(body, redactions) || null;
    if (!body || typeof body !== 'object')
        return null;
    const record = body;
    if (Array.isArray(record.errors)) {
        const messages = record.errors
            .map((item) => {
            if (!item || typeof item !== 'object')
                return null;
            const message = item.message;
            return typeof message === 'string' ? sanitizedText(message, redactions) : null;
        })
            .filter((message) => Boolean(message));
        if (messages.length > 0)
            return sanitizedText(messages.join('; '), redactions);
    }
    for (const key of ['message', 'error', 'Message']) {
        const value = record[key];
        if (typeof value === 'string')
            return sanitizedText(value, redactions) || null;
    }
    return null;
}
function providerHttpError(provider, response, body, redactions) {
    const detail = errorDetail(body, redactions);
    return new Error(`${provider}: HTTP ${response.status}${detail ? ` — ${detail}` : ''}`);
}
function providerContractError(provider, detail) {
    return new Error(`${provider}: invalid success response — ${detail}`);
}
function providerNetworkError(provider, error) {
    const name = error && typeof error === 'object' && 'name' in error ? String(error.name) : undefined;
    const reason = name === 'TimeoutError' || name === 'AbortError'
        ? `request timed out after ${TRANSPORT_TIMEOUT_MS / 1000} seconds`
        : 'network request failed';
    return new Error(`${provider}: ${reason}`);
}
async function readResponseBody(provider, response) {
    let text;
    try {
        text = await response.text();
    }
    catch (error) {
        throw providerNetworkError(provider, error);
    }
    if (!text)
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return text;
    }
}
async function providerFetch(provider, url, init) {
    try {
        return await fetch(url, { ...init, signal: AbortSignal.timeout(TRANSPORT_TIMEOUT_MS) });
    }
    catch (error) {
        throw providerNetworkError(provider, error);
    }
}
function responseString(body, key) {
    if (!body || typeof body !== 'object')
        return '';
    const value = body[key];
    return typeof value === 'string' ? value.trim() : '';
}
function providerOperationError(provider, error, redactions) {
    const rawMessage = error instanceof Error ? error.message : String(error);
    const detail = sanitizedText(rawMessage, redactions) || 'delivery failed';
    return new Error(`${provider}: ${detail}`);
}
/** Send an email through a resolved transport. Throws on provider error. */
export async function sendVia(transport, input) {
    const from = transport.from;
    const replyTo = transport.replyTo;
    const normalized = normalizeEmailDeliveryInput(input, { requireSingleRecipient: true });
    switch (transport.provider) {
        case 'resend':
            return sendResend(transport, normalized, from, replyTo);
        case 'sendgrid':
            return sendSendgrid(transport, normalized, from, replyTo);
        case 'mailgun':
            return sendMailgun(transport, normalized, from, replyTo);
        case 'postmark':
            return sendPostmark(transport, normalized, from, replyTo);
        case 'smtp':
            return sendSmtp(transport, normalized, from, replyTo);
    }
}
async function sendResend(t, input, from, replyTo) {
    const res = await providerFetch('Resend', 'https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${t.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
            from,
            to: toArray(input.to),
            subject: input.subject,
            html: input.html,
            text: input.text,
            reply_to: replyTo,
            attachments: input.attachments?.map((a) => ({ filename: a.filename, content: a.content, content_type: a.contentType })),
        }),
    });
    const body = await readResponseBody('Resend', res);
    if (res.status !== 200) {
        if (res.ok)
            throw providerContractError('Resend', `expected HTTP 200, received HTTP ${res.status}`);
        throw providerHttpError('Resend', res, body, [t.apiKey]);
    }
    const id = responseString(body, 'id');
    if (!id)
        throw providerContractError('Resend', 'missing id');
    return { id };
}
async function sendSendgrid(t, input, from, replyTo) {
    const content = [];
    content.push({ type: 'text/plain', value: input.text || ' ' });
    if (input.html)
        content.push({ type: 'text/html', value: input.html });
    const res = await providerFetch('SendGrid', 'https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: { Authorization: `Bearer ${t.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
            personalizations: [{ to: toArray(input.to).map((email) => ({ email })) }],
            from: parseAddress(from),
            reply_to: replyTo ? parseAddress(replyTo) : undefined,
            subject: input.subject,
            content,
            attachments: input.attachments?.map((a) => ({ filename: a.filename, content: a.content, type: a.contentType, disposition: 'attachment' })),
        }),
    });
    if (res.status !== 202) {
        const body = await readResponseBody('SendGrid', res);
        if (res.ok)
            throw providerContractError('SendGrid', `expected HTTP 202, received HTTP ${res.status}`);
        throw providerHttpError('SendGrid', res, body, [t.apiKey]);
    }
    const id = res.headers.get('x-message-id')?.trim();
    if (!id)
        throw providerContractError('SendGrid', 'missing x-message-id header');
    return { id };
}
async function sendMailgun(t, input, from, replyTo) {
    const form = new FormData();
    form.set('from', from);
    for (const to of toArray(input.to))
        form.append('to', to);
    form.set('subject', input.subject);
    if (input.text)
        form.set('text', input.text);
    if (input.html)
        form.set('html', input.html);
    if (replyTo)
        form.set('h:Reply-To', replyTo);
    for (const a of input.attachments ?? []) {
        const blob = new Blob([Buffer.from(a.content, 'base64')], { type: a.contentType || 'application/octet-stream' });
        form.append('attachment', blob, a.filename);
    }
    const base = t.region === 'eu' ? 'https://api.eu.mailgun.net' : 'https://api.mailgun.net';
    const res = await providerFetch('Mailgun', `${base}/v3/${t.domain}/messages`, {
        method: 'POST',
        headers: { Authorization: `Basic ${Buffer.from(`api:${t.apiKey}`).toString('base64')}` },
        body: form,
    });
    const body = await readResponseBody('Mailgun', res);
    if (res.status !== 200) {
        if (res.ok)
            throw providerContractError('Mailgun', `expected HTTP 200, received HTTP ${res.status}`);
        throw providerHttpError('Mailgun', res, body, [t.apiKey]);
    }
    const id = responseString(body, 'id');
    if (!id)
        throw providerContractError('Mailgun', 'missing id');
    return { id };
}
async function sendPostmark(t, input, from, replyTo) {
    const res = await providerFetch('Postmark', 'https://api.postmarkapp.com/email', {
        method: 'POST',
        headers: { 'X-Postmark-Server-Token': t.serverToken, 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
            From: from,
            To: toArray(input.to).join(', '),
            Subject: input.subject,
            HtmlBody: input.html || undefined,
            TextBody: input.text || undefined,
            ReplyTo: replyTo,
            Attachments: input.attachments?.map((a) => ({ Name: a.filename, Content: a.content, ContentType: a.contentType || 'application/octet-stream' })),
        }),
    });
    const body = await readResponseBody('Postmark', res);
    if (res.status !== 200) {
        if (res.ok)
            throw providerContractError('Postmark', `expected HTTP 200, received HTTP ${res.status}`);
        throw providerHttpError('Postmark', res, body, [t.serverToken]);
    }
    const json = body && typeof body === 'object' ? body : null;
    if (!json || json.ErrorCode !== 0)
        throw providerHttpError('Postmark', res, body, [t.serverToken]);
    const id = responseString(body, 'MessageID');
    if (!id)
        throw providerContractError('Postmark', 'missing MessageID');
    return { id };
}
async function sendSmtp(t, input, from, replyTo) {
    if (t.mode === 'database' && Boolean(t.username) !== Boolean(t.password)) {
        throw new Error('SMTP: username and password must both be provided, or both omitted for an unauthenticated relay');
    }
    const redactions = t.mode === 'database' ? [t.password ?? '', t.username ?? ''].filter(Boolean) : [];
    let connectionOptions;
    if (t.mode === 'local-dev') {
        if (process.env.NODE_ENV !== 'development')
            throw new Error('SMTP: local-dev transport is forbidden outside development mode');
        const host = t.host.trim().toLowerCase();
        const address = host === 'localhost' || host === 'localhost.localdomain' || host === '127.0.0.1'
            ? '127.0.0.1'
            : host === '::1' || host === '[::1]'
                ? '::1'
                : null;
        if (!address)
            throw new Error('SMTP: local-dev transport requires a loopback host');
        const runtime = t;
        if (runtime.username || runtime.password)
            throw new Error('SMTP: local-dev transport does not permit authentication');
        connectionOptions = {
            host: address,
            port: t.port,
            secure: false,
            ignoreTLS: true,
            connectionTimeout: TRANSPORT_TIMEOUT_MS,
            greetingTimeout: TRANSPORT_TIMEOUT_MS,
            socketTimeout: TRANSPORT_TIMEOUT_MS,
        };
    }
    else {
        let resolved;
        try {
            resolved = await resolvePublicHost(t.host, { timeoutMs: TRANSPORT_TIMEOUT_MS });
            if (resolved.ipLiteral)
                throw new Error('External SMTP host must be a DNS name so its TLS identity can be verified.');
        }
        catch (error) {
            throw providerOperationError('SMTP', error, redactions);
        }
        connectionOptions = {
            host: resolved.address,
            family: resolved.family,
            port: t.port,
            secure: t.secure,
            requireTLS: !t.secure,
            auth: t.username ? { user: t.username, pass: t.password } : undefined,
            tls: { rejectUnauthorized: true, servername: resolved.hostname },
            connectionTimeout: TRANSPORT_TIMEOUT_MS,
            greetingTimeout: TRANSPORT_TIMEOUT_MS,
            socketTimeout: TRANSPORT_TIMEOUT_MS,
        };
    }
    // Dynamic import keeps nodemailer out of the load path unless SMTP is used.
    const nodemailer = (await import('nodemailer')).default;
    let info;
    try {
        const tx = nodemailer.createTransport(connectionOptions);
        info = await tx.sendMail({
            from,
            to: toArray(input.to),
            subject: input.subject,
            text: input.text,
            html: input.html,
            replyTo,
            attachments: input.attachments?.map((a) => ({ filename: a.filename, content: Buffer.from(a.content, 'base64'), contentType: a.contentType })),
        });
    }
    catch (error) {
        throw providerOperationError('SMTP', error, redactions);
    }
    const id = typeof info.messageId === 'string' ? info.messageId.trim() : '';
    if (!id)
        throw providerContractError('SMTP', 'missing messageId');
    return { id };
}
//# sourceMappingURL=transport.js.map