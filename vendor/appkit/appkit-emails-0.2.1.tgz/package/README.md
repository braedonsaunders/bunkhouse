# @appkit/emails

Email delivery — Resend, SendGrid, Mailgun, Postmark, and SMTP transports with sealed-secret config and platform→tenant policy.

## Install

```bash
pnpm add @appkit/emails
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
