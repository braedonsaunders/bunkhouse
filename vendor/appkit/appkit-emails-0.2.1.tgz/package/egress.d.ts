export type ResolvedHost = {
    address: string;
    family: number;
    hostname: string;
    ipLiteral: boolean;
};
export declare function resolvePublicHost(host: string, _opts?: {
    timeoutMs?: number;
}): Promise<ResolvedHost>;
//# sourceMappingURL=egress.d.ts.map