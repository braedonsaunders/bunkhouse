import { type EmailProvider } from './providers.js';
import { type EmailAttachmentPayload, type EmailDeliveryInput } from './delivery-input.js';
export type EmailAttachment = EmailAttachmentPayload;
export type SendEmailInput = EmailDeliveryInput;
export type RawEmailConfig = {
    enabled?: boolean;
    provider?: EmailProvider;
    fromName?: string;
    fromEmail?: string;
    replyTo?: string;
    mailgunDomain?: string;
    mailgunRegion?: 'us' | 'eu';
    smtpHost?: string;
    smtpPort?: number;
    smtpSecure?: boolean;
    smtpUsername?: string;
    /** The single sealed secret (api key / server token / smtp password). */
    keyCiphertext?: string;
    keyNonce?: string;
};
export type EmailPolicyMode = 'tenant_optional' | 'global_only' | 'disabled';
export declare function isEmailPolicyMode(value: unknown): value is EmailPolicyMode;
export type PlatformEmailConfig = RawEmailConfig & {
    mode?: EmailPolicyMode;
};
type PlainEmailConfig = Omit<RawEmailConfig, 'keyCiphertext' | 'keyNonce'> & {
    secret?: string;
};
/** Unseal a stored secret → plaintext. Supplied by the app (its crypto). */
export type Unseal = (sealed: {
    ciphertext: string;
    nonce: string;
}) => string | null;
export declare function validateStoredEmailConfig(raw: RawEmailConfig | PlatformEmailConfig, options?: {
    requireComplete?: boolean;
}): void;
export type EmailTransport = {
    provider: 'resend';
    apiKey: string;
    from: string;
    replyTo?: string;
} | {
    provider: 'sendgrid';
    apiKey: string;
    from: string;
    replyTo?: string;
} | {
    provider: 'mailgun';
    apiKey: string;
    domain: string;
    region: 'us' | 'eu';
    from: string;
    replyTo?: string;
} | {
    provider: 'postmark';
    serverToken: string;
    from: string;
    replyTo?: string;
} | {
    provider: 'smtp';
    mode: 'database';
    host: string;
    port: number;
    secure: boolean;
    username?: string;
    password?: string;
    from: string;
    replyTo?: string;
} | {
    provider: 'smtp';
    mode: 'local-dev';
    host: string;
    port: number;
    secure: false;
    from: string;
    replyTo?: string;
};
/** Build a transport from already-plaintext config, or null when incomplete. */
export declare function buildTransport(c: PlainEmailConfig): EmailTransport | null;
/** Unseal a stored config and build its transport, or null when not configured. */
export declare function resolveEmailTransport(raw: RawEmailConfig | null | undefined, unseal: Unseal): EmailTransport | null;
export type EffectiveEmail = {
    kind: 'suppressed';
} | {
    kind: 'transport';
    transport: EmailTransport;
    source: 'tenant' | 'platform';
} | {
    kind: 'unconfigured';
};
/**
 * The platform → tenant resolution policy, as a pure function (unit-testable):
 *   'disabled'        → suppressed (kill switch)
 *   'global_only'     → platform provider, else unconfigured
 *   'tenant_optional' → tenant provider (if scoped + configured), else platform.
 * `tenantScoped` is false for platform sends so a tenant provider never sends a
 * non-tenant email. A configured-but-broken tenant override fails closed.
 */
export declare function resolveEffectiveTransport(platform: PlatformEmailConfig | null | undefined, tenant: RawEmailConfig | null | undefined, opts: {
    tenantScoped: boolean;
    unseal: Unseal;
}): EffectiveEmail;
/** Send an email through a resolved transport. Throws on provider error. */
export declare function sendVia(transport: EmailTransport, input: SendEmailInput): Promise<{
    id: string;
}>;
export {};
//# sourceMappingURL=transport.d.ts.map