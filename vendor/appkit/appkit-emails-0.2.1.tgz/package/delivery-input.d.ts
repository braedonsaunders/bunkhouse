export type EmailAttachmentPayload = {
    filename: string;
    /** base64-encoded content. */
    content: string;
    contentType?: string;
};
export type EmailDeliveryInput = {
    to: string | string[];
    subject: string;
    html?: string;
    text?: string;
    attachments?: EmailAttachmentPayload[];
};
export declare function isValidEmailAddress(value: string): boolean;
/** Validate + normalize recipients/subject/body before a send. */
export declare function normalizeEmailDeliveryInput(input: EmailDeliveryInput, opts?: {
    requireSingleRecipient?: boolean;
}): EmailDeliveryInput;
//# sourceMappingURL=delivery-input.d.ts.map