export type EmailProvider = 'resend' | 'sendgrid' | 'mailgun' | 'postmark' | 'smtp';
export type EmailFieldKind = 'text' | 'number' | 'boolean' | 'select';
export type EmailProviderField = {
    key: string;
    kind: EmailFieldKind;
    label: string;
    placeholder?: string;
    required?: boolean;
    options?: {
        value: string;
        label: string;
    }[];
    help?: string;
};
export type EmailProviderSpec = {
    value: EmailProvider;
    label: string;
    /** Whether this provider authenticates with a single sealed secret. */
    hasSecret: boolean;
    /** Label for the single sealed secret (api key / server token / password). */
    secretLabel: string;
    /** Placeholder shown in the secret field. */
    keyHint: string;
    /** Whether the secret is mandatory (SMTP can be open-relay / Mailpit). */
    secretRequired: boolean;
    /** Extra non-secret config fields this provider needs. */
    fields: EmailProviderField[];
    /** Optional note shown under the provider picker. */
    docsHint?: string;
};
export declare const EMAIL_PROVIDER_SPECS: EmailProviderSpec[];
export declare function isEmailProvider(value: unknown): value is EmailProvider;
//# sourceMappingURL=providers.d.ts.map