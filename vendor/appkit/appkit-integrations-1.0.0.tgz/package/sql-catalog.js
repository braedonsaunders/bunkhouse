export { SQL_DESTINATION_SUMMARY } from './destination-catalog.js';
//# sourceMappingURL=sql-catalog.js.map