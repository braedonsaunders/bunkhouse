import { type ReactNode } from 'react';
export type IntegrationDirection = 'in' | 'out';
export type IntegrationCatalogItem = {
    key: string;
    addValue: string;
    name: string;
    description: string;
    direction: IntegrationDirection;
    iconKey: string;
    detail: string;
    added: boolean;
    addedHref?: string;
};
export type IntegrationLinkRender = (props: {
    href: string;
    className?: string;
    children: ReactNode;
}) => ReactNode;
export declare function IntegrationCatalog({ items, onAdd, linkRender, }: {
    items: readonly IntegrationCatalogItem[];
    onAdd: (item: IntegrationCatalogItem) => void | Promise<void>;
    linkRender?: IntegrationLinkRender;
}): import("react").JSX.Element;
export declare function DirectionPill({ direction, }: {
    direction: IntegrationDirection;
}): import("react").JSX.Element;
//# sourceMappingURL=integration-catalog.d.ts.map