import type { DestinationDef } from './types.js';
export declare const sheetsDestination: DestinationDef;
//# sourceMappingURL=sheets.d.ts.map