'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useMemo, useState } from 'react';
import { ArrowUpRight, Building2, Check, Database, FileSpreadsheet, Plug, PlugZap, Plus, Search, Upload, } from 'lucide-react';
import { Button, Input, cn } from '@appkit/ui';
const ICONS = {
    database: Database,
    'building-2': Building2,
    'file-spreadsheet': FileSpreadsheet,
    'plug-zap': PlugZap,
    upload: Upload,
};
export function IntegrationCatalog({ items, onAdd, linkRender, }) {
    const [query, setQuery] = useState('');
    const [filter, setFilter] = useState('all');
    const filtered = useMemo(() => {
        const term = query.trim().toLowerCase();
        return items.filter((item) => (filter === 'all' || item.direction === filter) &&
            (!term ||
                `${item.name} ${item.description} ${item.detail}`
                    .toLowerCase()
                    .includes(term)));
    }, [filter, items, query]);
    return (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [_jsxs("div", { className: "relative w-full sm:max-w-xs", children: [_jsx(Search, { size: 15, className: "pointer-events-none absolute top-1/2 left-2.5 -translate-y-1/2 text-fg-muted" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Search integrations", className: "pl-8", "aria-label": "Search integrations" })] }), _jsx(DirectionFilter, { value: filter, onChange: setFilter })] }), !filtered.length ? (_jsxs("div", { className: "rounded-xl border border-dashed border-border py-12 text-center text-sm text-fg-muted", children: ["No integrations match", query.trim() ? ` “${query.trim()}”` : '', "."] })) : (_jsx("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3", children: filtered.map((item) => (_jsx(CatalogCard, { item: item, onAdd: onAdd, linkRender: linkRender }, item.key))) }))] }));
}
function DirectionFilter({ value, onChange, }) {
    const options = [
        ['all', 'All'],
        ['in', 'Sync in'],
        ['out', 'Push out'],
    ];
    return (_jsx("div", { className: "inline-flex rounded-lg border border-border bg-surface-hover p-0.5 text-sm", children: options.map(([option, label]) => (_jsx("button", { type: "button", onClick: () => onChange(option), className: cn('rounded-md px-3 py-1 font-medium transition', value === option
                ? 'bg-surface text-fg shadow-sm'
                : 'text-fg-muted hover:text-fg'), children: label }, option))) }));
}
function CatalogCard({ item, onAdd, linkRender, }) {
    const Icon = ICONS[item.iconKey] ?? Plug;
    const open = item.addedHref ? (_jsxs("span", { className: "inline-flex items-center gap-1 text-sm font-medium text-primary", children: [_jsx(Check, { size: 14 }), " Added ", _jsx(ArrowUpRight, { size: 13 })] })) : null;
    return (_jsxs("div", { className: "flex flex-col rounded-xl border border-border bg-surface p-4 transition hover:border-primary/40 hover:shadow-sm", children: [_jsxs("div", { className: "flex items-start gap-3", children: [_jsx("span", { className: "grid size-10 shrink-0 place-items-center rounded-lg bg-surface-hover text-fg-muted ring-1 ring-border-subtle", children: _jsx(Icon, { size: 18 }) }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("p", { className: "truncate font-semibold text-fg", children: item.name }), _jsx("div", { className: "mt-0.5", children: _jsx(DirectionPill, { direction: item.direction }) })] })] }), _jsx("p", { className: "mt-2.5 line-clamp-2 text-xs text-fg-muted", children: item.description }), _jsx("p", { className: "mt-auto pt-2 text-[11px] text-fg-subtle", children: item.detail }), _jsx("div", { className: "mt-3 flex justify-end border-t border-border-subtle pt-3", children: item.added && item.addedHref && open ? (linkRender ? (linkRender({
                    href: item.addedHref,
                    className: 'inline-flex items-center',
                    children: open,
                })) : (_jsx("a", { href: item.addedHref, children: open }))) : (_jsxs(Button, { type: "button", size: "sm", variant: "outline", onClick: () => void onAdd(item), children: [_jsx(Plus, { size: 14 }), " Add"] })) })] }));
}
export function DirectionPill({ direction, }) {
    return (_jsx("span", { className: cn('inline-flex rounded-full px-1.5 py-0.5 text-[10px] font-semibold tracking-wide uppercase', direction === 'in'
            ? 'bg-primary-subtle text-primary'
            : 'bg-warning-subtle text-warning'), children: direction === 'in' ? 'Sync in' : 'Push out' }));
}
//# sourceMappingURL=integration-catalog.js.map