import type { FieldDefinition, IntegrationEvent, IntegrationItem, TriggerDefinition } from './types.js';
export type TriggerCatalog = ReturnType<typeof createTriggerCatalog>;
export declare function createTriggerCatalog(definitions: readonly TriggerDefinition[]): {
    list: () => TriggerDefinition[];
    get: (key: string | null | undefined) => TriggerDefinition | undefined;
    require(key: string): TriggerDefinition;
    sampleItem(key: string): IntegrationItem;
    event(input: {
        key: string;
        tenantId: string;
        subjectId: string;
        items: IntegrationItem[];
    }): IntegrationEvent;
};
export declare function field(key: string, label: string, type: FieldDefinition['type'], options?: Pick<FieldDefinition, 'sample' | 'note'>): FieldDefinition;
//# sourceMappingURL=trigger-catalog.d.ts.map