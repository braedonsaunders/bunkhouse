export function outboundDispatchJobId(sourceEventId, automationId) {
    return `domain-outbound|${sourceEventId}|${automationId}`;
}
/**
 * Production event publisher extracted from the reference worker boundary.
 * The application supplies its durable queue, keeping this package independent
 * of any particular jobs implementation.
 */
export function createIntegrationPublisher(options) {
    return async function publishIntegrationEvent(context, event, sourceEventId) {
        if (event.tenantId !== context.tenantId)
            throw new Error('Integration event tenant does not match the publisher context');
        const ids = await options.store.listMatching(context.tenantId, event.type);
        await Promise.all(ids.map((automationId) => options.enqueueOutboundDispatch({ tenantId: context.tenantId, automationId, event }, outboundDispatchJobId(sourceEventId, automationId))));
    };
}
//# sourceMappingURL=publisher.js.map