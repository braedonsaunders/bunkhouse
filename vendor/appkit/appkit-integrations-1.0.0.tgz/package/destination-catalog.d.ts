import type { DestinationDef } from './types.js';
export type DestinationSummary = Pick<DestinationDef, 'key' | 'name' | 'description' | 'iconKey' | 'mappingKind' | 'reversible'>;
export declare const HTTP_DESTINATION_SUMMARY: {
    readonly key: "http";
    readonly name: "HTTP / REST request";
    readonly description: "POST, PUT or PATCH a token-templated body to a public HTTPS URL with custom headers and an optional bearer/API-key. Use for REST APIs, webhooks and automation hooks.";
    readonly iconKey: "webhook";
    readonly mappingKind: "http";
    readonly reversible: false;
};
export declare const CHAT_DESTINATION_SUMMARY: {
    readonly key: "slack";
    readonly name: "Slack / Teams message";
    readonly description: "Post a formatted message to a Slack or Microsoft Teams channel via a public HTTPS incoming-webhook URL. Combine a multi-item trigger into one message or send one each.";
    readonly iconKey: "message-square";
    readonly mappingKind: "slack";
    readonly reversible: false;
};
export declare const SHEETS_DESTINATION_SUMMARY: {
    readonly key: "sheets";
    readonly name: "Google Sheets";
    readonly description: "Append a row per item to a Google Sheet. Authenticates with a service-account key (no interactive sign-in) — share the sheet with the service account as an Editor.";
    readonly iconKey: "sheet";
    readonly mappingKind: "sheets";
    readonly reversible: false;
};
export declare const EMAIL_DESTINATION_SUMMARY: {
    readonly key: "email";
    readonly name: "Email";
    readonly description: "Send a bounded, sanitized, token-templated email through an app-provided transport.";
    readonly iconKey: "mail";
    readonly mappingKind: "email";
    readonly reversible: false;
};
export declare const SQL_DESTINATION_SUMMARY: {
    readonly key: "sql";
    readonly name: "External SQL database";
    readonly description: "Insert mapped rows into PostgreSQL, MySQL, MariaDB, or SQL Server over verified TLS. Supports weekly fan-out, required-field filtering, value maps, and identity-based reversal before retry.";
    readonly iconKey: "database";
    readonly mappingKind: "sql";
    readonly reversible: true;
};
export declare const INTEGRATION_DESTINATION_CATALOG: readonly [{
    readonly key: "http";
    readonly name: "HTTP / REST request";
    readonly description: "POST, PUT or PATCH a token-templated body to a public HTTPS URL with custom headers and an optional bearer/API-key. Use for REST APIs, webhooks and automation hooks.";
    readonly iconKey: "webhook";
    readonly mappingKind: "http";
    readonly reversible: false;
}, {
    readonly key: "slack";
    readonly name: "Slack / Teams message";
    readonly description: "Post a formatted message to a Slack or Microsoft Teams channel via a public HTTPS incoming-webhook URL. Combine a multi-item trigger into one message or send one each.";
    readonly iconKey: "message-square";
    readonly mappingKind: "slack";
    readonly reversible: false;
}, {
    readonly key: "sheets";
    readonly name: "Google Sheets";
    readonly description: "Append a row per item to a Google Sheet. Authenticates with a service-account key (no interactive sign-in) — share the sheet with the service account as an Editor.";
    readonly iconKey: "sheet";
    readonly mappingKind: "sheets";
    readonly reversible: false;
}, {
    readonly key: "email";
    readonly name: "Email";
    readonly description: "Send a bounded, sanitized, token-templated email through an app-provided transport.";
    readonly iconKey: "mail";
    readonly mappingKind: "email";
    readonly reversible: false;
}, {
    readonly key: "sql";
    readonly name: "External SQL database";
    readonly description: "Insert mapped rows into PostgreSQL, MySQL, MariaDB, or SQL Server over verified TLS. Supports weekly fan-out, required-field filtering, value maps, and identity-based reversal before retry.";
    readonly iconKey: "database";
    readonly mappingKind: "sql";
    readonly reversible: true;
}];
//# sourceMappingURL=destination-catalog.d.ts.map