'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useId, useMemo, useRef, useState, useTransition, } from 'react';
import { AlertCircle, CheckCircle2, Loader2, Plus, Send, Trash2, Zap, } from 'lucide-react';
import { Button, Input, Label, Select, Textarea, cn } from '@appkit/ui';
import { readIntegrationEditorSubmission, } from './authoring.js';
const DEFAULT_COPY = {
    name: 'Automation name',
    namePlaceholder: 'e.g. Send approved records to operations',
    triggerTitle: 'Choose a trigger',
    triggerSubtitle: 'Select the application event that starts this automation.',
    triggerPlaceholder: 'Select a trigger…',
    destinationTitle: 'Choose a destination',
    destinationSubtitle: 'Select where the event data should be delivered.',
    destinationPlaceholder: 'Select a destination…',
    configurationTitle: 'Configure and map',
    configurationSubtitle: 'Connect the service and map trigger tokens to destination fields.',
    enabled: 'Enable automation',
    oncePerRecord: 'Send only once per record',
    test: 'Test connection',
    testing: 'Testing…',
    save: 'Save automation',
    saving: 'Saving…',
    tokenTitle: 'Available tokens',
    tokenHelp: 'Focus a mapping field, then choose a token to insert it.',
    noTrigger: 'Choose a trigger to see its available data.',
};
export function IntegrationBuilder({ id, initial, triggers, destinations, onSave, onTest, copy: copyOverrides, }) {
    const copy = { ...DEFAULT_COPY, ...copyOverrides };
    const formRef = useRef(null);
    const activeElement = useRef(null);
    const [triggerKey, setTriggerKey] = useState(initial.triggerKey);
    const [destinationKey, setDestinationKey] = useState(initial.destinationKey);
    const [pending, startTransition] = useTransition();
    const [action, setAction] = useState(null);
    const [result, setResult] = useState(null);
    const trigger = useMemo(() => triggers.find((entry) => entry.key === triggerKey), [triggerKey, triggers]);
    const destination = useMemo(() => destinations.find((entry) => entry.key === destinationKey), [destinationKey, destinations]);
    const register = (event) => {
        activeElement.current = event.currentTarget;
    };
    const insertToken = (token) => {
        const element = activeElement.current;
        if (!element)
            return;
        const start = element.selectionStart ?? element.value.length;
        const end = element.selectionEnd ?? element.value.length;
        const value = `{{${token}}}`;
        element.value =
            element.value.slice(0, start) + value + element.value.slice(end);
        const cursor = start + value.length;
        element.focus();
        element.setSelectionRange(cursor, cursor);
    };
    const submission = () => {
        const form = formRef.current;
        if (!form || !destination)
            return null;
        return readIntegrationEditorSubmission({
            destination,
            formData: new FormData(form),
            baseConfig: initial.config,
        });
    };
    const runTest = () => {
        const value = submission();
        if (!value || !onTest)
            return;
        setResult(null);
        setAction('test');
        startTransition(async () => {
            try {
                setResult(await onTest(value));
            }
            catch (error) {
                setResult({
                    ok: false,
                    message: error instanceof Error ? error.message : 'Test failed.',
                });
            }
            finally {
                setAction(null);
            }
        });
    };
    return (_jsxs("form", { ref: formRef, className: "space-y-6", onSubmit: (event) => {
            event.preventDefault();
            const value = submission();
            if (!value)
                return;
            setResult(null);
            setAction('save');
            startTransition(async () => {
                try {
                    const saved = await onSave(value);
                    if (saved)
                        setResult(saved);
                }
                catch (error) {
                    setResult({
                        ok: false,
                        message: error instanceof Error ? error.message : 'Save failed.',
                    });
                }
                finally {
                    setAction(null);
                }
            });
        }, children: [_jsx("input", { type: "hidden", name: "id", value: id }), _jsx("input", { type: "hidden", name: "destinationKey", value: destinationKey }), _jsx(Field, { label: copy.name, children: _jsx(Input, { name: "name", defaultValue: initial.name, placeholder: copy.namePlaceholder, onFocus: register }) }), _jsxs(Section, { step: 1, title: copy.triggerTitle, subtitle: copy.triggerSubtitle, children: [_jsxs(Select, { name: "triggerKey", value: triggerKey, onChange: (event) => setTriggerKey(event.target.value), "aria-label": copy.triggerTitle, children: [_jsx("option", { value: "", children: copy.triggerPlaceholder }), triggers.map((entry) => (_jsx("option", { value: entry.key, children: entry.label }, entry.key)))] }), trigger ? (_jsx("p", { className: "text-xs text-fg-muted", children: trigger.description })) : null] }), _jsxs(Section, { step: 2, title: copy.destinationTitle, subtitle: copy.destinationSubtitle, children: [_jsxs(Select, { value: destinationKey, onChange: (event) => {
                            setDestinationKey(event.target.value);
                            setResult(null);
                        }, "aria-label": copy.destinationTitle, children: [_jsx("option", { value: "", children: copy.destinationPlaceholder }), destinations.map((entry) => (_jsx("option", { value: entry.key, children: entry.name }, entry.key)))] }), destination ? (_jsx("p", { className: "text-xs text-fg-muted", children: destination.description })) : null] }), destination ? (_jsx(Section, { step: 3, title: copy.configurationTitle, subtitle: copy.configurationSubtitle, children: _jsxs("div", { className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_220px]", children: [_jsxs("div", { className: "min-w-0 space-y-4", children: [destination.configFields.length ? (_jsx("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: destination.configFields.map((field) => (_jsx(FieldInput, { field: field, value: initial.config[field.key], onFocus: register }, field.key))) })) : null, destination.secretFields.length ? (_jsx("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: destination.secretFields.map((secret) => (_jsx(Field, { label: secret.label, required: secret.required, help: secret.help, children: _jsx(Input, { name: secret.key, type: "password", autoComplete: "new-password", placeholder: initial.secretsPresent[secret.key]
                                                ? 'Leave blank to keep the stored value'
                                                : '' }) }, secret.key))) })) : null, _jsx(MappingEditor, { destination: destination, mapping: initial.mapping, register: register })] }), _jsx(TokenPanel, { trigger: trigger, onInsert: insertToken, copy: copy })] }) })) : null, _jsxs("div", { className: "space-y-3 border-t border-border-subtle pt-4", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-x-6 gap-y-2", children: [_jsx(Check, { name: "enabled", defaultChecked: initial.enabled, label: copy.enabled }), destination && !destination.reversible ? (_jsx(Check, { name: "oncePerRecord", defaultChecked: initial.oncePerRecord, label: copy.oncePerRecord })) : null] }), result ? _jsx(ResultBanner, { result: result }) : null, _jsxs("div", { className: "flex items-center justify-end gap-2", children: [destination && onTest ? (_jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: runTest, disabled: pending, children: [pending && action === 'test' ? (_jsx(Loader2, { size: 14, className: "animate-spin" })) : (_jsx(Send, { size: 14 })), pending && action === 'test' ? copy.testing : copy.test] })) : null, _jsxs(Button, { type: "submit", disabled: pending || !destination, children: [pending && action === 'save' ? (_jsx(Loader2, { size: 14, className: "animate-spin" })) : (_jsx(Zap, { size: 14 })), pending && action === 'save' ? copy.saving : copy.save] })] })] })] }));
}
function ResultBanner({ result }) {
    return (_jsxs("div", { className: cn('flex items-start gap-2 rounded-lg border px-3 py-2 text-sm', result.ok
            ? 'border-success/40 bg-success-subtle text-success'
            : 'border-danger/40 bg-danger-subtle text-danger'), role: "status", children: [result.ok ? (_jsx(CheckCircle2, { size: 15, className: "mt-0.5 shrink-0" })) : (_jsx(AlertCircle, { size: 15, className: "mt-0.5 shrink-0" })), _jsx("span", { className: "break-words", children: result.message })] }));
}
function MappingEditor({ destination, mapping, register, }) {
    if (destination.mappingKind === 'sql')
        return _jsx(SqlMapping, { mapping: mapping, register: register });
    if (destination.mappingKind === 'http')
        return _jsx(HttpMapping, { mapping: mapping, register: register });
    if (destination.mappingKind === 'sheets')
        return _jsx(SheetsMapping, { mapping: mapping, register: register });
    if (destination.mappingKind === 'slack')
        return (_jsxs("div", { className: "space-y-3", children: [_jsx(Field, { label: "Message template", help: "The channel message. Insert tokens from the panel.", children: _jsx(Textarea, { name: "map-text", rows: 4, defaultValue: String(mapping.text ?? ''), onFocus: register, placeholder: "Record {{reference}} is ready" }) }), _jsx(Field, { label: "Block Kit JSON", help: "Optional Slack Block Kit array. It overrides plain text and sends one rich message per item.", children: _jsx(Textarea, { name: "map-blocks", rows: 4, className: "font-mono text-xs", defaultValue: String(mapping.blocks ?? ''), onFocus: register, placeholder: '[{"type":"section","text":{"type":"mrkdwn","text":"{{reference}}"}}]' }) })] }));
    return (_jsx(Field, { label: "Email body", help: "Insert tokens from the panel. Sanitized basic HTML is supported.", children: _jsx(Textarea, { name: "map-body", rows: 6, className: "font-mono text-xs", defaultValue: String(mapping.body ?? ''), onFocus: register, placeholder: "<p>{{reference}} is ready.</p>" }) }));
}
function SqlMapping({ mapping, register, }) {
    const rows = Object.entries(mapping.columns ?? {}).map(([name, value], index) => ({
        id: `existing-${index}`,
        name,
        value: value == null ? 'null' : String(value),
    }));
    return (_jsxs("div", { className: "space-y-3", children: [_jsxs("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: [_jsx(Field, { label: "Table", required: true, children: _jsx(Input, { name: "map-table", defaultValue: String(mapping.table ?? ''), placeholder: "time_entries" }) }), _jsx(Field, { label: "Identity column", help: "Required so partial retries can remove completed inserts before trying again.", required: true, children: _jsx(Input, { name: "map-idColumn", defaultValue: String(mapping.idColumn ?? ''), placeholder: "id" }) }), _jsx(Field, { label: "Row mode", children: _jsxs(Select, { name: "map-mode", defaultValue: mapping.mode === 'weekly' ? 'weekly' : 'row', children: [_jsx("option", { value: "row", children: "One row per item" }), _jsx("option", { value: "weekly", children: "One row per item per week" })] }) }), _jsx(Field, { label: "Required source field", help: "Items missing this field are skipped.", children: _jsx(Input, { name: "map-requireField", defaultValue: String(mapping.requireField ?? ''), placeholder: "externalEmployeeId", onFocus: register }) })] }), _jsx(Field, { label: "Value map", help: 'One per line: "Source value = external id". The mapped value is available as {{department}}.', children: _jsx(Textarea, { name: "map-departmentMap", rows: 2, className: "font-mono text-xs", defaultValue: String(mapping.departmentMap ?? ''), placeholder: 'Operations = 10\nAdministration = 20' }) }), _jsx(MappingRows, { initial: rows.length ? rows : [{ id: 'empty-0', name: '', value: '' }], addLabel: "Add column", render: (row) => (_jsxs(_Fragment, { children: [_jsx(Input, { name: "col-name", defaultValue: row.name, placeholder: "column_name", className: "sm:w-40" }), _jsx(Input, { name: "col-val", defaultValue: row.value, placeholder: "{{field}} or a literal", onFocus: register, className: "flex-1" })] })) })] }));
}
function HttpMapping({ mapping, register, }) {
    const rows = Object.entries(mapping.headers ?? {}).map(([name, value], index) => ({
        id: `existing-${index}`,
        name,
        value: String(value),
    }));
    return (_jsxs("div", { className: "space-y-3", children: [_jsx(MappingRows, { label: "Request headers", initial: rows, addLabel: "Add header", render: (row) => (_jsxs(_Fragment, { children: [_jsx(Input, { name: "hdr-key", defaultValue: row.name, placeholder: "X-Record", className: "sm:w-44" }), _jsx(Input, { name: "hdr-val", defaultValue: row.value, placeholder: "{{reference}}", onFocus: register, className: "flex-1" })] })) }), _jsx(Field, { label: "Request body", help: "The body sent once per item.", children: _jsx(Textarea, { name: "map-body", rows: 7, className: "font-mono text-xs", defaultValue: String(mapping.body ?? ''), onFocus: register, placeholder: '{"reference":"{{reference}}"}' }) })] }));
}
function SheetsMapping({ mapping, register, }) {
    const rows = (Array.isArray(mapping.values) ? mapping.values : []).map((value, index) => ({
        id: `existing-${index}`,
        name: '',
        value: value == null ? '' : String(value),
    }));
    return (_jsx(MappingRows, { label: "Row cells", help: "Add cells in sheet column order. Tokens and typed literals are supported.", initial: rows.length ? rows : [{ id: 'empty-0', name: '', value: '' }], addLabel: "Add cell", render: (row) => (_jsx(Input, { name: "val-expr", defaultValue: row.value, placeholder: "{{field}} or a literal", onFocus: register, className: "flex-1" })) }));
}
function MappingRows({ initial, render, addLabel, label = 'Column mapping', help = 'Map each destination field to a trigger token or typed literal.', }) {
    const id = useId();
    const sequence = useRef(initial.length);
    const [rows, setRows] = useState(initial);
    return (_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: label }), _jsx("p", { className: "text-xs text-fg-muted", children: help }), _jsx(RowList, { rows: rows, setRows: setRows, render: render, addLabel: addLabel, nextId: () => `${id}-${sequence.current++}` })] }));
}
function RowList({ rows, setRows, render, addLabel, nextId, }) {
    return (_jsxs("div", { className: "space-y-2", children: [rows.map((row) => (_jsxs("div", { className: "flex items-center gap-2", children: [render(row), _jsx("button", { type: "button", onClick: () => setRows((current) => current.filter((entry) => entry.id !== row.id)), className: "rounded p-1.5 text-fg-subtle hover:bg-danger-subtle hover:text-danger", title: "Remove row", "aria-label": "Remove row", children: _jsx(Trash2, { size: 14 }) })] }, row.id))), _jsxs("button", { type: "button", onClick: () => setRows((current) => [
                    ...current,
                    { id: nextId(), name: '', value: '' },
                ]), className: "inline-flex items-center gap-1 text-sm font-medium text-primary hover:text-primary/80", children: [_jsx(Plus, { size: 14 }), " ", addLabel] })] }));
}
function TokenPanel({ trigger, onInsert, copy, }) {
    if (!trigger)
        return (_jsx("aside", { className: "rounded-lg border border-dashed border-border p-3 text-xs text-fg-muted", children: copy.noTrigger }));
    return (_jsxs("aside", { className: "space-y-2 rounded-lg border border-border bg-surface-hover p-3", children: [_jsx("p", { className: "text-xs font-semibold text-fg", children: copy.tokenTitle }), _jsx("p", { className: "text-[11px] text-fg-muted", children: copy.tokenHelp }), _jsx("div", { className: "flex flex-wrap gap-1.5", children: trigger.fields.map((field) => (_jsx("button", { type: "button", onClick: () => onInsert(field.key), title: `{{${field.key}}}`, className: "rounded-md border border-border bg-surface px-2 py-1 text-[11px] text-fg-muted hover:border-primary/40 hover:text-primary", children: field.label }, field.key))) }), trigger.dynamicFieldsNote ? (_jsx("p", { className: "text-[11px] text-fg-muted", children: trigger.dynamicFieldsNote })) : null] }));
}
function Section({ step, title, subtitle, children, }) {
    return (_jsxs("section", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "grid size-6 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-fg", children: step }), _jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: title }), _jsx("p", { className: "text-xs text-fg-muted", children: subtitle })] })] }), _jsx("div", { className: "pl-8", children: children })] }));
}
function Field({ label, required, help, children, }) {
    return (_jsxs("div", { className: "space-y-1.5", children: [_jsxs(Label, { children: [label, required ? _jsx("span", { className: "text-danger", children: " *" }) : null] }), children, help ? _jsx("p", { className: "text-xs text-fg-muted", children: help }) : null] }));
}
function FieldInput({ field, value, onFocus, }) {
    const stringValue = value == null ? '' : String(value);
    return (_jsxs("div", { className: cn('space-y-1.5', field.type === 'textarea' && 'sm:col-span-2'), children: [_jsxs(Label, { htmlFor: field.key, children: [field.label, field.required ? _jsx("span", { className: "text-danger", children: " *" }) : null] }), field.type === 'textarea' ? (_jsx(Textarea, { id: field.key, name: field.key, rows: 4, defaultValue: stringValue, placeholder: field.placeholder, className: "font-mono text-xs", onFocus: onFocus })) : field.type === 'select' ? (_jsx(Select, { id: field.key, name: field.key, defaultValue: stringValue, children: (field.options ?? []).map((option) => (_jsx("option", { value: option.value, children: option.label }, option.value))) })) : field.type === 'boolean' ? (_jsx("div", { className: "pt-1", children: _jsx("input", { type: "checkbox", name: field.key, defaultChecked: value === true || value === 'true', className: "size-4 rounded border-border text-primary focus:ring-primary" }) })) : (_jsx(Input, { id: field.key, name: field.key, type: field.type === 'number' ? 'number' : 'text', defaultValue: stringValue, placeholder: field.placeholder, onFocus: onFocus })), field.help ? _jsx("p", { className: "text-xs text-fg-muted", children: field.help }) : null] }));
}
function Check({ name, defaultChecked, label, }) {
    return (_jsxs("label", { className: "flex items-center gap-2", children: [_jsx("input", { type: "checkbox", name: name, defaultChecked: defaultChecked, className: "size-4 rounded border-border text-primary focus:ring-primary" }), _jsx("span", { className: "text-sm font-medium text-fg", children: label })] }));
}
//# sourceMappingURL=integration-builder.js.map