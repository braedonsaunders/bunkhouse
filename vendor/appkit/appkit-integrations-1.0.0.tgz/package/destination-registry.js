import { slackDestination } from './chat.js';
import { createEmailDestination } from './email.js';
import { httpDestination } from './http.js';
import { sheetsDestination } from './sheets.js';
import { sqlDestination } from './sql.js';
export function createDestinationCatalog(destinations) {
    const map = new Map();
    for (const destination of destinations) {
        if (map.has(destination.key))
            throw new Error(`Duplicate integration destination: ${destination.key}`);
        map.set(destination.key, destination);
    }
    return {
        list: () => [...map.values()],
        get: (key) => key ? map.get(key) : undefined,
        require(key) {
            const destination = map.get(key);
            if (!destination)
                throw new Error(`Unknown integration destination: ${key}`);
            return destination;
        },
    };
}
export function createDefaultDestinationCatalog(options = {}) {
    return createDestinationCatalog([
        httpDestination,
        sqlDestination,
        slackDestination,
        sheetsDestination,
        ...(options.sendEmail ? [createEmailDestination(options.sendEmail)] : []),
    ]);
}
//# sourceMappingURL=destination-registry.js.map