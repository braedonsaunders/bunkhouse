export declare function deliveryRef(namespace: string, triggerKey: string, subjectId: string, index: number): string;
//# sourceMappingURL=idempotency.d.ts.map