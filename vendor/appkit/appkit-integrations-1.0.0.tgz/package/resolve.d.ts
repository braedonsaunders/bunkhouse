import type { IntegrationItem, Scalar } from './types.js';
export declare function resolveValue(expression: unknown, item: IntegrationItem): Scalar;
export declare function resolveText(template: string, item: IntegrationItem): string;
//# sourceMappingURL=resolve.d.ts.map