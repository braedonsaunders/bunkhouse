import type { DestinationDef } from './types.js';
interface WeekRow {
    dateStart: string;
    dateEnd: string;
    dayHours: number[];
}
export declare function buildWeekRows(startsAtIso: string, hoursPerDay: number, lengthDays: number): WeekRow[];
export declare const sqlDestination: DestinationDef;
export {};
//# sourceMappingURL=sql.d.ts.map