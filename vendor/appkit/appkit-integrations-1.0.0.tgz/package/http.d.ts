import type { DestinationDef } from './types.js';
export declare const httpDestination: DestinationDef;
//# sourceMappingURL=http.d.ts.map