import type { DestinationDef } from './types.js';
export declare const slackDestination: DestinationDef;
//# sourceMappingURL=chat.d.ts.map