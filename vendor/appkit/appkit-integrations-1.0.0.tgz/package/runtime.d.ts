import type { DeliveryRef, DeliveryResult, IntegrationDefinition, IntegrationEvent } from './types.js';
import type { ReturnTypeRegistry } from './internal-types.js';
export type DeliveryLedgerEntry = {
    externalRef: string | null;
    status: 'pushed' | 'failed' | 'reversed';
    detail?: Record<string, unknown>;
};
export interface IntegrationStore {
    getDefinition(tenantId: string, automationId: string): Promise<IntegrationDefinition | null>;
    listMatching(tenantId: string, triggerKey: string): Promise<string[]>;
    priorDelivery(tenantId: string, automationId: string, subjectType: string, subjectId: string): Promise<DeliveryLedgerEntry[]>;
    replaceDelivery(tenantId: string, automationId: string, subjectType: string, subjectId: string, externalSystem: string, refs: DeliveryRef[], status: 'pushed' | 'failed'): Promise<void>;
    recordStatus(tenantId: string, automationId: string, result: {
        ok: boolean;
        error?: string;
    }): Promise<void>;
}
export type PriorDelivery = {
    refs: string[];
    retryRefs: string[];
    complete: boolean;
};
export declare function summarizePriorDelivery(rows: readonly Pick<DeliveryLedgerEntry, 'externalRef' | 'status'>[]): PriorDelivery;
export type DispatchIntegrationOptions = {
    integrationId: string;
    event: IntegrationEvent;
    registry: ReturnTypeRegistry;
    store: IntegrationStore;
    unseal?: (value: unknown, key: string) => string | null;
    log?: (level: 'info' | 'warn' | 'error', message: string) => void;
    signal?: AbortSignal;
    data?: unknown;
};
/** The complete per-automation delivery unit used by the outbound worker. */
export declare function dispatchIntegration(options: DispatchIntegrationOptions): Promise<DeliveryResult>;
export declare function createIntegrationDispatcher(defaults: Omit<DispatchIntegrationOptions, 'integrationId' | 'event'>): (context: {
    tenantId: string;
}, automationId: string, event: IntegrationEvent) => Promise<DeliveryResult>;
export declare function createMemoryIntegrationStore(definitions: readonly IntegrationDefinition[]): IntegrationStore & {
    definitions: Map<string, IntegrationDefinition>;
    ledger: Map<string, DeliveryLedgerEntry[]>;
    statuses: Map<string, Array<{
        ok: boolean;
        error?: string;
    }>>;
};
//# sourceMappingURL=runtime.d.ts.map