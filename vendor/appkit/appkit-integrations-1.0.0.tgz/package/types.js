export function createIntegrationRegistry(options) {
    const triggers = new Map(options.triggers?.map((entry) => [entry.key, entry]) ?? []);
    const destinations = new Map(options.destinations?.map((entry) => [entry.key, entry]) ?? []);
    if (triggers.size !== (options.triggers?.length ?? 0))
        throw new Error('Integration trigger keys must be unique');
    if (destinations.size !== (options.destinations?.length ?? 0))
        throw new Error('Integration destination keys must be unique');
    return {
        triggers: () => [...triggers.values()],
        destinations: () => [...destinations.values()],
        trigger: (key) => triggers.get(key),
        destination: (key) => destinations.get(key),
        requireDestination(key) {
            const destination = destinations.get(key);
            if (!destination)
                throw new Error(`Unknown integration destination: ${key}`);
            return destination;
        },
    };
}
//# sourceMappingURL=types.js.map