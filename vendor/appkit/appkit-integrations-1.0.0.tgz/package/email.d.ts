import type { DestinationDef, Item } from './types.js';
export type IntegrationEmail = {
    tenantId: string;
    to: string[];
    subject: string;
    html: string;
    text: string;
};
export type IntegrationEmailSender = (message: IntegrationEmail) => Promise<void>;
export declare const emailDestinationAuthoring: {
    readonly configFields: [{
        readonly key: "to";
        readonly label: "Recipients";
        readonly type: "text";
        readonly required: true;
        readonly placeholder: "ops@example.com, {{ownerEmail}}";
        readonly help: "Comma-separated; tokens are supported.";
    }, {
        readonly key: "subject";
        readonly label: "Subject";
        readonly type: "text";
    }, {
        readonly key: "combine";
        readonly label: "Combine collection items";
        readonly type: "boolean";
    }];
    readonly secretFields: [];
    readonly key: "email";
    readonly name: "Email";
    readonly description: "Send a bounded, sanitized, token-templated email through an app-provided transport.";
    readonly iconKey: "mail";
    readonly mappingKind: "email";
    readonly reversible: false;
};
export declare function createIntegrationEmailBodyRenderer(bodyTemplate: string): (item: Item) => string;
export declare function createEmailDestination(sendEmail: IntegrationEmailSender): DestinationDef;
//# sourceMappingURL=email.d.ts.map