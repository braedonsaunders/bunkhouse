import type { IntegrationEvent } from './types.js';
import type { IntegrationStore } from './runtime.js';
export type OutboundDispatchJob = {
    tenantId: string;
    automationId: string;
    event: IntegrationEvent;
};
export type EnqueueOutboundDispatch = (data: OutboundDispatchJob, jobId: string) => Promise<unknown>;
export declare function outboundDispatchJobId(sourceEventId: string, automationId: string): string;
/**
 * Production event publisher extracted from the reference worker boundary.
 * The application supplies its durable queue, keeping this package independent
 * of any particular jobs implementation.
 */
export declare function createIntegrationPublisher(options: {
    store: IntegrationStore;
    enqueueOutboundDispatch: EnqueueOutboundDispatch;
}): (context: {
    tenantId: string;
}, event: IntegrationEvent, sourceEventId: string) => Promise<void>;
//# sourceMappingURL=publisher.d.ts.map