import { type DestinationAuthoringDefinition, type IntegrationEditorInitial, type IntegrationEditorSubmission } from './authoring.js';
import type { TriggerDefinition } from './types.js';
export type IntegrationBuilderResult = {
    ok: boolean;
    message: string;
};
export type IntegrationBuilderCopy = {
    name: string;
    namePlaceholder: string;
    triggerTitle: string;
    triggerSubtitle: string;
    triggerPlaceholder: string;
    destinationTitle: string;
    destinationSubtitle: string;
    destinationPlaceholder: string;
    configurationTitle: string;
    configurationSubtitle: string;
    enabled: string;
    oncePerRecord: string;
    test: string;
    testing: string;
    save: string;
    saving: string;
    tokenTitle: string;
    tokenHelp: string;
    noTrigger: string;
};
export declare function IntegrationBuilder({ id, initial, triggers, destinations, onSave, onTest, copy: copyOverrides, }: {
    id: string;
    initial: IntegrationEditorInitial;
    triggers: readonly TriggerDefinition[];
    destinations: readonly DestinationAuthoringDefinition[];
    onSave: (submission: IntegrationEditorSubmission) => Promise<void | IntegrationBuilderResult>;
    onTest?: (submission: IntegrationEditorSubmission) => Promise<IntegrationBuilderResult>;
    copy?: Partial<IntegrationBuilderCopy>;
}): import("react").JSX.Element;
//# sourceMappingURL=integration-builder.d.ts.map