import type { ReactNode } from 'react';
import { type IntegrationCatalogItem, type IntegrationDirection, type IntegrationLinkRender } from './integration-catalog.js';
export type ConnectedIntegration = {
    id: string;
    direction: IntegrationDirection;
    title: string;
    subtitle: string;
    status: string;
    href: string;
    badge?: string;
    meta: string;
    iconKey: string;
};
export declare function IntegrationHub({ connected, catalog, onAdd, onDelete, linkRender, header, }: {
    connected: readonly ConnectedIntegration[];
    catalog: readonly IntegrationCatalogItem[];
    onAdd: (item: IntegrationCatalogItem) => void | Promise<void>;
    onDelete?: (item: ConnectedIntegration) => void | Promise<void>;
    linkRender?: IntegrationLinkRender;
    header?: ReactNode;
}): import("react").JSX.Element;
//# sourceMappingURL=integration-hub.d.ts.map