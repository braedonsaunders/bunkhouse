'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { ArrowUpRight, Building2, Database, FileSpreadsheet, Plug, PlugZap, Trash2, Upload, } from 'lucide-react';
import { Badge, Button } from '@appkit/ui';
import { DirectionPill, IntegrationCatalog, } from './integration-catalog.js';
const ICONS = {
    database: Database,
    'building-2': Building2,
    'file-spreadsheet': FileSpreadsheet,
    'plug-zap': PlugZap,
    upload: Upload,
};
export function IntegrationHub({ connected, catalog, onAdd, onDelete, linkRender, header, }) {
    return (_jsxs("div", { className: "space-y-8", children: [header ?? (_jsxs("header", { className: "space-y-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Plug, { size: 22, className: "text-primary" }), _jsx("h1", { className: "text-2xl font-semibold text-fg", children: "Integrations" })] }), _jsx("p", { className: "max-w-2xl text-sm text-fg-muted", children: "Bring external records into your application and route application events to the services your team already uses." })] })), _jsxs("section", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-baseline gap-2", children: [_jsx("h2", { className: "text-sm font-semibold tracking-wide text-fg-muted uppercase", children: "Connected" }), _jsx("span", { className: "text-xs text-fg-subtle", children: connected.length })] }), !connected.length ? (_jsx("div", { className: "rounded-xl border border-dashed border-border px-5 py-8 text-sm text-fg-muted", children: "No connections or outbound automations yet." })) : (_jsx("div", { className: "grid grid-cols-1 gap-3 lg:grid-cols-2", children: connected.map((item) => (_jsx(ConnectedCard, { item: item, onDelete: onDelete, linkRender: linkRender }, `${item.direction}-${item.id}`))) }))] }), _jsxs("section", { className: "space-y-3", children: [_jsx("h2", { className: "text-sm font-semibold tracking-wide text-fg-muted uppercase", children: "Browse integrations" }), _jsx(IntegrationCatalog, { items: catalog, onAdd: onAdd, linkRender: linkRender })] })] }));
}
function ConnectedCard({ item, onDelete, linkRender, }) {
    const Icon = ICONS[item.iconKey] ?? Database;
    const content = (_jsx("span", { className: "font-semibold text-fg transition group-hover:text-primary", children: item.title }));
    return (_jsxs("div", { className: "group relative flex items-start gap-3 rounded-xl border border-border bg-surface p-4 shadow-sm transition hover:border-primary/40 hover:shadow-md", children: [_jsx("span", { className: "grid size-10 shrink-0 place-items-center rounded-lg bg-surface-hover text-fg-muted ring-1 ring-border-subtle", children: _jsx(Icon, { size: 18 }) }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [linkRender
                                ? linkRender({ href: item.href, children: content })
                                : _jsx("a", { href: item.href, children: content }), _jsx(DirectionPill, { direction: item.direction }), _jsx(StatusPill, { status: item.status }), item.badge ? (_jsx(Badge, { variant: "secondary", className: "text-[10px]", children: item.badge })) : null] }), _jsx("p", { className: "mt-1 truncate text-xs text-fg-muted", children: item.subtitle }), _jsx("p", { className: "mt-0.5 truncate text-[11px] text-fg-subtle", children: item.meta })] }), _jsxs("div", { className: "flex items-center gap-1 self-center text-fg-subtle transition group-hover:text-fg-muted", children: [_jsx(ArrowUpRight, { size: 15, className: "hidden sm:block" }), onDelete ? (_jsx(Button, { type: "button", variant: "ghost", size: "icon", "aria-label": `Remove ${item.title}`, onClick: () => void onDelete(item), children: _jsx(Trash2, { size: 14 }) })) : null] })] }));
}
function StatusPill({ status }) {
    const normalized = status.toLowerCase();
    const variant = normalized === 'ready' || normalized === 'connected' || normalized === 'success'
        ? 'success'
        : normalized === 'error' || normalized === 'failed'
            ? 'destructive'
            : 'secondary';
    return _jsx(Badge, { variant: variant, children: status });
}
//# sourceMappingURL=integration-hub.js.map