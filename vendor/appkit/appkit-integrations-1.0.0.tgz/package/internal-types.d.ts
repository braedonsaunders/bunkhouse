import type { createIntegrationRegistry } from './types.js';
export type ReturnTypeRegistry = ReturnType<typeof createIntegrationRegistry>;
//# sourceMappingURL=internal-types.d.ts.map