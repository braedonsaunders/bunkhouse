export type Scalar = string | number | boolean | null;
export type IntegrationItem = Record<string, Scalar>;
export type IntegrationEvent = {
    type: string;
    tenantId: string;
    subjectId: string;
    items: IntegrationItem[];
};
export type FieldDefinition = {
    key: string;
    label: string;
    type: 'string' | 'number' | 'boolean' | 'date';
    sample?: Scalar;
    note?: string;
};
export type FieldDef = FieldDefinition;
export type TriggerDefinition = {
    key: string;
    label: string;
    description: string;
    module: string;
    iconKey: string;
    subjectLabel: string;
    itemScope: 'single' | 'collection';
    fields: FieldDefinition[];
    dynamicFieldsNote?: string;
};
export type TriggerDef = TriggerDefinition;
export type ConfigField = {
    key: string;
    label: string;
    type: 'text' | 'number' | 'select' | 'textarea' | 'boolean';
    options?: {
        value: string;
        label: string;
    }[];
    placeholder?: string;
    help?: string;
    required?: boolean;
};
export type SecretField = {
    key: string;
    label: string;
    required?: boolean;
    help?: string;
};
export type DeliveryRef = {
    externalRef: string;
    detail?: Record<string, unknown>;
};
export type DeliveryResult = {
    ok: boolean;
    summary?: string;
    error?: string;
    refs?: DeliveryRef[];
};
export type DestinationTestContext = {
    tenantId: string;
    /** Optional application-owned data access available to custom destinations. */
    data?: unknown;
    config: Record<string, unknown>;
    secrets: Record<string, string>;
    signal?: AbortSignal;
};
export type DeliveryContext = DestinationTestContext & {
    triggerKey: string;
    subjectId: string;
    items: IntegrationItem[];
    mapping: Record<string, unknown>;
    priorRefs: string[];
    retryRefs: string[];
    oncePerRecord: boolean;
    log: (level: 'info' | 'warn' | 'error', message: string) => void;
};
export type DestinationDefinition = {
    key: string;
    name: string;
    description: string;
    iconKey: string;
    mappingKind: 'sql' | 'http' | 'slack' | 'sheets' | 'email' | (string & {});
    configFields: ConfigField[];
    secretFields: SecretField[];
    reversible: boolean;
    test?(context: DestinationTestContext): Promise<DeliveryResult>;
    deliver(context: DeliveryContext): Promise<DeliveryResult>;
};
export type Item = IntegrationItem;
export type DeliverRef = DeliveryRef;
export type DeliverResult = DeliveryResult;
export type DeliverContext = DeliveryContext;
export type DestinationDef = DestinationDefinition;
export type IntegrationResult = DeliveryResult;
export type IntegrationDefinition = {
    id: string;
    tenantId: string;
    name: string | null;
    enabled: boolean;
    triggerKey: string | null;
    destinationKey: string | null;
    config: Record<string, unknown>;
    secrets?: Record<string, unknown>;
    status?: 'draft' | 'ready' | 'error' | 'disabled';
    lastError?: string | null;
    lastRunAt?: Date | null;
};
export declare function createIntegrationRegistry(options: {
    triggers?: readonly TriggerDefinition[];
    destinations?: readonly DestinationDefinition[];
}): {
    triggers: () => TriggerDefinition[];
    destinations: () => DestinationDefinition[];
    trigger: (key: string) => TriggerDefinition | undefined;
    destination: (key: string) => DestinationDefinition | undefined;
    requireDestination(key: string): DestinationDefinition;
};
//# sourceMappingURL=types.d.ts.map