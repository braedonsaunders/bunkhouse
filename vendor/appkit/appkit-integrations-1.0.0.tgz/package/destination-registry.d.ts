import { type IntegrationEmailSender } from './email.js';
import type { DestinationDefinition } from './types.js';
export declare function createDestinationCatalog(destinations: readonly DestinationDefinition[]): {
    list: () => DestinationDefinition[];
    get: (key: string | null | undefined) => DestinationDefinition | undefined;
    require(key: string): DestinationDefinition;
};
export declare function createDefaultDestinationCatalog(options?: {
    sendEmail?: IntegrationEmailSender;
}): {
    list: () => DestinationDefinition[];
    get: (key: string | null | undefined) => DestinationDefinition | undefined;
    require(key: string): DestinationDefinition;
};
//# sourceMappingURL=destination-registry.d.ts.map