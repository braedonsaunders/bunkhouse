import type { DestinationDefinition } from './types.js';
export type DestinationAuthoringDefinition = Pick<DestinationDefinition, 'key' | 'name' | 'description' | 'iconKey' | 'mappingKind' | 'configFields' | 'secretFields' | 'reversible'>;
export type IntegrationEditorInitial = {
    name: string;
    enabled: boolean;
    oncePerRecord: boolean;
    triggerKey: string;
    destinationKey: string;
    config: Record<string, unknown>;
    secretsPresent: Record<string, boolean>;
    mapping: Record<string, unknown>;
};
export type IntegrationEditorSubmission = {
    id: string;
    name: string | null;
    enabled: boolean;
    ready: boolean;
    triggerKey: string | null;
    destinationKey: string;
    config: Record<string, unknown>;
    /** Plaintext replacements only. Applications seal these before persistence. */
    secretReplacements: Record<string, string>;
};
export declare function readDestinationMapping(destination: DestinationAuthoringDefinition, formData: FormData): Record<string, unknown>;
export declare function readIntegrationEditorSubmission(options: {
    destination: DestinationAuthoringDefinition;
    formData: FormData;
    baseConfig?: Record<string, unknown>;
}): IntegrationEditorSubmission;
//# sourceMappingURL=authoring.d.ts.map