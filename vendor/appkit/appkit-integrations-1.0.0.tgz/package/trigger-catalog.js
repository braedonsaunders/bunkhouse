export function createTriggerCatalog(definitions) {
    const map = new Map();
    for (const definition of definitions) {
        if (!definition.key.trim())
            throw new Error('Integration triggers require a key');
        if (map.has(definition.key))
            throw new Error(`Duplicate integration trigger: ${definition.key}`);
        map.set(definition.key, definition);
    }
    return {
        list: () => [...map.values()],
        get: (key) => key ? map.get(key) : undefined,
        require(key) {
            const trigger = map.get(key);
            if (!trigger)
                throw new Error(`Unknown integration trigger: ${key}`);
            return trigger;
        },
        sampleItem(key) {
            const item = {};
            for (const field of this.require(key).fields) {
                item[field.key] = field.sample ?? (field.type === 'number' ? 0 : field.type === 'boolean' ? false : '');
            }
            return item;
        },
        event(input) {
            const trigger = this.require(input.key);
            if (trigger.itemScope === 'single' && input.items.length !== 1) {
                throw new Error(`${trigger.label} requires exactly one integration item`);
            }
            return { type: trigger.key, tenantId: input.tenantId, subjectId: input.subjectId, items: input.items };
        },
    };
}
export function field(key, label, type, options = {}) {
    return { key, label, type, ...options };
}
//# sourceMappingURL=trigger-catalog.js.map