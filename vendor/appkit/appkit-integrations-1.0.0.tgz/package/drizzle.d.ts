import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { IntegrationStore } from './runtime.js';
type Db = NodePgDatabase<Record<string, never>>;
export type IntegrationTenantRunner = <T>(tenantId: string, operation: () => Promise<T>) => Promise<T>;
/** RLS-aware persistence for production automation definitions and ledgers. */
export declare function createDrizzleIntegrationStore(db: Db, withTenant: IntegrationTenantRunner): IntegrationStore;
export { tenantIntegrations, integrationExportLog, INTEGRATION_TENANT_TABLES, } from './schema.js';
//# sourceMappingURL=drizzle.d.ts.map