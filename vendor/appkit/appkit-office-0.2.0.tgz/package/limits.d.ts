/**
 * Shared office-file ceilings for upload, editing, and background conversion.
 */
export declare const MAX_DOCX_CONVERSION_BYTES: number;
export declare const MAX_PPTX_FILE_BYTES: number;
export declare const DOCX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
export declare const PPTX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
export declare const XLSX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
export declare const PDF_MIME_TYPE = "application/pdf";
//# sourceMappingURL=limits.d.ts.map