# @appkit/office

Office-document authoring for AI agents and applications: HTML to .docx/.pdf via headless LibreOffice, plain-text precision edits inside .docx via Flat ODT, PDF concatenation via poppler, and declarative .xlsx workbooks via the optional exceljs adapter.

## Install

```bash
pnpm add @appkit/office
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
