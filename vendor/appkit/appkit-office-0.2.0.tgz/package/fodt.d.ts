export type FodtEdit = {
    find: string;
    replace: string;
};
export type FodtEditResult = {
    find: string;
    count: number;
};
export declare function encodeEntities(s: string): string;
/**
 * Apply exact-match plain-text edits to a Flat ODT document. Every occurrence
 * of each `find` is replaced; the per-edit result carries the occurrence
 * count (0 = not found — the caller reports that back to the model).
 */
export declare function replaceTextInFodt(fodt: string, edits: FodtEdit[]): {
    fodt: string;
    results: FodtEditResult[];
};
//# sourceMappingURL=fodt.d.ts.map