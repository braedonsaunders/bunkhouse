import { execFile } from 'node:child_process';
import { type FodtEdit, type FodtEditResult } from './fodt.js';
export declare const exec: typeof execFile.__promisify__;
export declare function resolveSoffice(): Promise<string>;
/**
 * Convert one office file with LibreOffice headless. `convertTo` is soffice's
 * --convert-to argument (e.g. 'pdf', 'txt:Text'); returns the converted bytes.
 */
export declare function sofficeConvert(input: Buffer, inputName: string, convertTo: string): Promise<Buffer>;
/** Concatenate PDFs in order with poppler's pdfunite. */
export declare function pdfUnite(pdfs: Buffer[]): Promise<Buffer>;
/** Render a full HTML document (see `officeDocumentHtml`) to a .docx. */
export declare function htmlToDocx(html: string): Promise<Buffer>;
/**
 * Render a full HTML document (see `officeDocumentHtml`) to a PDF.
 *
 * This deliberately takes the same HTML -> DOCX -> PDF route as an operator
 * exporting the generated Word document. LibreOffice 7.4's headless HTML
 * import inserts a completely blank first page when it is exported directly
 * to PDF (even for a one-line document); importing the HTML to DOCX first is
 * stable on that production version and on current LibreOffice releases.
 */
export declare function htmlToPdf(html: string): Promise<Buffer>;
/** Render an existing .docx to a PDF. */
export declare function docxToPdf(docx: Buffer): Promise<Buffer>;
/** Extract the plain text of a .docx (the read side of the edit loop). */
export declare function docxToText(docx: Buffer): Promise<string>;
/**
 * Apply exact-match plain-text edits inside a .docx without disturbing its
 * formatting: the document round-trips docx → Flat ODT → `replaceTextInFodt`
 * → docx, so character styles, lists, tables and images all survive. Each
 * result carries the occurrence count (0 = the find string was not present).
 */
export declare function replaceTextInDocx(docx: Buffer, edits: FodtEdit[]): Promise<{
    docx: Buffer;
    results: FodtEditResult[];
}>;
export * from './fodt.js';
export * from './html.js';
export * from './limits.js';
export * from './xlsx.js';
//# sourceMappingURL=index.d.ts.map