export type OfficeBranding = {
    companyName?: string;
    /** Hex color (`#rgb`, `#rrggbb`, …) for the letterhead rule and links. */
    accentColor?: string;
    footerText?: string;
};
export type OfficeDocumentHtmlInput = {
    /** Body markup — sanitize untrusted input with `sanitizeOfficeHtml` first. */
    bodyHtml: string;
    title?: string;
    branding?: OfficeBranding;
};
export declare function escapeHtml(s: string): string;
/**
 * Reduce untrusted HTML to the print-safe allowlist: h1–h4, p, ul/ol/li,
 * strong/em/u, blockquote, table/thead/tbody/tr/th/td, a[href http/https/
 * mailto], br, hr, and img limited to embedded `data:` raster images.
 * Disallowed wrappers keep their text; script-like elements vanish with their
 * content; comments, doctypes, and processing instructions are removed; the
 * output is re-balanced so every emitted element is closed.
 */
export declare function sanitizeOfficeHtml(html: string): string;
/**
 * Wrap body HTML in a complete printable document for LibreOffice conversion
 * (`htmlToDocx` / `htmlToPdf`): US-letter pages with 0.75in margins, a serif
 * reading hierarchy, bordered tables, page-break-friendly headings and rows,
 * and an optional letterhead line plus footer from `branding`. Remote images
 * are refused; embed images as `data:` URIs. Sanitize untrusted body markup
 * with `sanitizeOfficeHtml` before calling.
 */
export declare function officeDocumentHtml(input: OfficeDocumentHtmlInput): string;
//# sourceMappingURL=html.d.ts.map