export type OfficeBranding = {
    companyName?: string;
    /** Hex color (`#rgb`, `#rrggbb`, …) for the letterhead rule and links. */
    accentColor?: string;
    footerText?: string;
};
export type OfficeDocumentHtmlInput = {
    /** Body markup — sanitize untrusted input with `sanitizeOfficeHtml` first. */
    bodyHtml: string;
    title?: string;
    branding?: OfficeBranding;
    /**
     * Page orientation. Portrait suits prose and narrow tables; landscape exists
     * because a wide table has nowhere else to go — a fourteen-column financial
     * summary rendered portrait simply loses its right-hand columns off the edge
     * of the sheet, silently, with no indication in the output that anything is
     * missing. Defaults to portrait.
     */
    orientation?: 'portrait' | 'landscape';
    /**
     * Table density. `compact` sets tabular type smaller and tightens cell
     * padding, which is what a table with more columns than a page has room for
     * actually needs — landscape buys width once, and a fourteen-column
     * financial summary still wants the last column back. Prose is unaffected;
     * only tables change. Defaults to normal.
     */
    density?: 'normal' | 'compact';
};
export declare function escapeHtml(s: string): string;
/**
 * Reduce untrusted HTML to the print-safe allowlist: h1–h4, p, ul/ol/li,
 * strong/em/u, blockquote, table/thead/tbody/tr/th/td, a[href http/https/
 * mailto], br, hr, and img limited to embedded `data:` raster images.
 * Disallowed wrappers keep their text; script-like elements vanish with their
 * content; comments, doctypes, and processing instructions are removed; the
 * output is re-balanced so every emitted element is closed.
 */
export declare function sanitizeOfficeHtml(html: string): string;
/**
 * Wrap body HTML in a complete printable document for LibreOffice conversion
 * (`htmlToDocx` / `htmlToPdf`): US-letter pages with 0.75in margins, a serif
 * reading hierarchy, bordered tables, page-break-friendly headings and rows,
 * and an optional letterhead line plus footer from `branding`. Remote images
 * are refused; embed images as `data:` URIs. Sanitize untrusted body markup
 * with `sanitizeOfficeHtml` before calling.
 */
export declare function officeDocumentHtml(input: OfficeDocumentHtmlInput): string;
//# sourceMappingURL=html.d.ts.map