export type WorkbookColumnSpec = {
    header: string;
    key: string;
    /** Character width; computed from a sample of the rows when omitted. */
    width?: number;
    /** Excel number format for the column, e.g. `'#,##0.00'` or `'yyyy-mm-dd'`. */
    numFmt?: string;
};
export type SheetSpec = {
    name: string;
    columns: WorkbookColumnSpec[];
    rows: Record<string, string | number | boolean | null>[];
    /** Cell formulas applied after the rows land, e.g. `{ cell: 'D2', formula: 'B2*C2' }`. */
    formulas?: {
        cell: string;
        formula: string;
    }[];
    freezeHeader?: boolean;
    autoFilter?: boolean;
    /** Bold the header row. Defaults to true. */
    boldHeader?: boolean;
};
export type WorkbookSpec = {
    creator?: string;
    sheets: SheetSpec[];
};
/** True when the optional `exceljs` peer resolves in this environment. */
export declare function excelJsAvailable(): Promise<boolean>;
/** Strip characters Excel forbids in sheet names and clamp to 31 characters. */
export declare function sanitizeSheetName(value: string): string;
/**
 * Render a declarative workbook spec to .xlsx bytes: typed columns with number
 * formats and sampled auto-widths, ordered data rows, optional cell formulas,
 * a bold (default) and optionally frozen/filtered header row, and Excel-legal
 * deduplicated sheet names.
 */
export declare function renderWorkbook(spec: WorkbookSpec): Promise<Buffer>;
//# sourceMappingURL=xlsx.d.ts.map