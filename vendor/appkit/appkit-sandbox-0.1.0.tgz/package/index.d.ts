export type SandboxStatus = 'ok' | 'error' | 'timeout' | 'forbidden' | 'aborted' | 'governance';
export interface SandboxLimits {
    timeoutMs?: number;
    unitBudget?: number;
    memoryBytes?: number;
    stackBytes?: number;
}
export interface SandboxHostFunction {
    /** Governance units charged before each invocation. */
    cost: number;
    handler: (args: unknown[]) => Promise<unknown> | unknown;
}
export interface SandboxOptions extends SandboxLimits {
    source: string;
    /** Function declared by the authored source. Defaults to `main`. */
    entrypoint?: string;
    /** Frozen argument passed to the entrypoint. */
    input: unknown;
    /** Host object exposed in the sandbox. Defaults to `app`. */
    globalName?: string;
    /** Dotted host methods become nested functions, such as `storage.get`. */
    functions?: Record<string, SandboxHostFunction>;
    /** Frozen values copied onto the host object before execution. */
    values?: Record<string, unknown>;
    /** Cost of one host log call. Defaults to one unit. */
    logCost?: number;
}
export interface SandboxResult {
    status: SandboxStatus;
    value?: unknown;
    error?: string;
    code?: string;
    logs: string[];
    units: number;
    durationMs: number;
}
/** A host adapter may throw this to return a classified, non-ambient fault. */
export declare class SandboxFault extends Error {
    readonly code: string;
    readonly name = "SandboxFault";
    constructor(code: string, message: string);
}
export declare function forbidden(message: string): never;
export declare function abort(message: string): never;
/**
 * Execute authored JavaScript in a fresh QuickJS WASM runtime. The authored
 * program has no Node globals, filesystem, network, process, module loader, or
 * database connection. Every capability is an explicit host function.
 */
export declare function runSandbox(options: SandboxOptions): Promise<SandboxResult>;
//# sourceMappingURL=index.d.ts.map