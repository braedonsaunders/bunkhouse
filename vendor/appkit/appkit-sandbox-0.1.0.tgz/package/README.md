# @appkit/sandbox

Governed QuickJS isolation for user-authored JavaScript with async host capabilities, execution budgets, and structured faults.

## Install

```bash
pnpm add @appkit/sandbox
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
