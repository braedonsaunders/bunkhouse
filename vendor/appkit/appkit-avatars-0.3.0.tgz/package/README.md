# @appkit/avatars

AI avatar/image generation through the AI SDK provider layer — pass your @appkit/ai tenant AiConfig; openai and google image models.

## Install

```bash
pnpm add @appkit/avatars
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
