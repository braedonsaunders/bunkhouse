# @appkit/pdf

Pure-JS documents, statements, templates, and hardened HTML-to-PDF rendering.

## Install

```bash
pnpm add @appkit/pdf
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
