import type PDFKit from 'pdfkit';
import type { PdfTableGroup, PdfTheme } from './types.js';
import type { ResolvedPage } from './page.js';
/** Compute column widths (pt) that fill `contentWidth`, with sensible caps. */
export declare function computeColumnWidths(doc: InstanceType<typeof PDFKit>, group: PdfTableGroup, contentWidth: number, theme: PdfTheme): number[];
/**
 * Render a table group's body (header + rows) starting at `startY`. Handles
 * its own page breaks and re-draws the header on continuation pages. Returns
 * the y cursor after the last row.
 */
export declare function drawTable(doc: InstanceType<typeof PDFKit>, page: ResolvedPage, group: PdfTableGroup, startY: number, theme: PdfTheme): number;
//# sourceMappingURL=table.d.ts.map