import type { PdfPaperSize } from './types.js';
export type PdfOrientation = 'portrait' | 'landscape';
export type HtmlDocumentPdfInput = {
    /** Already-merged body HTML (sanitized at save, values escaped at merge). */
    bodyHtml: string;
    paperSize: PdfPaperSize;
    orientation: PdfOrientation;
    marginMm: number;
    /** Exact full-bleed page dimensions for cards, labels, and custom artboards. */
    physicalSize?: {
        widthIn: number;
        heightIn: number;
    };
    /** Running header/footer; `{{page}}` / `{{pages}}` become live counters. */
    headerHtml?: string | null;
    footerHtml?: string | null;
};
/**
 * Print merged template HTML on the chosen paper at the chosen orientation and
 * margins, with the org's own running header/footer. `{{page}}`/`{{pages}}` in
 * the header/footer become Chromium's live page counters.
 */
export declare function renderHtmlDocumentPdf(input: HtmlDocumentPdfInput): Promise<Buffer>;
//# sourceMappingURL=html.d.ts.map