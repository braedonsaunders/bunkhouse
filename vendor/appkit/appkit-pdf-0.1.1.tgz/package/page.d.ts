import type { PdfPageSetup, PdfPaperSize } from './types.js';
/** 1 millimetre in PostScript points (72 pt/in ÷ 25.4 mm/in). */
export declare const PT_PER_MM: number;
export declare function mmToPt(mm: number): number;
/** Paper dimensions in points, PORTRAIT (width × height). */
export declare const PAPER_PORTRAIT_PT: Record<PdfPaperSize, {
    width: number;
    height: number;
}>;
export type ResolvedPage = {
    width: number;
    height: number;
    margin: number;
    /** Content area (after margins). */
    contentWidth: number;
    contentTop: number;
    contentBottom: number;
    contentLeft: number;
};
/** Resolve a page setup into concrete point geometry. */
export declare function resolvePage(setup: PdfPageSetup): ResolvedPage;
//# sourceMappingURL=page.d.ts.map