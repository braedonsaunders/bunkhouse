import { hexColor } from '@appkit/tokens';
// The vendor-neutral document model the PDF engine renders. Kept dependency-
// free and decoupled from @appkit/reports so this package stays a pure
// renderer: callers (the web report adapters, the view export path)
// shape their own result types into this generic input.
//
// The visual vocabulary supports a cover header with organization branding, a key-
// figures summary band, and one section per group of rows — re-implemented on
// top of pdfkit (pure JS, no Chromium) instead of HTML + Puppeteer.
/** Paper sizes a document can print on. */
export const PDF_PAPER_SIZES = ['letter', 'a4', 'legal'];
/** Compact shrinks type and cell padding so more rows fit per page. */
export const PDF_DENSITIES = ['standard', 'compact'];
export const DEFAULT_PDF_LAYOUT = {
    paperSize: 'letter',
    orientation: 'landscape',
    marginMm: 15,
    density: 'standard',
};
export const PDF_MARGIN_MM_MIN = 5;
export const PDF_MARGIN_MM_MAX = 30;
/** Whitelist/clamp a partial setup into a complete, safe one. */
export function resolvePdfPageSetup(raw) {
    const paperSize = PDF_PAPER_SIZES.includes(raw?.paperSize)
        ? raw.paperSize
        : DEFAULT_PDF_LAYOUT.paperSize;
    const orientation = raw?.orientation === 'portrait' ? 'portrait' : 'landscape';
    const m = Number(raw?.marginMm);
    const marginMm = Number.isFinite(m)
        ? Math.min(Math.max(Math.round(m), PDF_MARGIN_MM_MIN), PDF_MARGIN_MM_MAX)
        : DEFAULT_PDF_LAYOUT.marginMm;
    const density = raw?.density === 'compact' ? 'compact' : 'standard';
    return { paperSize, orientation, marginMm, density };
}
export const PDF_PAPER_SIZE_LABELS = {
    letter: 'Letter',
    a4: 'A4',
    legal: 'Legal',
};
export const DEFAULT_PRIMARY_COLOR = hexColor('primary');
//# sourceMappingURL=types.js.map