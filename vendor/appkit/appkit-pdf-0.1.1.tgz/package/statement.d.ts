import { type PdfBranding, type PdfPageSetup } from './types.js';
export type StatementPdfColumnKind = 'amount' | 'variance_abs' | 'variance_pct';
export type StatementPdfColumn = {
    label: string;
    kind: StatementPdfColumnKind;
};
export type StatementPdfRow = {
    kind: 'section' | 'account' | 'subtotal' | 'total';
    label: string;
    /** Account-tree depth for indentation (description column only). */
    indent?: number;
    /** Column-aligned values; null/undefined renders blank. Percentages are raw
     *  (e.g. -83.4 → "(83.4%)"); amounts should already be scaled by the caller. */
    values?: (number | null | undefined)[];
};
export type StatementPdfStyle = 'formal' | 'modern';
export type StatementPdfInput = {
    companyName: string;
    title: string;
    periodPhrase: string;
    /** e.g. "In thousands" — printed under the header. */
    scaleNote?: string;
    /** Decimal places for amount columns (0 when scaled, else 2). */
    decimals?: number;
    columns: StatementPdfColumn[];
    rows: StatementPdfRow[];
    style: StatementPdfStyle;
    branding: PdfBranding;
    page: PdfPageSetup;
    generatedAt: Date;
    /** Optional footnote line (e.g. rounding note). */
    footnote?: string;
};
/** Render a financial statement to a PDF Buffer. */
export declare function renderStatementPdf(input: StatementPdfInput): Promise<Buffer>;
//# sourceMappingURL=statement.d.ts.map