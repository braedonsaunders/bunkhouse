// Financial-statement PDF renderer — a "serious", audit-grade statement, as
// opposed to the generic zebra-striped table renderer in document.ts. Applies
// professional conventions: a 3-line centred header (Company / Statement /
// period phrase), negatives in parentheses, currency symbol only on the first
// row and on total rows, a dash for zero, thousands separators, single rule
// above subtotals + double rule below grand totals, and account-hierarchy
// indentation. Two themes chosen by the tenant: `formal` (serif, greyscale,
// classic GAAP) and `modern` (sans + brand accent + logo).
import PDFDocument from 'pdfkit';
import { hexColor } from '@appkit/tokens';
import { DEFAULT_PRIMARY_COLOR } from './types.js';
import { resolvePage } from './page.js';
function themeFor(style, primary) {
    if (style === 'formal') {
        return {
            font: 'Times-Roman',
            fontBold: 'Times-Bold',
            fontItalic: 'Times-Italic',
            text: hexColor('fg'),
            muted: hexColor('fg-muted'),
            rule: hexColor('fg'),
            accent: hexColor('fg'),
        };
    }
    return {
        font: 'Helvetica',
        fontBold: 'Helvetica-Bold',
        fontItalic: 'Helvetica-Oblique',
        text: hexColor('fg'),
        muted: hexColor('fg-muted'),
        rule: hexColor('fg-subtle'),
        accent: primary,
    };
}
const DASH = '–';
const LOGO_H = 32;
function decodeDataUrl(url) {
    const m = /^data:image\/[a-zA-Z0-9.+-]+;base64,(.+)$/.exec(url);
    if (!m)
        return null;
    try {
        return Buffer.from(m[1], 'base64');
    }
    catch {
        return null;
    }
}
function formatValue(v, kind, decimals) {
    if (v === null || v === undefined)
        return '';
    if (kind === 'variance_pct') {
        if (!Number.isFinite(v))
            return DASH;
        const s = `${Math.abs(v).toFixed(1)}%`;
        return v < 0 ? `(${s})` : s;
    }
    const eps = decimals === 0 ? 0.5 : 0.005;
    if (Math.abs(v) < eps)
        return DASH;
    const abs = Math.abs(v).toLocaleString('en-CA', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
    return v < 0 ? `(${abs})` : abs;
}
/** Render a financial statement to a PDF Buffer. */
export async function renderStatementPdf(input) {
    const page = resolvePage(input.page);
    const primary = input.branding.primaryColor || DEFAULT_PRIMARY_COLOR;
    const theme = themeFor(input.style, primary);
    const decimals = input.decimals ?? 2;
    const dense = input.page.density === 'compact';
    const sz = { title: dense ? 15 : 18, company: dense ? 11 : 13, meta: dense ? 8.5 : 9.5, body: dense ? 8.5 : 9.5 };
    const rowPadY = dense ? 3 : 4.5;
    const doc = new PDFDocument({
        bufferPages: true,
        size: [page.width, page.height],
        margins: { top: page.margin, bottom: page.margin, left: page.margin, right: page.margin },
        info: { Title: input.title, Author: input.companyName, Subject: input.periodPhrase, Creator: 'appkit' },
    });
    const chunks = [];
    doc.on('data', (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
    // --- Column geometry --------------------------------------------------------
    const nCols = input.columns.length;
    const descW = Math.max(160, Math.min(page.contentWidth * 0.4, page.contentWidth - nCols * 62));
    const valW = (page.contentWidth - descW) / Math.max(1, nCols);
    const valX = (i) => page.contentLeft + descW + i * valW;
    const cellPad = 5;
    // --- Header (3-line centred stack) -----------------------------------------
    let y = page.contentTop;
    const logoBuf = input.branding.logoBuffer ?? (input.branding.logoUrl ? decodeDataUrl(input.branding.logoUrl) : null);
    if (input.style === 'modern' && logoBuf) {
        try {
            doc.image(logoBuf, page.contentLeft, y, { fit: [LOGO_H * 1.8, LOGO_H] });
        }
        catch {
            /* invalid image — ignore */
        }
    }
    doc.font(theme.fontBold).fontSize(sz.company).fillColor(theme.text);
    doc.text(input.companyName, page.contentLeft, y, { width: page.contentWidth, align: 'center' });
    doc.font(theme.fontBold).fontSize(sz.title).fillColor(theme.text);
    doc.text(input.title, page.contentLeft, doc.y + 1, { width: page.contentWidth, align: 'center' });
    doc.font(theme.font).fontSize(sz.meta).fillColor(theme.muted);
    doc.text(input.periodPhrase, page.contentLeft, doc.y + 1, { width: page.contentWidth, align: 'center' });
    if (input.scaleNote) {
        doc.font(theme.fontItalic).fontSize(sz.meta - 0.5).fillColor(theme.muted);
        doc.text(input.scaleNote, page.contentLeft, doc.y + 1, { width: page.contentWidth, align: 'center' });
    }
    y = doc.y + 6;
    doc
        .moveTo(page.contentLeft, y)
        .lineTo(page.contentLeft + page.contentWidth, y)
        .lineWidth(input.style === 'modern' ? 2 : 1)
        .strokeColor(theme.accent)
        .stroke();
    y += 8;
    // --- Column header ----------------------------------------------------------
    const drawColumnHeader = () => {
        doc.font(theme.fontBold).fontSize(sz.body).fillColor(theme.text);
        for (let i = 0; i < nCols; i++) {
            doc.text(input.columns[i].label, valX(i), y, { width: valW - cellPad, align: 'right' });
        }
        y = doc.y + 2;
        doc.moveTo(page.contentLeft, y).lineTo(page.contentLeft + page.contentWidth, y).lineWidth(0.8).strokeColor(theme.rule).stroke();
        y += rowPadY;
    };
    drawColumnHeader();
    const valuesRightEdge = page.contentLeft + page.contentWidth;
    const valuesLeftEdge = page.contentLeft + descW + cellPad;
    let firstAmountRowDone = false;
    const ensureSpace = (rowH) => {
        if (y + rowH > page.contentBottom) {
            doc.addPage();
            y = page.contentTop;
            drawColumnHeader();
        }
    };
    // --- Body rows --------------------------------------------------------------
    for (const row of input.rows) {
        doc.fontSize(sz.body);
        const isTotalish = row.kind === 'subtotal' || row.kind === 'total';
        const bold = row.kind === 'section' || isTotalish;
        doc.font(bold ? theme.fontBold : theme.font);
        const rowH = doc.currentLineHeight() + rowPadY;
        if (row.kind === 'section') {
            ensureSpace(rowH + 2);
            y += 2;
            doc.fillColor(theme.text).text(row.label.toUpperCase(), page.contentLeft, y, { width: descW });
            y = doc.y + rowPadY;
            continue;
        }
        ensureSpace(rowH + (isTotalish ? 6 : 0));
        // Single rule above subtotals/totals, across the value columns.
        if (isTotalish) {
            doc.moveTo(valuesLeftEdge - cellPad, y).lineTo(valuesRightEdge, y).lineWidth(0.7).strokeColor(theme.rule).stroke();
            y += 2;
        }
        const indent = (row.indent ?? 0) * 12;
        doc.font(bold ? theme.fontBold : theme.font).fillColor(theme.text);
        doc.text(row.label, page.contentLeft + indent, y, { width: descW - indent, lineBreak: false, ellipsis: true });
        const showCurrency = isTotalish || !firstAmountRowDone;
        for (let i = 0; i < nCols; i++) {
            const kind = input.columns[i].kind;
            const text = formatValue(row.values?.[i], kind, decimals);
            let cell = text;
            if (text && text !== DASH && kind !== 'variance_pct' && showCurrency)
                cell = `$ ${text}`;
            const neg = typeof row.values?.[i] === 'number' && row.values[i] < 0;
            doc.fillColor(input.style === 'formal' ? theme.text : neg ? hexColor('danger') : theme.text);
            doc.text(cell, valX(i), y, { width: valW - cellPad, align: 'right', lineBreak: false });
        }
        if (row.values && row.values.some((v) => typeof v === 'number'))
            firstAmountRowDone = true;
        y = doc.y + rowPadY;
        // Double rule below a grand total.
        if (row.kind === 'total') {
            doc.moveTo(valuesLeftEdge - cellPad, y).lineTo(valuesRightEdge, y).lineWidth(0.7).strokeColor(theme.rule).stroke();
            doc.moveTo(valuesLeftEdge - cellPad, y + 2).lineTo(valuesRightEdge, y + 2).lineWidth(0.7).strokeColor(theme.rule).stroke();
            y += 5;
        }
    }
    if (input.footnote) {
        y += 8;
        doc.font(theme.fontItalic).fontSize(sz.meta - 1).fillColor(theme.muted);
        doc.text(input.footnote, page.contentLeft, y, { width: page.contentWidth });
    }
    stampFooters(doc, page, input, theme);
    return new Promise((resolve, reject) => {
        doc.on('error', reject);
        doc.on('end', () => resolve(Buffer.concat(chunks)));
        doc.end();
    });
}
function stampFooters(doc, page, input, theme) {
    const range = doc.bufferedPageRange();
    const footerY = Math.min(page.contentBottom + (page.margin - 10) / 2, page.height - 14);
    const stamp = input.generatedAt.toISOString().slice(0, 10);
    for (let i = range.start; i < range.start + range.count; i++) {
        doc.switchToPage(i);
        // The footer sits in the bottom MARGIN band (below contentBottom). Drawing
        // text there makes pdfkit think the page overflowed and auto-insert a new
        // page (one per text call → runaway trailing blank pages). Zeroing the
        // page's bottom margin while stamping lets us write in the band safely.
        const savedBottom = doc.page.margins.bottom;
        doc.page.margins.bottom = 0;
        doc.font(theme.font).fontSize(8).fillColor(theme.muted);
        doc.text(`${input.companyName} · ${input.title}`, page.contentLeft, footerY, {
            width: page.contentWidth * 0.5,
            align: 'left',
            lineBreak: false,
            ellipsis: true,
        });
        doc.text(`${stamp}    Page ${i - range.start + 1} of ${range.count}`, page.contentLeft + page.contentWidth * 0.5, footerY, {
            width: page.contentWidth * 0.5,
            align: 'right',
            lineBreak: false,
        });
        doc.page.margins.bottom = savedBottom;
    }
}
//# sourceMappingURL=statement.js.map