/** Hard resource ceilings for the synchronous render path. */
export declare const TEMPLATE_RENDER_LIMITS: {
    readonly templateChars: 1000000;
    readonly mergeValueChars: 1000000;
    readonly renderOutputChars: 4000000;
    readonly plainTextChars: 2000000;
    readonly tokens: 20000;
    readonly astNodes: 20000;
    readonly nestingDepth: 32;
    readonly loopIterations: 10000;
    readonly expressionChars: 256;
    readonly hiddenHtmlDepth: 32;
};
export declare function escapeTemplateHtml(s: string): string;
/** Stringify a merge value; if it looks like HTML, reduce it to plain text. */
export declare function plainValue(v: unknown): string;
/**
 * Render an authored template that may contain {{#each}} / {{#if}} blocks and
 * dotted paths, against `values`. When `escapeHtml` is set, substituted values
 * are escaped ({{{raw}}} opts a field out). Untrusted boundaries set
 * `allowRawValues: false`, which treats triple-brace values as escaped data too.
 */
export declare function renderTemplate(tpl: string, values: Record<string, unknown>, opts?: {
    escapeHtml?: boolean;
    allowRawValues?: boolean;
}): string;
/**
 * Expand `data-each` / `data-if` builder markers into mustache blocks:
 *   <tr data-each="lines">…</tr>   → {{#each lines}}<tr>…</tr>{{/each}}
 *   <tr data-if="memo">…</tr>      → {{#if memo}}<tr>…</tr>{{/if}}
 * Only `<tr>` is supported. A quote-aware linear scanner pairs each marked row
 * with its closing tag and rejects invalid nested rows. The marker attribute
 * is stripped from the emitted row.
 */
export declare function expandRepeatMarkers(html: string): string;
/** Derive readable plain text from HTML (used to plainify HTML-bearing values). */
export declare function htmlToPlainText(html: string): string;
export declare function sanitizeTemplateHtml(html: string): string;
/** Sanitize an embeddable fragment without adding document wrappers. */
export declare function sanitizeTemplateFragment(html: string): string;
/**
 * Sanitize a tokenized header/footer fragment and prove that every token is in
 * text content — a record value can never become a URL, CSS, or attribute.
 */
export declare function sanitizeTokenizedFragment(html: string): string;
/**
 * Compile authored builder HTML for storage: sanitize (keeping the
 * data-each/data-if markers), then expand the markers into mustache blocks.
 * Returns both the sanitized source (reloaded by the builder) and the
 * compiled HTML (merged at render time).
 */
export declare function compileTemplateHtml(sourceHtml: string): {
    sanitizedSource: string;
    compiledHtml: string;
};
//# sourceMappingURL=template.d.ts.map