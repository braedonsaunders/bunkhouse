// @appkit/pdf — the dependency-light pure-JS document renderer.
// Authored templates and Chromium printing are opt-in through /template and /html.
// Server-only: import from route handlers / server components only.
export * from './types.js';
export * from './page.js';
export { drawTable, computeColumnWidths } from './table.js';
export { renderPdfDocument } from './document.js';
export { renderStatementPdf } from './statement.js';
//# sourceMappingURL=index.js.map