import { type PdfDocumentInput } from './types.js';
/** Render a report document to a PDF Buffer. */
export declare function renderPdfDocument(input: PdfDocumentInput): Promise<Buffer>;
//# sourceMappingURL=document.d.ts.map