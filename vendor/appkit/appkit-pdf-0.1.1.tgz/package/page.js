// Page geometry: paper dimensions in PostScript points and mm→pt conversion.
// pdfkit itself accepts `size`/`layout` keywords, but the renderer needs the
// raw point dimensions for cursor math (column widths, row wrapping, footers).
/** 1 millimetre in PostScript points (72 pt/in ÷ 25.4 mm/in). */
export const PT_PER_MM = 72 / 25.4;
export function mmToPt(mm) {
    return mm * PT_PER_MM;
}
/** Paper dimensions in points, PORTRAIT (width × height). */
export const PAPER_PORTRAIT_PT = {
    letter: { width: 612, height: 792 },
    a4: { width: 595.28, height: 841.89 },
    legal: { width: 612, height: 1008 },
};
/** Resolve a page setup into concrete point geometry. */
export function resolvePage(setup) {
    const portrait = PAPER_PORTRAIT_PT[setup.paperSize];
    const landscape = setup.orientation === 'landscape';
    const width = landscape ? portrait.height : portrait.width;
    const height = landscape ? portrait.width : portrait.height;
    const margin = mmToPt(setup.marginMm);
    return {
        width,
        height,
        margin,
        contentWidth: width - margin * 2,
        contentTop: margin,
        contentBottom: height - margin,
        contentLeft: margin,
    };
}
//# sourceMappingURL=page.js.map