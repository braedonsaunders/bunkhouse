/**
 * The in-guest agent: PID 1's helper inside the microVM, speaking the framed
 * JSON protocol over a vsock stream. This is the only new attack surface in
 * the desk design, so it is deliberately small: a bounded frame decoder, a
 * strict parser, a closed dispatch switch, and nothing else. Everything that
 * touches the guest OS — spawning processes, driving the compositor, reading
 * the clipboard — is injected as a handler so the message-handling core stays
 * pure and unit-testable on any platform.
 *
 * The module depends only on `node:` built-ins and this package's own
 * protocol module; it ships in the same package and is started by the guest's
 * init.
 */
import { Buffer } from 'node:buffer';
import type { Duplex } from 'node:stream';
import { type GuestEventMessage, type GuestExecResult, type GuestObservation, type GuestInput } from './protocol.js';
import type { DeskHandoverScope } from './events.js';
export interface GuestExecCall {
    command: string;
    args: readonly string[];
    cwd: string | null;
    env: Readonly<Record<string, string>> | null;
    timeoutMs: number | null;
}
export interface GuestJobStartCall {
    command: string;
    args: readonly string[];
    cwd: string | null;
    env: Readonly<Record<string, string>> | null;
}
/**
 * The operations the guest environment implements. Handlers own all contact
 * with the OS; the core owns all contact with the wire.
 */
export interface GuestAgentHandlers {
    exec(call: GuestExecCall): Promise<GuestExecResult>;
    jobStart(call: GuestJobStartCall): Promise<{
        jobId: string;
    }>;
    jobSignal(call: {
        jobId: string;
        signal: 'SIGTERM' | 'SIGKILL';
    }): Promise<void>;
    screenStart(call: {
        width: number;
        height: number;
    }): Promise<void>;
    screenStop(): Promise<void>;
    observe(): Promise<GuestObservation>;
    input(action: GuestInput): Promise<void>;
    a11yInvoke(call: {
        nodeId: string;
        action: string;
    }): Promise<void>;
    launch(call: {
        appId: string;
        args: readonly string[];
    }): Promise<void>;
    clipboardRead(): Promise<{
        text: string;
    }>;
    clipboardWrite(call: {
        text: string;
    }): Promise<void>;
    framesStart(call: {
        fps: number;
        width: number;
        height: number;
    }): Promise<void>;
    framesStop(): Promise<void>;
    handoverBegin(call: {
        ttlMs: number;
        scope: DeskHandoverScope;
    }): Promise<{
        url: string;
    }>;
    handoverEnd(): Promise<void>;
    capabilities(): Promise<{
        virtioGpu: boolean;
    }>;
}
export interface GuestAgentCore {
    /**
     * Consume one chunk of the byte stream and return the frames to write back,
     * in order. Malformed requests produce error responses; a framing violation
     * (oversized or non-JSON frame) throws, and the caller must drop the
     * connection — a length-prefixed stream cannot be resynchronized once its
     * lengths are untrusted.
     */
    handleChunk(chunk: Buffer): Promise<Buffer[]>;
    /** Encode an unsolicited guest-to-host event frame. */
    encodeEvent(event: GuestEventMessage): Buffer;
}
export declare function createGuestAgentCore(handlers: GuestAgentHandlers, options?: {
    maxFrameBytes?: number;
}): GuestAgentCore;
export interface RunningGuestAgent {
    /** Push an unsolicited event (job exit, frame, focus change) to the host. */
    sendEvent(event: GuestEventMessage): void;
    /** Resolves when the connection has closed. */
    closed: Promise<void>;
}
/**
 * Bind the pure core to a real byte stream. This is the entire impure surface
 * of the guest agent: read chunks, write responses, destroy the connection on
 * a framing violation.
 */
export declare function runGuestAgent(options: {
    stream: Duplex;
    handlers: GuestAgentHandlers;
    maxFrameBytes?: number;
}): RunningGuestAgent;
//# sourceMappingURL=guest-agent.d.ts.map