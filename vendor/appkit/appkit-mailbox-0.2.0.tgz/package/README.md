# @appkit/mailbox

Mail engine: incremental IMAP sync + SMTP send with RFC-5322 threading, persistence-injected so the application owns the ledger.

## Install

```bash
pnpm add @appkit/mailbox
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
