import * as React from 'react';
import { type SceneCharacter, type SceneGroundConfig, type WalkingConfig } from './config.js';
type Position = {
    x: number;
    y: number;
};
export type WalkingCharacterProps = {
    character: SceneCharacter;
    ground: SceneGroundConfig;
    config: WalkingConfig;
    containerWidth: number;
    containerHeight: number;
    baseSize?: number;
    onPositionChange?: (id: string, position: Position) => void;
    getOtherPositions?: (excludeId: string) => Position[];
    onSelect?: (id: string) => void;
};
/**
 * One character on the stage: strolls to nearby points, idles with a gentle
 * bounce or sway, faces its direction of travel, scales and sorts by depth,
 * and keeps clear of its neighbours and the exclusion zones.
 */
export declare const WalkingCharacter: React.NamedExoticComponent<WalkingCharacterProps>;
export {};
//# sourceMappingURL=walking-character.d.ts.map