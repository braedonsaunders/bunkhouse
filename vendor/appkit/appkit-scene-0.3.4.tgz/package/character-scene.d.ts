import * as React from 'react';
import { type SceneCharacter, type SceneGroundConfig, type WalkingConfig } from './config.js';
export type CharacterSceneProps = {
    characters: SceneCharacter[];
    ground?: SceneGroundConfig;
    config?: Partial<WalkingConfig>;
    /** Rendered above the ground, inside the stage — cards, headings, actions. */
    children?: React.ReactNode;
    /**
     * A painted stage — trees, fire, skyline — rendered over the gradients and
     * under every character (see `scene-art.tsx`). Characters always walk in
     * front of the art, exactly as OpenStudio layered its homepage world.
     */
    art?: React.ReactNode;
    /** Keep characters out of the area the overlay content occupies. */
    contentZone?: {
        minX: number;
        maxX: number;
        minY: number;
        maxY: number;
    };
    onSelect?: (id: string) => void;
    baseCharacterSize?: number;
    className?: string;
    /** Stage height; the scene is purely decorative below its content. */
    height?: number | string;
};
/**
 * A stage where characters live: a backdrop, a receding floor, and any number
 * of characters that walk, idle, and sort by depth. Data comes from the
 * application; the scene owns only geometry and motion.
 */
export declare function CharacterScene({ characters, ground, config, children, art, contentZone, onSelect, baseCharacterSize, className, height, }: CharacterSceneProps): React.JSX.Element;
//# sourceMappingURL=character-scene.d.ts.map