export { CharacterScene } from './character-scene.js';
export { WalkingCharacter } from './walking-character.js';
export { CharacterBadges, CharacterSpeech, CharacterStatus } from './character-badges.js';
export { useSceneAnimationFrame } from './use-animation-frame.js';
// Re-exported because a scene is the thing that needs to measure its own box,
// and every consumer of this package already reaches for it here. Dropping it
// would be a silent breaking change for anyone on an older @appkit/ui.
export { useElementSize } from '@appkit/ui';
export { DEFAULT_WALKING_CONFIG, IDLE_MOTION, LOBBY_GROUND, biasedSpawn, calculateScale, calculateZIndex, clampToWalkable, isInsideZones, pathCrossesZones, } from './config.js';
export { OFFICE_SCENE_KINDS, SCENE_BACKDROPS, SCENE_COMPONENTS, SCENE_GROUNDS, SCENE_HORIZONS, SCENE_ORDER, SceneArt, sceneGround, } from './scene-art.js';
//# sourceMappingURL=index.js.map