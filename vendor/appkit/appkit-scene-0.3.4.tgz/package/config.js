/**
 * Scene geometry and motion constants — extracted from the OpenStudio
 * homepage world and generalized: no product data, no data fetching, all
 * numbers overridable by the consuming application.
 *
 * The scene is a shallow stage seen from the front. Y (in percent of the
 * container height) doubles as depth: characters near the horizon are small
 * and behind, characters near the bottom are large and in front.
 */
export const DEFAULT_WALKING_CONFIG = {
    walkSpeed: 0.005,
    idleDuration: [3000, 7000],
    walkDuration: [2000, 4000],
    settlingDuration: 300,
    minEntityDistance: 8,
    spawnMinY: 60,
    exclusionZones: [],
};
/** A neutral indoor stage that suits an application shell. */
export const LOBBY_GROUND = {
    horizonY: 30,
    walkableArea: { minX: 6, maxX: 94, minY: 42, maxY: 88 },
    scaleRange: { min: 0.55, max: 1.15 },
    groundStyle: { colors: ['color-mix(in oklab, var(--color-bg) 88%, black)', 'var(--color-bg)'] },
    backdropStyle: { colors: ['var(--color-bg)', 'color-mix(in oklab, var(--color-bg) 92%, var(--color-primary))'] },
};
export const IDLE_MOTION = {
    bounce: { bounce: 4, rotate: 0, speed: 1.2 },
    sway: { bounce: 0, rotate: 2, speed: 2 },
    still: { bounce: 0, rotate: 0, speed: 1 },
    dance: { bounce: 6, rotate: 3, speed: 0.8 },
};
/** Depth scale from the character's Y position. */
export function calculateScale(y, ground) {
    const { minY, maxY } = ground.walkableArea;
    const t = Math.max(0, Math.min(1, (y - minY) / Math.max(1, maxY - minY)));
    return ground.scaleRange.min + t * (ground.scaleRange.max - ground.scaleRange.min);
}
/** Nearer characters paint over farther ones. */
export function calculateZIndex(y, ground) {
    const { minY, maxY } = ground.walkableArea;
    const t = Math.max(0, Math.min(1, (y - minY) / Math.max(1, maxY - minY)));
    return 10 + Math.round(t * 80);
}
export function clampToWalkable(x, y, area) {
    return {
        x: Math.max(area.minX, Math.min(area.maxX, x)),
        y: Math.max(area.minY, Math.min(area.maxY, y)),
    };
}
export function isInsideZones(x, y, zones) {
    return zones.some((zone) => x >= zone.minX && x <= zone.maxX && y >= zone.minY && y <= zone.maxY);
}
export function pathCrossesZones(x1, y1, x2, y2, zones) {
    if (zones.length === 0)
        return false;
    if (isInsideZones(x1, y1, zones) || isInsideZones(x2, y2, zones))
        return true;
    const steps = 10;
    for (let i = 1; i < steps; i++) {
        const t = i / steps;
        if (isInsideZones(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, zones))
            return true;
    }
    return false;
}
/** A downstage spawn point, clear of the exclusion zones. */
export function biasedSpawn(ground, config) {
    const { walkableArea } = ground;
    const minY = Math.max(walkableArea.minY, config.spawnMinY);
    for (let attempt = 0; attempt < 12; attempt++) {
        const x = walkableArea.minX + 4 + Math.random() * Math.max(1, walkableArea.maxX - walkableArea.minX - 8);
        const y = minY + Math.random() * Math.max(1, walkableArea.maxY - minY - 2);
        if (!isInsideZones(x, y, config.exclusionZones))
            return { x, y };
    }
    return { x: (walkableArea.minX + walkableArea.maxX) / 2, y: walkableArea.maxY - 4 };
}
//# sourceMappingURL=config.js.map