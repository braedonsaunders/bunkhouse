import { type SceneProps } from './scene-art.js';
declare function OfficeScene({ isDark }: SceneProps): import("react").JSX.Element;
declare function ExecutiveScene({ isDark }: SceneProps): import("react").JSX.Element;
declare function WarehouseScene({ isDark }: SceneProps): import("react").JSX.Element;
declare function ServerRoomScene({ isDark }: SceneProps): import("react").JSX.Element;
declare function BreakRoomScene({ isDark }: SceneProps): import("react").JSX.Element;
export { OfficeScene, ExecutiveScene, WarehouseScene, ServerRoomScene, BreakRoomScene };
//# sourceMappingURL=scene-art-office.d.ts.map