/**
 * Scene geometry and motion constants — extracted from the OpenStudio
 * homepage world and generalized: no product data, no data fetching, all
 * numbers overridable by the consuming application.
 *
 * The scene is a shallow stage seen from the front. Y (in percent of the
 * container height) doubles as depth: characters near the horizon are small
 * and behind, characters near the bottom are large and in front.
 */
import type * as React from 'react';
export type SceneGroundConfig = {
    /** Horizon line, percent from the top. */
    horizonY: number;
    /** Where characters may stand, in percent of the container. */
    walkableArea: {
        minX: number;
        maxX: number;
        minY: number;
        maxY: number;
    };
    /** Character scale at the horizon (min) and at the front edge (max). */
    scaleRange: {
        min: number;
        max: number;
    };
    /**
     * CSS backgrounds for the floor and the backdrop behind it — either color
     * stops for a plain top-to-bottom gradient, or a complete CSS background
     * (`css`), which wins when both are given. The painted stages in
     * `scene-art.tsx` use full gradient strings.
     */
    groundStyle: {
        colors?: string[];
        css?: string;
    };
    backdropStyle: {
        colors?: string[];
        css?: string;
    };
};
export type IdleAnimation = 'bounce' | 'sway' | 'still' | 'dance';
export type SceneCharacter = {
    id: string;
    name: string;
    /** Their role, shown beside the name on hover. */
    title?: string;
    /** Standing, transparent-background full-body art. Falls back to initials. */
    imageUrl?: string;
    /**
     * A rendered figure to use instead of `imageUrl` — for characters composed
     * from layered parts rather than stored as one flattened image (see
     * `@appkit/avatars/react`'s `ComposedAvatar`). It is stretched to the
     * character's box and mirrored with it, exactly as the image would be.
     */
    figure?: React.ReactNode;
    /** Multiplier on the scene walk speed (1 = normal). */
    walkSpeed?: number;
    idleAnimation?: IdleAnimation;
    /**
     * What this character is doing, shown as a pill beside them whether or not
     * anyone is hovering.
     *
     * A stage full of characters wandering about conveys that the office is
     * populated and nothing at all about whether anybody is working. The name
     * card on hover answers "who is that"; this answers "what is going on", which
     * is the question somebody actually opens this screen to ask.
     */
    status?: {
        label: string;
        tone: 'active' | 'busy' | 'idle' | 'waiting' | 'trouble';
        /** A second line — what it is working on, in a few words. */
        detail?: string;
    };
    /**
     * Something the character is saying right now, drawn as a bubble above them.
     *
     * Short-lived by nature: pass it while it is true and drop it when it stops
     * being. Long text is clamped rather than allowed to cover the scene — a
     * speech bubble is a glance, not a transcript.
     */
    speech?: {
        text: string;
        /** Distinguishes thinking-to-itself from talking to somebody. */
        kind?: 'say' | 'think';
    };
};
export type WalkingConfig = {
    /** Percent of the container traversed per millisecond. */
    walkSpeed: number;
    /** Random idle pause range, ms. */
    idleDuration: [number, number];
    /** Random walk-leg duration range, ms. */
    walkDuration: [number, number];
    /** Settling pause after arriving, ms. */
    settlingDuration: number;
    /** Minimum distance between characters, in percent units. */
    minEntityDistance: number;
    /** Characters spawn below this Y (percent) — keeps them downstage. */
    spawnMinY: number;
    /** Rectangles characters never enter or cross (e.g. the content card). */
    exclusionZones: {
        minX: number;
        maxX: number;
        minY: number;
        maxY: number;
    }[];
};
export declare const DEFAULT_WALKING_CONFIG: WalkingConfig;
/** A neutral indoor stage that suits an application shell. */
export declare const LOBBY_GROUND: SceneGroundConfig;
export declare const IDLE_MOTION: Record<IdleAnimation, {
    bounce: number;
    rotate: number;
    speed: number;
}>;
/** Depth scale from the character's Y position. */
export declare function calculateScale(y: number, ground: SceneGroundConfig): number;
/** Nearer characters paint over farther ones. */
export declare function calculateZIndex(y: number, ground: SceneGroundConfig): number;
export declare function clampToWalkable(x: number, y: number, area: SceneGroundConfig['walkableArea']): {
    x: number;
    y: number;
};
export declare function isInsideZones(x: number, y: number, zones: WalkingConfig['exclusionZones']): boolean;
export declare function pathCrossesZones(x1: number, y1: number, x2: number, y2: number, zones: WalkingConfig['exclusionZones']): boolean;
/** A downstage spawn point, clear of the exclusion zones. */
export declare function biasedSpawn(ground: SceneGroundConfig, config: WalkingConfig): {
    x: number;
    y: number;
};
//# sourceMappingURL=config.d.ts.map