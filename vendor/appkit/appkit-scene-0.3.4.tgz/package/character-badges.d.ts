import type { SceneCharacter } from './config.js';
/**
 * What a character is doing, and what it is saying.
 *
 * A stage of figures strolling about conveys that the office is populated and
 * nothing whatever about whether anybody is working — which is the only reason
 * to open it. These answer that without being hovered, because you cannot
 * hover eight characters at once.
 *
 * THE RULE THAT SHAPES ALL OF THIS: a label beside a walking figure has almost
 * no horizontal room, so nothing that needs truncating may go in it. The first
 * version put a sentence there and clipped it, and every character ended up
 * wearing the same grey "needs… waiting on a deci…" — unreadable, identical,
 * and worse than nothing. So the split is strict:
 *
 *   - the PILL carries state: one short word from a fixed vocabulary, with a
 *     glyph that animates the KIND of work. Never truncated, because nothing
 *     long is ever put in it.
 *   - the BUBBLE carries specifics, above the head, where there is room for a
 *     sentence and where clamping to three lines looks deliberate.
 *   - the NAME card stays on hover, and the pill crossfades out as it arrives
 *     so the two never stack.
 *
 * The glyphs are drawn here rather than imported so they can move: a rotating
 * arc reads as work in progress at eleven pixels in a way no static icon does.
 */
export type SceneActivity = 'working' | 'reading' | 'searching' | 'talking' | 'writing' | 'waiting' | 'idle';
/**
 * The pill: a moving glyph and one word. Nothing here can overflow, because
 * nothing long is allowed in.
 */
export declare function CharacterStatus({ status, scale }: {
    status: NonNullable<SceneCharacter['status']>;
    scale: number;
}): import("react").JSX.Element;
/**
 * The speech bubble: where the specifics go, because up here there is room for
 * them and clamping to three lines looks deliberate rather than clipped.
 */
export declare function CharacterSpeech({ speech, scale }: {
    speech: NonNullable<SceneCharacter['speech']>;
    scale: number;
}): import("react").JSX.Element;
/**
 * Both, placed around the figure. The pill sits exactly where the name card
 * does and fades as that arrives, so hovering swaps one for the other instead
 * of stacking two labels under a walking character.
 */
export declare function CharacterBadges({ character, scale, size, }: {
    character: SceneCharacter;
    scale: number;
    /** The figure's rendered box, so the bubble clears the head. */
    size: number;
}): import("react").JSX.Element;
//# sourceMappingURL=character-badges.d.ts.map