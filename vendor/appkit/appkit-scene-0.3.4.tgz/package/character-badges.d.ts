import type { SceneCharacter } from './config.js';
/**
 * The status pill: a dot, a few words, and optionally what it is working on.
 *
 * Deliberately the same material as the hover name card — elevated surface,
 * soft shadow, a little blur — so the scene reads as one family of labels
 * rather than a card and a separate widget that happen to share a stage.
 */
export declare function CharacterStatus({ status, scale, }: {
    status: NonNullable<SceneCharacter['status']>;
    /** The character's depth scale, so distant labels stay proportionate. */
    scale: number;
}): import("react").JSX.Element;
/**
 * The speech bubble, drawn above the character with a tail pointing down at
 * them.
 *
 * `think` gets a softer, rounder treatment and a trail of dots rather than a
 * tail — the ordinary comic grammar, and the quickest way to tell working out
 * loud from talking to somebody.
 */
export declare function CharacterSpeech({ speech, scale, }: {
    speech: NonNullable<SceneCharacter['speech']>;
    scale: number;
}): import("react").JSX.Element;
/**
 * Both, stacked above and below the figure, mounted and unmounted with
 * animation so a status appearing or a line being said is something you notice
 * out of the corner of your eye.
 */
export declare function CharacterBadges({ character, scale, size, }: {
    character: SceneCharacter;
    scale: number;
    /** The figure's rendered box, so the bubble sits just above the head. */
    size: number;
}): import("react").JSX.Element;
//# sourceMappingURL=character-badges.d.ts.map