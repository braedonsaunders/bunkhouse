/**
 * Scene art — six fully drawn stages (beach, campfire, forest, studio, space,
 * rooftop), each with a day and a night take, ported whole from the OpenStudio
 * homepage world. Everything is inline SVG and CSS gradients: no image assets,
 * sharp at any size, and themed by the `isDark` flag alone.
 *
 * The art is deliberately self-contained — the walking, depth-scaling, and
 * selection logic live in `CharacterScene`, which paints one of these behind
 * its characters via the `art` prop.
 */
import * as React from 'react';
/** The stages that ship with the scene package — leisure and work. */
export type SceneKind = 'beach' | 'campfire' | 'forest' | 'studio' | 'space' | 'rooftop' | 'office' | 'executive' | 'warehouse' | 'serverroom' | 'breakroom';
export interface SceneProps {
    isDark: boolean;
}
export declare function seededRandom(seed: number): () => number;
/** Horizon line per stage, percent from the top — mirrors the walk geometry. */
export declare const SCENE_HORIZONS: Record<SceneKind, number>;
declare const StarField: React.NamedExoticComponent<{
    count?: number;
    maxTop?: number;
}>;
declare const CloudLayer: React.NamedExoticComponent<{
    isDark: boolean;
}>;
declare const Particles: React.NamedExoticComponent<{
    color?: string;
    count?: number;
}>;
declare function BeachScene({ isDark }: SceneProps): React.JSX.Element;
export declare const PineTreeSilhouette: React.NamedExoticComponent<{
    x: number;
    scale: number;
    isDark: boolean;
}>;
export declare const LoonRipples: React.NamedExoticComponent<{
    x: number;
    isDark: boolean;
}>;
declare function CampfireScene({ isDark }: SceneProps): React.JSX.Element;
declare function ForestScene({ isDark }: SceneProps): React.JSX.Element;
declare function StudioScene({ isDark }: SceneProps): React.JSX.Element;
declare function SpaceScene({ isDark }: SceneProps): React.JSX.Element;
declare function RooftopScene({ isDark }: SceneProps): React.JSX.Element;
export declare const SCENE_COMPONENTS: Record<SceneKind, React.FC<SceneProps>>;
export declare const SCENE_BACKDROPS: Record<SceneKind, {
    day: string;
    night: string;
}>;
export declare const SCENE_GROUNDS: Record<SceneKind, {
    day: string;
    night: string;
}>;
export declare const SCENE_ORDER: SceneKind[];
/** The work environments — the subset an application about work reaches for. */
export declare const OFFICE_SCENE_KINDS: SceneKind[];
export { BeachScene, CampfireScene, ForestScene, StudioScene, SpaceScene, RooftopScene, };
export { StarField, CloudLayer, Particles };
import type { SceneGroundConfig } from './config.js';
/**
 * The full ground config for a painted stage: OpenStudio's walk geometry with
 * the stage's own day-or-night gradients. Pass to `CharacterScene`'s `ground`
 * alongside `art={<SceneArt kind={...} isDark={...} />}`.
 */
export declare function sceneGround(kind: SceneKind, isDark: boolean): SceneGroundConfig;
/** One painted stage, chosen by kind. */
export declare function SceneArt({ kind, isDark }: {
    kind: SceneKind;
    isDark: boolean;
}): React.JSX.Element;
//# sourceMappingURL=scene-art.d.ts.map