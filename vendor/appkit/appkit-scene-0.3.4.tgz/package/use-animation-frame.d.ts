/**
 * A requestAnimationFrame loop that pauses when the tab is hidden or the
 * caller says the scene is off-screen, and hands the callback a clamped
 * delta so a long pause never teleports characters.
 */
export declare function useSceneAnimationFrame(callback: (deltaMs: number) => void, active: boolean): void;
//# sourceMappingURL=use-animation-frame.d.ts.map