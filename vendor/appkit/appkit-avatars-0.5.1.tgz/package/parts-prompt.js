// Art direction for generating library parts.
//
// Ported from OpenStudio's `src/lib/avatar/generator.ts` (`ASSET_PROMPT_SUFFIX`
// / `ASSET_NEGATIVE_PROMPT`) and adjusted for one difference that matters: our
// parts are composited as DOM layers, so they must arrive **alpha-cut**.
// OpenStudio asked for a pure white background and cut it out afterwards with
// an image processor; asking for transparency directly removes a whole
// post-processing step, and the white-background wording is kept as the
// fallback instruction for models that cannot emit alpha.
//
// Pure strings and string-building — no provider, no network. Safe to import
// from a client bundle.
/**
 * The house style every part shares. A parts library only reads as one
 * character if every asset was drawn to the same sentence.
 */
export const PART_STYLE_SUFFIX = 'isolated single object, fully transparent background (PNG alpha, no backdrop of any kind), ' +
    'perfectly centered in frame, front-facing symmetric view, no shadows, no gradients, ' +
    'flat solid colors, clean vector-style illustration, 2D character asset sprite, ' +
    'uniform consistent art style, consistent scale with other parts of the same set, ' +
    'crisp clean cut-out edges, professional character art quality';
/** What a part must never contain. Kept verbatim in spirit from OpenStudio. */
export const PART_NEGATIVE_PROMPT = 'photorealistic, photograph, photo, realistic, hyperrealistic, 3D render, 3D, CGI, ' +
    'background scenery, complex background, colored background, gradient background, ' +
    'textured background, white background, checkerboard background, ' +
    'shadows, drop shadow, cast shadow, ambient occlusion, multiple objects, additional items, ' +
    'side view, three-quarter view, angled view, perspective, depth of field, bokeh, ' +
    'film grain, noise, blur, blurry, watermark, signature, text, logo, frame, border, ' +
    'vignette, lens flare, glow, reflection, glossy highlights, ' +
    'cropped, cut off, partial object, off-center';
/**
 * Build the full prompt for one library part. Mirrors OpenStudio's
 * `buildPromptFromPreset`: description, then category rules, then the shared
 * style, then the negative prompt folded in for models that take only one
 * string.
 */
export function buildPartPrompt(request) {
    const segments = [
        `${request.categoryLabel.toLowerCase()} asset for a character avatar: ${request.description.trim()}`,
    ];
    if (request.promptAddition?.trim())
        segments.push(request.promptAddition.trim());
    if (request.styleSuffix?.trim())
        segments.push(request.styleSuffix.trim());
    segments.push(PART_STYLE_SUFFIX);
    const prompt = segments.join(', ');
    return {
        prompt: `${prompt}.\n\nDo NOT include any of the following: ${PART_NEGATIVE_PROMPT}.`,
        negativePrompt: PART_NEGATIVE_PROMPT,
    };
}
//# sourceMappingURL=parts-prompt.js.map