import { type AvatarComposition, type AvatarHeadViewport, type AvatarPart, type AvatarPartCategory, type AvatarPartTransform } from '../composition.js';
export declare function useCompositionState(initial: AvatarComposition, categories: readonly AvatarPartCategory[]): {
    place: (part: AvatarPart, category: AvatarPartCategory) => void;
    remove: (categoryId: string) => void;
    select: (categoryId: string | null) => void;
    transform: (categoryId: string, transform: Partial<AvatarPartTransform>, commitChange?: boolean) => void;
    reorder: (categoryId: string, direction: "up" | "down") => void;
    setColorVariant: (categoryId: string, variant: string | null) => void;
    setOpacity: (categoryId: string, opacity: number, commitChange?: boolean) => void;
    setHidden: (categoryId: string, hidden: boolean) => void;
    setHeadViewport: (viewport: AvatarHeadViewport, commitChange?: boolean) => void;
    load: (composition: AvatarComposition) => void;
    reset: () => void;
    undo: () => void;
    redo: () => void;
    composition: AvatarComposition;
    selectedCategoryId: string | null;
    canUndo: boolean;
    canRedo: boolean;
    orderedCategoryIds: string[];
};
//# sourceMappingURL=use-composition-state.d.ts.map