'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Button, Input, Label, Select } from '@appkit/ui';
/**
 * Draw a new part without leaving the figure you are building: pick the slot,
 * say what you want, and keep the take that fits. Kept parts land in the
 * library rail immediately.
 */
export function GeneratePanel({ categories, generator, defaultCategoryId, onKept, }) {
    const [categoryId, setCategoryId] = React.useState(defaultCategoryId ?? categories[0]?.id ?? '');
    const [description, setDescription] = React.useState('');
    const [candidates, setCandidates] = React.useState([]);
    const [meta, setMeta] = React.useState(null);
    const [error, setError] = React.useState(null);
    const [busy, startBusy] = React.useTransition();
    const [keptIndex, setKeptIndex] = React.useState(null);
    const category = categories.find((entry) => entry.id === categoryId);
    const generate = () => startBusy(async () => {
        setError(null);
        setKeptIndex(null);
        const result = await generator.generate(categoryId, description.trim());
        if (!result.ok) {
            setCandidates([]);
            setError(result.message);
            return;
        }
        setCandidates(result.images);
        setMeta({ model: result.model, prompt: result.prompt });
    });
    const keep = (dataUri, index) => startBusy(async () => {
        setError(null);
        if (!meta)
            return;
        const name = description.trim() || `${category?.label ?? categoryId} ${index + 1}`;
        const result = await generator.keep({ categoryId, name, dataUri, model: meta.model, prompt: meta.prompt });
        if (!result.ok) {
            setError(result.message);
            return;
        }
        setKeptIndex(index);
        onKept?.(result.part, categoryId);
    });
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col rounded-lg border border-border bg-surface", children: [_jsxs("div", { className: "shrink-0 space-y-2 border-b border-border p-3", children: [_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { htmlFor: "generate-slot", children: "Slot" }), _jsx(Select, { id: "generate-slot", value: categoryId, onChange: (event) => setCategoryId(event.target.value), children: categories.map((entry) => (_jsx("option", { value: entry.id, children: entry.label }, entry.id))) })] }), _jsxs("div", { className: "space-y-1", children: [_jsx(Label, { htmlFor: "generate-description", children: "Describe it" }), _jsx(Input, { id: "generate-description", value: description, onChange: (event) => setDescription(event.target.value), placeholder: category ? `e.g. ${category.label.toLowerCase()} in navy` : 'e.g. round tortoiseshell glasses', onKeyDown: (event) => {
                                    if (event.key === 'Enter' && !busy)
                                        generate();
                                } })] }), _jsx(Button, { type: "button", size: "sm", className: "w-full", disabled: busy, onClick: generate, children: busy && candidates.length === 0 ? 'Drawing…' : 'Draw options' }), error ? _jsx("p", { className: "text-xs text-danger", children: error }) : null] }), _jsx("div", { className: "min-h-0 flex-1 overflow-y-auto p-3", children: candidates.length === 0 ? (_jsx("p", { className: "text-xs text-fg-muted", children: "Parts are drawn on a transparent background in the house style, so anything you keep composes with the rest of the library." })) : (_jsx("div", { className: "grid grid-cols-2 gap-2", children: candidates.map((uri, index) => (_jsxs("button", { type: "button", disabled: busy, onClick: () => keep(uri, index), title: "Keep this one", className: keptIndex === index
                            ? 'overflow-hidden rounded-lg border-2 border-primary bg-bg-subtle'
                            : 'overflow-hidden rounded-lg border border-border bg-bg-subtle transition-colors hover:border-primary', children: [_jsx("img", { src: uri, alt: `Option ${index + 1}`, className: "aspect-square w-full object-contain" }), _jsx("span", { className: "block px-1 pb-1 text-[11px] text-fg-muted", children: keptIndex === index ? 'in the library' : 'keep' })] }, index))) })) })] }));
}
//# sourceMappingURL=generate-panel.js.map