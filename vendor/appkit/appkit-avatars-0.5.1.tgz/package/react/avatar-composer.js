'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Redo2, RotateCcw, Undo2 } from 'lucide-react';
import { Alert, AlertDescription, Badge, Button, SubtabNav } from '@appkit/ui';
import { CANVAS_HEIGHT, CANVAS_WIDTH, missingRequiredCategories, } from '../composition.js';
import { ComposedAvatar } from './composed-avatar.js';
import { ComposerStage } from './composer-stage.js';
import { LayerPanel } from './layer-panel.js';
import { PartLibraryPanel } from './part-library-panel.js';
import { GeneratePanel } from './generate-panel.js';
import { TransformControls } from './transform-controls.js';
import { useCompositionState } from './use-composition-state.js';
export function AvatarComposer({ composition: initialComposition, parts, categories, onChange, onSave, saving, saveLabel = 'Save avatar', stageWidth = 340, subjectName, generateAction, generator, }) {
    const state = useCompositionState(initialComposition, categories);
    const [mode, setMode] = React.useState('compose');
    const [rail, setRail] = React.useState('parts');
    const { composition } = state;
    const changeRef = React.useRef(onChange);
    changeRef.current = onChange;
    const firstRender = React.useRef(true);
    React.useEffect(() => {
        if (firstRender.current) {
            firstRender.current = false;
            return;
        }
        changeRef.current?.(composition);
    }, [composition]);
    const placedPartIds = React.useMemo(() => new Set(Object.values(composition.parts).map((placement) => placement.partId)), [composition]);
    const missing = React.useMemo(() => missingRequiredCategories(composition, categories), [composition, categories]);
    const selectedCategory = categories.find((category) => category.id === state.selectedCategoryId);
    // The stage fills its column: as wide as fits, but never taller than the
    // panel, so the whole figure stays on screen at any window height.
    const stageAreaRef = React.useRef(null);
    const [stageArea, setStageArea] = React.useState({ width: 0, height: 0 });
    React.useEffect(() => {
        const element = stageAreaRef.current;
        if (!element)
            return;
        const observer = new ResizeObserver((entries) => {
            const rect = entries[0]?.contentRect;
            if (rect)
                setStageArea({ width: rect.width, height: rect.height });
        });
        observer.observe(element);
        return () => observer.disconnect();
    }, []);
    // Room for the caption and preview strip under the figure.
    const availableHeight = Math.max(240, stageArea.height - 84);
    const fittedStageWidth = Math.max(220, Math.min(stageArea.width || stageWidth, (availableHeight * CANVAS_WIDTH) / CANVAS_HEIGHT));
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col gap-3", children: [_jsxs("div", { className: "flex shrink-0 flex-wrap items-center justify-between gap-2", children: [_jsx(SubtabNav, { tabs: [
                            { key: 'compose', label: 'Compose' },
                            { key: 'headFraming', label: 'Head framing' },
                        ], active: mode, onSelect: (key) => {
                            setMode(key);
                            state.select(null);
                        }, ariaLabel: "Composer mode" }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Button, { type: "button", variant: "ghost", size: "sm", title: "Undo", disabled: !state.canUndo, onClick: state.undo, children: _jsx(Undo2, { className: "size-4" }) }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", title: "Redo", disabled: !state.canRedo, onClick: state.redo, children: _jsx(Redo2, { className: "size-4" }) }), _jsxs(Button, { type: "button", variant: "ghost", size: "sm", title: "Clear the figure", onClick: state.reset, children: [_jsx(RotateCcw, { className: "mr-1.5 size-4" }), " Clear"] }), onSave ? (_jsx(Button, { type: "button", disabled: saving, onClick: () => onSave(composition), children: saving ? 'Saving…' : saveLabel })) : null] })] }), parts.length === 0 ? (_jsx(Alert, { className: "shrink-0", children: _jsxs(AlertDescription, { className: "flex flex-wrap items-center gap-3", children: [_jsx("span", { children: "The parts library is empty \u2014 generate a set of parts and the figure builds from them." }), generateAction] }) })) : null, _jsxs("div", { className: "grid min-h-0 flex-1 gap-4 md:grid-cols-3", children: [_jsxs("div", { className: "flex min-h-0 flex-col gap-2 md:col-span-1", children: [_jsx(SubtabNav, { tabs: [
                                    { key: 'parts', label: 'Parts' },
                                    { key: 'layers', label: 'Layers', count: state.orderedCategoryIds.length },
                                    ...(generator ? [{ key: 'generate', label: 'Draw' }] : []),
                                ], active: rail, onSelect: (key) => setRail(key), ariaLabel: "Composer panel" }), _jsx("div", { className: "min-h-0 flex-1 overflow-hidden", children: rail === 'parts' ? (_jsx(PartLibraryPanel, { categories: categories, parts: parts, placedPartIds: placedPartIds, activeCategoryId: state.selectedCategoryId, onPlace: state.place })) : rail === 'generate' && generator ? (_jsx(GeneratePanel, { categories: categories, generator: generator, defaultCategoryId: state.selectedCategoryId, onKept: (part, categoryId) => {
                                        // Straight onto the figure: drawing a part is only useful if
                                        // you can see it on the person you are building.
                                        const category = categories.find((entry) => entry.id === categoryId);
                                        if (part && category)
                                            state.place(part, category);
                                    } })) : (_jsx(LayerPanel, { composition: composition, orderedCategoryIds: state.orderedCategoryIds, categories: categories, parts: parts, selectedCategoryId: state.selectedCategoryId, onSelect: state.select, onRemove: state.remove, onReorder: state.reorder, onSetColorVariant: state.setColorVariant, onSetOpacity: state.setOpacity, onSetHidden: state.setHidden })) }), _jsx("div", { className: "shrink-0", children: _jsx(TransformControls, { categoryId: state.selectedCategoryId, category: selectedCategory, placement: state.selectedCategoryId ? composition.parts[state.selectedCategoryId] : undefined, onTransform: state.transform }) })] }), _jsxs("div", { ref: stageAreaRef, className: "flex min-h-0 flex-col items-center justify-center gap-2 rounded-lg border border-border bg-surface p-3 md:col-span-2", children: [_jsx(ComposerStage, { composition: composition, parts: parts, categories: categories, selectedCategoryId: state.selectedCategoryId, mode: mode, width: fittedStageWidth, onSelect: state.select, onTransform: state.transform, onHeadViewport: state.setHeadViewport }), _jsxs("div", { className: "flex shrink-0 flex-wrap items-center justify-center gap-3", children: [_jsxs("span", { className: "flex items-center gap-2", children: [_jsx(ComposedAvatar, { composition: composition, parts: parts, categories: categories, variant: "head", size: 32, rounded: true, ...(subjectName ? { name: subjectName } : {}) }), _jsx("span", { className: "text-xs text-fg-muted", children: "Portrait everywhere else" })] }), missing.length > 0 ? (_jsxs(Badge, { variant: "outline", children: ["still to place: ", missing.map((category) => category.label.toLowerCase()).join(', ')] })) : null] }), _jsx("p", { className: "shrink-0 text-center text-xs text-fg-muted", children: mode === 'compose'
                                    ? 'Drag a part to move it, the corners to scale, the top handle to rotate. Hold Shift to bypass snapping.'
                                    : 'Drag the frame over the face. Every portrait in the app is this crop of the figure — there is no second image.' })] })] })] }));
}
//# sourceMappingURL=avatar-composer.js.map