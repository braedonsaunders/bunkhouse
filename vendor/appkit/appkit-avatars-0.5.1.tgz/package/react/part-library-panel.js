'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronDown, ChevronRight, Search } from 'lucide-react';
import { Badge, Input } from '@appkit/ui';
import { resolvePartUrl } from '../composition.js';
/**
 * The parts library — the composer's left rail.
 *
 * Ported from OpenStudio's `AssetLibraryPanel`: search across names and tags,
 * collapsible category groups with a count, and a thumbnail grid where a click
 * places the part. The lock/rarity overlay went with the unlock economy; what
 * replaces it is a "placed" marker, because a category holds one part and
 * clicking a second one replaces the first.
 */
export function PartLibraryPanel({ categories, parts, placedPartIds, activeCategoryId, onPlace, }) {
    const [query, setQuery] = React.useState('');
    const [collapsed, setCollapsed] = React.useState(new Set());
    const filtered = React.useMemo(() => {
        const trimmed = query.trim().toLowerCase();
        if (!trimmed)
            return parts;
        return parts.filter((part) => part.name.toLowerCase().includes(trimmed) ||
            part.tags?.some((tag) => tag.toLowerCase().includes(trimmed)));
    }, [parts, query]);
    const byCategory = React.useMemo(() => {
        const grouped = new Map();
        for (const part of filtered) {
            const list = grouped.get(part.categoryId);
            if (list)
                list.push(part);
            else
                grouped.set(part.categoryId, [part]);
        }
        return grouped;
    }, [filtered]);
    const toggle = (categoryId) => setCollapsed((previous) => {
        const next = new Set(previous);
        if (next.has(categoryId))
            next.delete(categoryId);
        else
            next.add(categoryId);
        return next;
    });
    const visible = categories.filter((category) => (byCategory.get(category.id)?.length ?? 0) > 0);
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col rounded-lg border border-border bg-surface", children: [_jsx("div", { className: "border-b border-border p-3", children: _jsxs("div", { className: "relative", children: [_jsx(Search, { className: "pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-fg-muted" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Search parts", "aria-label": "Search parts", className: "pl-8" })] }) }), _jsx("div", { className: "min-h-0 flex-1 overflow-y-auto", children: visible.length === 0 ? (_jsx("p", { className: "p-4 text-sm text-fg-muted", children: parts.length === 0
                        ? 'No parts in the library yet. Generate a set under Settings → Avatar parts.'
                        : 'No parts match that search.' })) : (visible.map((category) => {
                    const categoryParts = byCategory.get(category.id) ?? [];
                    const open = !collapsed.has(category.id);
                    return (_jsxs("div", { className: "border-b border-border last:border-b-0", children: [_jsxs("button", { type: "button", onClick: () => toggle(category.id), className: `flex w-full items-center justify-between px-3 py-2 text-left transition-colors hover:bg-bg-subtle ${activeCategoryId === category.id ? 'bg-primary-subtle' : ''}`, "aria-expanded": open, children: [_jsxs("span", { className: "flex items-center gap-2 text-sm font-medium text-fg", children: [open ? (_jsx(ChevronDown, { className: "size-4 text-fg-muted" })) : (_jsx(ChevronRight, { className: "size-4 text-fg-muted" })), category.label, category.required ? (_jsx(Badge, { variant: "outline", className: "text-[10px]", children: "required" })) : null] }), _jsx("span", { className: "text-xs text-fg-muted", children: categoryParts.length })] }), open ? (_jsx("div", { className: "grid grid-cols-3 gap-1.5 p-2", children: categoryParts.map((part) => {
                                    const placed = placedPartIds.has(part.id);
                                    return (_jsxs("button", { type: "button", onClick: () => onPlace(part, category), title: part.name, className: `group relative aspect-square overflow-hidden rounded-md border transition-colors ${placed
                                            ? 'border-primary ring-1 ring-primary/40'
                                            : 'border-border hover:border-primary'}`, children: [_jsx("img", { src: resolvePartUrl(part), alt: part.name, loading: "lazy", draggable: false, className: "h-full w-full bg-bg-subtle object-contain" }), placed ? (_jsx("span", { className: "absolute right-1 top-1 size-2 rounded-full bg-primary" })) : null] }, part.id));
                                }) })) : null] }, category.id));
                })) })] }));
}
//# sourceMappingURL=part-library-panel.js.map