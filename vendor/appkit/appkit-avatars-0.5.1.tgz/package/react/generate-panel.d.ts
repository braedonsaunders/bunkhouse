import * as React from 'react';
import type { AvatarPart, AvatarPartCategory } from '../composition.js';
/**
 * What the application must do for the composer to grow its own library:
 * turn a slot and a description into candidate images, then keep the chosen
 * one. Both are the app's business — it owns the model provider and the
 * store — so the composer only drives them.
 */
export type PartGenerator = {
    generate: (categoryId: string, description: string) => Promise<{
        ok: true;
        images: string[];
        model: string;
        prompt: string;
    } | {
        ok: false;
        message: string;
    }>;
    keep: (input: {
        categoryId: string;
        name: string;
        dataUri: string;
        model: string;
        prompt: string;
    }) => Promise<{
        ok: true;
        part?: AvatarPart;
    } | {
        ok: false;
        message: string;
    }>;
};
/**
 * Draw a new part without leaving the figure you are building: pick the slot,
 * say what you want, and keep the take that fits. Kept parts land in the
 * library rail immediately.
 */
export declare function GeneratePanel({ categories, generator, defaultCategoryId, onKept, }: {
    categories: readonly AvatarPartCategory[];
    generator: PartGenerator;
    defaultCategoryId?: string | null;
    onKept?: (part: AvatarPart | undefined, categoryId: string) => void;
}): React.JSX.Element;
//# sourceMappingURL=generate-panel.d.ts.map