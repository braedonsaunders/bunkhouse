import * as React from 'react';
import { type AvatarComposition, type AvatarHeadViewport, type AvatarPart, type AvatarPartCategory, type AvatarPartTransform } from '../composition.js';
export type StageMode = 'compose' | 'headFraming';
export declare function ComposerStage({ composition, parts, categories, selectedCategoryId, mode, width, onSelect, onTransform, onHeadViewport, }: {
    composition: AvatarComposition;
    parts: readonly AvatarPart[];
    categories: readonly AvatarPartCategory[];
    selectedCategoryId: string | null;
    mode: StageMode;
    /** Rendered stage width in px. Height follows the 512×768 aspect. */
    width: number;
    onSelect: (categoryId: string | null) => void;
    onTransform: (categoryId: string, transform: Partial<AvatarPartTransform>, commit?: boolean) => void;
    onHeadViewport: (viewport: AvatarHeadViewport, commit?: boolean) => void;
}): React.JSX.Element;
//# sourceMappingURL=composer-stage.d.ts.map