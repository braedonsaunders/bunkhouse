import type { AvatarPartCategory, AvatarPartPlacement, AvatarPartTransform } from '../composition.js';
/**
 * Numeric transform entry for the selected layer — ported from OpenStudio's
 * `TransformControls`. X/Y/rotation carry over; width and height are replaced
 * by a single `scale`, because a part's aspect ratio is a property of the
 * artwork and letting an operator stretch it independently is how a library
 * stops looking like one set.
 */
export declare function TransformControls({ categoryId, category, placement, onTransform, }: {
    categoryId: string | null;
    category: AvatarPartCategory | undefined;
    placement: AvatarPartPlacement | undefined;
    onTransform: (categoryId: string, transform: Partial<AvatarPartTransform>, commit?: boolean) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=transform-controls.d.ts.map