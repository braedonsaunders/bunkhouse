import * as React from 'react';
import { type AvatarComposition, type AvatarPart, type AvatarPartCategory } from '../composition.js';
/**
 * The layer stack — the composer's right rail.
 *
 * Ported from OpenStudio's `LayerPanel`: top layer first, thumbnail, name and
 * slot, a colour-variant tray with an opacity slider, and per-layer remove.
 * Drag-to-reorder is replaced by explicit up/down controls — the same
 * operation, but keyboard-reachable and unambiguous on touch, which HTML5
 * drag-and-drop reordering is not.
 */
export declare function LayerPanel({ composition, orderedCategoryIds, categories, parts, selectedCategoryId, onSelect, onRemove, onReorder, onSetColorVariant, onSetOpacity, onSetHidden, }: {
    composition: AvatarComposition;
    orderedCategoryIds: readonly string[];
    categories: readonly AvatarPartCategory[];
    parts: readonly AvatarPart[];
    selectedCategoryId: string | null;
    onSelect: (categoryId: string | null) => void;
    onRemove: (categoryId: string) => void;
    onReorder: (categoryId: string, direction: 'up' | 'down') => void;
    onSetColorVariant: (categoryId: string, variant: string | null) => void;
    onSetOpacity: (categoryId: string, opacity: number, commit?: boolean) => void;
    onSetHidden: (categoryId: string, hidden: boolean) => void;
}): React.JSX.Element;
//# sourceMappingURL=layer-panel.d.ts.map