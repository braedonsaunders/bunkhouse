'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { RotateCcw } from 'lucide-react';
import { Button, Input, Slider } from '@appkit/ui';
/**
 * Numeric transform entry for the selected layer — ported from OpenStudio's
 * `TransformControls`. X/Y/rotation carry over; width and height are replaced
 * by a single `scale`, because a part's aspect ratio is a property of the
 * artwork and letting an operator stretch it independently is how a library
 * stops looking like one set.
 */
export function TransformControls({ categoryId, category, placement, onTransform, }) {
    if (!categoryId || !category || !placement) {
        return (_jsx("div", { className: "rounded-lg border border-border bg-surface p-4", children: _jsx("p", { className: "text-center text-sm text-fg-muted", children: "Select a layer to move, scale, or rotate it." }) }));
    }
    const { transform } = placement;
    const set = (field, value, commit = true) => onTransform(categoryId, { [field]: value }, commit);
    return (_jsxs("div", { className: "space-y-3 rounded-lg border border-border bg-surface p-3", children: [_jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(Field, { label: "X", value: Math.round(transform.x), onChange: (v) => set('x', v) }), _jsx(Field, { label: "Y", value: Math.round(transform.y), onChange: (v) => set('y', v) })] }), _jsxs("div", { children: [_jsxs("div", { className: "mb-1 flex items-center justify-between", children: [_jsx("label", { className: "text-xs text-fg-muted", children: "Scale" }), _jsxs("span", { className: "text-xs tabular-nums text-fg-muted", children: [transform.scale.toFixed(2), "\u00D7"] })] }), _jsx(Slider, { min: 20, max: 300, value: Math.round(transform.scale * 100), onChange: (event) => set('scale', Number(event.target.value) / 100, false), onPointerUp: () => set('scale', transform.scale, true), "aria-label": "Scale" })] }), _jsxs("div", { children: [_jsxs("div", { className: "mb-1 flex items-center justify-between", children: [_jsx("label", { className: "text-xs text-fg-muted", children: "Rotation" }), _jsxs("span", { className: "text-xs tabular-nums text-fg-muted", children: [Math.round(transform.rotation), "\u00B0"] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Slider, { min: -180, max: 180, value: Math.round(transform.rotation), onChange: (event) => set('rotation', Number(event.target.value), false), onPointerUp: () => set('rotation', transform.rotation, true), "aria-label": "Rotation" }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", title: "Reset rotation", onClick: () => set('rotation', 0), children: _jsx(RotateCcw, { className: "size-4" }) })] })] }), _jsxs(Button, { type: "button", variant: "outline", size: "sm", className: "w-full", onClick: () => onTransform(categoryId, { ...category.defaultTransform }, true), children: ["Reset to ", category.label.toLowerCase(), " default"] })] }));
}
function Field({ label, value, onChange, }) {
    return (_jsxs("div", { children: [_jsx("label", { className: "mb-1 block text-xs text-fg-muted", children: label }), _jsx(Input, { type: "number", value: value, onChange: (event) => onChange(Number.parseInt(event.target.value, 10) || 0) })] }));
}
//# sourceMappingURL=transform-controls.js.map