import * as React from 'react';
import { type AvatarPart, type AvatarPartCategory } from '../composition.js';
/**
 * The parts library — the composer's left rail.
 *
 * Ported from OpenStudio's `AssetLibraryPanel`: search across names and tags,
 * collapsible category groups with a count, and a thumbnail grid where a click
 * places the part. The lock/rarity overlay went with the unlock economy; what
 * replaces it is a "placed" marker, because a category holds one part and
 * clicking a second one replaces the first.
 */
export declare function PartLibraryPanel({ categories, parts, placedPartIds, activeCategoryId, onPlace, }: {
    categories: readonly AvatarPartCategory[];
    parts: readonly AvatarPart[];
    placedPartIds: ReadonlySet<string>;
    activeCategoryId: string | null;
    onPlace: (part: AvatarPart, category: AvatarPartCategory) => void;
}): React.JSX.Element;
//# sourceMappingURL=part-library-panel.d.ts.map