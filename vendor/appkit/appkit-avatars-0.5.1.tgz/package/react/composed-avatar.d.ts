import * as React from 'react';
import { type AvatarComposition, type AvatarPart, type AvatarPartCategory } from '../composition.js';
/**
 * `full` renders the whole 512×768 stage; `head` crops to the composition's
 * head viewport. There is no third variant and no second stored image — a
 * portrait is this component with `variant="head"`.
 */
export type ComposedAvatarVariant = 'full' | 'head';
/**
 * `idle` is the resting figure — a slow breathing rise and a faint sway.
 * `talking` is the loop for a live call: a quicker head bob with the mouth
 * layer working. Both honour `prefers-reduced-motion` and fall still.
 */
export type ComposedAvatarAnimation = 'idle' | 'talking' | 'none';
export type ComposedAvatarProps = {
    composition: AvatarComposition;
    parts: readonly AvatarPart[];
    categories: readonly AvatarPartCategory[];
    variant?: ComposedAvatarVariant;
    /**
     * Rendered width in pixels. `full` is `size` wide and 1.5× that tall (the
     * stage's aspect); `head` is a `size` square.
     */
    size: number;
    animate?: ComposedAvatarAnimation;
    /** Shown when the composition resolves to no layers. Defaults to initials. */
    fallback?: React.ReactNode;
    /** Used for the initials fallback and the accessible name. */
    name?: string;
    className?: string;
    /** Round the frame — the usual choice for `head` in a directory. */
    rounded?: boolean;
};
/**
 * The one avatar renderer: a composition painted as absolutely positioned
 * `<img>` layers inside a scaled stage.
 *
 * OpenStudio composited to a `<canvas>` and stored the flattened PNG, which
 * cost it a stored image per size and per crop and made per-layer motion
 * impossible. Layering in the DOM instead keeps every part addressable — so a
 * mouth can move while a call is live — and stays sharp at any size, because
 * the browser rasterizes the source art at the size actually shown.
 */
export declare function ComposedAvatar({ composition, parts, categories, variant, size, animate, fallback, name, className, rounded, }: ComposedAvatarProps): React.JSX.Element;
//# sourceMappingURL=composed-avatar.d.ts.map