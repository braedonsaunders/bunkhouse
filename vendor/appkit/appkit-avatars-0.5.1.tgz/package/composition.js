// The avatar composition model — a parts library placed on one full-body
// stage, and the head crop that derives every portrait from it.
//
// Extracted from the OpenStudio avatar component system (`src/types/avatar.ts`,
// `src/lib/avatar/compositor.ts`, `src/components/avatar/canvas/*`) and
// generalized: no unlock rules, no rarity economy, no product storage. What
// remains is the part library, the per-layer transform, the layer order, and
// the head viewport.
//
// ## The coordinate model
//
// One canvas, {@link CANVAS_WIDTH} × {@link CANVAS_HEIGHT} **canvas units**,
// origin at the top-left, +x right and +y down. OpenStudio composed on a
// square 512×512 stage, which cannot hold a standing figure without wasting
// half the frame on empty margin; a portrait 512×768 stage fits one head-to-
// feet character with the same 512-unit horizontal vocabulary, so ported
// horizontal offsets carry over unchanged.
//
// There is exactly **one** composition per subject — the full body. A headshot
// is not a second image: it is {@link AvatarComposition.headViewport}, a
// rectangle in the same canvas units, and rendering a portrait means scaling
// and translating the one composition so that rectangle fills the frame.
/** Full-body stage width, in canvas units. */
export const CANVAS_WIDTH = 512;
/** Full-body stage height, in canvas units. */
export const CANVAS_HEIGHT = 768;
/**
 * A head-and-shoulders crop for a figure standing on the 512×768 stage: a
 * square roughly the top fifth of the frame, centred. Templates and the
 * composer both start here and adjust.
 */
export const DEFAULT_HEAD_VIEWPORT = { x: 156, y: 32, width: 200, height: 200 };
/** An empty composition — no parts placed, default head framing. */
export function createEmptyComposition(headViewport = DEFAULT_HEAD_VIEWPORT) {
    return { version: 1, parts: {}, headViewport: { ...headViewport } };
}
/**
 * Resolve a composition into back-to-front paint order.
 *
 * Ported from OpenStudio's compositor, which sorted the categories by
 * `layerOrder` and drew each selection at the category's fixed render box.
 * Here the placement carries its own transform, so the box is the category
 * frame scaled by the placement — free placement rather than fixed slots —
 * and the order may be overridden per layer.
 *
 * Categories and parts that no longer exist are skipped rather than thrown on:
 * a library is editable, and a person's saved composition must survive a part
 * being retired.
 */
export function sortLayers(composition, parts, categories, options) {
    const partsById = new Map(parts.map((part) => [part.id, part]));
    const categoriesById = new Map(categories.map((category) => [category.id, category]));
    const layers = [];
    for (const [categoryId, placement] of Object.entries(composition.parts)) {
        if (placement.hidden && !options?.includeHidden)
            continue;
        const category = categoriesById.get(categoryId);
        const part = partsById.get(placement.partId);
        if (!category || !part)
            continue;
        layers.push({
            categoryId,
            category,
            part,
            placement,
            url: resolvePartUrl(part, placement.colorVariant),
            order: placement.layerOrder ?? category.layerOrder,
            box: {
                left: placement.transform.x,
                top: placement.transform.y,
                width: category.frame.width * placement.transform.scale,
                height: category.frame.height * placement.transform.scale,
            },
            opacity: placement.opacity ?? 1,
        });
    }
    return layers.sort((a, b) => a.order - b.order || a.categoryId.localeCompare(b.categoryId));
}
/** The artwork for a part, preferring the requested colour variant. */
export function resolvePartUrl(part, colorVariant) {
    if (colorVariant) {
        const variant = part.colorVariants?.[colorVariant];
        if (variant)
            return variant;
    }
    return part.imageUrl;
}
/** Place a part in its category, keeping any transform already set there. */
export function placePart(composition, part, category) {
    const existing = composition.parts[category.id];
    return {
        ...composition,
        parts: {
            ...composition.parts,
            [category.id]: {
                partId: part.id,
                transform: existing?.transform ?? { ...category.defaultTransform },
                ...(existing?.colorVariant ? { colorVariant: existing.colorVariant } : {}),
                ...(existing?.layerOrder !== undefined ? { layerOrder: existing.layerOrder } : {}),
                ...(existing?.opacity !== undefined ? { opacity: existing.opacity } : {}),
            },
        },
    };
}
/** Remove a category's part from the composition. */
export function removePart(composition, categoryId) {
    if (!composition.parts[categoryId])
        return composition;
    const parts = { ...composition.parts };
    delete parts[categoryId];
    return { ...composition, parts };
}
/**
 * Which required categories are still empty. A composition can be saved
 * incomplete — half a figure is a legitimate work in progress — but the
 * composer says so.
 */
export function missingRequiredCategories(composition, categories) {
    return categories.filter((category) => category.required && !composition.parts[category.id]);
}
/**
 * The transform that makes a rectangle of the stage fill a frame.
 *
 * This is the whole headshot mechanism: pass {@link AvatarComposition.headViewport}
 * and the frame size, and the composition — rendered at its natural
 * {@link CANVAS_WIDTH}×{@link CANVAS_HEIGHT} — lands cropped to the head.
 * `cover` (the default) scales until the shorter viewport axis fills the
 * frame, so a portrait never shows empty bars; `contain` guarantees the whole
 * viewport is visible.
 */
export function viewportTransform(viewport, frame, fit = 'cover') {
    const byWidth = frame.width / Math.max(1, viewport.width);
    const byHeight = frame.height / Math.max(1, viewport.height);
    const scale = fit === 'cover' ? Math.max(byWidth, byHeight) : Math.min(byWidth, byHeight);
    return {
        scale,
        translateX: frame.width / 2 - scale * (viewport.x + viewport.width / 2),
        translateY: frame.height / 2 - scale * (viewport.y + viewport.height / 2),
    };
}
/** Smallest head crop, in canvas units — below this the face is unreadable. */
export const MIN_HEAD_VIEWPORT = 40;
export function clampHeadViewport(viewport) {
    // The crop's aspect ratio is fixed — it is the shape every portrait in the
    // app renders at — so clamping scales both axes by the same factor. Clamping
    // them independently would let a frame dragged past an edge come back
    // stretched, and the face would then render distorted everywhere it appears.
    const ratio = viewport.height > 0 ? viewport.width / viewport.height : 1;
    let height = Math.max(MIN_HEAD_VIEWPORT, viewport.height);
    let width = height * ratio;
    const shrink = Math.min(1, CANVAS_WIDTH / width, CANVAS_HEIGHT / height);
    width *= shrink;
    height *= shrink;
    return {
        width,
        height,
        x: Math.min(CANVAS_WIDTH - width, Math.max(0, viewport.x)),
        y: Math.min(CANVAS_HEIGHT - height, Math.max(0, viewport.y)),
    };
}
//# sourceMappingURL=composition.js.map