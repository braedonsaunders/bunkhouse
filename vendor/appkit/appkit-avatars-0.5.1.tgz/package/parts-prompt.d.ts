/**
 * The house style every part shares. A parts library only reads as one
 * character if every asset was drawn to the same sentence.
 */
export declare const PART_STYLE_SUFFIX: string;
/** What a part must never contain. Kept verbatim in spirit from OpenStudio. */
export declare const PART_NEGATIVE_PROMPT: string;
export type PartPromptRequest = {
    /** What the operator asked for: "short curly red hair". */
    description: string;
    /** The slot it fills, for the model's benefit: "Hair". */
    categoryLabel: string;
    /** The category's own art direction — {@link AvatarPartCategory.promptAddition}. */
    promptAddition?: string;
    /** Extra house style shared across the whole library. */
    styleSuffix?: string;
};
/**
 * Build the full prompt for one library part. Mirrors OpenStudio's
 * `buildPromptFromPreset`: description, then category rules, then the shared
 * style, then the negative prompt folded in for models that take only one
 * string.
 */
export declare function buildPartPrompt(request: PartPromptRequest): {
    prompt: string;
    negativePrompt: string;
};
//# sourceMappingURL=parts-prompt.d.ts.map