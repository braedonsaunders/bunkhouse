export { ComposedAvatar, type ComposedAvatarProps, type ComposedAvatarVariant, type ComposedAvatarAnimation, } from './react/composed-avatar.js';
export { AvatarComposer } from './react/avatar-composer.js';
export { ComposerStage, type StageMode } from './react/composer-stage.js';
export { PartLibraryPanel } from './react/part-library-panel.js';
export { LayerPanel } from './react/layer-panel.js';
export { TransformControls } from './react/transform-controls.js';
export { useCompositionState } from './react/use-composition-state.js';
export { GeneratePanel, type PartGenerator } from './react/generate-panel.js';
//# sourceMappingURL=react.d.ts.map