export declare function assertUuid(value: string, label: string): void;
export declare function assertString(value: string, label: string, options: {
    min?: number;
    max: number;
    pattern?: RegExp;
}): void;
export declare function assertOptionalString(value: string | undefined, label: string, max: number): void;
export declare function assertRelativeAppPath(value: string | undefined, label: string): void;
export declare function assertJsonBytes(value: unknown, label: string, maxBytes: number): void;
export declare function assertIdentifier(value: string, label: string, max?: number): void;
export declare function assertQueueJobId(value: string | undefined, label?: string): void;
//# sourceMappingURL=validation.d.ts.map