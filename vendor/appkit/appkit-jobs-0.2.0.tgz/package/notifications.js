import { createHash } from 'node:crypto';
import { Queue } from 'bullmq';
import { createProfileQueue, createProfileWorker } from './profile.js';
import { assertIdentifier, assertJsonBytes, assertOptionalString, assertQueueJobId, assertRelativeAppPath, assertString, assertUuid, } from './validation.js';
const MAX_USERS_PER_JOB = 250;
const MAX_USERS_PER_ENQUEUE = 100_000;
const MAX_JOBS_PER_ADD_BULK = 40;
const CHANNELS = new Set(['in_app', 'email', 'push', 'sms']);
export const NOTIFICATION_QUEUE_PROFILE = {
    name: 'notifications',
    defaultJobOptions: { attempts: 3, backoff: { type: 'fixed', delay: 5_000 }, removeOnComplete: { age: 24 * 3_600 }, removeOnFail: { age: 7 * 24 * 3_600 } },
    workerConcurrency: 10,
};
export const PUSH_QUEUE_PROFILE = {
    name: 'push',
    defaultJobOptions: { attempts: 5, backoff: { type: 'exponential', delay: 10_000 }, removeOnComplete: { age: 24 * 3_600 }, removeOnFail: { age: 30 * 24 * 3_600 } },
    workerConcurrency: 10,
};
export function normalizeNotifyJobData(data) {
    assertUuid(data.tenantId, 'Notification tenantId');
    if (!Array.isArray(data.userIds))
        throw new Error('Notification userIds must be an array.');
    const userIds = [...new Set(data.userIds.map((id) => id.trim()).filter(Boolean))];
    if (userIds.length === 0 || userIds.length > MAX_USERS_PER_ENQUEUE)
        throw new Error(`Notification userIds must contain between 1 and ${MAX_USERS_PER_ENQUEUE} recipients.`);
    for (const id of userIds)
        assertString(id, 'Notification userId', { min: 1, max: 200 });
    assertIdentifier(data.category, 'Notification category', 100);
    assertIdentifier(data.type, 'Notification type', 150);
    assertString(data.title, 'Notification title', { min: 1, max: 500 });
    assertOptionalString(data.body, 'Notification body', 20_000);
    assertRelativeAppPath(data.linkPath, 'Notification linkPath');
    assertJsonBytes(data.data ?? {}, 'Notification data', 64 * 1_024);
    if (data.channels && (data.channels.length === 0 || data.channels.length > CHANNELS.size || data.channels.some((channel) => !CHANNELS.has(channel))))
        throw new Error('Notification channels are invalid.');
    return { ...data, userIds, channels: data.channels ? [...new Set(data.channels)] : undefined };
}
export function buildNotifyQueueJobs(data, options = {}) {
    const normalized = normalizeNotifyJobData(data);
    assertQueueJobId(options.jobId, 'Notification jobId');
    if (normalized.userIds.length <= MAX_USERS_PER_JOB)
        return [{ name: 'dispatch', data: normalized, opts: options }];
    const jobs = [];
    for (let offset = 0; offset < normalized.userIds.length; offset += MAX_USERS_PER_JOB) {
        const userIds = normalized.userIds.slice(offset, offset + MAX_USERS_PER_JOB);
        const jobId = options.jobId ? `notification-batch|${createHash('sha256').update(`${normalized.tenantId}\0${options.jobId}\0${userIds.join('\0')}`).digest('hex')}` : undefined;
        jobs.push({ name: 'dispatch', data: { ...normalized, userIds }, opts: { ...options, ...(jobId ? { jobId } : {}) } });
    }
    return jobs;
}
export function assertPushJobData(data) {
    assertUuid(data.tenantId, 'Push tenantId');
    assertString(data.userId, 'Push userId', { min: 1, max: 200 });
    assertUuid(data.subscriptionId, 'Push subscriptionId');
    assertString(data.title, 'Push title', { min: 1, max: 500 });
    assertOptionalString(data.body, 'Push body', 20_000);
    assertRelativeAppPath(data.linkPath, 'Push linkPath');
}
/**
 * Bind the two production notification queues to an application-owned Jobs
 * runtime. Queue construction remains lazy, so importing this module never
 * contacts Redis during builds or server-component analysis.
 */
export function createNotificationQueues(jobs, overrides = {}) {
    let notifyQueue;
    let pushQueue;
    const getNotifyQueue = () => notifyQueue ??= createProfileQueue(jobs, NOTIFICATION_QUEUE_PROFILE, overrides.notifications);
    const getPushQueue = () => pushQueue ??= createProfileQueue(jobs, PUSH_QUEUE_PROFILE, overrides.push);
    return {
        getNotifyQueue,
        getPushQueue,
        async enqueueNotification(data, options) {
            const queue = getNotifyQueue();
            const definitions = buildNotifyQueueJobs(data, options);
            if (definitions.length === 1)
                return queue.add(definitions[0].name, definitions[0].data, definitions[0].opts);
            const added = [];
            for (let offset = 0; offset < definitions.length; offset += MAX_JOBS_PER_ADD_BULK)
                added.push(...await queue.addBulk(definitions.slice(offset, offset + MAX_JOBS_PER_ADD_BULK)));
            return added;
        },
        async enqueuePush(data, jobId) {
            assertPushJobData(data);
            assertQueueJobId(jobId, 'Push jobId');
            return getPushQueue().add('send', data, { jobId });
        },
        createNotificationWorker(processor) {
            return createProfileWorker(jobs, NOTIFICATION_QUEUE_PROFILE, processor, overrides.notifications);
        },
        createPushWorker(processor) {
            return createProfileWorker(jobs, PUSH_QUEUE_PROFILE, processor, overrides.push);
        },
    };
}
//# sourceMappingURL=notifications.js.map