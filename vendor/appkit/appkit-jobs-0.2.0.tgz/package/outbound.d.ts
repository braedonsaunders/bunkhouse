import type { Processor } from 'bullmq';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const OUTBOUND_QUEUE = "outbound";
export declare const OUTBOUND_QUEUE_PROFILE: {
    readonly name: "outbound";
    readonly defaultJobOptions: {
        readonly attempts: 5;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 15000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 5;
};
export type OutboundEvent = {
    type: string;
    tenantId: string;
    subjectId: string;
    items: Array<Record<string, string | number | boolean | null>>;
};
export type OutboundDispatchJob = {
    tenantId: string;
    automationId: string;
    event: OutboundEvent;
};
export declare function assertOutboundDispatchJob(data: OutboundDispatchJob): void;
export declare function createOutboundQueue(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => import("bullmq").Queue<OutboundDispatchJob, any, string, OutboundDispatchJob, any, string>;
    enqueueOutboundDispatch(data: OutboundDispatchJob, jobId?: string): Promise<import("bullmq").Job<OutboundDispatchJob, any, string>>;
    createWorker<R>(processor: Processor<OutboundDispatchJob, R>): import("bullmq").Worker<OutboundDispatchJob, R, string>;
};
//# sourceMappingURL=outbound.d.ts.map