import type { JobsOptions, Processor } from 'bullmq';
import type { TenantJobScope } from './identity.js';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const MIGRATION_QUEUE = "migration";
export declare const MIGRATION_QUEUE_PROFILE: {
    readonly name: "migration";
    readonly defaultJobOptions: {
        readonly attempts: 2;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 120000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 2;
};
export type MigrationJobData = TenantJobScope & {
    connectionId: string;
    mode: 'full_migration' | 'mirror' | 'attachments';
    triggeredBy?: string;
};
export declare function assertMigrationJobData(data: MigrationJobData): void;
export declare function createMigrationQueue(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => import("bullmq").Queue<MigrationJobData, any, string, MigrationJobData, any, string>;
    enqueueMigration(data: MigrationJobData, options?: JobsOptions): Promise<import("bullmq").Job<MigrationJobData, any, string>>;
    createWorker<R>(processor: Processor<MigrationJobData, R>): import("bullmq").Worker<MigrationJobData, R, string>;
};
//# sourceMappingURL=migration.d.ts.map