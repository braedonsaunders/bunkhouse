import { Queue, Worker, type ConnectionOptions, type Processor, type WorkerOptions } from 'bullmq';
/**
 * A BullMQ + Redis harness generalized behind a factory. Producers and blocking consumers need
 * opposite retry semantics: web/scheduler publishers must fail in bounded time
 * when Redis is down (`maxRetriesPerRequest: 1`); workers must keep their
 * blocking connection alive so BullMQ resumes after an outage
 * (`maxRetriesPerRequest: null`). Both stay lazy — importing a queue must not
 * connect (production builds walk the graph without Redis running).
 */
export type Jobs = {
    getConnection: () => ConnectionOptions;
    getBlockingConnection: () => ConnectionOptions;
    defineQueue: <T = unknown>(name: string) => Queue<T>;
    createWorker: <T = unknown, R = unknown>(name: string, processor: Processor<T, R>, options?: Omit<WorkerOptions, 'connection'>) => Worker<T, R>;
    closeJobConnections: () => Promise<void>;
};
export declare function createJobs(opts: {
    redisUrl: string;
}): Jobs;
export { Queue, Worker, type ConnectionOptions, type Processor, type WorkerOptions } from 'bullmq';
export * from './health.js';
export * from './rate-limit.js';
export * from './validation.js';
export * from './web-push.js';
export * from './notifications.js';
export * from './identity.js';
export * from './profile.js';
export * from './email.js';
export * from './outbound.js';
export * from './pdf.js';
export * from './reports.js';
export * from './scheduled.js';
export * from './scripts.js';
export * from './sandbox.js';
export * from './migration.js';
export * from './capture.js';
//# sourceMappingURL=index.d.ts.map