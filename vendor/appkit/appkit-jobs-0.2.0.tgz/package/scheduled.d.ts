import type { JobsOptions, Processor } from 'bullmq';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const SCHEDULED_QUEUE = "scheduled";
export declare const SCHEDULED_QUEUE_PROFILE: {
    readonly name: "scheduled";
    readonly defaultJobOptions: {
        readonly attempts: 3;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 10000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 5;
};
export type ScheduledTick = {
    kind: 'form_session_overdue_scan';
} | {
    kind: 'report_schedule_scan';
} | {
    kind: 'compliance_scan';
} | {
    kind: 'escalation_scan';
} | {
    kind: 'digest_scan';
} | {
    kind: 'scheduled_flow_scan';
} | {
    kind: 'sync_scan';
} | {
    kind: 'sync_run';
    tenantId: string;
    connectionId: string;
    trigger: 'scheduled' | 'manual';
} | {
    kind: 'db_maintenance';
    trigger?: 'scheduled' | 'manual';
} | {
    kind: 'domain_event_outbox_scan';
} | {
    kind: 'storage_object_deletion_scan';
} | {
    kind: 'office_render_reconcile';
};
export declare function isProductionScheduledTick(data: {
    kind: string;
}): data is ScheduledTick;
export declare function assertScheduledTick(data: ScheduledTick): void;
export declare function scheduledJobOptions(data: ScheduledTick, options?: JobsOptions): JobsOptions | undefined;
export type ScheduledDefinition<TTick extends {
    kind: string;
} = ScheduledTick> = {
    name: string;
    data: TTick;
    pattern: string;
    jobId: string;
    repeatKey: string;
};
export declare const PRODUCTION_SCHEDULES: readonly ScheduledDefinition[];
export type ExistingRepeatableJob = {
    key: string;
    name?: string;
    pattern?: string | null;
};
export declare function unconfiguredScheduleKeys(repeatables: readonly ExistingRepeatableJob[], schedules?: readonly ScheduledDefinition<{
    kind: string;
}>[]): string[];
export type ScheduledQueueOptions<TCustom extends {
    kind: string;
} = never> = QueueProfileOverrides & {
    schedules?: readonly ScheduledDefinition<ScheduledTick | TCustom>[];
    validateCustomTick?: (data: TCustom) => void;
};
export declare function createScheduledQueue<TCustom extends {
    kind: string;
} = never>(jobs: Jobs, options?: ScheduledQueueOptions<TCustom>): {
    getQueue: () => import("bullmq").Queue<ScheduledTick | TCustom, any, string, (ScheduledTick | TCustom) | (TCustom extends import("bullmq").Job<infer D, any, any> ? D : ScheduledTick | TCustom), any, string | (TCustom extends import("bullmq").Job<any, any, infer N extends string> ? N : string)>;
    enqueueScheduled: (name: string, data: ScheduledTick | TCustom, jobOptions?: JobsOptions) => Promise<import("bullmq").Job<(ScheduledTick | TCustom) | (TCustom extends import("bullmq").Job<infer D, any, any> ? D : ScheduledTick | TCustom), any, string | (TCustom extends import("bullmq").Job<any, any, infer N extends string> ? N : string)>>;
    registerSchedules: () => Promise<void>;
    createWorker<R>(processor: Processor<ScheduledTick | TCustom, R>): import("bullmq").Worker<ScheduledTick | TCustom, R, string>;
};
//# sourceMappingURL=scheduled.d.ts.map