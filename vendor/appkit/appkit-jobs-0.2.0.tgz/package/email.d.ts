import type { JobsOptions, Processor } from 'bullmq';
import { type EmailAttachmentPayload } from '@appkit/email-render/delivery-input';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const EMAIL_QUEUE = "emails";
export declare const EMAIL_QUEUE_PROFILE: {
    readonly name: "emails";
    readonly defaultJobOptions: {
        readonly attempts: 5;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 30000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 10;
};
export type EmailAttachment = EmailAttachmentPayload;
export type EmailJobData<TMeta extends Record<string, unknown> = Record<string, unknown>> = {
    /** Optional application identity used to resolve a tenant-owned provider. */
    tenantId?: string;
    /** Compatible identity spelling used by organization-based applications. */
    orgId?: string;
    /** One recipient per durable job prevents address disclosure between users. */
    to: string;
    subject: string;
    html: string;
    text: string;
    attachments?: EmailAttachment[];
    meta?: TMeta;
};
export type EnqueueEmailData<TMeta extends Record<string, unknown> = Record<string, unknown>> = Omit<EmailJobData<TMeta>, 'to'> & {
    to: string | string[];
};
export type EmailQueueJob<TMeta extends Record<string, unknown> = Record<string, unknown>> = {
    name: 'send';
    data: EmailJobData<TMeta>;
    opts?: JobsOptions;
};
/** Build one private durable job per normalized recipient without opening Redis. */
export declare function buildEmailQueueJobs<TMeta extends Record<string, unknown>>(data: EnqueueEmailData<TMeta>, options?: JobsOptions): EmailQueueJob<TMeta>[];
export declare function createEmailQueue<TMeta extends Record<string, unknown> = Record<string, unknown>>(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => import("bullmq").Queue<EmailJobData<TMeta>, any, string, EmailJobData<TMeta>, any, string>;
    enqueueEmail(data: EnqueueEmailData<TMeta>, options?: JobsOptions): Promise<import("bullmq").Job<EmailJobData<TMeta>, any, string>[]>;
    createWorker<R>(processor: Processor<EmailJobData<TMeta>, R>): import("bullmq").Worker<EmailJobData<TMeta>, R, string>;
};
//# sourceMappingURL=email.d.ts.map