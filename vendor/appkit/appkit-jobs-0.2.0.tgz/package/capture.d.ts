import type { JobsOptions, Processor } from 'bullmq';
import type { TenantJobScope } from './identity.js';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const CAPTURE_QUEUE = "capture";
export declare const CAPTURE_QUEUE_PROFILE: {
    readonly name: "capture";
    readonly defaultJobOptions: {
        readonly attempts: 3;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 30000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 3;
};
type CaptureItemIdentity = {
    itemId: string;
    captureItemId?: never;
} | {
    captureItemId: string;
    itemId?: never;
};
export type CaptureJobData = TenantJobScope & CaptureItemIdentity & {
    actorId?: string;
};
export declare function captureItemId(data: CaptureJobData): string;
export declare function assertCaptureJobData(data: CaptureJobData): void;
export type CaptureQueueOptions = QueueProfileOverrides & {
    jobIdPrefix?: string;
};
export declare function captureJobId(data: CaptureJobData, prefix?: string): string;
export declare function createCaptureQueue(jobs: Jobs, options?: CaptureQueueOptions): {
    getQueue: () => import("bullmq").Queue<CaptureJobData, any, string, CaptureJobData, any, string>;
    enqueueCapture(data: CaptureJobData, jobOptions?: JobsOptions): Promise<import("bullmq").Job<CaptureJobData, any, string>>;
    createWorker<R>(processor: Processor<CaptureJobData, R>): import("bullmq").Worker<CaptureJobData, R, string>;
};
export {};
//# sourceMappingURL=capture.d.ts.map