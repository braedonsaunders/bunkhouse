import type { JobsOptions, Processor } from 'bullmq';
import type { TenantJobScope } from './identity.js';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const SCRIPTS_QUEUE = "scripts";
export declare const SCRIPTS_QUEUE_PROFILE: {
    readonly name: "scripts";
    readonly defaultJobOptions: {
        readonly attempts: 1;
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 4;
};
export type ScriptJobData = TenantJobScope & {
    scriptId: string;
    kind: 'scheduled' | 'bulk';
    actorId?: string;
};
export declare function assertScriptJobData(data: ScriptJobData): void;
export declare function createScriptsQueue(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => import("bullmq").Queue<ScriptJobData, any, string, ScriptJobData, any, string>;
    enqueueScriptRun(data: ScriptJobData, options?: JobsOptions): Promise<import("bullmq").Job<ScriptJobData, any, string>>;
    createWorker<R>(processor: Processor<ScriptJobData, R>): import("bullmq").Worker<ScriptJobData, R, string>;
};
//# sourceMappingURL=scripts.d.ts.map