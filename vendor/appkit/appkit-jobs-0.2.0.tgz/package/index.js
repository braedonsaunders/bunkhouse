import { Redis } from 'ioredis';
import { Queue, Worker } from 'bullmq';
export function createJobs(opts) {
    let producer;
    let blocking;
    const getConnection = () => {
        producer ??= new Redis(opts.redisUrl, { enableReadyCheck: false, maxRetriesPerRequest: 1 });
        return producer;
    };
    const getBlockingConnection = () => {
        blocking ??= new Redis(opts.redisUrl, { enableReadyCheck: false, maxRetriesPerRequest: null });
        return blocking;
    };
    const defineQueue = (name) => new Queue(name, { connection: getConnection() });
    const createWorker = (name, processor, options) => new Worker(name, processor, { connection: getBlockingConnection(), ...options });
    async function closeJobConnections() {
        const connections = [producer, blocking].filter((c) => Boolean(c));
        producer = undefined;
        blocking = undefined;
        const results = await Promise.allSettled(connections.map(async (c) => {
            try {
                await c.quit();
            }
            catch (error) {
                c.disconnect(false);
                throw error;
            }
        }));
        const failures = results
            .filter((r) => r.status === 'rejected')
            .map((r) => r.reason);
        if (failures.length > 0) {
            throw new AggregateError(failures, 'One or more Redis connections failed to close cleanly');
        }
    }
    return { getConnection, getBlockingConnection, defineQueue, createWorker, closeJobConnections };
}
export { Queue, Worker } from 'bullmq';
export * from './health.js';
export * from './rate-limit.js';
export * from './validation.js';
export * from './web-push.js';
export * from './notifications.js';
export * from './identity.js';
export * from './profile.js';
export * from './email.js';
export * from './outbound.js';
export * from './pdf.js';
export * from './reports.js';
export * from './scheduled.js';
export * from './scripts.js';
export * from './sandbox.js';
export * from './migration.js';
export * from './capture.js';
//# sourceMappingURL=index.js.map