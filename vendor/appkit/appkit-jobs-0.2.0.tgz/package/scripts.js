import { assertTenantJobScope } from './identity.js';
import { createProfileQueue, createProfileWorker } from './profile.js';
import { assertString } from './validation.js';
export const SCRIPTS_QUEUE = 'scripts';
export const SCRIPTS_QUEUE_PROFILE = {
    name: SCRIPTS_QUEUE,
    defaultJobOptions: {
        // Authored scripts are not idempotent by contract and must never auto-retry.
        attempts: 1,
        removeOnComplete: { age: 7 * 24 * 3_600 },
        removeOnFail: { age: 30 * 24 * 3_600 },
    },
    workerConcurrency: 4,
};
export function assertScriptJobData(data) {
    assertTenantJobScope(data, 'Script');
    assertString(data.scriptId, 'Script scriptId', { min: 1, max: 200 });
    if (data.kind !== 'scheduled' && data.kind !== 'bulk')
        throw new Error('Script job kind is invalid.');
    if (data.actorId !== undefined)
        assertString(data.actorId, 'Script actorId', { min: 1, max: 200 });
}
export function createScriptsQueue(jobs, overrides = {}) {
    let queue;
    const getQueue = () => queue ??= createProfileQueue(jobs, SCRIPTS_QUEUE_PROFILE, overrides);
    return {
        getQueue,
        async enqueueScriptRun(data, options) {
            assertScriptJobData(data);
            return getQueue().add(data.kind, data, options);
        },
        createWorker(processor) {
            return createProfileWorker(jobs, SCRIPTS_QUEUE_PROFILE, processor, overrides);
        },
    };
}
//# sourceMappingURL=scripts.js.map