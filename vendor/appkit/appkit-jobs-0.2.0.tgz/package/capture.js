import { assertTenantJobScope } from './identity.js';
import { createProfileQueue, createProfileWorker } from './profile.js';
import { assertQueueJobId, assertString } from './validation.js';
export const CAPTURE_QUEUE = 'capture';
export const CAPTURE_QUEUE_PROFILE = {
    name: CAPTURE_QUEUE,
    defaultJobOptions: {
        attempts: 3,
        backoff: { type: 'exponential', delay: 30_000 },
        removeOnComplete: { age: 30 * 24 * 3_600 },
        removeOnFail: { age: 90 * 24 * 3_600 },
    },
    workerConcurrency: 3,
};
export function captureItemId(data) {
    const itemId = data.itemId ?? data.captureItemId;
    if (!itemId || (data.itemId && data.captureItemId)) {
        throw new Error('Capture job must contain exactly one item identity.');
    }
    return itemId;
}
export function assertCaptureJobData(data) {
    assertTenantJobScope(data, 'Capture');
    assertString(captureItemId(data), 'Capture itemId', { min: 1, max: 200 });
    if (data.actorId !== undefined)
        assertString(data.actorId, 'Capture actorId', { min: 1, max: 200 });
}
export function captureJobId(data, prefix = 'capture') {
    assertString(prefix, 'Capture jobId prefix', { min: 1, max: 100, pattern: /^[A-Za-z0-9._|-]+$/ });
    return `${prefix}|${captureItemId(data)}`;
}
export function createCaptureQueue(jobs, options = {}) {
    let queue;
    const getQueue = () => queue ??= createProfileQueue(jobs, CAPTURE_QUEUE_PROFILE, options);
    return {
        getQueue,
        async enqueueCapture(data, jobOptions) {
            assertCaptureJobData(data);
            const jobId = jobOptions?.jobId ?? captureJobId(data, options.jobIdPrefix);
            assertQueueJobId(jobId, 'Capture jobId');
            return getQueue().add('extract', data, { jobId: captureJobId(data, options.jobIdPrefix), ...jobOptions });
        },
        createWorker(processor) {
            return createProfileWorker(jobs, CAPTURE_QUEUE_PROFILE, processor, options);
        },
    };
}
//# sourceMappingURL=capture.js.map