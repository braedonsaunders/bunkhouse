import type { JobsOptions, Processor } from 'bullmq';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const SANDBOX_QUEUE = "sandbox";
export declare const SANDBOX_QUEUE_PROFILE: {
    readonly name: "sandbox";
    readonly defaultJobOptions: {
        readonly attempts: 1;
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 1;
};
type SandboxSourceIdentity = {
    productionTenantId: string;
    productionOrgId?: never;
} | {
    productionOrgId: string;
    productionTenantId?: never;
};
export type SandboxJobData = (SandboxSourceIdentity & {
    op: 'create';
    name: string;
    tier: 'dev' | 'masked' | 'full' | 'as_of';
    masked: boolean;
    asOfPeriodId?: string | null;
    createdBy?: string | null;
}) | {
    op: 'refresh';
    sandboxId: string;
    keepCustomizations: boolean;
} | {
    op: 'reset';
    sandboxId: string;
} | {
    op: 'delete';
    sandboxId: string;
};
export declare function assertSandboxJobData(data: SandboxJobData): void;
export declare function createSandboxQueue(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => import("bullmq").Queue<SandboxJobData, any, string, SandboxJobData, any, string>;
    enqueueSandboxOp(data: SandboxJobData, options?: JobsOptions): Promise<import("bullmq").Job<SandboxJobData, any, string>>;
    createWorker<R>(processor: Processor<SandboxJobData, R>): import("bullmq").Worker<SandboxJobData, R, string>;
};
export {};
//# sourceMappingURL=sandbox.d.ts.map