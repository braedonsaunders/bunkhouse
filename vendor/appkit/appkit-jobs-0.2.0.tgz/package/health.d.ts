/** Probe Redis through an isolated, bounded connection suitable for readiness. */
export declare function assertRedisReady(options: {
    url: string;
    timeoutMs?: number;
}): Promise<void>;
//# sourceMappingURL=health.d.ts.map