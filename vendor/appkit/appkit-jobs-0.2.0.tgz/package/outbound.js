import { createProfileQueue, createProfileWorker } from './profile.js';
import { assertIdentifier, assertJsonBytes, assertQueueJobId, assertString, assertUuid, } from './validation.js';
export const OUTBOUND_QUEUE = 'outbound';
export const OUTBOUND_QUEUE_PROFILE = {
    name: OUTBOUND_QUEUE,
    defaultJobOptions: {
        attempts: 5,
        backoff: { type: 'exponential', delay: 15_000 },
        removeOnComplete: { age: 7 * 24 * 3_600 },
        removeOnFail: { age: 30 * 24 * 3_600 },
    },
    workerConcurrency: 5,
};
export function assertOutboundDispatchJob(data) {
    assertUuid(data.tenantId, 'Outbound tenantId');
    assertUuid(data.automationId, 'Outbound automationId');
    if (!data.event || data.event.tenantId !== data.tenantId) {
        throw new Error('Outbound event identity does not match its dispatch tenant.');
    }
    assertIdentifier(data.event.type, 'Outbound event type', 200);
    assertString(data.event.subjectId, 'Outbound subjectId', { min: 1, max: 200 });
    if (!Array.isArray(data.event.items) || data.event.items.length > 5_000) {
        throw new Error('Outbound event items exceed the 5000 item limit.');
    }
    for (const item of data.event.items) {
        if (!item || typeof item !== 'object' || Array.isArray(item)) {
            throw new Error('Outbound event items must be flat records.');
        }
        const entries = Object.entries(item);
        if (entries.length > 500)
            throw new Error('Outbound event item exceeds the 500-field limit.');
        for (const [key, value] of entries) {
            assertString(key, 'Outbound event item key', { min: 1, max: 200 });
            if (value !== null && typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean') {
                throw new Error('Outbound event item values must be scalar JSON values.');
            }
            if (typeof value === 'string' && value.length > 100_000) {
                throw new Error('Outbound event item string exceeds 100000 characters.');
            }
            if (typeof value === 'number' && !Number.isFinite(value)) {
                throw new Error('Outbound event item numbers must be finite.');
            }
        }
    }
    assertJsonBytes(data.event.items, 'Outbound event items', 1_024 * 1_024);
}
export function createOutboundQueue(jobs, overrides = {}) {
    let queue;
    const getQueue = () => queue ??= createProfileQueue(jobs, OUTBOUND_QUEUE_PROFILE, overrides);
    return {
        getQueue,
        async enqueueOutboundDispatch(data, jobId) {
            assertOutboundDispatchJob(data);
            assertQueueJobId(jobId, 'Outbound jobId');
            return getQueue().add('dispatch', data, jobId ? { jobId } : undefined);
        },
        createWorker(processor) {
            return createProfileWorker(jobs, OUTBOUND_QUEUE_PROFILE, processor, overrides);
        },
    };
}
//# sourceMappingURL=outbound.js.map