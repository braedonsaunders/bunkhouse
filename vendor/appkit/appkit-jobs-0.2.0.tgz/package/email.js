import { createHash } from 'node:crypto';
import { normalizeEmailDeliveryInput, } from '@appkit/email-render/delivery-input';
import { createProfileQueue, createProfileWorker } from './profile.js';
export const EMAIL_QUEUE = 'emails';
export const EMAIL_QUEUE_PROFILE = {
    name: EMAIL_QUEUE,
    defaultJobOptions: {
        attempts: 5,
        backoff: { type: 'exponential', delay: 30_000 },
        removeOnComplete: { age: 7 * 24 * 3_600 },
        removeOnFail: { age: 30 * 24 * 3_600 },
    },
    workerConcurrency: 10,
};
function fanoutOptions(options, recipient) {
    if (!options?.jobId)
        return options;
    const digest = createHash('sha256')
        .update(options.jobId)
        .update('\0')
        .update(recipient.toLowerCase())
        .digest('hex');
    return { ...options, jobId: `email-fanout|${digest}` };
}
/** Build one private durable job per normalized recipient without opening Redis. */
export function buildEmailQueueJobs(data, options) {
    const normalized = normalizeEmailDeliveryInput(data);
    return normalized.to.map((recipient) => ({
        name: 'send',
        data: { ...data, ...normalized, to: recipient },
        opts: normalized.to.length === 1 ? options : fanoutOptions(options, recipient),
    }));
}
export function createEmailQueue(jobs, overrides = {}) {
    let queue;
    const getQueue = () => queue ??= createProfileQueue(jobs, EMAIL_QUEUE_PROFILE, overrides);
    return {
        getQueue,
        async enqueueEmail(data, options) {
            const definitions = buildEmailQueueJobs(data, options);
            const target = getQueue();
            if (definitions.length === 1) {
                const job = definitions[0];
                return [await target.add(job.name, job.data, job.opts)];
            }
            return target.addBulk(definitions);
        },
        createWorker(processor) {
            return createProfileWorker(jobs, EMAIL_QUEUE_PROFILE, processor, overrides);
        },
    };
}
//# sourceMappingURL=email.js.map