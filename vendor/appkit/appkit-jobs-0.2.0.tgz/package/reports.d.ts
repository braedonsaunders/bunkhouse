import type { JobsOptions, Processor } from 'bullmq';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const REPORTS_QUEUE = "reports";
export declare const REPORT_RUN_QUEUE_PROFILE: {
    readonly name: "reports";
    readonly defaultJobOptions: {
        readonly attempts: 3;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 30000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 2;
};
export declare const REPORT_DELIVERY_QUEUE_PROFILE: {
    readonly name: "reports";
    readonly defaultJobOptions: {
        readonly attempts: 3;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 60000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 3;
};
/** Durable scheduled-report claim used by the production scheduler/worker pair. */
export type ReportRunJobData = {
    tenantId: string;
    scheduleId: string;
    runId: string;
};
/** Render-and-deliver report job used by definition-driven applications. */
export type ReportDeliveryJobData = {
    orgId: string;
    definitionId: string;
    scheduleId?: string;
    recipients: string[];
    params?: Record<string, string>;
};
export declare function assertReportRunJobData(data: ReportRunJobData): void;
export declare function reportRunJobId(data: ReportRunJobData): string;
export declare function assertReportDeliveryJobData(data: ReportDeliveryJobData): void;
export declare function createReportRunQueue(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => import("bullmq").Queue<ReportRunJobData, any, string, ReportRunJobData, any, string>;
    enqueueReportRun(data: ReportRunJobData): Promise<import("bullmq").Job<ReportRunJobData, any, string>>;
    createWorker<R>(processor: Processor<ReportRunJobData, R>): import("bullmq").Worker<ReportRunJobData, R, string>;
};
export declare function createReportDeliveryQueue(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => import("bullmq").Queue<ReportDeliveryJobData, any, string, ReportDeliveryJobData, any, string>;
    enqueueReportRun(data: ReportDeliveryJobData, options?: JobsOptions): Promise<import("bullmq").Job<ReportDeliveryJobData, any, string>>;
    createWorker<R>(processor: Processor<ReportDeliveryJobData, R>): import("bullmq").Worker<ReportDeliveryJobData, R, string>;
};
//# sourceMappingURL=reports.d.ts.map