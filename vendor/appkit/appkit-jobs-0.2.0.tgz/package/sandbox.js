import { createProfileQueue, createProfileWorker } from './profile.js';
import { assertString, assertUuid } from './validation.js';
export const SANDBOX_QUEUE = 'sandbox';
export const SANDBOX_QUEUE_PROFILE = {
    name: SANDBOX_QUEUE,
    defaultJobOptions: {
        // Clone/refresh operations can leave partial state and are not safe to retry blindly.
        attempts: 1,
        removeOnComplete: { age: 7 * 24 * 3_600 },
        removeOnFail: { age: 30 * 24 * 3_600 },
    },
    workerConcurrency: 1,
};
export function assertSandboxJobData(data) {
    if (data.op === 'create') {
        const sourceId = data.productionTenantId ?? data.productionOrgId;
        if (!sourceId || (data.productionTenantId && data.productionOrgId)) {
            throw new Error('Sandbox create must contain exactly one production tenant identity.');
        }
        assertUuid(sourceId, 'Sandbox production tenant identity');
        assertString(data.name, 'Sandbox name', { min: 1, max: 200 });
        if (!['dev', 'masked', 'full', 'as_of'].includes(data.tier))
            throw new Error('Sandbox tier is invalid.');
        if (data.asOfPeriodId != null)
            assertString(data.asOfPeriodId, 'Sandbox asOfPeriodId', { min: 1, max: 200 });
        if (data.createdBy != null)
            assertString(data.createdBy, 'Sandbox createdBy', { min: 1, max: 200 });
        return;
    }
    assertUuid(data.sandboxId, 'Sandbox sandboxId');
}
export function createSandboxQueue(jobs, overrides = {}) {
    let queue;
    const getQueue = () => queue ??= createProfileQueue(jobs, SANDBOX_QUEUE_PROFILE, overrides);
    return {
        getQueue,
        async enqueueSandboxOp(data, options) {
            assertSandboxJobData(data);
            return getQueue().add(data.op, data, options);
        },
        createWorker(processor) {
            return createProfileWorker(jobs, SANDBOX_QUEUE_PROFILE, processor, overrides);
        },
    };
}
//# sourceMappingURL=sandbox.js.map