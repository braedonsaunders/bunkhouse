import { Queue, type JobsOptions, type Processor, type Worker } from 'bullmq';
import type { Jobs } from './index.js';
export type QueueProfile = {
    name: string;
    defaultJobOptions: JobsOptions;
    workerConcurrency: number;
};
export type QueueProfileOverrides = {
    name?: string;
    workerConcurrency?: number;
};
export declare function createProfileQueue<T>(jobs: Jobs, profile: QueueProfile, overrides?: QueueProfileOverrides): Queue<T>;
export declare function createProfileWorker<T, R = unknown>(jobs: Jobs, profile: QueueProfile, processor: Processor<T, R>, overrides?: QueueProfileOverrides): Worker<T, R>;
//# sourceMappingURL=profile.d.ts.map