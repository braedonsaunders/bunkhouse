import { assertUuid } from './validation.js';
export function assertTenantJobScope(scope, label = 'Job') {
    const tenantId = scope.tenantId ?? scope.orgId;
    if (!tenantId || (scope.tenantId && scope.orgId)) {
        throw new Error(`${label} must contain exactly one tenantId or orgId.`);
    }
    assertUuid(tenantId, `${label} tenant identity`);
    return tenantId;
}
//# sourceMappingURL=identity.js.map