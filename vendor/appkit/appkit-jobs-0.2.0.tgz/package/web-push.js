import webpush from 'web-push';
import { resolvePublicHost, secureFetch, validateOutboundRequestConfiguration } from '@appkit/sync/egress';
const MAX_ENDPOINT_LENGTH = 2_048;
const MAX_PUSH_PAYLOAD_BYTES = 3_072;
const MAX_PUSH_RESPONSE_BYTES = 16 * 1_024;
const PUSH_TIMEOUT_MS = 15_000;
function decodeBase64Url(value, label, expectedBytes) {
    const maxEncodedLength = Math.ceil((expectedBytes * 4) / 3) + 2;
    if (value.length > maxEncodedLength)
        throw new Error(`${label} has an invalid length or encoding.`);
    let normalized = value.trim();
    let padding = 0;
    while (normalized.endsWith('=')) {
        padding += 1;
        if (padding > 2)
            throw new Error(`${label} is not valid base64url data.`);
        normalized = normalized.slice(0, -1);
    }
    if (!normalized || [...normalized].some((character) => !/[A-Za-z0-9_-]/.test(character)))
        throw new Error(`${label} is not valid base64url data.`);
    const decoded = Buffer.from(normalized, 'base64url');
    if (decoded.length !== expectedBytes || decoded.toString('base64url') !== normalized)
        throw new Error(`${label} has an invalid length or encoding.`);
    return normalized;
}
export function validateWebPushEndpoint(endpoint) {
    if (typeof endpoint !== 'string' || !endpoint || endpoint.length > MAX_ENDPOINT_LENGTH)
        throw new Error('Web Push endpoint is missing or too long.');
    return validateOutboundRequestConfiguration(endpoint).url.href;
}
export function validateWebPushSubscription(input) {
    const endpoint = validateWebPushEndpoint(input.endpoint);
    const p256dh = decodeBase64Url(input.keys.p256dh, 'Web Push p256dh key', 65);
    if (Buffer.from(p256dh, 'base64url')[0] !== 4)
        throw new Error('Web Push p256dh key is not an uncompressed P-256 key.');
    const auth = decodeBase64Url(input.keys.auth, 'Web Push auth secret', 16);
    return { endpoint, keys: { p256dh, auth } };
}
export async function validateWebPushSubscriptionForPersistence(input) {
    const validated = validateWebPushSubscription(input);
    await resolvePublicHost(new URL(validated.endpoint).hostname, { timeoutMs: 5_000 });
    return validated;
}
function truncateJsonString(value, maxEncodedBytes) {
    const points = [...value];
    let low = 0;
    let high = points.length;
    while (low < high) {
        const middle = Math.ceil((low + high) / 2);
        if (Buffer.byteLength(JSON.stringify(points.slice(0, middle).join(''))) <= maxEncodedBytes)
            low = middle;
        else
            high = middle - 1;
    }
    if (low === points.length)
        return value;
    while (low > 0 && Buffer.byteLength(JSON.stringify(`${points.slice(0, low).join('')}…`)) > maxEncodedBytes)
        low -= 1;
    return `${points.slice(0, low).join('')}…`;
}
export function buildWebPushPayload(input) {
    const title = truncateJsonString(input.title, 512);
    const linkPath = input.linkPath ? truncateJsonString(input.linkPath, 1_024) : undefined;
    const base = { title, ...(linkPath ? { linkPath } : {}) };
    if (!input.body)
        return JSON.stringify(base);
    const points = [...input.body];
    let low = 0;
    let high = points.length;
    while (low < high) {
        const middle = Math.ceil((low + high) / 2);
        const candidate = JSON.stringify({ ...base, body: `${points.slice(0, middle).join('')}${middle < points.length ? '…' : ''}` });
        if (Buffer.byteLength(candidate) <= MAX_PUSH_PAYLOAD_BYTES)
            low = middle;
        else
            high = middle - 1;
    }
    const payload = JSON.stringify({ ...base, body: `${points.slice(0, low).join('')}${low < points.length ? '…' : ''}` });
    if (Buffer.byteLength(payload) > MAX_PUSH_PAYLOAD_BYTES)
        throw new Error('Web Push payload could not be reduced to the delivery limit.');
    return payload;
}
function requestHeaders(headers) {
    return Object.fromEntries(Object.entries(headers).filter(([name]) => name.toLowerCase() !== 'content-length').map(([name, value]) => [name, String(value)]));
}
export async function sendWebPushNotification(input) {
    const subscription = validateWebPushSubscription(input.subscription);
    const request = webpush.generateRequestDetails(subscription, buildWebPushPayload(input.payload), {
        TTL: 5 * 60,
        urgency: 'normal',
        contentEncoding: 'aes128gcm',
        vapidDetails: input.vapid,
    });
    const response = await secureFetch(request.endpoint, {
        method: 'POST',
        headers: requestHeaders(request.headers),
        body: request.body ?? null,
        timeoutMs: PUSH_TIMEOUT_MS,
        maxRequestBytes: 16 * 1_024,
        maxResponseBytes: MAX_PUSH_RESPONSE_BYTES,
        maxRedirects: 0,
    });
    if (response.ok)
        return;
    const detail = (await response.text()).replace(/[\u0000-\u001f\u007f]+/g, ' ').slice(0, 300);
    const error = new Error(`Web Push provider returned HTTP ${response.status}${detail ? `: ${detail}` : ''}`);
    error.statusCode = response.status;
    throw error;
}
//# sourceMappingURL=web-push.js.map