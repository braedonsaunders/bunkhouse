import { Queue } from 'bullmq';
export function createProfileQueue(jobs, profile, overrides = {}) {
    return new Queue(overrides.name ?? profile.name, {
        connection: jobs.getConnection(),
        defaultJobOptions: profile.defaultJobOptions,
    });
}
export function createProfileWorker(jobs, profile, processor, overrides = {}) {
    return jobs.createWorker(overrides.name ?? profile.name, processor, {
        concurrency: overrides.workerConcurrency ?? profile.workerConcurrency,
    });
}
//# sourceMappingURL=profile.js.map