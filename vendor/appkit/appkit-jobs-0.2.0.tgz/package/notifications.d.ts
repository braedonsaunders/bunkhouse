import { Queue, type JobsOptions, type Processor } from 'bullmq';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
/** Source-compatible job data for the production multi-channel dispatcher. */
export type NotifyJobData = {
    tenantId: string;
    userIds: string[];
    category: string;
    type: string;
    title: string;
    body?: string;
    linkPath?: string;
    data?: Record<string, unknown>;
    isCritical?: boolean;
    channels?: ('in_app' | 'email' | 'push' | 'sms')[];
};
export type PushJobData = {
    tenantId: string;
    userId: string;
    subscriptionId: string;
    title: string;
    body?: string;
    linkPath?: string;
};
export type NotificationQueueJob<T> = {
    name: string;
    data: T;
    opts: JobsOptions;
};
export declare const NOTIFICATION_QUEUE_PROFILE: {
    readonly name: "notifications";
    readonly defaultJobOptions: {
        readonly attempts: 3;
        readonly backoff: {
            readonly type: "fixed";
            readonly delay: 5000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 10;
};
export declare const PUSH_QUEUE_PROFILE: {
    readonly name: "push";
    readonly defaultJobOptions: {
        readonly attempts: 5;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 10000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 10;
};
export declare function normalizeNotifyJobData(data: NotifyJobData): NotifyJobData;
export declare function buildNotifyQueueJobs(data: NotifyJobData, options?: JobsOptions): NotificationQueueJob<NotifyJobData>[];
export declare function assertPushJobData(data: PushJobData): void;
/**
 * Bind the two production notification queues to an application-owned Jobs
 * runtime. Queue construction remains lazy, so importing this module never
 * contacts Redis during builds or server-component analysis.
 */
export declare function createNotificationQueues(jobs: Jobs, overrides?: {
    notifications?: QueueProfileOverrides;
    push?: QueueProfileOverrides;
}): {
    getNotifyQueue: () => Queue<NotifyJobData, any, string, NotifyJobData, any, string>;
    getPushQueue: () => Queue<PushJobData, any, string, PushJobData, any, string>;
    enqueueNotification(data: NotifyJobData, options?: JobsOptions): Promise<import("bullmq").Job<NotifyJobData, any, string> | import("bullmq").Job<NotifyJobData, any, string>[]>;
    enqueuePush(data: PushJobData, jobId: string): Promise<import("bullmq").Job<PushJobData, any, string>>;
    createNotificationWorker<R>(processor: Processor<NotifyJobData, R>): import("bullmq").Worker<NotifyJobData, R, string>;
    createPushWorker<R>(processor: Processor<PushJobData, R>): import("bullmq").Worker<PushJobData, R, string>;
};
//# sourceMappingURL=notifications.d.ts.map