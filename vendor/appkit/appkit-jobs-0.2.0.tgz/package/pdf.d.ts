import { type Processor, type Queue } from 'bullmq';
import type { EmailAttachment } from './email.js';
import type { Jobs } from './index.js';
import { type QueueProfileOverrides } from './profile.js';
export declare const PDF_QUEUE = "pdfs";
export declare const PDF_QUEUE_PROFILE: {
    readonly name: "pdfs";
    readonly defaultJobOptions: {
        readonly attempts: 3;
        readonly backoff: {
            readonly type: "exponential";
            readonly delay: 15000;
        };
        readonly removeOnComplete: {
            readonly age: number;
        };
        readonly removeOnFail: {
            readonly age: number;
        };
    };
    readonly workerConcurrency: 3;
};
export type PdfEmailPayload = {
    to: string[];
    subject: string;
    html: string;
    text: string;
    filename: string;
    category?: string;
    tenantId?: string;
    attachments?: EmailAttachment[];
};
export type PdfArtifactTarget = {
    kind: 'form_response';
    responseId: string;
};
export type PdfJobData = {
    kind: 'record_summary';
    tenantId: string;
    subjectId: string;
    entityType: string;
    heading: string;
    reference?: string | null;
    subtitle?: string | null;
    fields: {
        label: string;
        value: string;
    }[];
    sections?: {
        label: string;
        columns: {
            key: string;
            label: string;
        }[];
        rows: Record<string, string>[];
        moreRows?: number;
    }[];
    photos?: {
        url: string;
        caption?: string;
    }[];
    filename?: string;
    artifactTarget?: PdfArtifactTarget;
    email?: PdfEmailPayload;
} | {
    kind: 'template_pdf';
    tenantId: string;
    html: string;
    paperSize: 'letter' | 'a4' | 'legal';
    orientation: 'portrait' | 'landscape';
    marginMm: number;
    headerHtml?: string | null;
    footerHtml?: string | null;
    entityType: string;
    entityId: string;
    filename?: string;
    artifactTarget?: PdfArtifactTarget;
    email?: PdfEmailPayload;
} | {
    kind: 'document_version_render';
    tenantId: string;
    documentId: string;
    versionId: string;
} | {
    kind: 'document_master_pdf';
    tenantId: string;
    documentId: string;
} | {
    kind: 'document_book';
    tenantId: string;
    bookId: string;
} | {
    kind: 'document_bundle';
    tenantId: string;
    parts: {
        html: string;
        paperSize: 'letter' | 'a4' | 'legal';
        orientation: 'portrait' | 'landscape';
        marginMm: number;
        headerHtml?: string | null;
        footerHtml?: string | null;
    }[];
    filename: string;
    entityType: string;
    entityId: string;
    email?: PdfEmailPayload;
};
export type RecordSummaryPdfJobData = Omit<Extract<PdfJobData, {
    kind: 'record_summary';
}>, 'artifactTarget' | 'email'>;
type WithoutPdfDelivery<T> = T extends unknown ? Omit<T, 'artifactTarget' | 'email'> & {
    artifactTarget?: never;
    email?: never;
} : never;
export type OnDemandPdfJobData = WithoutPdfDelivery<Extract<PdfJobData, {
    kind: 'record_summary';
}> | Extract<PdfJobData, {
    kind: 'template_pdf';
}> | Extract<PdfJobData, {
    kind: 'document_master_pdf';
}> | Extract<PdfJobData, {
    kind: 'document_book';
}> | Extract<PdfJobData, {
    kind: 'document_bundle';
}>>;
export type RenderedPdfArtifact = {
    attachmentId?: string | null;
    r2Key: string;
    sizeBytes: number;
    filename: string;
};
export declare function assertPdfJobData(data: PdfJobData): void;
export declare function pdfJobId(data: PdfJobData): string;
type WithoutArtifactTarget<T> = T extends unknown ? Omit<T, 'artifactTarget'> & {
    artifactTarget?: never;
} : never;
export type PdfEmailableJobData = WithoutArtifactTarget<Extract<PdfJobData, {
    kind: 'record_summary' | 'template_pdf' | 'document_bundle';
}>>;
export declare function createPdfQueue(jobs: Jobs, overrides?: QueueProfileOverrides): {
    getQueue: () => Queue<PdfJobData, any, string, PdfJobData, any, string>;
    enqueuePdf: (data: PdfJobData, deterministicJobId?: string) => Promise<void>;
    renderPdfOnDemand: (data: OnDemandPdfJobData, opts?: {
        timeoutMs?: number;
    }) => Promise<RenderedPdfArtifact>;
    enqueuePdfEmail: (pdf: PdfEmailableJobData, email: PdfEmailPayload, deterministicJobId?: string) => Promise<void>;
    enqueueDocumentVersionRender: (data: Extract<PdfJobData, {
        kind: "document_version_render";
    }>) => Promise<void>;
    createWorker<R>(processor: Processor<PdfJobData, R>): import("bullmq").Worker<PdfJobData, R, string>;
};
export {};
//# sourceMappingURL=pdf.d.ts.map