/** Accepts either naming convention used by the production applications. */
export type TenantJobScope = {
    tenantId: string;
    orgId?: never;
} | {
    orgId: string;
    tenantId?: never;
};
export declare function assertTenantJobScope(scope: TenantJobScope, label?: string): string;
//# sourceMappingURL=identity.d.ts.map