export type WebPushSubscriptionInput = {
    endpoint: string;
    keys: {
        p256dh: string;
        auth: string;
    };
};
export type WebPushPayload = {
    title: string;
    body?: string;
    linkPath?: string;
};
export type WebPushVapidDetails = {
    subject: string;
    publicKey: string;
    privateKey: string;
};
export declare function validateWebPushEndpoint(endpoint: string): string;
export declare function validateWebPushSubscription(input: WebPushSubscriptionInput): WebPushSubscriptionInput;
export declare function validateWebPushSubscriptionForPersistence(input: WebPushSubscriptionInput): Promise<WebPushSubscriptionInput>;
export declare function buildWebPushPayload(input: WebPushPayload): string;
export declare function sendWebPushNotification(input: {
    subscription: WebPushSubscriptionInput;
    payload: WebPushPayload;
    vapid: WebPushVapidDetails;
}): Promise<void>;
//# sourceMappingURL=web-push.d.ts.map