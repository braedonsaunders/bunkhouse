export type RateLimitInput = {
    key: string;
    limit: number;
    windowSeconds: number;
};
export type RateLimitStatus = {
    allowed: boolean;
    count: number;
    remaining: number;
    resetAt: Date;
};
export type RateLimiter = {
    consume: (input: RateLimitInput) => Promise<RateLimitStatus>;
    status: (input: RateLimitInput) => Promise<RateLimitStatus>;
    recordFailure: (input: RateLimitInput) => Promise<RateLimitStatus>;
    reset: (input: Pick<RateLimitInput, 'key' | 'windowSeconds'>) => Promise<void>;
    close: () => Promise<void>;
};
export declare function createRateLimiter(options: {
    redisUrl: string;
}): RateLimiter;
//# sourceMappingURL=rate-limit.d.ts.map