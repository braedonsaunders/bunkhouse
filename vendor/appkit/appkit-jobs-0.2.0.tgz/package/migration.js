import { assertTenantJobScope } from './identity.js';
import { createProfileQueue, createProfileWorker } from './profile.js';
import { assertString } from './validation.js';
export const MIGRATION_QUEUE = 'migration';
export const MIGRATION_QUEUE_PROFILE = {
    name: MIGRATION_QUEUE,
    defaultJobOptions: {
        attempts: 2,
        backoff: { type: 'exponential', delay: 120_000 },
        removeOnComplete: { age: 30 * 24 * 3_600 },
        removeOnFail: { age: 30 * 24 * 3_600 },
    },
    workerConcurrency: 2,
};
export function assertMigrationJobData(data) {
    assertTenantJobScope(data, 'Migration');
    assertString(data.connectionId, 'Migration connectionId', { min: 1, max: 200 });
    if (!['full_migration', 'mirror', 'attachments'].includes(data.mode)) {
        throw new Error('Migration mode is invalid.');
    }
    if (data.triggeredBy !== undefined)
        assertString(data.triggeredBy, 'Migration triggeredBy', { min: 1, max: 200 });
}
export function createMigrationQueue(jobs, overrides = {}) {
    let queue;
    const getQueue = () => queue ??= createProfileQueue(jobs, MIGRATION_QUEUE_PROFILE, overrides);
    return {
        getQueue,
        async enqueueMigration(data, options) {
            assertMigrationJobData(data);
            return getQueue().add(data.mode, data, options);
        },
        createWorker(processor) {
            return createProfileWorker(jobs, MIGRATION_QUEUE_PROFILE, processor, overrides);
        },
    };
}
//# sourceMappingURL=migration.js.map