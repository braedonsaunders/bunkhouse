export { syncMailbox, verifyImap } from './sync.js';
export { sendMail, verifySmtp } from './send.js';
//# sourceMappingURL=index.js.map