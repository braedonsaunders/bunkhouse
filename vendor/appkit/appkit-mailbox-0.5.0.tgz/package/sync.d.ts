import type { MailboxConnection, MailboxStore, SyncResult } from './types.js';
/**
 * One incremental IMAP sync pass over INBOX. UIDVALIDITY change resets the
 * cursor (server renumbered the mailbox); otherwise only UIDs above the last
 * seen are fetched. Dedupe is by Message-ID via the store, so overlapping
 * passes are idempotent.
 */
export declare function syncMailbox(conn: MailboxConnection, store: MailboxStore): Promise<SyncResult>;
/** Cheap connectivity check used by the connect flow: can we authenticate? */
export declare function verifyImap(conn: MailboxConnection): Promise<void>;
//# sourceMappingURL=sync.d.ts.map