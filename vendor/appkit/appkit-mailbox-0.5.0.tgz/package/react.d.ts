/**
 * MailboxInbox — the operator surface for the mail engine.
 *
 * The engine in `./index` speaks IMAP/SMTP and owns no state; this component
 * owns no data. Everything it renders arrives as props and every mutation
 * leaves through a callback, so the application keeps the ledger, the folder
 * counts, and the send/reply transport. Only the reply and compose drafts
 * (with their busy/error state) live here, because a draft has no meaning
 * outside the pane that is typing it.
 *
 * The three-pane layout, folder rail, row anatomy, reading pane, empty states,
 * and skeleton follow `@appkit/notifications`' `NotificationInbox` so a mail
 * screen and a notification screen read as the same product.
 */
import * as React from 'react';
export type MailboxOption = {
    id: string;
    ownerName: string;
    address: string;
};
export type MailFolderKey = 'inbox' | 'sent' | 'all';
export type MailThreadListItem = {
    id: string;
    /** The other side of the conversation — one name, or a joined list. */
    counterparty: string;
    subject: string;
    /** ISO 8601 timestamp of the most recent message in the thread. */
    at: string;
    /** The thread is still awaiting a resolution. */
    open: boolean;
    unread?: boolean;
};
export type MailAttachmentView = {
    filename: string;
    /** Pre-formatted by the application ("184 KB") — this component never guesses units. */
    sizeLabel: string;
    href: string;
};
export type MailMessageView = {
    id: string;
    direction: 'inbound' | 'outbound';
    fromLabel: string;
    toLabel: string;
    /** ISO 8601 timestamp. */
    at: string;
    bodyText: string;
    attachments: MailAttachmentView[];
};
export type MailboxInboxCopy = {
    title: string;
    mailbox: string;
    searchMailboxes: string;
    folders: string;
    inbox: string;
    sent: string;
    all: string;
    refresh: string;
    newMessage: string;
    back: string;
    cancel: string;
    open: string;
    unread: string;
    conversation: string;
    conversations: string;
    messageNoun: string;
    messagesNoun: string;
    emptyList: string;
    emptyListDescription: string;
    emptyPane: string;
    emptyPaneDescription: string;
    noBody: string;
    attachments: string;
    download: string;
    reply: string;
    replyPlaceholder: string;
    send: string;
    sending: string;
    to: string;
    toPlaceholder: string;
    subject: string;
    subjectPlaceholder: string;
    message: string;
    messagePlaceholder: string;
};
export type MailboxInboxProps = {
    mailboxes: MailboxOption[];
    activeMailboxId: string;
    /**
     * Where switching mailbox goes. Omit it — or pass a single mailbox — on a
     * surface that is about one mailbox, and the switcher is not rendered.
     */
    onSwitchMailbox?: ((id: string) => void) | undefined;
    folder: MailFolderKey;
    folderCounts?: Partial<Record<MailFolderKey, number>>;
    onSwitchFolder: (key: MailFolderKey) => void;
    threads: MailThreadListItem[];
    activeThreadId: string | null;
    onSelectThread: (id: string | null) => void;
    conversation: {
        subject: string;
        messages: MailMessageView[];
    } | null;
    onReply: (text: string) => Promise<void>;
    onCompose: (draft: {
        to: string;
        subject: string;
        text: string;
    }) => Promise<void>;
    onRefresh?: () => void;
    /** Whose voice the reply is sent in — e.g. "Reply as Dana". */
    replyLabel?: string;
    className?: string;
    copy?: Partial<MailboxInboxCopy>;
};
export declare function MailboxInbox({ mailboxes, activeMailboxId, onSwitchMailbox, folder, folderCounts, onSwitchFolder, threads, activeThreadId, onSelectThread, conversation, onReply, onCompose, onRefresh, replyLabel, className, copy: copyOverrides, }: MailboxInboxProps): React.JSX.Element;
export declare function MailboxInboxSkeleton({ className }?: {
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=react.d.ts.map