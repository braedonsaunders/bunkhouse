import type { MailboxConnection, SendMailArgs, SendMailResult } from './types.js';
/**
 * Send one message over the mailbox's SMTP endpoint. Reply threading is the
 * caller's contract: pass the answered Message-ID and the full chain so every
 * client threads the conversation correctly.
 */
export declare function sendMail(conn: MailboxConnection, args: SendMailArgs): Promise<SendMailResult>;
/** Connectivity check for the connect flow: does SMTP accept our login? */
export declare function verifySmtp(conn: MailboxConnection): Promise<void>;
//# sourceMappingURL=send.d.ts.map