# @appkit/crypto

Sealed secrets (AES-256-GCM, HKDF-derived key) — the single implementation for tenant credentials at rest.

## Install

```bash
pnpm add @appkit/crypto
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
