export type SealedSecret = {
    ciphertext: string;
    nonce: string;
};
export type Sealer = {
    sealSecret: (plain: string) => SealedSecret;
    unsealSecret: (sealed: SealedSecret) => string | null;
};
export type ContextualSecretContext = {
    /** HKDF salt, normally a tenant id. */
    salt: string | Uint8Array;
    /** AES-GCM additional authenticated data, normally a record/key identity. */
    additionalData?: string | Uint8Array;
};
export type ContextualSealer = {
    /** Versioned base64 payload: version || nonce || auth tag || ciphertext. */
    sealSecret: (plain: string, context: ContextualSecretContext) => string;
    unsealSecret: (sealed: string, context: ContextualSecretContext) => string | null;
};
/** Build a sealer from an explicit source secret (HKDF-derived AES-256 key). */
export declare function createSealer(sourceSecret: string, options?: {
    hkdfInfo?: string;
}): Sealer;
/**
 * Build a compact contextual sealer for tenant/record-bound credentials.
 *
 * This entry exists for applications whose persisted ciphertext must derive a
 * different data key per tenant and bind the payload to a record identity.
 * It also lets an existing application move its established versioned compact
 * ciphertext into AppKit without rewriting live secrets.
 */
export declare function createContextualSealer(sourceSecret: string | Uint8Array, options?: {
    hkdfInfo?: string;
    sourceEncoding?: BufferEncoding;
    version?: number;
}): ContextualSealer;
export declare function sealSecret(plain: string): SealedSecret;
export declare function unsealSecret(sealed: SealedSecret): string | null;
//# sourceMappingURL=index.d.ts.map