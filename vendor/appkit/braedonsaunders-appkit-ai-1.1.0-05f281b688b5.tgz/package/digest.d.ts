import { type AiConfig } from './client.js';
export type DigestEntry = {
    date: string;
    author?: string | null;
    location?: string | null;
    text: string;
};
/** Summarise a batch of activity entries. Null when AI is unconfigured or empty. */
export declare function generateDigest(config: AiConfig | null | undefined, args: {
    scope?: string;
    entries: DigestEntry[];
}): Promise<string | null>;
//# sourceMappingURL=digest.d.ts.map