import { type AiConfig, type ModelTier } from './client.js';
export declare function runBuilderPrompt(config: AiConfig | null | undefined, args: {
    system: string;
    prompt: string;
    tier?: ModelTier;
}): Promise<string | null>;
//# sourceMappingURL=builder.d.ts.map