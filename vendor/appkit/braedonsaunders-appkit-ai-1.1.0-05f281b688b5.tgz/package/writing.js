// Inline writing assist — streamed token-by-token into the editor.
import { streamText } from 'ai';
import { AIDisabledError, getModel } from './client.js';
import { ENTRY_WRITING_SYSTEM, orgContextLine } from './prompts.js';
export const WRITING_MODES = [
    'tidy',
    'expand',
    'continue',
    'rephrase',
    'fix',
    'bulletize',
    'summarize',
];
const INSTRUCTIONS = {
    tidy: 'Rewrite the text below so it reads clearly and professionally, preserving every fact. Fix grammar and flow. Keep it roughly the same length.',
    expand: 'Expand the brief notes below into a fuller entry. Add natural connective wording, but NEVER invent specific facts (names, numbers, events) that are not present or clearly implied.',
    continue: 'Continue the entry below in the same voice for one to three more sentences. Output only the continuation.',
    rephrase: 'Rephrase the text below{tone}, preserving the meaning and all facts.',
    fix: 'Correct spelling, grammar and punctuation in the text below. Change nothing else.',
    bulletize: 'Convert the text below into a tight bulleted list covering the key activity, observations, and follow-up actions. Use "- " bullets and no preamble.',
    summarize: 'Summarize the text below into one short paragraph capturing the key activity, observations, and actions.',
};
export function isWritingMode(v) {
    return WRITING_MODES.includes(v);
}
/**
 * Stream a writing-assist transformation as a plain text-stream Response. Throws
 * AIDisabledError when the tenant has no model configured.
 */
export function streamWritingAssist(config, args) {
    const model = getModel(config, 'fast');
    if (!model)
        throw new AIDisabledError();
    const instruction = INSTRUCTIONS[args.mode].replace('{tone}', args.tone ? ` in a ${args.tone} tone` : '');
    const context = args.context
        ? `\n\nContext (background only, do not repeat verbatim): ${args.context}`
        : '';
    const result = streamText({
        model,
        system: ENTRY_WRITING_SYSTEM + orgContextLine(config?.org),
        prompt: `${instruction}${context}\n\n---\n${args.text}`,
        temperature: 0.4,
    });
    return result.toTextStreamResponse();
}
//# sourceMappingURL=writing.js.map