import { type LanguageModel } from 'ai';
export type AiProvider = 'anthropic' | 'openai' | 'google' | 'openrouter' | 'groq' | 'xai' | 'deepseek' | 'mistral' | 'custom';
export type ModelTier = 'fast' | 'smart';
/**
 * Platform-wide AI policy governing per-tenant overrides (mirrors the email/SMS
 * policy modes). 'disabled' is a global kill switch; 'global_only' forces the
 * platform provider for every tenant; 'tenant_optional' lets each tenant use its
 * own provider and falls back to the platform default.
 */
export type AiPolicyMode = 'tenant_optional' | 'global_only' | 'disabled';
export type AiConfig = {
    provider: AiProvider;
    apiKey: string;
    modelFast?: string | null;
    modelSmart?: string | null;
    /**
     * Endpoint for OpenAI-compatible providers. Required for `custom`; for the
     * named compatible providers it is an optional override of the built-in URL.
     */
    baseUrl?: string | null;
    /**
     * Organization (tenant) identity for prompt grounding, so generated content
     * uses the real org name instead of a placeholder. Populated by
     * `getTenantAiConfig`; content-generation paths inject it into the system
     * prompt, analysis/vision paths ignore it.
     */
    org?: {
        name: string;
    } | null;
};
type ProviderKind = 'anthropic' | 'openai' | 'google' | 'openai-compatible';
export type ProviderSpec = {
    value: AiProvider;
    label: string;
    kind: ProviderKind;
    /** Built-in endpoint for a named OpenAI-compatible provider (null otherwise). */
    baseUrl: string | null;
    /** True when the tenant MUST supply their own base URL (i.e. `custom`). */
    requiresBaseUrl: boolean;
    /** Default fast/smart model ids (placeholders + fallbacks). Empty for `custom`. */
    fast: string;
    smart: string;
    /** Placeholder shown in the API-key field. */
    keyHint: string;
    /** Optional note about the model-id format for this provider. */
    modelHint?: string;
    /**
     * True when this provider's API accepts IMAGE content inside a tool result
     * (Anthropic does; OpenAI's and Google's function/tool results are text/JSON
     * only). Gates vision tools that return rendered page images to the model —
     * see `providerSupportsImageToolResults`.
     */
    visionToolResults: boolean;
};
/**
 * Provider catalogue — single source of truth for the settings UI, the model
 * factory and config validation. Add a provider here and it lights up everywhere.
 */
export declare const AI_PROVIDER_SPECS: ProviderSpec[];
export declare function isAiProvider(value: unknown): value is AiProvider;
export declare function providerSpec(provider: AiProvider): ProviderSpec;
/**
 * Validate and canonicalize a persisted AI endpoint override. Runtime requests
 * repeat the public-DNS check immediately before opening each socket.
 */
export declare function validateAiBaseUrl(provider: AiProvider, rawBaseUrl: string | null | undefined): Promise<string | null>;
/** Socket-pinned transport for tenant-configurable OpenAI-compatible endpoints. */
export declare const secureAiFetch: typeof globalThis.fetch;
export declare function defaultModel(provider: AiProvider, tier: ModelTier): string;
/**
 * Whether the configured provider accepts IMAGE content in a tool result — the
 * capability that lets a tool hand rendered PDF pages back to the model for
 * vision reading. Currently Anthropic only; other providers' tool/function
 * results are text/JSON only, so exposing such a tool to them would break the
 * agent turn. Used to gate the assistant's `view_document_pages` tool.
 */
export declare function providerSupportsImageToolResults(config: AiConfig | null | undefined): boolean;
export declare function isAiConfigured(config: AiConfig | null | undefined): config is AiConfig;
/** Resolve a language model from a tenant's config, or null when not configured. */
export declare function getModel(config: AiConfig | null | undefined, tier?: ModelTier): LanguageModel | null;
export declare class AIDisabledError extends Error {
    readonly name = "AIDisabledError";
    constructor();
}
/** Live test of a config — sends a tiny prompt and reports success/failure. */
export declare function pingModel(config: AiConfig | null | undefined): Promise<{
    ok: boolean;
    message: string;
}>;
export {};
//# sourceMappingURL=client.d.ts.map