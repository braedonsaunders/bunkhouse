'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { parseJsonEventStream, readUIMessageStream, uiMessageChunkSchema, } from 'ai';
import { AlertCircle, CheckCircle2, ChevronRight, Database, ListPlus, Loader2, Pencil, RotateCcw, Send, Sparkles, Square, Trash2, } from 'lucide-react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Button, EmptyState, UiLink, cn } from '@braedonsaunders/appkit-ui';
const DEFAULT_LABELS = {
    title: 'Assistant',
    welcomeTitle: 'How can I help?',
    welcomeDescription: 'Ask about your workspace or let the assistant use an approved tool.',
    disabledTitle: 'Connect an AI provider',
    disabledDescription: 'Connect an AI provider to enable agent conversations. No provider credentials are included in the demo.',
    placeholder: 'Ask the assistant…',
    send: 'Send',
    stop: 'Stop generating',
    failed: 'The assistant could not complete that turn. Please try again.',
    input: 'Input',
    result: 'Result',
    working: 'Working',
    step: 'step',
    steps: 'steps',
    queue: 'Add to queue',
    queueTitle: 'Up next',
    queuePosition: 'Position',
    queued: 'Queued',
    dispatching: 'Starting',
    retrying: 'Retrying',
    queueFailed: 'This queued message needs attention.',
    editQueued: 'Edit queued message',
    removeQueued: 'Remove queued message',
    retryQueued: 'Retry queued message',
};
/**
 * The streaming thread/composer extracted from the sibling assistant. The app
 * owns persistence and the HTTP transport; appkit owns UI-message decoding,
 * cancellation, ordered part rendering, and tool cards.
 */
export function AgentPanel({ enabled, initialMessages = [], suggestions = [], labels: labelOverrides, headerActions, emptyContent, send, dispatchState = 'idle', queuedMessages = [], enqueue, onEditQueuedMessage, onRemoveQueuedMessage, onRetryQueuedMessage, maxPromptCharacters = 32_000, toolLabels, }) {
    const labels = { ...DEFAULT_LABELS, ...labelOverrides };
    const [messages, setMessages] = React.useState(initialMessages);
    const [input, setInput] = React.useState('');
    const [streaming, setStreaming] = React.useState(false);
    const [enqueueing, setEnqueueing] = React.useState(false);
    const [error, setError] = React.useState(null);
    const abortRef = React.useRef(null);
    const messageViewportRef = React.useRef(null);
    const scrollToBottom = React.useCallback(() => {
        window.requestAnimationFrame(() => {
            const viewport = messageViewportRef.current;
            if (viewport)
                viewport.scrollTop = viewport.scrollHeight;
        });
    }, []);
    // An existing conversation opens where work most recently happened. Keep
    // this scoped to the panel's own viewport: scrollIntoView also moves every
    // scrolling ancestor and can make an otherwise app-height page jump.
    React.useLayoutEffect(() => {
        scrollToBottom();
    }, [scrollToBottom]);
    const submit = React.useCallback(async (raw) => {
        const prompt = raw.trim();
        if (!enabled || !prompt || prompt.length > maxPromptCharacters)
            return;
        const shouldEnqueue = dispatchState !== 'idle' || abortRef.current !== null || queuedMessages.length > 0;
        if (shouldEnqueue) {
            if (!enqueue || enqueueing)
                return;
            setEnqueueing(true);
            setError(null);
            try {
                await enqueue(prompt);
                setInput('');
            }
            catch {
                setError(labels.queueFailed);
            }
            finally {
                setEnqueueing(false);
            }
            return;
        }
        if (!send)
            return;
        const controller = new AbortController();
        abortRef.current = controller;
        const stamp = Date.now();
        setInput('');
        setError(null);
        setMessages((current) => [...current, { id: `user-${stamp}`, role: 'user', parts: [{ type: 'text', text: prompt }] }, { id: `assistant-${stamp}`, role: 'assistant', parts: [] }]);
        setStreaming(true);
        scrollToBottom();
        let producedParts = false;
        try {
            const response = await send(prompt, controller.signal);
            if (!response.ok || !response.body)
                throw new Error('agent request failed');
            const chunks = parseJsonEventStream({ stream: response.body, schema: uiMessageChunkSchema }).pipeThrough(new TransformStream({ transform(part, stream) { if (part.success && part.value)
                    stream.enqueue(part.value); } }));
            let lastParts = [];
            for await (const message of readUIMessageStream({ stream: chunks })) {
                lastParts = message.parts;
                producedParts = lastParts.length > 0;
                setMessages((current) => replaceLastAssistantParts(current, lastParts));
                scrollToBottom();
            }
            if (lastParts.length === 0 && !controller.signal.aborted)
                setError(labels.failed);
        }
        catch (reason) {
            if (reason.name !== 'AbortError')
                setError(labels.failed);
        }
        finally {
            if (!producedParts) {
                setMessages((current) => current.filter((message) => message.id !== `assistant-${stamp}`));
            }
            setStreaming(false);
            if (abortRef.current === controller)
                abortRef.current = null;
        }
    }, [dispatchState, enabled, enqueue, enqueueing, labels.failed, labels.queueFailed, maxPromptCharacters, queuedMessages.length, scrollToBottom, send]);
    const queueMode = dispatchState !== 'idle' || streaming || queuedMessages.length > 0;
    return (_jsxs("div", { className: "flex min-h-0 flex-1 flex-col bg-bg-subtle", children: [_jsxs("header", { className: "flex h-12 shrink-0 items-center gap-2 border-b border-border bg-surface px-4", children: [_jsx(Sparkles, { size: 16, className: "text-primary" }), _jsx("span", { className: "text-sm font-medium text-fg", children: labels.title }), headerActions != null ? _jsx("div", { className: "ml-auto flex items-center gap-2", children: headerActions }) : null] }), _jsxs("div", { ref: messageViewportRef, className: "app-scroll min-h-0 flex-1 overflow-y-auto", children: [messages.length === 0 && emptyContent != null ? (_jsx("div", { className: "flex min-h-full flex-col", children: emptyContent })) : (_jsx("div", { className: "mx-auto w-full max-w-3xl px-4 py-6", children: messages.length === 0 ? _jsx(AgentWelcome, { enabled: enabled, title: enabled ? labels.welcomeTitle : labels.disabledTitle, description: enabled ? labels.welcomeDescription : labels.disabledDescription, suggestions: suggestions, onPick: (value) => void submit(value) }) : _jsx("div", { className: "space-y-6", children: messages.map((message) => message.role === 'system' ? null : _jsx(AgentMessageRow, { message: message, streaming: streaming, labels: labels, toolLabels: toolLabels }, message.id)) }) })), error ? _jsx("div", { role: "alert", className: "mx-auto mb-5 w-[calc(100%-2rem)] max-w-3xl rounded-lg border border-danger/25 bg-danger-subtle px-3 py-2 text-sm text-danger", children: error }) : null] }), enabled ? _jsx("div", { className: "shrink-0 border-t border-border bg-surface px-4 py-3", children: _jsxs("div", { className: "mx-auto w-full max-w-3xl", children: [queuedMessages.length > 0 ? _jsx(AgentMessageQueue, { messages: queuedMessages, labels: labels, onEdit: onEditQueuedMessage, onRemove: onRemoveQueuedMessage, onRetry: onRetryQueuedMessage }) : null, _jsxs("div", { className: "flex items-end gap-2 rounded-2xl border border-border-strong bg-surface p-2 shadow-sm focus-within:border-primary focus-within:ring-2 focus-within:ring-ring/20", children: [_jsx("textarea", { value: input, onChange: (event) => setInput(event.target.value), onKeyDown: (event) => { if (event.key === 'Enter' && !event.shiftKey) {
                                        event.preventDefault();
                                        void submit(input);
                                    } }, maxLength: maxPromptCharacters, rows: 1, placeholder: labels.placeholder, className: "max-h-40 flex-1 resize-none overflow-y-auto border-0 bg-transparent px-2 py-1.5 text-base text-fg outline-none placeholder:text-fg-subtle sm:text-sm" }), streaming ? _jsx(Button, { type: "button", variant: "outline", size: "icon", onClick: () => abortRef.current?.abort(), "aria-label": labels.stop, children: _jsx(Square, { size: 16 }) }) : null, _jsx(Button, { type: "button", size: "icon", onClick: () => void submit(input), disabled: !input.trim() || (queueMode ? !enqueue || enqueueing : !send), "aria-label": queueMode ? labels.queue : labels.send, children: enqueueing ? _jsx(Loader2, { size: 16, className: "animate-spin" }) : queueMode ? _jsx(ListPlus, { size: 16 }) : _jsx(Send, { size: 16 }) })] })] }) }) : null] }));
}
export function AgentMessageQueue({ messages, labels: labelOverrides, onEdit, onRemove, onRetry, }) {
    const labels = { ...DEFAULT_LABELS, ...labelOverrides };
    return (_jsxs("section", { className: "mb-3 rounded-xl border border-border bg-bg-subtle p-2", "aria-label": labels.queueTitle, children: [_jsx("div", { className: "px-2 pb-1 text-xs font-medium text-fg-muted", children: labels.queueTitle }), _jsx("ol", { className: "space-y-1", children: messages.map((message) => (_jsxs("li", { className: "flex min-w-0 items-center gap-2 rounded-lg bg-surface px-2 py-1.5 shadow-xs", children: [_jsx("span", { className: "flex size-6 shrink-0 items-center justify-center rounded-md bg-primary-subtle text-xs font-medium text-primary", "aria-label": `${labels.queuePosition} ${message.position}`, children: message.position }), _jsx("span", { className: "min-w-0 flex-1 truncate text-sm text-fg", children: message.text }), _jsx("span", { className: cn('shrink-0 text-xs', message.status === 'failed' ? 'text-danger' : 'text-fg-muted'), children: message.statusLabel ?? queueStatusLabel(message.status, labels) }), message.retryable && onRetry ? _jsx(Button, { type: "button", variant: "ghost", size: "icon", className: "size-7", onClick: () => onRetry(message), "aria-label": labels.retryQueued, children: _jsx(RotateCcw, { size: 14 }) }) : null, message.editable && onEdit ? _jsx(Button, { type: "button", variant: "ghost", size: "icon", className: "size-7", onClick: () => onEdit(message), "aria-label": labels.editQueued, children: _jsx(Pencil, { size: 14 }) }) : null, message.removable && onRemove ? _jsx(Button, { type: "button", variant: "ghost", size: "icon", className: "size-7", onClick: () => onRemove(message), "aria-label": labels.removeQueued, children: _jsx(Trash2, { size: 14 }) }) : null] }, message.id))) })] }));
}
function queueStatusLabel(status, labels) {
    if (status === 'dispatching')
        return labels.dispatching;
    if (status === 'retrying')
        return labels.retrying;
    if (status === 'failed')
        return labels.queueFailed;
    return labels.queued;
}
function replaceLastAssistantParts(messages, parts) {
    const copy = messages.slice();
    for (let index = copy.length - 1; index >= 0; index -= 1) {
        if (copy[index]?.role === 'assistant') {
            copy[index] = { ...copy[index], parts };
            break;
        }
    }
    return copy;
}
function AgentWelcome({ enabled, title, description, suggestions, onPick }) {
    return _jsxs("div", { className: "pt-10", children: [_jsx(EmptyState, { icon: _jsx(Sparkles, {}), title: title, description: description }), enabled && suggestions.length ? _jsx("div", { className: "mx-auto mt-6 grid max-w-2xl gap-2 sm:grid-cols-2", children: suggestions.map((suggestion) => _jsx("button", { type: "button", onClick: () => onPick(suggestion), className: "rounded-xl border border-border bg-surface px-4 py-3 text-left text-sm text-fg-muted shadow-sm transition-colors hover:border-primary/40 hover:bg-primary-subtle hover:text-fg", children: suggestion }, suggestion)) }) : null] });
}
function AgentMessageRow({ message, streaming, labels, toolLabels }) {
    if (message.role === 'user') {
        const text = message.parts.find((part) => part.type === 'text')?.text;
        return _jsx("div", { className: "flex justify-end", children: _jsx("div", { className: "max-w-[85%] rounded-2xl rounded-br-md bg-primary px-4 py-2 text-sm whitespace-pre-wrap text-primary-fg", children: text }) });
    }
    return _jsxs("div", { className: "flex gap-3", children: [_jsx("span", { className: "mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full bg-primary text-primary-fg shadow-sm", children: _jsx(Sparkles, { size: 16 }) }), _jsx("div", { className: "min-w-0 flex-1 pt-0.5", children: message.parts.length === 0 && streaming ? _jsx("div", { className: "flex items-center gap-1 py-1.5", children: [0, 1, 2].map((index) => _jsx("span", { className: "size-1.5 animate-bounce rounded-full bg-fg-subtle", style: { animationDelay: `${index * 0.15}s` } }, index)) }) : _jsx(AgentMessageParts, { parts: message.parts, labels: labels, toolLabels: toolLabels }) })] });
}
function AgentMessageParts({ parts, labels, toolLabels }) {
    const rendered = [];
    let tools = [];
    let toolGroupStart = 0;
    const flushTools = () => {
        if (tools.length === 0)
            return;
        rendered.push(_jsx(AgentToolActivity, { parts: tools, labels: labels, toolLabels: toolLabels }, `tools-${toolGroupStart}`));
        tools = [];
    };
    parts.forEach((part, index) => {
        if (isAgentToolPart(part)) {
            if (tools.length === 0)
                toolGroupStart = index;
            tools.push(part);
            return;
        }
        if (part.type === 'step-start' || part.type === 'reasoning')
            return;
        flushTools();
        if (part.type === 'text' && typeof part.text === 'string' && part.text.trim()) {
            rendered.push(_jsx(ChatMarkdown, { children: part.text }, `text-${index}`));
        }
    });
    flushTools();
    return _jsx("div", { className: "space-y-2.5", children: rendered });
}
function isAgentToolPart(part) {
    return part.type === 'dynamic-tool' || part.type.startsWith('tool-');
}
function agentToolName(part) {
    return part.type === 'dynamic-tool' ? String(part.toolName ?? 'tool') : part.type.slice(5);
}
function agentToolRunning(part) {
    const state = String(part.state ?? 'output-available');
    return state === 'input-streaming' || state === 'input-available';
}
function agentToolErrored(part) {
    return String(part.state) === 'output-error' || part.output?.ok === false;
}
/**
 * A multi-step run stays quiet in the transcript: the newest action and total
 * step count occupy one line, while the complete inputs/results remain one
 * click away. Applications keep their full durable audit trail separately.
 */
function AgentToolActivity({ parts, labels, toolLabels }) {
    const [open, setOpen] = React.useState(false);
    const latest = parts.at(-1);
    const latestName = agentToolName(latest);
    const running = parts.some(agentToolRunning);
    const errored = parts.some(agentToolErrored);
    const count = parts.length;
    const status = running ? labels.working : `${count} ${count === 1 ? labels.step : labels.steps}`;
    return _jsxs("div", { className: "text-sm", children: [_jsxs("button", { type: "button", onClick: () => setOpen((value) => !value), "aria-expanded": open, className: "flex h-7 max-w-full items-center gap-1.5 rounded-md px-1.5 text-left text-xs text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg", children: [_jsx("span", { className: cn('size-1.5 shrink-0 rounded-full', running ? 'animate-pulse bg-primary' : errored ? 'bg-danger' : 'bg-success') }), _jsx("span", { className: "shrink-0 font-medium", children: status }), _jsx("span", { "aria-hidden": true, className: "text-fg-subtle", children: "\u00B7" }), _jsx("span", { className: "min-w-0 truncate", children: toolLabels?.[latestName] ?? latestName.replaceAll('_', ' ') }), _jsx(ChevronRight, { size: 12, className: cn('shrink-0 text-fg-subtle transition-transform', open && 'rotate-90') })] }), open ? _jsx("div", { className: "mt-1.5 space-y-1.5 border-l border-border pl-2", children: parts.map((part, index) => { const name = agentToolName(part); return _jsx(AgentToolCard, { name: name, label: toolLabels?.[name], state: String(part.state ?? 'output-available'), input: part.input, output: part.output, inputLabel: labels.input, resultLabel: labels.result }, `${name}-${index}`); }) }) : null] });
}
export function ChatMarkdown({ children }) {
    return _jsx("div", { className: "space-y-2 text-sm leading-relaxed text-fg", children: _jsx(Markdown, { remarkPlugins: [remarkGfm], components: { p: ({ children: content }) => _jsx("p", { className: "whitespace-pre-wrap", children: content }), h1: ({ children: content }) => _jsx("h1", { className: "text-lg font-semibold", children: content }), h2: ({ children: content }) => _jsx("h2", { className: "text-base font-semibold", children: content }), ul: ({ children: content }) => _jsx("ul", { className: "list-disc space-y-1 pl-5", children: content }), ol: ({ children: content }) => _jsx("ol", { className: "list-decimal space-y-1 pl-5", children: content }), code: ({ children: content }) => _jsx("code", { className: "rounded bg-bg-subtle px-1 py-0.5 font-mono text-[0.85em] text-primary", children: content }), pre: ({ children: content }) => _jsx("pre", { className: "overflow-auto rounded-lg bg-overlay p-3 text-sm whitespace-pre-wrap text-white", children: content }), table: ({ children: content }) => _jsx("div", { className: "overflow-x-auto", children: _jsx("table", { className: "w-full border-collapse text-sm", children: content }) }), th: ({ children: content }) => _jsx("th", { className: "border-b border-border px-2 py-1 text-left", children: content }), td: ({ children: content }) => _jsx("td", { className: "border-b border-border-subtle px-2 py-1", children: content }), a: ({ href, children: content }) => href?.startsWith('/') ? _jsx(UiLink, { href: href, className: "font-medium text-primary underline-offset-2 hover:underline", children: content }) : _jsx("a", { href: href, target: "_blank", rel: "noreferrer", className: "font-medium text-primary underline-offset-2 hover:underline", children: content }) }, children: children }) });
}
export function AgentToolCard({ name, label, state, input, output, inputLabel = 'Input', resultLabel = 'Result' }) {
    const [open, setOpen] = React.useState(false);
    const running = state === 'input-streaming' || state === 'input-available';
    const errored = state === 'output-error' || output?.ok === false;
    return _jsxs("div", { className: "overflow-hidden rounded-lg border border-border bg-bg-subtle text-sm", children: [_jsxs("button", { type: "button", onClick: () => setOpen((value) => !value), className: "flex w-full items-center gap-2.5 px-3 py-2 text-left transition-colors hover:bg-surface-hover", children: [_jsx("span", { className: cn('flex size-6 shrink-0 items-center justify-center rounded-md', errored ? 'bg-danger-subtle text-danger' : 'bg-primary-subtle text-primary'), children: _jsx(Database, { size: 14 }) }), _jsx("span", { className: "min-w-0 flex-1 truncate font-medium text-fg", children: label ?? name.replaceAll('_', ' ') }), running ? _jsx(Loader2, { size: 14, className: "animate-spin text-fg-subtle" }) : errored ? _jsx(AlertCircle, { size: 14, className: "text-danger" }) : _jsx(CheckCircle2, { size: 14, className: "text-success" }), _jsx(ChevronRight, { size: 14, className: cn('text-fg-subtle transition-transform', open && 'rotate-90') })] }), open ? _jsxs("div", { className: "space-y-2 border-t border-border px-3 py-2", children: [input !== undefined ? _jsx(AgentToolDetail, { label: inputLabel, value: input }) : null, output !== undefined ? _jsx(AgentToolDetail, { label: resultLabel, value: output }) : null] }) : null] });
}
function AgentToolDetail({ label, value }) {
    let text;
    try {
        text = JSON.stringify(value, null, 2);
    }
    catch {
        text = String(value);
    }
    return _jsxs("div", { children: [_jsx("div", { className: "mb-1 text-[11px] font-semibold tracking-wide text-fg-subtle uppercase", children: label }), _jsx("pre", { className: "max-h-60 overflow-auto rounded-md bg-surface p-2 text-xs leading-relaxed text-fg ring-1 ring-border", children: text })] });
}
//# sourceMappingURL=react.js.map