import type { ModelMessage } from 'ai';
export declare const DEFAULT_VISUAL_CONTEXT_FRAMES = 2;
export type VisualContextPruneResult = {
    messages: ModelMessage[];
    prunedFrames: number;
    deduplicatedFrames: number;
};
/**
 * Keep only the newest distinct tool-result images. Tool-call/result structure
 * remains intact, and textual metadata stays available, but a long desktop or
 * browser session no longer resends every historical screenshot on every step.
 * User-supplied image messages are deliberately untouched.
 */
export declare function pruneVisualToolContext(messages: readonly ModelMessage[], options?: {
    keepRecent?: number;
    omittedText?: string;
}): VisualContextPruneResult;
//# sourceMappingURL=context.d.ts.map