import { type LanguageModel, type ModelMessage, type ToolSet, type UIMessage } from 'ai';
export type AgentModelTier = 'fast' | 'smart';
export declare class AgentDisabledError extends Error {
    constructor(message?: string);
}
export type AgentTurnResult = {
    parts: UIMessage['parts'];
    aborted: boolean;
    finishReason: string;
    usage: {
        inputTokens: number;
        outputTokens: number;
    };
};
export type RunAgentTurnArgs = {
    model: LanguageModel | null | undefined;
    messages: ModelMessage[];
    system: string;
    tools: ToolSet;
    maxSteps?: number;
    temperature?: number;
    abortSignal?: AbortSignal;
    onComplete?: (result: AgentTurnResult) => void | Promise<void>;
    errorMessage?: string;
};
export declare const DEFAULT_AGENT_MAX_STEPS = 12;
export declare function normalizeAgentMaxSteps(value?: number): number;
/**
 * One tenant-agnostic, multi-step tool-using turn. The consuming app resolves
 * the model and closes every tool over its own RequestContext/RBAC boundary.
 */
export declare function runAgentTurn(args: RunAgentTurnArgs): Response;
//# sourceMappingURL=agent.d.ts.map