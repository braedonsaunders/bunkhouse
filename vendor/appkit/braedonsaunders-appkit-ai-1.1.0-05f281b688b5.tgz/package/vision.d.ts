import { z } from 'zod';
import { type AiConfig } from './client.js';
export declare const photoInsightSchema: z.ZodObject<{
    caption: z.ZodString;
}, z.core.$strip>;
export type PhotoInsight = z.infer<typeof photoInsightSchema>;
export declare const AI_VISION_LIMITS: {
    readonly images: 4;
    readonly imageBytes: number;
    readonly totalImageBytes: number;
    readonly promptChars: 4000;
};
export declare function assertVisionRequest(args: {
    images: readonly Uint8Array[];
    prompt?: string;
}): void;
/**
 * Caption a photo from storage-validated bytes. Returns null when AI
 * is unconfigured.
 */
export declare function describePhoto(config: AiConfig | null | undefined, args: {
    image: Uint8Array;
}): Promise<PhotoInsight | null>;
export declare const visionSeverity: z.ZodEnum<{
    low: "low";
    medium: "medium";
    high: "high";
}>;
export type VisionSeverity = z.infer<typeof visionSeverity>;
export declare const safetyVisionSchema: z.ZodObject<{
    summary: z.ZodString;
    overallRisk: z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        none: "none";
    }>;
    ppe: z.ZodArray<z.ZodObject<{
        item: z.ZodString;
        status: z.ZodEnum<{
            present: "present";
            missing: "missing";
            incorrect: "incorrect";
        }>;
        detail: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    hazards: z.ZodArray<z.ZodObject<{
        type: z.ZodString;
        severity: z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
        }>;
        detail: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type SafetyVisionAnalysis = z.infer<typeof safetyVisionSchema>;
/**
 * Review storage-validated jobsite photo bytes for missing PPE + hazards.
 * Returns null when AI is unconfigured or no images are supplied.
 */
export declare function runVisionAnalysis(config: AiConfig | null | undefined, args: {
    images: Uint8Array[];
    prompt?: string;
}): Promise<SafetyVisionAnalysis | null>;
//# sourceMappingURL=vision.d.ts.map