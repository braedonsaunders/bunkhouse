import { z } from 'zod';
import { type AiConfig } from './client.js';
import type { DigestEntry } from './digest.js';
export declare const activityAnalysisSchema: z.ZodObject<{
    summary: z.ZodString;
    sentiment: z.ZodObject<{
        label: z.ZodEnum<{
            positive: "positive";
            steady: "steady";
            mixed: "mixed";
            concerned: "concerned";
            negative: "negative";
        }>;
        score: z.ZodNumber;
        rationale: z.ZodString;
    }, z.core.$strip>;
    themes: z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        count: z.ZodNumber;
    }, z.core.$strip>>;
    issues: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        severity: z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
        }>;
        detail: z.ZodString;
        location: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    actions: z.ZodArray<z.ZodObject<{
        action: z.ZodString;
        owner: z.ZodString;
        priority: z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
        }>;
        rationale: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type ActivityAnalysis = z.infer<typeof activityAnalysisSchema>;
export declare const datasetAnalysisSchema: z.ZodObject<{
    summary: z.ZodString;
    points: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        detail: z.ZodString;
        tone: z.ZodEnum<{
            positive: "positive";
            negative: "negative";
            neutral: "neutral";
            watch: "watch";
        }>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type DatasetAnalysis = z.infer<typeof datasetAnalysisSchema>;
/** Analyse an arbitrary tabular query result under a user-supplied instruction.
 *  Null when AI is unconfigured or there are no rows. */
export declare function analyseDataset(config: AiConfig | null | undefined, args: {
    instruction: string;
    columns: {
        key: string;
        label: string;
    }[];
    rows: Record<string, unknown>[];
}): Promise<DatasetAnalysis | null>;
/** Analyse a batch of activity entries. Null when AI is unconfigured or empty. */
export declare function analyseActivityEntries(config: AiConfig | null | undefined, args: {
    scope?: string;
    entries: DigestEntry[];
}): Promise<ActivityAnalysis | null>;
//# sourceMappingURL=analysis.d.ts.map