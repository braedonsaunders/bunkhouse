import { type AiConfig } from './client.js';
export type WritingMode = 'tidy' | 'expand' | 'continue' | 'rephrase' | 'fix' | 'bulletize' | 'summarize';
export declare const WRITING_MODES: WritingMode[];
export declare function isWritingMode(v: string): v is WritingMode;
/**
 * Stream a writing-assist transformation as a plain text-stream Response. Throws
 * AIDisabledError when the tenant has no model configured.
 */
export declare function streamWritingAssist(config: AiConfig | null | undefined, args: {
    mode: WritingMode;
    text: string;
    tone?: string;
    context?: string;
}): Response;
//# sourceMappingURL=writing.d.ts.map