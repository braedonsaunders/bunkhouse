import * as React from 'react';
export type AgentMessage = {
    id: string;
    role: 'user' | 'assistant' | 'system';
    parts: unknown[];
};
export type AgentQueuedMessage = {
    id: string;
    text: string;
    position: number;
    status: 'queued' | 'dispatching' | 'retrying' | 'failed';
    statusLabel?: string;
    editable?: boolean;
    removable?: boolean;
    retryable?: boolean;
};
export type AgentDispatchState = 'idle' | 'running' | 'recovering';
export type AgentPanelLabels = {
    title: string;
    welcomeTitle: string;
    welcomeDescription: string;
    disabledTitle: string;
    disabledDescription: string;
    placeholder: string;
    send: string;
    stop: string;
    failed: string;
    input: string;
    result: string;
    working: string;
    step: string;
    steps: string;
    queue: string;
    queueTitle: string;
    queuePosition: string;
    queued: string;
    dispatching: string;
    retrying: string;
    queueFailed: string;
    editQueued: string;
    removeQueued: string;
    retryQueued: string;
};
export type AgentPanelProps = {
    enabled: boolean;
    initialMessages?: AgentMessage[];
    suggestions?: string[];
    labels?: Partial<AgentPanelLabels>;
    headerActions?: React.ReactNode;
    /** Replaces the stock empty-state card while preserving the panel header and composer. */
    emptyContent?: React.ReactNode;
    send?: (prompt: string, signal: AbortSignal) => Promise<Response>;
    /** Durable dispatch state supplied by the application after reload or handoff. */
    dispatchState?: AgentDispatchState;
    /** Application-owned queue, already ordered by its durable dispatch position. */
    queuedMessages?: readonly AgentQueuedMessage[];
    /** Persists a turn behind the active or previously queued work. */
    enqueue?: (prompt: string) => Promise<void>;
    onEditQueuedMessage?: (message: AgentQueuedMessage) => void;
    onRemoveQueuedMessage?: (message: AgentQueuedMessage) => void;
    onRetryQueuedMessage?: (message: AgentQueuedMessage) => void;
    maxPromptCharacters?: number;
    toolLabels?: Record<string, string>;
};
/**
 * The streaming thread/composer extracted from the sibling assistant. The app
 * owns persistence and the HTTP transport; appkit owns UI-message decoding,
 * cancellation, ordered part rendering, and tool cards.
 */
export declare function AgentPanel({ enabled, initialMessages, suggestions, labels: labelOverrides, headerActions, emptyContent, send, dispatchState, queuedMessages, enqueue, onEditQueuedMessage, onRemoveQueuedMessage, onRetryQueuedMessage, maxPromptCharacters, toolLabels, }: AgentPanelProps): React.JSX.Element;
export declare function AgentMessageQueue({ messages, labels: labelOverrides, onEdit, onRemove, onRetry, }: {
    messages: readonly AgentQueuedMessage[];
    labels?: Partial<AgentPanelLabels>;
    onEdit?: (message: AgentQueuedMessage) => void;
    onRemove?: (message: AgentQueuedMessage) => void;
    onRetry?: (message: AgentQueuedMessage) => void;
}): React.JSX.Element;
export declare function ChatMarkdown({ children }: {
    children: string;
}): React.JSX.Element;
export declare function AgentToolCard({ name, label, state, input, output, inputLabel, resultLabel }: {
    name: string;
    label?: string;
    state: string;
    input?: unknown;
    output?: unknown;
    inputLabel?: string;
    resultLabel?: string;
}): React.JSX.Element;
//# sourceMappingURL=react.d.ts.map