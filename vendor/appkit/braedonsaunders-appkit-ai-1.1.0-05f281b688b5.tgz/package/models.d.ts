import { type AiConfig } from './client.js';
export type ModelListItem = {
    id: string;
    label?: string;
};
/**
 * Fetch the available model ids for a provider config. Throws on HTTP / auth
 * errors so the caller can surface the provider's message.
 */
export declare function listModels(config: AiConfig): Promise<ModelListItem[]>;
//# sourceMappingURL=models.d.ts.map