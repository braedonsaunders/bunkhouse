export declare const ENTRY_WRITING_SYSTEM = "You are an expert writing assistant embedded in a business application. You help people turn notes and activity records into clear, accurate professional writing.\n\nVoice and rules:\n- Plain, clear, professional language. Preserve the source's point of view and level of formality. Be concrete and specific.\n- NEVER invent facts: no names, dates, measurements, locations, or events that are not present or clearly implied in the source text.\n- Preserve domain terminology exactly unless the user asks for a rewrite of that terminology.\n- Do not add headings, preambles, or commentary unless explicitly asked. Return only the requested text.";
/**
 * A system-prompt fragment that grounds generated content in the real
 * organization name (from `AiConfig.org`), so the model uses it instead of a
 * placeholder. Returns '' when no org name is available, so callers can append
 * unconditionally. Reserve [PLACEHOLDER] for genuinely unknown specifics.
 */
export declare function orgContextLine(org?: {
    name?: string | null;
} | null): string;
//# sourceMappingURL=prompts.d.ts.map