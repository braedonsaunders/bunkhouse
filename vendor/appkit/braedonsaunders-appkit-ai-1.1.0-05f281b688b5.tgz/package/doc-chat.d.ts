import { type AiConfig } from './client.js';
export type DocChatMessage = {
    role: 'user' | 'assistant';
    content: string;
};
export type DocAgentToolImpl = {
    /** Fresh plain text of the current document. */
    readDocument: () => Promise<string>;
    /** Exact-match text edits; returns per-edit occurrence counts. */
    editDocument: (edits: {
        find: string;
        replace: string;
    }[]) => Promise<{
        find: string;
        count: number;
    }[]>;
    /** Replace the entire document with new HTML content. */
    writeDocument: (html: string) => Promise<void>;
};
export type DocAgentResult = {
    text: string;
    /** Human-readable notes about what the agent did (shown in the panel). */
    actions: string[];
    docChanged: boolean;
};
/**
 * Run one agent turn (multi-step tool loop) for the document assistant.
 * Throws AIDisabledError when the tenant has no model configured.
 */
export declare function runDocAgent(config: AiConfig | null | undefined, args: {
    messages: DocChatMessage[];
    docText?: string;
    tools: DocAgentToolImpl;
    maxSteps?: number;
}): Promise<DocAgentResult>;
//# sourceMappingURL=doc-chat.d.ts.map