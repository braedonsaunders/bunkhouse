// Config-driven AI client. Provider + API key + models (+ base URL) are passed
// in per call (resolved from per-tenant settings), NOT read from the environment.
import { createAnthropic } from '@ai-sdk/anthropic';
import { createGoogleGenerativeAI } from '@ai-sdk/google';
import { createOpenAI } from '@ai-sdk/openai';
import { createOpenAICompatible } from '@ai-sdk/openai-compatible';
import { resolvePublicHost, secureFetch, validateOutboundRequestConfiguration, } from '@braedonsaunders/appkit-sync/egress';
import { generateText } from 'ai';
const MAX_AI_REQUEST_BYTES = 16 * 1024 * 1024;
const MAX_AI_RESPONSE_BYTES = 16 * 1024 * 1024;
/**
 * How long one model call may take before the transport gives up on it.
 *
 * This is not a budget — the caller's own loop governs how much work an agent
 * may do — it is only the point past which a socket is assumed dead. Two
 * minutes turned out to be inside the normal range for a reasoning model
 * answering with tool calls: measured runs on several hosted models spent
 * longer than that on a single step, and each one died on this timeout having
 * produced nothing, billed nothing, and lost every step that came before it.
 *
 * Ten minutes is comfortably past the slowest observed step while still
 * catching a connection that has genuinely gone away.
 */
const AI_REQUEST_TIMEOUT_MS = 600_000;
/**
 * Provider catalogue — single source of truth for the settings UI, the model
 * factory and config validation. Add a provider here and it lights up everywhere.
 */
export const AI_PROVIDER_SPECS = [
    {
        value: 'anthropic',
        label: 'Anthropic — Claude',
        kind: 'anthropic',
        baseUrl: null,
        requiresBaseUrl: false,
        fast: 'claude-haiku-4-5-20251001',
        smart: 'claude-sonnet-4-6',
        keyHint: 'sk-ant-…',
        visionToolResults: true,
    },
    {
        value: 'openai',
        label: 'OpenAI — GPT',
        kind: 'openai',
        baseUrl: null,
        requiresBaseUrl: false,
        fast: 'gpt-4o-mini',
        smart: 'gpt-4o',
        keyHint: 'sk-…',
        visionToolResults: false,
    },
    {
        value: 'google',
        label: 'Google — Gemini',
        kind: 'google',
        baseUrl: null,
        requiresBaseUrl: false,
        fast: 'gemini-2.5-flash',
        smart: 'gemini-2.5-pro',
        keyHint: 'AIza…',
        visionToolResults: false,
    },
    {
        value: 'openrouter',
        label: 'OpenRouter — any model, one key',
        kind: 'openai-compatible',
        baseUrl: 'https://openrouter.ai/api/v1',
        requiresBaseUrl: false,
        fast: 'anthropic/claude-3.5-haiku',
        smart: 'anthropic/claude-3.5-sonnet',
        keyHint: 'sk-or-…',
        modelHint: 'Use vendor/model slugs, e.g. anthropic/claude-3.5-sonnet or openai/gpt-4o.',
        // OpenRouter proxies many vendors over an OpenAI-compatible surface; image
        // tool-results aren't reliably supported, so keep vision tools off here.
        visionToolResults: false,
    },
    {
        value: 'groq',
        label: 'Groq — fast inference',
        kind: 'openai-compatible',
        baseUrl: 'https://api.groq.com/openai/v1',
        requiresBaseUrl: false,
        fast: 'llama-3.1-8b-instant',
        smart: 'llama-3.3-70b-versatile',
        keyHint: 'gsk_…',
        visionToolResults: false,
    },
    {
        value: 'xai',
        label: 'xAI — Grok',
        kind: 'openai-compatible',
        baseUrl: 'https://api.x.ai/v1',
        requiresBaseUrl: false,
        fast: 'grok-2-1212',
        smart: 'grok-2-vision-1212',
        keyHint: 'xai-…',
        visionToolResults: false,
    },
    {
        value: 'deepseek',
        label: 'DeepSeek',
        kind: 'openai-compatible',
        baseUrl: 'https://api.deepseek.com',
        requiresBaseUrl: false,
        fast: 'deepseek-chat',
        smart: 'deepseek-chat',
        keyHint: 'sk-…',
        visionToolResults: false,
    },
    {
        value: 'mistral',
        label: 'Mistral',
        kind: 'openai-compatible',
        baseUrl: 'https://api.mistral.ai/v1',
        requiresBaseUrl: false,
        fast: 'mistral-small-latest',
        smart: 'mistral-large-latest',
        keyHint: 'Your Mistral API key',
        visionToolResults: false,
    },
    {
        value: 'custom',
        label: 'Custom (OpenAI-compatible)',
        kind: 'openai-compatible',
        baseUrl: null,
        requiresBaseUrl: true,
        fast: '',
        smart: '',
        keyHint: 'Your provider API key',
        modelHint: 'Use a public HTTPS OpenAI-compatible endpoint (for example Together, Fireworks, Perplexity, or hosted vLLM) and set explicit model ids.',
        visionToolResults: false,
    },
];
const SPEC_BY_VALUE = Object.fromEntries(AI_PROVIDER_SPECS.map((s) => [s.value, s]));
export function isAiProvider(value) {
    return typeof value === 'string' && Object.hasOwn(SPEC_BY_VALUE, value);
}
export function providerSpec(provider) {
    return SPEC_BY_VALUE[provider];
}
function withoutTrailingSlashes(value) {
    let end = value.length;
    while (end > 0 && value.charCodeAt(end - 1) === 47)
        end -= 1;
    return value.slice(0, end);
}
/**
 * Validate and canonicalize a persisted AI endpoint override. Runtime requests
 * repeat the public-DNS check immediately before opening each socket.
 */
export async function validateAiBaseUrl(provider, rawBaseUrl) {
    const spec = providerSpec(provider);
    const raw = rawBaseUrl?.trim() ?? '';
    if (spec.kind !== 'openai-compatible') {
        if (raw)
            throw new Error(`${spec.label} does not support a custom base URL.`);
        return null;
    }
    if (!raw) {
        if (spec.requiresBaseUrl)
            throw new Error('A public HTTPS base URL is required.');
        return null;
    }
    let submitted;
    try {
        submitted = new URL(raw);
    }
    catch {
        throw new Error('The AI base URL is not valid.');
    }
    if (submitted.search || submitted.hash) {
        throw new Error('The AI base URL must not include a query string or fragment.');
    }
    const validated = validateOutboundRequestConfiguration(submitted).url;
    await resolvePublicHost(validated.hostname);
    const path = withoutTrailingSlashes(validated.pathname);
    validated.pathname = path || '/';
    const canonical = withoutTrailingSlashes(validated.href);
    return canonical || validated.origin;
}
async function readBoundedRequestBody(request) {
    if (!request.body)
        return undefined;
    const declaredLength = Number(request.headers.get('content-length'));
    if (Number.isFinite(declaredLength) && declaredLength > MAX_AI_REQUEST_BYTES) {
        throw new Error(`AI request body exceeded ${MAX_AI_REQUEST_BYTES} bytes.`);
    }
    const reader = request.body.getReader();
    const chunks = [];
    let total = 0;
    try {
        for (;;) {
            if (request.signal.aborted)
                throw request.signal.reason;
            const { done, value } = await reader.read();
            if (done)
                break;
            total += value.byteLength;
            if (total > MAX_AI_REQUEST_BYTES) {
                await reader.cancel();
                throw new Error(`AI request body exceeded ${MAX_AI_REQUEST_BYTES} bytes.`);
            }
            chunks.push(value);
        }
    }
    finally {
        reader.releaseLock();
    }
    const body = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
        body.set(chunk, offset);
        offset += chunk.byteLength;
    }
    return body;
}
/** Socket-pinned transport for tenant-configurable OpenAI-compatible endpoints. */
export const secureAiFetch = async (input, init) => {
    const request = new Request(input, init);
    const method = request.method.toUpperCase();
    if (!['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
        throw new Error(`AI request method ${method} is not supported.`);
    }
    const body = await readBoundedRequestBody(request);
    return secureFetch(request.url, {
        method: method,
        headers: request.headers,
        body,
        timeoutMs: AI_REQUEST_TIMEOUT_MS,
        maxRequestBytes: MAX_AI_REQUEST_BYTES,
        maxResponseBytes: MAX_AI_RESPONSE_BYTES,
        maxRedirects: 2,
        signal: request.signal,
    });
};
export function defaultModel(provider, tier) {
    const spec = SPEC_BY_VALUE[provider] ?? SPEC_BY_VALUE.anthropic;
    return tier === 'smart' ? spec.smart : spec.fast;
}
/**
 * Whether the configured provider accepts IMAGE content in a tool result — the
 * capability that lets a tool hand rendered PDF pages back to the model for
 * vision reading. Currently Anthropic only; other providers' tool/function
 * results are text/JSON only, so exposing such a tool to them would break the
 * agent turn. Used to gate the assistant's `view_document_pages` tool.
 */
export function providerSupportsImageToolResults(config) {
    if (!config)
        return false;
    return SPEC_BY_VALUE[config.provider]?.visionToolResults ?? false;
}
export function isAiConfigured(config) {
    if (!config || !config.apiKey)
        return false;
    const spec = SPEC_BY_VALUE[config.provider];
    if (!spec)
        return false;
    if (spec.requiresBaseUrl && !config.baseUrl?.trim())
        return false;
    return true;
}
/** Resolve a language model from a tenant's config, or null when not configured. */
export function getModel(config, tier = 'fast') {
    if (!isAiConfigured(config))
        return null;
    const spec = SPEC_BY_VALUE[config.provider];
    const modelId = (tier === 'smart' ? config.modelSmart : config.modelFast) || defaultModel(config.provider, tier);
    // `custom` has no default model — without an explicit one, AI stays disabled.
    if (!modelId)
        return null;
    switch (spec.kind) {
        case 'anthropic':
            return createAnthropic({ apiKey: config.apiKey })(modelId);
        case 'openai':
            return createOpenAI({ apiKey: config.apiKey })(modelId);
        case 'google':
            return createGoogleGenerativeAI({ apiKey: config.apiKey })(modelId);
        case 'openai-compatible': {
            const baseURL = config.baseUrl?.trim() || spec.baseUrl;
            if (!baseURL)
                return null;
            return createOpenAICompatible({
                name: spec.value,
                apiKey: config.apiKey,
                baseURL,
                fetch: secureAiFetch,
            })(modelId);
        }
    }
}
export class AIDisabledError extends Error {
    name = 'AIDisabledError';
    constructor() {
        super('No AI provider is available for this request.');
    }
}
/** Live test of a config — sends a tiny prompt and reports success/failure. */
export async function pingModel(config) {
    const model = getModel(config, 'fast');
    if (!model) {
        return {
            ok: false,
            message: 'Not configured yet — check the provider, API key, model and base URL.',
        };
    }
    try {
        const { text } = await generateText({ model, prompt: 'Reply with the single word: ok' });
        return { ok: true, message: `Connected — the model replied “${text.trim().slice(0, 24)}”.` };
    }
    catch (e) {
        return { ok: false, message: e instanceof Error ? e.message.slice(0, 180) : 'Request failed.' };
    }
}
//# sourceMappingURL=client.js.map