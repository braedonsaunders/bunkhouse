import { z } from 'zod';
import { type AiConfig } from './client.js';
export declare const entryMetaSchema: z.ZodObject<{
    summary: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export type EntryMeta = z.infer<typeof entryMetaSchema>;
/** Extract summary + tags from entry plaintext. Null when AI is unconfigured or text is too short. */
export declare function extractEntryMeta(config: AiConfig | null | undefined, bodyText: string): Promise<EntryMeta | null>;
//# sourceMappingURL=extract.d.ts.map