export * from './types.js';
export { createSuperadminService, SuperadminConflictError, SuperadminGuardError, SuperadminNotFoundError, } from './service.js';
//# sourceMappingURL=index.d.ts.map