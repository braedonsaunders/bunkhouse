'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Avatar, Badge, Button, Drawer, Input, Label, RecordList, Select, Switch, cn, confirmDialog, } from '@appkit/ui';
import { Building2, KeyRound, MonitorSmartphone, ShieldCheck, UserPlus, Users } from 'lucide-react';
/**
 * Instance-operator user administration: every account that can sign in to
 * the platform, with activation, super-admin standing, credentials, and
 * session controls.
 */
export function PlatformUsersAdmin({ users, currentUserId, tenants, defaultTenantId, actions, title = 'Users', description = 'Every account that can sign in to this installation. Deactivating an account blocks sign-in immediately and ends its sessions.', }) {
    const [query, setQuery] = React.useState('');
    const [status, setStatus] = React.useState('all');
    const [sort, setSort] = React.useState({ key: 'name', dir: 'asc' });
    const [selectedId, setSelectedId] = React.useState(null);
    const [creating, setCreating] = React.useState(false);
    const [notice, setNotice] = React.useState(null);
    const filtered = React.useMemo(() => {
        const needle = query.trim().toLocaleLowerCase();
        const base = users.filter((user) => {
            if (status !== 'all' && user.isActive !== (status === 'active'))
                return false;
            if (!needle)
                return true;
            return user.name.toLocaleLowerCase().includes(needle) || user.email.toLocaleLowerCase().includes(needle);
        });
        const dir = sort.dir === 'asc' ? 1 : -1;
        return [...base].sort((a, b) => {
            const key = sort.key;
            return String(a[key] ?? '').localeCompare(String(b[key] ?? '')) * dir;
        });
    }, [users, query, status, sort]);
    const counts = {
        all: users.length,
        active: users.filter((user) => user.isActive).length,
        inactive: users.filter((user) => !user.isActive).length,
    };
    const selected = users.find((user) => user.id === selectedId) ?? null;
    const columns = React.useMemo(() => [
        {
            key: 'name',
            label: 'Name',
            sortable: true,
            render: (user) => (_jsxs("div", { className: "flex items-center gap-3", children: [_jsx(Avatar, { name: user.name, src: user.image ?? undefined, size: 32 }), _jsxs("div", { className: "flex min-w-0 items-center gap-1.5", children: [_jsx("span", { className: "truncate font-medium text-fg", children: user.name }), user.id === currentUserId ? _jsx(Badge, { variant: "outline", children: "You" }) : null, user.isSuperAdmin ? _jsx(Badge, { variant: "warning", children: "Super admin" }) : null] })] })),
        },
        {
            key: 'email',
            label: 'Email',
            sortable: true,
            render: (user) => _jsx("span", { className: "text-fg-muted", children: user.email }),
        },
        {
            key: 'isActive',
            label: 'Status',
            render: (user) => (_jsx(Badge, { variant: user.isActive ? 'success' : 'secondary', children: user.isActive ? 'Active' : 'Deactivated' })),
        },
        {
            key: 'hasCredential',
            label: 'Sign-in',
            render: (user) => (_jsxs("div", { className: "flex flex-wrap gap-1", children: [_jsx(Badge, { variant: user.hasCredential ? 'secondary' : 'outline', children: user.hasCredential ? 'Password' : 'No credential' }), user.emailVerified ? null : _jsx(Badge, { variant: "outline", children: "Unverified" })] })),
        },
        {
            key: 'activeSessionCount',
            label: 'Sessions',
            render: (user) => _jsx("span", { className: "tabular-nums text-fg-muted", children: user.activeSessionCount }),
        },
        {
            key: 'lastSeenAt',
            label: 'Last seen',
            render: (user) => (_jsx("span", { className: "whitespace-nowrap text-fg-muted", children: formatDateTime(user.lastSeenAt) })),
        },
    ], [currentUserId]);
    async function run(operation, successMessage) {
        setNotice(null);
        const result = await operation();
        if (!result.ok) {
            setNotice({ tone: 'error', message: result.message });
            return false;
        }
        const message = result.message ?? successMessage;
        if (message)
            setNotice({ tone: 'success', message });
        return true;
    }
    return (_jsxs("div", { className: "flex min-h-0 flex-1 flex-col gap-5", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl font-semibold tracking-tight text-fg", children: title }), _jsx("p", { className: "mt-1 max-w-3xl text-sm text-fg-muted", children: description })] }), notice ? (_jsx("div", { role: notice.tone === 'error' ? 'alert' : 'status', className: cn('rounded-lg border px-4 py-3 text-sm', notice.tone === 'error'
                    ? 'border-danger/30 bg-danger-subtle text-danger'
                    : 'border-success/30 bg-success-subtle text-success'), children: notice.message })) : null, _jsx(RecordList, { columns: columns, rows: filtered, getRowId: (user) => user.id, search: { value: query, onChange: setQuery, placeholder: 'Search name or email…' }, sort: sort, onSortChange: (key) => setSort((s) => (s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' })), filters: _jsx("div", { className: "flex max-w-full overflow-x-auto rounded-lg border border-border bg-surface p-1", "aria-label": "Filter users by status", children: [
                        { value: 'all', label: 'All' },
                        { value: 'active', label: 'Active' },
                        { value: 'inactive', label: 'Deactivated' },
                    ].map((filter) => (_jsxs("button", { type: "button", "aria-pressed": status === filter.value, onClick: () => setStatus(filter.value), className: cn('flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors', status === filter.value ? 'bg-primary-subtle text-primary' : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx("span", { children: filter.label }), _jsx("span", { className: "tabular-nums text-fg-subtle", children: counts[filter.value] })] }, filter.value))) }), toolbarActions: _jsxs(Button, { onClick: () => setCreating(true), children: [_jsx(UserPlus, { size: 16 }), "Add user"] }), onRowClick: (user) => setSelectedId(user.id), empty: {
                    icon: _jsx(Users, {}),
                    title: 'No users found',
                    description: 'Try a different search or filter.',
                } }), selected ? (_jsx(UserDrawer, { user: selected, isCurrentUser: selected.id === currentUserId, onClose: () => setSelectedId(null), onUpdate: (input, successMessage) => run(() => actions.updateUser(selected.id, input), successMessage), onSetPassword: (password) => run(() => actions.setPassword(selected.id, password), 'Password updated.'), onRevokeSessions: () => run(() => actions.revokeUserSessions(selected.id), 'All sessions ended.') })) : null, creating ? (_jsx(CreateUserDrawer, { tenants: tenants, defaultTenantId: defaultTenantId, onClose: () => setCreating(false), onCreate: async (input) => {
                    const saved = await run(() => actions.createUser(input), `${input.email} can now sign in.`);
                    if (saved)
                        setCreating(false);
                } })) : null] }));
}
function UserDrawer({ user, isCurrentUser, onClose, onUpdate, onSetPassword, onRevokeSessions, }) {
    const [name, setName] = React.useState(user.name);
    const [password, setPassword] = React.useState('');
    const [busy, startBusy] = React.useTransition();
    async function changeActivation(next) {
        if (!next) {
            const confirmed = await confirmDialog({
                message: `Deactivate ${user.name}? They are signed out everywhere and cannot sign in again until reactivated.`,
                confirmLabel: 'Deactivate account',
                tone: 'danger',
            });
            if (!confirmed)
                return;
        }
        await onUpdate({ isActive: next }, next ? 'Account reactivated.' : 'Account deactivated and signed out.');
    }
    async function changeSuperAdmin(next) {
        const confirmed = await confirmDialog({
            message: next
                ? `Grant ${user.name} super-admin access? They will be able to manage every account and setting on this installation.`
                : `Remove ${user.name}'s super-admin access?`,
            confirmLabel: next ? 'Grant super admin' : 'Remove super admin',
            tone: next ? 'default' : 'danger',
        });
        if (!confirmed)
            return;
        await onUpdate({ isSuperAdmin: next }, next ? 'Super-admin access granted.' : 'Super-admin access removed.');
    }
    return (_jsx(Drawer, { open: true, onClose: onClose, size: "lg", title: _jsxs("span", { className: "flex items-center gap-2", children: [user.name, _jsx(Badge, { variant: user.isActive ? 'success' : 'secondary', children: user.isActive ? 'Active' : 'Deactivated' }), user.isSuperAdmin ? _jsx(Badge, { variant: "warning", children: "Super admin" }) : null] }), description: user.email, children: _jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-user-name", children: "Name" }), _jsx(Input, { id: "superadmin-user-name", value: name, onChange: (event) => setName(event.target.value) })] }), _jsx("div", { className: "flex items-end", children: _jsx(Button, { variant: "outline", disabled: busy || name.trim() === user.name || !name.trim(), onClick: () => startBusy(async () => void (await onUpdate({ name }, 'Name updated.'))), children: "Save name" }) })] }), _jsxs("dl", { className: "grid gap-4 rounded-xl border border-border bg-bg-subtle p-4 sm:grid-cols-2", children: [_jsx(Metric, { label: "Email", value: user.email }), _jsx(Metric, { label: "Created", value: formatDateTime(user.createdAt) }), _jsx(Metric, { label: "Last seen", value: formatDateTime(user.lastSeenAt) }), _jsx(Metric, { label: "Account ID", value: user.id, mono: true })] }), _jsxs("section", { className: "divide-y divide-border rounded-xl border border-border", children: [_jsx(AccessRow, { title: "Account active", description: isCurrentUser
                                ? 'This is your account. Another super admin must deactivate it.'
                                : 'When off, sign-in is refused and every session ends immediately.', checked: user.isActive, disabled: busy || isCurrentUser, onChange: (next) => startBusy(() => changeActivation(next)) }), _jsx(AccessRow, { title: "Super admin", description: "Full instance-operator access: user management, sessions, and platform settings.", checked: user.isSuperAdmin, disabled: busy, onChange: (next) => startBusy(() => changeSuperAdmin(next)) }), _jsx(AccessRow, { title: "Email verified", description: "Marks the address as confirmed without sending a verification email.", checked: user.emailVerified, disabled: busy, onChange: (next) => startBusy(async () => void (await onUpdate({ emailVerified: next }, next ? 'Email marked verified.' : 'Email marked unverified.'))) })] }), _jsxs("section", { className: "space-y-4 rounded-xl border border-border p-4", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(KeyRound, { size: 16, className: "text-fg-muted" }), _jsx("h3", { className: "text-sm font-semibold text-fg", children: "Password" })] }), _jsx("p", { className: "text-sm text-fg-muted", children: user.hasCredential
                                ? 'Replaces the current password. Existing sessions stay signed in until revoked.'
                                : 'This account has no password yet — set one so it can sign in.' }), _jsxs("div", { className: "flex flex-wrap items-end gap-3", children: [_jsxs("div", { className: "min-w-56 flex-1 space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-user-password", children: "New password" }), _jsx(Input, { id: "superadmin-user-password", type: "password", autoComplete: "new-password", value: password, onChange: (event) => setPassword(event.target.value), placeholder: "At least 8 characters" })] }), _jsx(Button, { variant: "outline", disabled: busy || password.length < 8, onClick: () => startBusy(async () => {
                                        if (await onSetPassword(password))
                                            setPassword('');
                                    }), children: "Set password" })] })] }), _jsxs("section", { className: "space-y-3 rounded-xl border border-border p-4", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(ShieldCheck, { size: 16, className: "text-fg-muted" }), _jsx("h3", { className: "text-sm font-semibold text-fg", children: "Sessions" })] }), _jsxs("p", { className: "text-sm text-fg-muted", children: [user.activeSessionCount === 1
                                    ? '1 active session.'
                                    : `${user.activeSessionCount} active sessions.`, ' ', "Ending them signs this account out of every device."] }), _jsx(Button, { variant: "outline", size: "sm", disabled: busy || user.activeSessionCount === 0, onClick: () => startBusy(async () => {
                                const confirmed = await confirmDialog({
                                    message: `End all of ${user.name}'s sessions?${isCurrentUser ? ' This includes the session you are using right now.' : ''}`,
                                    confirmLabel: 'End sessions',
                                    tone: 'danger',
                                });
                                if (confirmed)
                                    await onRevokeSessions();
                            }), children: "End all sessions" })] })] }) }));
}
function CreateUserDrawer({ tenants, defaultTenantId, onClose, onCreate, }) {
    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [tenantId, setTenantId] = React.useState(defaultTenantId);
    const [isSuperAdmin, setIsSuperAdmin] = React.useState(false);
    const [busy, startBusy] = React.useTransition();
    const valid = name.trim().length > 0 && email.includes('@') && password.length >= 8 && tenantId.length > 0;
    return (_jsx(Drawer, { open: true, onClose: onClose, size: "lg", title: "Add user", description: "Creates a sign-in account for this installation. Share the password securely; the user can change it after signing in.", footer: _jsxs("div", { className: "flex justify-end gap-2", children: [_jsx(Button, { variant: "outline", onClick: onClose, children: "Cancel" }), _jsx(Button, { disabled: !valid || busy, onClick: () => startBusy(() => onCreate({ name, email, password, isSuperAdmin, tenantId })), children: "Create user" })] }), children: _jsxs("div", { className: "space-y-5", children: [_jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-create-name", children: "Name" }), _jsx(Input, { id: "superadmin-create-name", value: name, onChange: (event) => setName(event.target.value) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-create-email", children: "Email" }), _jsx(Input, { id: "superadmin-create-email", type: "email", value: email, onChange: (event) => setEmail(event.target.value) })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-create-tenant", children: "Workspace" }), _jsx(Select, { id: "superadmin-create-tenant", required: true, value: tenantId, onChange: (event) => setTenantId(event.target.value), placeholder: "Choose a workspace", children: tenants.map((tenant) => (_jsx("option", { value: tenant.id, children: tenant.name }, tenant.id))) }), _jsx("p", { className: "text-xs text-fg-muted", children: "The workspace this account joins on creation. Move or add memberships later from Tenants." })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-create-password", children: "Password" }), _jsx(Input, { id: "superadmin-create-password", type: "password", autoComplete: "new-password", value: password, onChange: (event) => setPassword(event.target.value), placeholder: "At least 8 characters" })] }), _jsxs("label", { className: "flex items-start gap-3 rounded-lg border border-border p-3", children: [_jsx(Switch, { checked: isSuperAdmin, onChange: (event) => setIsSuperAdmin(event.target.checked) }), _jsxs("span", { children: [_jsx("span", { className: "block text-sm font-medium text-fg", children: "Super admin" }), _jsx("span", { className: "block text-sm text-fg-muted", children: "Grants full instance-operator access, including this panel." })] })] })] }) }));
}
/** Live sessions across the installation, with per-session revocation. */
export function PlatformSessionsAdmin({ sessions, actions, title = 'Active sessions', description = 'Every live sign-in across the installation. Revoking a session signs that device out immediately.', }) {
    const [notice, setNotice] = React.useState(null);
    const [busy, startBusy] = React.useTransition();
    const columns = React.useMemo(() => [
        {
            key: 'userName',
            label: 'User',
            render: (session) => (_jsxs("div", { children: [_jsxs("div", { className: "flex min-w-0 items-center gap-2", children: [_jsx("span", { className: "truncate font-medium text-fg", children: session.userName }), session.isCurrentSession ? _jsx(Badge, { variant: "outline", children: "This session" }) : null] }), _jsx("div", { className: "truncate text-xs text-fg-muted", children: session.userEmail })] })),
        },
        {
            key: 'createdAt',
            label: 'Signed in',
            render: (session) => (_jsx("span", { className: "whitespace-nowrap text-fg-muted", children: formatDateTime(session.createdAt) })),
        },
        {
            key: 'expiresAt',
            label: 'Expires',
            render: (session) => (_jsx("span", { className: "whitespace-nowrap text-fg-muted", children: formatDateTime(session.expiresAt) })),
        },
        {
            key: 'ipAddress',
            label: 'IP address',
            render: (session) => _jsx("span", { className: "font-mono text-xs text-fg-muted", children: session.ipAddress || '—' }),
        },
        {
            key: 'userAgent',
            label: 'Device',
            render: (session) => (_jsx("span", { className: "block max-w-64 truncate text-xs text-fg-muted", title: session.userAgent ?? undefined, children: session.userAgent || '—' })),
        },
        {
            key: 'revoke',
            label: '',
            kind: 'actions',
            render: (session) => (_jsx(Button, { variant: "ghost", size: "sm", className: "text-danger", disabled: busy, onClick: (event) => {
                    event.stopPropagation();
                    startBusy(async () => {
                        const confirmed = await confirmDialog({
                            message: session.isCurrentSession
                                ? 'Revoke the session you are using right now? You will be signed out.'
                                : `Revoke ${session.userName}'s session? That device is signed out immediately.`,
                            confirmLabel: 'Revoke session',
                            tone: 'danger',
                        });
                        if (!confirmed)
                            return;
                        setNotice(null);
                        const result = await actions.revokeSession(session.id);
                        if (!result.ok)
                            setNotice({ tone: 'error', message: result.message });
                        else if (result.message)
                            setNotice({ tone: 'warning', message: result.message });
                    });
                }, children: "Revoke" })),
        },
    ], [actions, busy]);
    return (_jsxs("div", { className: "flex min-h-0 flex-1 flex-col gap-5", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-lg font-semibold tracking-tight text-fg", children: title }), _jsx("p", { className: "mt-1 max-w-3xl text-sm text-fg-muted", children: description })] }), notice ? (_jsx("div", { role: "alert", className: cn('rounded-lg border px-4 py-3 text-sm', notice.tone === 'error'
                    ? 'border-danger/30 bg-danger-subtle text-danger'
                    : 'border-warning/30 bg-warning-subtle text-warning'), children: notice.message })) : null, _jsx(RecordList, { columns: columns, rows: sessions, getRowId: (session) => session.id, empty: {
                    icon: _jsx(MonitorSmartphone, {}),
                    title: 'No active sessions',
                    description: 'Nobody is signed in right now.',
                } })] }));
}
/**
 * Instance-operator tenant administration: every workspace of the
 * installation, with activation, membership management, and creation.
 */
export function PlatformTenantsAdmin({ tenants, members, currentTenantId, actions, title = 'Tenants', description = 'Every workspace on this installation. Suspending a tenant hides it from members immediately; its data is kept.', }) {
    const [selectedId, setSelectedId] = React.useState(null);
    const [creating, setCreating] = React.useState(false);
    const [sort, setSort] = React.useState({ key: 'name', dir: 'asc' });
    const [notice, setNotice] = React.useState(null);
    const selected = tenants.find((tenant) => tenant.id === selectedId) ?? null;
    const columns = React.useMemo(() => [
        {
            key: 'name',
            label: 'Name',
            sortable: true,
            render: (tenant) => (_jsxs("div", { className: "flex min-w-0 items-center gap-1.5", children: [_jsx("span", { className: "truncate font-medium text-fg", children: tenant.name }), tenant.id === currentTenantId ? _jsx(Badge, { variant: "outline", children: "Current" }) : null] })),
        },
        {
            key: 'slug',
            label: 'Slug',
            sortable: true,
            render: (tenant) => _jsx("span", { className: "font-mono text-xs text-fg-muted", children: tenant.slug }),
        },
        {
            key: 'status',
            label: 'Status',
            render: (tenant) => (_jsx(Badge, { variant: tenant.status === 'active' ? 'success' : 'secondary', children: tenant.status === 'active' ? 'Active' : tenant.status === 'suspended' ? 'Suspended' : 'Archived' })),
        },
        {
            key: 'memberCount',
            label: 'Members',
            render: (tenant) => _jsx("span", { className: "tabular-nums text-fg-muted", children: tenant.memberCount }),
        },
        {
            key: 'createdAt',
            label: 'Created',
            render: (tenant) => (_jsx("span", { className: "whitespace-nowrap text-fg-muted", children: formatDateTime(tenant.createdAt) })),
        },
    ], [currentTenantId]);
    const sorted = React.useMemo(() => {
        const dir = sort.dir === 'asc' ? 1 : -1;
        return [...tenants].sort((a, b) => {
            const key = sort.key;
            return String(a[key] ?? '').localeCompare(String(b[key] ?? '')) * dir;
        });
    }, [tenants, sort]);
    async function run(operation, successMessage) {
        setNotice(null);
        const result = await operation();
        if (!result.ok) {
            setNotice({ tone: 'error', message: result.message });
            return false;
        }
        const message = result.message ?? successMessage;
        if (message)
            setNotice({ tone: result.message ? 'warning' : 'success', message });
        return true;
    }
    return (_jsxs("div", { className: "flex min-h-0 flex-1 flex-col gap-5", children: [_jsxs("div", { className: "flex flex-wrap items-start justify-between gap-4", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl font-semibold tracking-tight text-fg", children: title }), _jsx("p", { className: "mt-1 max-w-3xl text-sm text-fg-muted", children: description })] }), _jsxs(Button, { onClick: () => setCreating(true), children: [_jsx(Building2, { size: 16 }), "Add tenant"] })] }), notice ? (_jsx("div", { role: notice.tone === 'error' ? 'alert' : 'status', className: cn('rounded-lg border px-4 py-3 text-sm', notice.tone === 'error'
                    ? 'border-danger/30 bg-danger-subtle text-danger'
                    : notice.tone === 'warning'
                        ? 'border-warning/30 bg-warning-subtle text-warning'
                        : 'border-success/30 bg-success-subtle text-success'), children: notice.message })) : null, _jsx(RecordList, { columns: columns, rows: sorted, getRowId: (tenant) => tenant.id, sort: sort, onSortChange: (key) => setSort((s) => (s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' })), onRowClick: (tenant) => setSelectedId(tenant.id), empty: {
                    icon: _jsx(Building2, {}),
                    title: 'No tenants',
                    description: 'Create the first workspace to get started.',
                } }), selected ? (_jsx(TenantDrawer, { tenant: selected, members: members[selected.id] ?? [], isCurrentTenant: selected.id === currentTenantId, onClose: () => setSelectedId(null), onSetStatus: (status) => run(() => actions.setTenantStatus(selected.id, status), status === 'active' ? 'Tenant reactivated.' : 'Tenant suspended.'), onAddMember: (email) => run(() => actions.addMember(selected.id, email), `${email} added.`), onSetMemberStatus: (membershipId, status) => run(() => actions.setMemberStatus(selected.id, membershipId, status), status === 'active' ? 'Membership reactivated.' : 'Membership suspended.'), onRemoveMember: (membershipId) => run(() => actions.removeMember(selected.id, membershipId), 'Member removed.') })) : null, creating ? (_jsx(CreateTenantDrawer, { onClose: () => setCreating(false), onCreate: async (input) => {
                    const saved = await run(() => actions.createTenant(input), `${input.name} created.`);
                    if (saved)
                        setCreating(false);
                } })) : null] }));
}
function TenantDrawer({ tenant, members, isCurrentTenant, onClose, onSetStatus, onAddMember, onSetMemberStatus, onRemoveMember, }) {
    const [email, setEmail] = React.useState('');
    const [busy, startBusy] = React.useTransition();
    const suspended = tenant.status === 'suspended';
    async function changeStatus(next) {
        if (!next) {
            const confirmed = await confirmDialog({
                message: `Suspend ${tenant.name}?${isCurrentTenant ? ' This is the tenant you are currently working in — you will lose this workspace until it is reactivated.' : ''} Members lose access immediately; nothing is deleted.`,
                confirmLabel: 'Suspend tenant',
                tone: 'danger',
            });
            if (!confirmed)
                return;
        }
        await onSetStatus(next ? 'active' : 'suspended');
    }
    return (_jsx(Drawer, { open: true, onClose: onClose, size: "lg", title: _jsxs("span", { className: "flex items-center gap-2", children: [tenant.name, _jsx(Badge, { variant: tenant.status === 'active' ? 'success' : 'secondary', children: tenant.status === 'active' ? 'Active' : tenant.status === 'suspended' ? 'Suspended' : 'Archived' }), isCurrentTenant ? _jsx(Badge, { variant: "outline", children: "Current workspace" }) : null] }), description: `Slug: ${tenant.slug} (permanent)`, children: _jsxs("div", { className: "space-y-6", children: [_jsxs("dl", { className: "grid gap-4 rounded-xl border border-border bg-bg-subtle p-4 sm:grid-cols-2", children: [_jsx(Metric, { label: "Slug", value: tenant.slug, mono: true }), _jsx(Metric, { label: "Created", value: formatDateTime(tenant.createdAt) }), _jsx(Metric, { label: "Active members", value: String(tenant.memberCount) }), _jsx(Metric, { label: "Tenant ID", value: tenant.id, mono: true })] }), _jsx("section", { className: "divide-y divide-border rounded-xl border border-border", children: _jsx(AccessRow, { title: "Tenant active", description: isCurrentTenant
                            ? 'This is the workspace you are working in right now. Suspending it takes it away from you too.'
                            : 'When off, members cannot use this workspace. Data is kept; reactivate any time.', checked: !suspended && tenant.status === 'active', disabled: busy || tenant.status === 'archived', onChange: (next) => startBusy(() => changeStatus(next)) }) }), _jsxs("section", { className: "space-y-4 rounded-xl border border-border p-4", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Users, { size: 16, className: "text-fg-muted" }), _jsx("h3", { className: "text-sm font-semibold text-fg", children: "Members" })] }), _jsxs("div", { className: "flex flex-wrap items-end gap-3", children: [_jsxs("div", { className: "min-w-56 flex-1 space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-tenant-member-email", children: "Add member by email" }), _jsx(Input, { id: "superadmin-tenant-member-email", type: "email", value: email, onChange: (event) => setEmail(event.target.value), placeholder: "An existing account's email" })] }), _jsxs(Button, { variant: "outline", disabled: busy || !email.includes('@'), onClick: () => startBusy(async () => {
                                        if (await onAddMember(email.trim()))
                                            setEmail('');
                                    }), children: [_jsx(UserPlus, { size: 16 }), "Add member"] })] }), members.length === 0 ? (_jsx("p", { className: "text-sm text-fg-muted", children: "No members yet. Add an existing account by email." })) : (_jsx("ul", { className: "divide-y divide-border rounded-lg border border-border", children: members.map((member) => (_jsxs("li", { className: "flex flex-wrap items-center justify-between gap-3 px-3 py-2", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("div", { className: "flex items-center gap-1.5", children: [_jsx("span", { className: "truncate text-sm font-medium text-fg", children: member.userName }), _jsx(Badge, { variant: member.status === 'active' ? 'success' : member.status === 'invited' ? 'outline' : 'secondary', children: member.status })] }), _jsx("div", { className: "truncate text-xs text-fg-muted", children: member.userEmail })] }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Button, { variant: "ghost", size: "sm", disabled: busy, onClick: () => startBusy(async () => {
                                                    await onSetMemberStatus(member.membershipId, member.status === 'active' ? 'suspended' : 'active');
                                                }), children: member.status === 'active' ? 'Suspend' : 'Activate' }), _jsx(Button, { variant: "ghost", size: "sm", className: "text-danger", disabled: busy, onClick: () => startBusy(async () => {
                                                    const confirmed = await confirmDialog({
                                                        message: `Remove ${member.userName} from ${tenant.name}? Their account remains; only this workspace access ends.`,
                                                        confirmLabel: 'Remove member',
                                                        tone: 'danger',
                                                    });
                                                    if (confirmed)
                                                        await onRemoveMember(member.membershipId);
                                                }), children: "Remove" })] })] }, member.membershipId))) }))] })] }) }));
}
function CreateTenantDrawer({ onClose, onCreate, }) {
    const [name, setName] = React.useState('');
    const [slug, setSlug] = React.useState('');
    const [slugTouched, setSlugTouched] = React.useState(false);
    const [busy, startBusy] = React.useTransition();
    const valid = name.trim().length > 0 && /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(slug);
    function suggestSlug(value) {
        return value
            .toLocaleLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 63);
    }
    return (_jsx(Drawer, { open: true, onClose: onClose, size: "lg", title: "Add tenant", description: "Creates a new workspace. It starts empty, with no members \u2014 add them from the tenant's drawer.", footer: _jsxs("div", { className: "flex justify-end gap-2", children: [_jsx(Button, { variant: "outline", onClick: onClose, children: "Cancel" }), _jsx(Button, { disabled: !valid || busy, onClick: () => startBusy(() => onCreate({ name: name.trim(), slug })), children: "Create tenant" })] }), children: _jsxs("div", { className: "space-y-5", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-create-tenant-name", children: "Name" }), _jsx(Input, { id: "superadmin-create-tenant-name", value: name, onChange: (event) => {
                                setName(event.target.value);
                                if (!slugTouched)
                                    setSlug(suggestSlug(event.target.value));
                            } })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "superadmin-create-tenant-slug", children: "Slug" }), _jsx(Input, { id: "superadmin-create-tenant-slug", value: slug, onChange: (event) => {
                                setSlugTouched(true);
                                setSlug(event.target.value.toLocaleLowerCase());
                            }, placeholder: "lowercase-and-hyphens" }), _jsx("p", { className: "text-xs text-fg-muted", children: "Permanent identifier \u2014 lowercase letters, digits, and hyphens. It cannot be changed after creation." })] })] }) }));
}
function AccessRow({ title, description, checked, disabled, onChange, }) {
    return (_jsxs("div", { className: "flex items-start justify-between gap-4 p-4", children: [_jsxs("div", { children: [_jsx("div", { className: "text-sm font-medium text-fg", children: title }), _jsx("div", { className: "mt-0.5 text-sm text-fg-muted", children: description })] }), _jsx(Switch, { checked: checked, disabled: disabled, onChange: (event) => onChange(event.target.checked), "aria-label": title })] }));
}
function Metric({ label, value, mono = false }) {
    return (_jsxs("div", { children: [_jsx("dt", { className: "text-xs font-medium uppercase tracking-wide text-fg-subtle", children: label }), _jsx("dd", { className: cn('mt-1 truncate text-sm font-semibold text-fg', mono && 'font-mono text-xs'), children: value })] }));
}
function formatDateTime(value) {
    if (!value)
        return 'Never';
    return value.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}
//# sourceMappingURL=react.js.map