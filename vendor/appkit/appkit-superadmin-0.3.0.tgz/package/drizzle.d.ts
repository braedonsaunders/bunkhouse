import type { PgDatabase } from 'drizzle-orm/pg-core';
import type { PgQueryResultHKT } from 'drizzle-orm/pg-core/session';
import type { SuperadminPersistence, SuperadminService, SuperadminServiceOptions } from './types.js';
/** Database-neutral contract shared by Drizzle's node-postgres and postgres-js drivers. */
export type SuperadminDatabase<TQueryResult extends PgQueryResultHKT = PgQueryResultHKT, TSchema extends Record<string, unknown> = Record<string, never>> = PgDatabase<TQueryResult, TSchema>;
export type DrizzleSuperadminOptions<TQueryResult extends PgQueryResultHKT = PgQueryResultHKT, TSchema extends Record<string, unknown> = Record<string, never>> = {
    /**
     * A connection that can reach the GLOBAL identity tables (users, sessions,
     * accounts). These tables carry no tenant scope — run this on the
     * cross-tenant pool the auth runtime itself uses.
     */
    db: SuperadminDatabase<TQueryResult, TSchema>;
};
/** Postgres persistence adapter over the @appkit/db identity schema. */
export declare function createDrizzleSuperadminPersistence<TQueryResult extends PgQueryResultHKT, TSchema extends Record<string, unknown>>(options: DrizzleSuperadminOptions<TQueryResult, TSchema>): SuperadminPersistence;
export type DrizzleSuperadminServiceOptions<TQueryResult extends PgQueryResultHKT = PgQueryResultHKT, TSchema extends Record<string, unknown> = Record<string, never>> = DrizzleSuperadminOptions<TQueryResult, TSchema> & Omit<SuperadminServiceOptions, 'persistence'>;
/** Convenience: guard-railed service directly over a Postgres identity schema. */
export declare function createDrizzleSuperadminService<TQueryResult extends PgQueryResultHKT, TSchema extends Record<string, unknown>>(options: DrizzleSuperadminServiceOptions<TQueryResult, TSchema>): SuperadminService;
//# sourceMappingURL=drizzle.d.ts.map