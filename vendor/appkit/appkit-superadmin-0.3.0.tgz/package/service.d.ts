import type { SuperadminService, SuperadminServiceOptions } from './types.js';
/** A mutation was refused because it would break the platform's operability. */
export declare class SuperadminGuardError extends Error {
    name: string;
}
/** The requested record does not exist. */
export declare class SuperadminNotFoundError extends Error {
    name: string;
}
/** The mutation conflicts with an existing record. */
export declare class SuperadminConflictError extends Error {
    name: string;
}
/**
 * Builds the instance-operator service over any persistence adapter. All guard
 * rails live here: the last active super admin can be neither deactivated nor
 * demoted, deactivation revokes the account's live sessions, and revoking the
 * operator's own current session is flagged in the result rather than
 * happening silently.
 */
export declare function createSuperadminService(options: SuperadminServiceOptions): SuperadminService;
//# sourceMappingURL=service.d.ts.map