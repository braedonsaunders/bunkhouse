import type { PlatformTenantRecord, PlatformTenantStatus, SuperadminPersistence, SuperadminService, SuperadminServiceOptions, TenantMemberStatus, PlatformUserRecord } from './types.js';
export type MemoryUserSeed = {
    id: string;
    name: string;
    email: string;
    image?: string | null;
    emailVerified?: boolean;
    isActive?: boolean;
    isSuperAdmin?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
};
export type MemorySessionSeed = {
    id: string;
    userId: string;
    createdAt?: Date;
    expiresAt?: Date;
    ipAddress?: string | null;
    userAgent?: string | null;
};
export type MemoryTenantSeed = {
    id: string;
    name: string;
    slug: string;
    status?: PlatformTenantStatus;
    createdAt?: Date;
    updatedAt?: Date;
};
export type MemoryMembershipSeed = {
    id: string;
    tenantId: string;
    userId: string;
    displayName?: string;
    status?: TenantMemberStatus;
    joinedAt?: Date | null;
    createdAt?: Date;
};
type MemoryMembership = {
    id: string;
    tenantId: string;
    userId: string;
    displayName: string;
    status: TenantMemberStatus;
    joinedAt: Date | null;
    invitedBy: string | null;
    createdAt: Date;
};
export type MemorySuperadminState = {
    users: Map<string, Omit<PlatformUserRecord, 'hasCredential' | 'activeSessionCount' | 'lastSeenAt'>>;
    /** userId → password hash */
    credentials: Map<string, string>;
    sessions: Map<string, {
        id: string;
        userId: string;
        createdAt: Date;
        expiresAt: Date;
        ipAddress: string | null;
        userAgent: string | null;
    }>;
    tenants: Map<string, Omit<PlatformTenantRecord, 'memberCount'>>;
    memberships: Map<string, MemoryMembership>;
};
export type MemorySuperadminPersistence = SuperadminPersistence & {
    state: MemorySuperadminState;
};
/** In-memory persistence adapter for tests, previews, and local tooling. */
export declare function createMemorySuperadminPersistence(seed?: {
    users?: MemoryUserSeed[];
    credentials?: Record<string, string>;
    sessions?: MemorySessionSeed[];
    tenants?: MemoryTenantSeed[];
    memberships?: MemoryMembershipSeed[];
}, clock?: {
    now?: () => Date;
    id?: () => string;
}): MemorySuperadminPersistence;
/** Complete in-memory service — the shape tests and previews consume. */
export declare function createMemorySuperadminService(seed?: Parameters<typeof createMemorySuperadminPersistence>[0], options?: Partial<Omit<SuperadminServiceOptions, 'persistence'>> & {
    now?: () => Date;
    id?: () => string;
}): {
    service: SuperadminService;
    persistence: MemorySuperadminPersistence;
};
export {};
//# sourceMappingURL=memory.d.ts.map