import * as React from 'react';
import type { PlatformSessionRecord, PlatformTenantRecord, PlatformUserRecord, TenantMemberRecord } from './types.js';
/**
 * Server-action friendly result contract: the application owns the actions
 * (authorization, persistence, revalidation) and the components render state,
 * collect input, and surface outcomes.
 */
export type SuperadminActionResult = {
    ok: true;
    message?: string;
} | {
    ok: false;
    message: string;
};
export type PlatformUsersActions = {
    createUser(input: {
        name: string;
        email: string;
        password: string;
        isSuperAdmin?: boolean;
        /** The workspace the new account joins — chosen explicitly in the drawer. */
        tenantId: string;
    }): Promise<SuperadminActionResult>;
    updateUser(userId: string, input: {
        name?: string;
        isActive?: boolean;
        isSuperAdmin?: boolean;
        emailVerified?: boolean;
    }): Promise<SuperadminActionResult>;
    setPassword(userId: string, password: string): Promise<SuperadminActionResult>;
    revokeUserSessions(userId: string): Promise<SuperadminActionResult>;
};
export type PlatformUsersAdminProps = {
    users: PlatformUserRecord[];
    /** The signed-in operator, so their own row is labeled and guarded in copy. */
    currentUserId?: string;
    /** Workspaces a new account can join — typically the active tenants. */
    tenants: {
        id: string;
        name: string;
    }[];
    /** Preselected workspace in the Add-user drawer — typically the operator's current tenant. */
    defaultTenantId: string;
    actions: PlatformUsersActions;
    title?: string;
    description?: string;
};
/**
 * Instance-operator user administration: every account that can sign in to
 * the platform, with activation, super-admin standing, credentials, and
 * session controls.
 */
export declare function PlatformUsersAdmin({ users, currentUserId, tenants, defaultTenantId, actions, title, description, }: PlatformUsersAdminProps): React.JSX.Element;
export type PlatformSessionsActions = {
    revokeSession(sessionId: string): Promise<SuperadminActionResult>;
};
export type PlatformSessionsAdminProps = {
    sessions: PlatformSessionRecord[];
    actions: PlatformSessionsActions;
    title?: string;
    description?: string;
};
/** Live sessions across the installation, with per-session revocation. */
export declare function PlatformSessionsAdmin({ sessions, actions, title, description, }: PlatformSessionsAdminProps): React.JSX.Element;
export type PlatformTenantsActions = {
    createTenant(input: {
        name: string;
        slug: string;
    }): Promise<SuperadminActionResult>;
    setTenantStatus(tenantId: string, status: 'active' | 'suspended'): Promise<SuperadminActionResult>;
    addMember(tenantId: string, email: string): Promise<SuperadminActionResult>;
    setMemberStatus(tenantId: string, membershipId: string, status: 'active' | 'suspended'): Promise<SuperadminActionResult>;
    removeMember(tenantId: string, membershipId: string): Promise<SuperadminActionResult>;
};
export type PlatformTenantsAdminProps = {
    tenants: PlatformTenantRecord[];
    /** tenantId → members, preloaded by the server page and refreshed on revalidation. */
    members: Record<string, TenantMemberRecord[]>;
    /** The tenant the operator is currently working in — suspending it is called out. */
    currentTenantId?: string;
    actions: PlatformTenantsActions;
    title?: string;
    description?: string;
};
/**
 * Instance-operator tenant administration: every workspace of the
 * installation, with activation, membership management, and creation.
 */
export declare function PlatformTenantsAdmin({ tenants, members, currentTenantId, actions, title, description, }: PlatformTenantsAdminProps): React.JSX.Element;
//# sourceMappingURL=react.d.ts.map