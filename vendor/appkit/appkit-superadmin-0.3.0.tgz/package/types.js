/**
 * Instance-operator administration over the platform identity model. This is
 * deliberately NOT tenant IAM (@appkit/iam): it manages the global accounts
 * that can sign in at all — credentials, activation, super-admin standing,
 * and live sessions — across every tenant of the installation.
 */
export {};
//# sourceMappingURL=types.js.map