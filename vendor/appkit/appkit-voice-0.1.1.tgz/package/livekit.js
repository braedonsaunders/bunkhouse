import { AccessToken } from 'livekit-server-sdk';
export async function mintLiveKitToken(credentials, args) {
    const token = new AccessToken(credentials.apiKey, credentials.apiSecret, {
        identity: args.identity,
        name: args.name,
        ttl: args.ttlSeconds ?? 3600,
        ...(args.metadata ? { metadata: args.metadata } : {}),
    });
    token.addGrant({
        room: args.room,
        roomJoin: true,
        canPublish: args.canPublish ?? true,
        canSubscribe: args.canSubscribe ?? true,
    });
    return token.toJwt();
}
//# sourceMappingURL=livekit.js.map