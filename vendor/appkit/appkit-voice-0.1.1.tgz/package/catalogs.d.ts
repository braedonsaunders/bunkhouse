import type { VoiceCatalogItem } from './types.js';
export declare const DEEPGRAM_STT_MODELS: VoiceCatalogItem[];
export declare const ELEVENLABS_TTS_MODELS: VoiceCatalogItem[];
export declare const OPENAI_REALTIME_MODELS: VoiceCatalogItem[];
export declare const OPENAI_REALTIME_VOICES: VoiceCatalogItem[];
export declare const GEMINI_LIVE_MODELS: VoiceCatalogItem[];
export declare const GEMINI_LIVE_VOICES: VoiceCatalogItem[];
/** Live voice catalog from the tenant's own ElevenLabs account (incl. clones). */
export declare function listElevenLabsVoices(apiKey: string): Promise<VoiceCatalogItem[]>;
//# sourceMappingURL=catalogs.d.ts.map