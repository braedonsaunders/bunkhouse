/**
 * LiveKit access tokens. Server credentials (API key/secret) are deployment
 * infrastructure — the app passes them in; identities and rooms are the
 * app's domain (e.g. room per call session, identity per person id).
 */
export type LiveKitCredentials = {
    apiKey: string;
    apiSecret: string;
};
export type MintTokenArgs = {
    identity: string;
    name: string;
    room: string;
    /** Serialized app context (tenant/person ids) surfaced to room participants. */
    metadata?: string;
    canPublish?: boolean;
    canSubscribe?: boolean;
    /** Token validity, seconds (default 1h). */
    ttlSeconds?: number;
};
export declare function mintLiveKitToken(credentials: LiveKitCredentials, args: MintTokenArgs): Promise<string>;
//# sourceMappingURL=livekit.d.ts.map