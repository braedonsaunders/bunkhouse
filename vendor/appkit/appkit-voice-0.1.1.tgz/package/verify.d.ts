export type VerifyResult = {
    ok: true;
} | {
    ok: false;
    message: string;
};
export declare function verifyDeepgramKey(apiKey: string): Promise<VerifyResult>;
export declare function verifyElevenLabsKey(apiKey: string): Promise<VerifyResult>;
//# sourceMappingURL=verify.d.ts.map