# @appkit/voice

Voice layer seam: per-agent voice config types, speech-provider catalogs and key verification (Deepgram, ElevenLabs, OpenAI Realtime, Gemini Live), and LiveKit access-token minting — credentials injected, never env.

## Install

```bash
pnpm add @appkit/voice
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
