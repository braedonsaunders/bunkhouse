# @appkit/forms-core

Framework-neutral form schemas, evaluation, validation, scoring, localization, and automation planning.

## Install

```bash
pnpm add @appkit/forms-core
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
