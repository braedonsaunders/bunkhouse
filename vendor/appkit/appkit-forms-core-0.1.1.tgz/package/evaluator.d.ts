import type { DefaultValueExpression, FormulaExpression, LogicRule } from './schema.js';
export type FieldValueMap = Record<string, unknown>;
/** Per-row map keyed by section id → array of row value maps. */
export type RowMap = Record<string, Array<FieldValueMap>>;
/**
 * Map of picker field id → attribute map fetched from the picked entity.
 *
 * Keyed by the *picker field key* (not the entity id) so the runtime can
 * prefetch one row per picker and let the evaluator look up attrs without
 * needing to know what id the picker resolved to. `null` means the picker
 * has no selection (or the entity wasn't found / RLS-blocked).
 */
export type EntityAttrsByField = Record<string, Record<string, unknown> | null>;
/**
 * Evaluation context shared by logic + formula evaluators.
 *
 * `values`   — flat top-level field values (non-repeating sections).
 * `rows`     — per-section repeating-row arrays. `rows[sectionId][rowIndex][fieldKey]`.
 * `entities` — allowlisted attribute maps for each picker field's selection,
 *              loaded server-side and refreshed on picker change. Read by the
 *              `entity_attr` formula operator.
 * `requestContext` — used by `resolveDefaultValue` to produce `today`, `now`,
 *                    `current_user_*` defaults.
 */
export type EvalContext = {
    values: FieldValueMap;
    rows: RowMap;
    entities?: EntityAttrsByField;
    requestContext?: {
        now?: Date;
        currentUserPersonId?: string | null;
        currentUserName?: string | null;
    };
};
/**
 * Evaluate a LogicRule against the given values/rows context.
 * Returns true if the rule is satisfied. An undefined rule is treated as
 * "always true" by the caller, not here — pass-through is up to the renderer.
 */
export declare function evaluateLogicRule(rule: LogicRule, ctx: EvalContext): boolean;
/**
 * Evaluate a FormulaExpression tree. Returns `number | string | null`.
 *
 * - Pure arithmetic operators coerce inputs to numbers (missing → 0).
 * - `concat` produces a string.
 * - `if` returns whichever branch matches the condition.
 * - `sum_section` / `count_section` walk `ctx.rows[sectionKey]`.
 */
export declare function evaluateFormulaTree(expr: FormulaExpression, ctx: EvalContext): number | string | null;
/**
 * Resolve a DefaultValueExpression to a concrete value for the first render
 * of a field. Returns `undefined` if no default applies (e.g. expression
 * evaluates to null).
 */
export declare function resolveDefaultValue(expr: DefaultValueExpression, ctx: EvalContext): unknown;
//# sourceMappingURL=evaluator.d.ts.map