import { z } from 'zod';
import { type DefaultValueExpression, type LogicRule } from './schema.js';
import { type EvalContext } from './evaluator.js';
import type { FlowSubjectProfile } from './flow-subjects.js';
export declare const emailTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"literal">;
    email: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"role">;
    role: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"field">;
    field: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"submitter">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"person">;
    personId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"submitter_manager">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"record_person_manager">;
    personField: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"department_manager">;
    departmentId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"person_group">;
    groupId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"person_group_for_record_person">;
    groupId: z.ZodString;
    personField: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"org_unit_contact">;
    contactId: z.ZodString;
    orgUnitField: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"compliance_recipient">;
    obligationId: z.ZodString;
    personField: z.ZodString;
    recipient: z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"person">;
        personId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"literal">;
        email: z.ZodString;
    }, z.core.$strip>], "type">;
}, z.core.$strip>], "type">;
export type EmailTarget = z.infer<typeof emailTargetSchema>;
export declare const recipientTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"literal">;
    email: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"role">;
    role: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"field">;
    field: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"submitter">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"person">;
    personId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"submitter_manager">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"record_person_manager">;
    personField: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"department_manager">;
    departmentId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"person_group">;
    groupId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"person_group_for_record_person">;
    groupId: z.ZodString;
    personField: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"org_unit_contact">;
    contactId: z.ZodString;
    orgUnitField: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"compliance_recipient">;
    obligationId: z.ZodString;
    personField: z.ZodString;
    recipient: z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"person">;
        personId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"literal">;
        email: z.ZodString;
    }, z.core.$strip>], "type">;
}, z.core.$strip>], "type">;
export type RecipientTarget = EmailTarget;
export declare const assigneeTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"role">;
    role: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"field">;
    field: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"literal">;
    userId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"submitter">;
}, z.core.$strip>], "type">;
export type AssigneeTarget = z.infer<typeof assigneeTargetSchema>;
export declare const triggerDataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    trigger: z.ZodLiteral<"on_submit">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_field_value">;
    rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"status_change">;
    from: z.ZodOptional<z.ZodString>;
    to: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"scheduled">;
    cron: z.ZodString;
    tz: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"session_overdue">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_create">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_sign">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_lock">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_unlock">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_delete">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"manual">;
    buttonId: z.ZodString;
    label: z.ZodString;
    icon: z.ZodOptional<z.ZodString>;
    variant: z.ZodOptional<z.ZodEnum<{
        default: "default";
        outline: "outline";
        destructive: "destructive";
        secondary: "secondary";
    }>>;
    confirm: z.ZodOptional<z.ZodString>;
    showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
    requirePermission: z.ZodOptional<z.ZodString>;
    inputs: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        type: z.ZodEnum<{
            number: "number";
            text: "text";
            date: "date";
            select: "select";
            person: "person";
            textarea: "textarea";
        }>;
        required: z.ZodOptional<z.ZodBoolean>;
        options: z.ZodOptional<z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            label: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>>>;
    order: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>], "trigger">;
export type TriggerData = z.infer<typeof triggerDataSchema>;
export type TriggerKind = TriggerData['trigger'];
export declare const actionDataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    action: z.ZodLiteral<"send_email">;
    to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"literal">;
        email: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"field">;
        field: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"person">;
        personId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter_manager">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"record_person_manager">;
        personField: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"department_manager">;
        departmentId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"person_group">;
        groupId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"person_group_for_record_person">;
        groupId: z.ZodString;
        personField: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"org_unit_contact">;
        contactId: z.ZodString;
        orgUnitField: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compliance_recipient">;
        obligationId: z.ZodString;
        personField: z.ZodString;
        recipient: z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"person">;
            personId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"literal">;
            email: z.ZodString;
        }, z.core.$strip>], "type">;
    }, z.core.$strip>], "type">>;
    channel: z.ZodOptional<z.ZodEnum<{
        email: "email";
        sms: "sms";
        in_app: "in_app";
    }>>;
    mode: z.ZodOptional<z.ZodEnum<{
        inline: "inline";
        template: "template";
        design: "design";
    }>>;
    subject: z.ZodOptional<z.ZodString>;
    bodyTemplate: z.ZodOptional<z.ZodString>;
    templateId: z.ZodOptional<z.ZodString>;
    subjectOverride: z.ZodOptional<z.ZodString>;
    sourceHtml: z.ZodOptional<z.ZodString>;
    compiledHtml: z.ZodOptional<z.ZodString>;
    subjectTemplate: z.ZodOptional<z.ZodString>;
    attachPdf: z.ZodOptional<z.ZodBoolean>;
    pdfTemplateId: z.ZodOptional<z.ZodString>;
    pdfFormat: z.ZodOptional<z.ZodEnum<{
        full: "full";
        summary: "summary";
    }>>;
    spreadsheetAttachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
        templateAttachmentId: z.ZodString;
        filename: z.ZodOptional<z.ZodString>;
        when: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
    }, z.core.$strip>>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"create_capa">;
    titleTemplate: z.ZodString;
    descriptionTemplate: z.ZodOptional<z.ZodString>;
    severity: z.ZodOptional<z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        critical: "critical";
    }>>;
    dueInDays: z.ZodOptional<z.ZodNumber>;
    assignee: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"field">;
        field: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"literal">;
        userId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter">;
    }, z.core.$strip>], "type">>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"create_incident">;
    titleTemplate: z.ZodString;
    incidentType: z.ZodOptional<z.ZodString>;
    severity: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"notify_role">;
    role: z.ZodString;
    message: z.ZodString;
    channel: z.ZodOptional<z.ZodEnum<{
        email: "email";
        sms: "sms";
        in_app: "in_app";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"set_field">;
    field: z.ZodString;
    value: z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"flag_non_compliant">;
    reason: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"webhook">;
    url: z.ZodString;
    method: z.ZodDefault<z.ZodEnum<{
        POST: "POST";
        PUT: "PUT";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"create_response">;
    templateId: z.ZodString;
    prefill: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"analyze_photos">;
    fieldId: z.ZodString;
    storeInField: z.ZodOptional<z.ZodString>;
    createCapaOnHazard: z.ZodOptional<z.ZodBoolean>;
    minSeverity: z.ZodOptional<z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"start_monitored_session">;
    intervalMinutes: z.ZodNumber;
    graceMinutes: z.ZodNumber;
    durationMinutes: z.ZodOptional<z.ZodNumber>;
    requireGeo: z.ZodOptional<z.ZodBoolean>;
    intervalFieldKey: z.ZodOptional<z.ZodString>;
    graceFieldKey: z.ZodOptional<z.ZodString>;
    durationFieldKey: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"change_status">;
    to: z.ZodString;
    lock: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"duplicate_record">;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"export_pdf">;
    pdfFormat: z.ZodOptional<z.ZodEnum<{
        full: "full";
        summary: "summary";
    }>>;
}, z.core.$strip>], "action">;
export type ActionData = z.infer<typeof actionDataSchema>;
export type ActionKind = ActionData['action'];
export type FlowEventSource = 'ui' | 'api' | 'sync' | 'script' | 'schedule' | 'close_automation';
export declare const gateDataSchema: z.ZodObject<{
    title: z.ZodString;
    assignee: z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"field">;
        field: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"literal">;
        userId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter">;
    }, z.core.$strip>], "type">;
    signatureRequired: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type GateData = z.infer<typeof gateDataSchema>;
export declare const automationNodeSchema: z.ZodObject<{
    id: z.ZodString;
    position: z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
    }, z.core.$strip>;
    data: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"trigger">;
        trigger: z.ZodDiscriminatedUnion<[z.ZodObject<{
            trigger: z.ZodLiteral<"on_submit">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_field_value">;
            rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"status_change">;
            from: z.ZodOptional<z.ZodString>;
            to: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"scheduled">;
            cron: z.ZodString;
            tz: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"session_overdue">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_create">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_sign">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_lock">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_unlock">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_delete">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"manual">;
            buttonId: z.ZodString;
            label: z.ZodString;
            icon: z.ZodOptional<z.ZodString>;
            variant: z.ZodOptional<z.ZodEnum<{
                default: "default";
                outline: "outline";
                destructive: "destructive";
                secondary: "secondary";
            }>>;
            confirm: z.ZodOptional<z.ZodString>;
            showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
            requirePermission: z.ZodOptional<z.ZodString>;
            inputs: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                type: z.ZodEnum<{
                    number: "number";
                    text: "text";
                    date: "date";
                    select: "select";
                    person: "person";
                    textarea: "textarea";
                }>;
                required: z.ZodOptional<z.ZodBoolean>;
                options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    value: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strip>>>;
            }, z.core.$strip>>>;
            order: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>], "trigger">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"condition">;
        rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
        label: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"action">;
        action: z.ZodDiscriminatedUnion<[z.ZodObject<{
            action: z.ZodLiteral<"send_email">;
            to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"literal">;
                email: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"field">;
                field: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"person">;
                personId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter_manager">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"record_person_manager">;
                personField: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"department_manager">;
                departmentId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"person_group">;
                groupId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"person_group_for_record_person">;
                groupId: z.ZodString;
                personField: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"org_unit_contact">;
                contactId: z.ZodString;
                orgUnitField: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"compliance_recipient">;
                obligationId: z.ZodString;
                personField: z.ZodString;
                recipient: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"person">;
                    personId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"literal">;
                    email: z.ZodString;
                }, z.core.$strip>], "type">;
            }, z.core.$strip>], "type">>;
            channel: z.ZodOptional<z.ZodEnum<{
                email: "email";
                sms: "sms";
                in_app: "in_app";
            }>>;
            mode: z.ZodOptional<z.ZodEnum<{
                inline: "inline";
                template: "template";
                design: "design";
            }>>;
            subject: z.ZodOptional<z.ZodString>;
            bodyTemplate: z.ZodOptional<z.ZodString>;
            templateId: z.ZodOptional<z.ZodString>;
            subjectOverride: z.ZodOptional<z.ZodString>;
            sourceHtml: z.ZodOptional<z.ZodString>;
            compiledHtml: z.ZodOptional<z.ZodString>;
            subjectTemplate: z.ZodOptional<z.ZodString>;
            attachPdf: z.ZodOptional<z.ZodBoolean>;
            pdfTemplateId: z.ZodOptional<z.ZodString>;
            pdfFormat: z.ZodOptional<z.ZodEnum<{
                full: "full";
                summary: "summary";
            }>>;
            spreadsheetAttachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                templateAttachmentId: z.ZodString;
                filename: z.ZodOptional<z.ZodString>;
                when: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
            }, z.core.$strip>>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"create_capa">;
            titleTemplate: z.ZodString;
            descriptionTemplate: z.ZodOptional<z.ZodString>;
            severity: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                critical: "critical";
            }>>;
            dueInDays: z.ZodOptional<z.ZodNumber>;
            assignee: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"field">;
                field: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"literal">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter">;
            }, z.core.$strip>], "type">>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"create_incident">;
            titleTemplate: z.ZodString;
            incidentType: z.ZodOptional<z.ZodString>;
            severity: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"notify_role">;
            role: z.ZodString;
            message: z.ZodString;
            channel: z.ZodOptional<z.ZodEnum<{
                email: "email";
                sms: "sms";
                in_app: "in_app";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"set_field">;
            field: z.ZodString;
            value: z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"flag_non_compliant">;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"webhook">;
            url: z.ZodString;
            method: z.ZodDefault<z.ZodEnum<{
                POST: "POST";
                PUT: "PUT";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"create_response">;
            templateId: z.ZodString;
            prefill: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"analyze_photos">;
            fieldId: z.ZodString;
            storeInField: z.ZodOptional<z.ZodString>;
            createCapaOnHazard: z.ZodOptional<z.ZodBoolean>;
            minSeverity: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"start_monitored_session">;
            intervalMinutes: z.ZodNumber;
            graceMinutes: z.ZodNumber;
            durationMinutes: z.ZodOptional<z.ZodNumber>;
            requireGeo: z.ZodOptional<z.ZodBoolean>;
            intervalFieldKey: z.ZodOptional<z.ZodString>;
            graceFieldKey: z.ZodOptional<z.ZodString>;
            durationFieldKey: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"change_status">;
            to: z.ZodString;
            lock: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"duplicate_record">;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"export_pdf">;
            pdfFormat: z.ZodOptional<z.ZodEnum<{
                full: "full";
                summary: "summary";
            }>>;
        }, z.core.$strip>], "action">;
        label: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"gate">;
        gate: z.ZodObject<{
            title: z.ZodString;
            assignee: z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"field">;
                field: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"literal">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter">;
            }, z.core.$strip>], "type">;
            signatureRequired: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strip>;
    }, z.core.$strip>], "kind">;
}, z.core.$strip>;
export type AutomationNode = z.infer<typeof automationNodeSchema>;
export declare const automationEdgeSchema: z.ZodObject<{
    id: z.ZodString;
    source: z.ZodString;
    target: z.ZodString;
    sourceHandle: z.ZodOptional<z.ZodEnum<{
        then: "then";
        else: "else";
        next: "next";
        approve: "approve";
        reject: "reject";
    }>>;
}, z.core.$strip>;
export type AutomationEdge = z.infer<typeof automationEdgeSchema>;
export declare const automationGraphSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    nodes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        position: z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, z.core.$strip>;
        data: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"trigger">;
            trigger: z.ZodDiscriminatedUnion<[z.ZodObject<{
                trigger: z.ZodLiteral<"on_submit">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_field_value">;
                rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"status_change">;
                from: z.ZodOptional<z.ZodString>;
                to: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"scheduled">;
                cron: z.ZodString;
                tz: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"session_overdue">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_create">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_sign">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_lock">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_unlock">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_delete">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"manual">;
                buttonId: z.ZodString;
                label: z.ZodString;
                icon: z.ZodOptional<z.ZodString>;
                variant: z.ZodOptional<z.ZodEnum<{
                    default: "default";
                    outline: "outline";
                    destructive: "destructive";
                    secondary: "secondary";
                }>>;
                confirm: z.ZodOptional<z.ZodString>;
                showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
                requirePermission: z.ZodOptional<z.ZodString>;
                inputs: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    type: z.ZodEnum<{
                        number: "number";
                        text: "text";
                        date: "date";
                        select: "select";
                        person: "person";
                        textarea: "textarea";
                    }>;
                    required: z.ZodOptional<z.ZodBoolean>;
                    options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        value: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strip>>>;
                }, z.core.$strip>>>;
                order: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>], "trigger">;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"condition">;
            rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
            label: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"action">;
            action: z.ZodDiscriminatedUnion<[z.ZodObject<{
                action: z.ZodLiteral<"send_email">;
                to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"literal">;
                    email: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"role">;
                    role: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"field">;
                    field: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"person">;
                    personId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter_manager">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"record_person_manager">;
                    personField: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"department_manager">;
                    departmentId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"person_group">;
                    groupId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"person_group_for_record_person">;
                    groupId: z.ZodString;
                    personField: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"org_unit_contact">;
                    contactId: z.ZodString;
                    orgUnitField: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"compliance_recipient">;
                    obligationId: z.ZodString;
                    personField: z.ZodString;
                    recipient: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        type: z.ZodLiteral<"person">;
                        personId: z.ZodString;
                    }, z.core.$strip>, z.ZodObject<{
                        type: z.ZodLiteral<"literal">;
                        email: z.ZodString;
                    }, z.core.$strip>], "type">;
                }, z.core.$strip>], "type">>;
                channel: z.ZodOptional<z.ZodEnum<{
                    email: "email";
                    sms: "sms";
                    in_app: "in_app";
                }>>;
                mode: z.ZodOptional<z.ZodEnum<{
                    inline: "inline";
                    template: "template";
                    design: "design";
                }>>;
                subject: z.ZodOptional<z.ZodString>;
                bodyTemplate: z.ZodOptional<z.ZodString>;
                templateId: z.ZodOptional<z.ZodString>;
                subjectOverride: z.ZodOptional<z.ZodString>;
                sourceHtml: z.ZodOptional<z.ZodString>;
                compiledHtml: z.ZodOptional<z.ZodString>;
                subjectTemplate: z.ZodOptional<z.ZodString>;
                attachPdf: z.ZodOptional<z.ZodBoolean>;
                pdfTemplateId: z.ZodOptional<z.ZodString>;
                pdfFormat: z.ZodOptional<z.ZodEnum<{
                    full: "full";
                    summary: "summary";
                }>>;
                spreadsheetAttachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    templateAttachmentId: z.ZodString;
                    filename: z.ZodOptional<z.ZodString>;
                    when: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
                }, z.core.$strip>>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"create_capa">;
                titleTemplate: z.ZodString;
                descriptionTemplate: z.ZodOptional<z.ZodString>;
                severity: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    critical: "critical";
                }>>;
                dueInDays: z.ZodOptional<z.ZodNumber>;
                assignee: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"role">;
                    role: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"field">;
                    field: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"literal">;
                    userId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter">;
                }, z.core.$strip>], "type">>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"create_incident">;
                titleTemplate: z.ZodString;
                incidentType: z.ZodOptional<z.ZodString>;
                severity: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"notify_role">;
                role: z.ZodString;
                message: z.ZodString;
                channel: z.ZodOptional<z.ZodEnum<{
                    email: "email";
                    sms: "sms";
                    in_app: "in_app";
                }>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"set_field">;
                field: z.ZodString;
                value: z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"flag_non_compliant">;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"webhook">;
                url: z.ZodString;
                method: z.ZodDefault<z.ZodEnum<{
                    POST: "POST";
                    PUT: "PUT";
                }>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"create_response">;
                templateId: z.ZodString;
                prefill: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"analyze_photos">;
                fieldId: z.ZodString;
                storeInField: z.ZodOptional<z.ZodString>;
                createCapaOnHazard: z.ZodOptional<z.ZodBoolean>;
                minSeverity: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                }>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"start_monitored_session">;
                intervalMinutes: z.ZodNumber;
                graceMinutes: z.ZodNumber;
                durationMinutes: z.ZodOptional<z.ZodNumber>;
                requireGeo: z.ZodOptional<z.ZodBoolean>;
                intervalFieldKey: z.ZodOptional<z.ZodString>;
                graceFieldKey: z.ZodOptional<z.ZodString>;
                durationFieldKey: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"change_status">;
                to: z.ZodString;
                lock: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"duplicate_record">;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"export_pdf">;
                pdfFormat: z.ZodOptional<z.ZodEnum<{
                    full: "full";
                    summary: "summary";
                }>>;
            }, z.core.$strip>], "action">;
            label: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"gate">;
            gate: z.ZodObject<{
                title: z.ZodString;
                assignee: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"role">;
                    role: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"field">;
                    field: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"literal">;
                    userId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter">;
                }, z.core.$strip>], "type">;
                signatureRequired: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strip>;
        }, z.core.$strip>], "kind">;
    }, z.core.$strip>>;
    edges: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        source: z.ZodString;
        target: z.ZodString;
        sourceHandle: z.ZodOptional<z.ZodEnum<{
            then: "then";
            else: "else";
            next: "next";
            approve: "approve";
            reject: "reject";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type AutomationGraph = z.infer<typeof automationGraphSchema>;
export declare function emptyAutomationGraph(): AutomationGraph;
export declare function lintAutomationGraph(graph: AutomationGraph, fieldIds: Set<string>, profile?: FlowSubjectProfile): string[];
/** Actions the current worker executor can safely perform without web state. */
export declare function scheduledSafeActions(_hasRecordSelect?: boolean): Set<ActionKind>;
/**
 * Scheduled and session-overdue triggers execute in the worker, not in a web
 * request. The worker only has a narrow, side-effect-safe executor; reject
 * branches that would otherwise save successfully and then silently no-op.
 */
export declare function lintWorkerTriggerCompatibility(graph: AutomationGraph): string[];
export type PlannedGate = {
    nodeId: string;
    gate: GateData;
};
export type PlannedAction = {
    nodeId: string;
    action: ActionData;
};
export type AutomationPlan = {
    actions: ActionData[];
    actionNodes: PlannedAction[];
    gates: PlannedGate[];
};
/**
 * Plan the Actions + Gates reached from EVERY trigger node matching `trigger`.
 * Pure: the caller performs the side effects server-side.
 *
 * A graph may legitimately carry several triggers of the same type (multiple
 * manual buttons, several `on_field_value` branches with different rules, or
 * distinct `status_change` transitions). Each satisfied trigger contributes its
 * downstream branch; the branches are collected together so a shared `seen` set
 * dedupes any actions two triggers converge on. Planning only the first
 * matching node would silently drop the rest.
 *
 * Trigger-specific selection:
 *   • `manual` — when `opts.buttonId` is supplied, plan just that button;
 *     otherwise plan every manual button (rare, but well-defined).
 *   • `on_field_value` — a node fires only when its own rule passes.
 *   • `status_change` — when `opts.toStatus` is supplied the engine enforces
 *     the node's `to` (and optional `from`) filter so a `from: X → to: Y`
 *     transition does not fire on `Z → Y`. When `opts.toStatus` is absent the
 *     match is by trigger name only (the caller is expected to have already
 *     narrowed by target status).
 */
export declare function planAutomation(graph: AutomationGraph, trigger: TriggerData['trigger'], evalCtx: EvalContext, opts?: {
    buttonId?: string;
    fromStatus?: string | null;
    toStatus?: string;
    /** Restrict same-kind planning to these exact trigger node ids. */
    triggerNodeIds?: string[];
}): AutomationPlan;
/**
 * Resume a paused flow from a Gate's `approve` / `reject` branch after a human
 * decision. Returns the downstream Actions + any further Gates.
 */
export declare function planFromGate(graph: AutomationGraph, gateNodeId: string, branch: 'approve' | 'reject', evalCtx: EvalContext): AutomationPlan;
export type { DefaultValueExpression, LogicRule };
//# sourceMappingURL=automation.d.ts.map