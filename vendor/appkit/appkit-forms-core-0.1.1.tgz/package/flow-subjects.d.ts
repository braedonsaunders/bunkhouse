import type { TriggerData, ActionData } from './automation.js';
export type FlowSubjectType = 'form_template' | 'module';
export type FlowFieldKind = 'text' | 'number' | 'enum' | 'date' | 'person' | 'org_unit' | 'bool';
/** A merge token / condition field exposed by a subject. */
export type FlowFieldDef = {
    key: string;
    label: string;
    kind?: FlowFieldKind;
    /** The flow may persist a new value into this field. */
    writable?: boolean;
    /** The field contains attachments accepted by photo analysis. */
    photoSource?: boolean;
    /** The field accepts a plain-text photo-analysis result. */
    textOutput?: boolean;
};
/**
 * A repeating child collection a subject exposes (e.g. a hazard assessment's
 * `hazards`, `signatures`, `photos`). Templates iterate it with
 * `{{#each <key>}} … {{/each}}`; inside the loop each `fields` entry is an item
 * column referenced as `{{<field.key>}}`. Drives the builder's drag-in "table"
 * blocks and the email-render loop engine.
 */
export type FlowCollectionDef = {
    key: string;
    label: string;
    fields: FlowFieldDef[];
};
export type FlowSubjectProfile = {
    subjectType: FlowSubjectType;
    /** templateId (forms) | moduleKey e.g. 'journals' (modules). */
    subjectKey: string;
    /** Human label used in lint messages + canvas chrome. */
    label: string;
    triggers: TriggerData['trigger'][];
    actions: ActionData['action'][];
    /** Allowed `to` values for a status_change trigger (modules with a status enum). */
    statusValues?: string[];
    /** Field tokens for conditions, {{interpolation}}, and recipient `field` targets. */
    fields: FlowFieldDef[];
    /**
     * Repeating child collections (line-items) the subject exposes for
     * `{{#each}}` tables — hazards, signatures, ppe, photos, etc. Absent ⇒ the
     * subject has no tabular data.
     */
    collections?: FlowCollectionDef[];
};
/** Field keys exposed to the shared condition and automation builders. */
export declare function profileFieldIds(profile: FlowSubjectProfile): Set<string>;
export declare const FORM_TEMPLATE_TRIGGERS: TriggerData['trigger'][];
export declare const FORM_TEMPLATE_ACTIONS: ActionData['action'][];
export declare const FORM_STATUS_VALUES: string[];
//# sourceMappingURL=flow-subjects.d.ts.map