// Flow SUBJECTS — the small abstraction that lets ONE Flows engine + ONE canvas
// drive both Builder form templates and native modules (journals, hazard
// assessments, incidents, …).
//
// A `FlowSubjectProfile` is pure data describing what a subject offers: which
// triggers/actions are valid, which status values exist, and the field "tokens"
// available for conditions, {{interpolation}}, and recipient resolution. The
// canvas renders against this profile; `lintAutomationGraph(graph, fieldIds,
// profile)` rejects anything outside it. Server-side behaviour lives in the
// matching FlowSubjectAdapter (apps/web/src/lib/flows).
/** Field keys exposed to the shared condition and automation builders. */
export function profileFieldIds(profile) {
    return new Set(profile.fields.map((field) => field.key));
}
// The full vocabulary a Builder form template supports today — used to build the
// form-template profile so the existing designer keeps every trigger/action.
export const FORM_TEMPLATE_TRIGGERS = [
    'on_submit',
    'on_field_value',
    'status_change',
    'scheduled',
    'session_overdue',
    'manual',
];
export const FORM_TEMPLATE_ACTIONS = [
    'send_email',
    'create_capa',
    'create_incident',
    'notify_role',
    'set_field',
    'flag_non_compliant',
    'webhook',
    'create_response',
    'analyze_photos',
    'start_monitored_session',
    'change_status',
    'duplicate_record',
    'export_pdf',
];
export const FORM_STATUS_VALUES = [
    'submitted',
    'in_review',
    'closed',
    'rejected',
    'non_compliant',
];
//# sourceMappingURL=flow-subjects.js.map