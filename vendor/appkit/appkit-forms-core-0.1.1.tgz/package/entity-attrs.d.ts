import type { FieldType, FormSchemaV1 } from './schema.js';
export type EntityKind = 'person' | 'site';
export type EntityAttrValueType = 'string' | 'date';
export type EntityAttrDef = {
    /** Stable machine key — matches the DB column or a small derived field. */
    key: string;
    /** Human-readable label for designer pickers. */
    label: string;
    /**
     * Hint for downstream coercion. `date` values are returned as ISO strings
     * (yyyy-mm-dd or full ISO timestamps depending on the source column).
     */
    valueType: EntityAttrValueType;
};
/**
 * Map of picker field types → allowed attributes. Adding an entry here
 * surfaces it in the formula builder AND tells the server loader which
 * column to select from the row.
 */
export declare const ENTITY_ATTRS: Record<EntityKind, EntityAttrDef[]>;
/**
 * Pickers that resolve to a single entity (one id) — the only kind that
 * `entity_attr` supports. Multi-pickers (e.g. `multi_person_picker`) are
 * not currently dereferenceable because the formula would need to choose
 * which row to surface.
 */
export declare const PICKER_TO_ENTITY_KIND: Record<string, EntityKind>;
/**
 * Lookup helper: given a picker field type, return the matching EntityKind
 * (or null if the field type is not a single-entity picker).
 */
export declare function entityKindForPicker(fieldType: string): EntityKind | null;
/**
 * Resolve a top-level picker field from a trusted template schema. Runtime
 * entity-attribute fetches use this instead of accepting a client-supplied
 * picker type. Repeating pickers are intentionally unreachable because the
 * evaluator has no row-indexed entity context.
 */
export declare function entityAttrPickerTypeForField(schema: FormSchemaV1, fieldId: string): FieldType | null;
/**
 * Lookup helper: given a kind and an attribute key, return the definition
 * (or null if the attribute isn't allowlisted). Used by the evaluator to
 * decide whether to surface a value at all.
 */
export declare function getEntityAttrDef(kind: EntityKind, attrKey: string): EntityAttrDef | null;
/**
 * Pick the human label out of a loaded entity-attr map. The "name" column
 * varies by kind (person → displayName, org unit → name), so we probe a fixed
 * priority list. Shared by the
 * response viewer and the PDF renderer so a picked entity reads the same in
 * both places. Returns null when no usable label is present.
 */
export declare function entityDisplayName(attrs: Record<string, unknown> | null | undefined): string | null;
//# sourceMappingURL=entity-attrs.d.ts.map