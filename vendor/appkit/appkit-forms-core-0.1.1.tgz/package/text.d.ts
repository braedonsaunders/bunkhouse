/** Convert rich-text HTML to readable plaintext, preserving block line breaks. */
export declare function htmlToText(html: string | null | undefined): string;
/** Single-line preview: strips HTML, collapses whitespace, and ellipsizes. */
export declare function htmlToSnippet(html: string | null | undefined, max?: number): string;
//# sourceMappingURL=text.d.ts.map