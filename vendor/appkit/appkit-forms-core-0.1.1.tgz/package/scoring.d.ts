import type { FormSchemaV1 } from './schema.js';
export type ScoreRow = {
    fieldId: string;
    sectionId: string;
    score: number | null;
    label: string;
    weight: number;
};
/**
 * Extract a normalized list of scored fields from a response payload.
 * Persisted to form_response_scores for analytic roll-ups.
 */
export declare function extractScores(schema: FormSchemaV1, values: Record<string, unknown>): ScoreRow[];
//# sourceMappingURL=scoring.d.ts.map