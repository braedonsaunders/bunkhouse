import type { FieldType, FormField } from './schema.js';
export type FieldTypeMeta = {
    type: FieldType;
    category: 'standard' | 'choice' | 'scoring' | 'picker' | 'media' | 'identity' | 'computed' | 'data' | 'display';
    label: string;
    description: string;
    scoring: boolean;
    valueKind: 'string' | 'number' | 'boolean' | 'string_array' | 'attachment' | 'attachment_array' | 'entity_ref' | 'entity_ref_array' | 'compound' | 'none';
    /** App-provided options adapter used by domain pickers. */
    optionsSource?: 'gl_accounts' | 'parties';
};
export declare const FIELD_TYPES: Record<FieldType, FieldTypeMeta>;
export declare function isScoringField(type: FieldType): boolean;
/** Whether a field owns a caller-supplied value in a persisted response. */
export declare function isResponseValueField(type: FieldType): boolean;
/** Whether this configured field instance owns a persisted response value. */
export declare function storesResponseValue(field: FormField): boolean;
//# sourceMappingURL=field-types.d.ts.map