import { z } from 'zod';
export declare const i18nStringSchema: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
export type I18nString = z.infer<typeof i18nStringSchema>;
export declare const logicRuleSchema: z.ZodType<LogicRule>;
export type LogicRule = {
    op: 'and' | 'or';
    rules: LogicRule[];
} | {
    op: 'not';
    rule: LogicRule;
} | {
    op: 'eq' | 'ne' | 'gt' | 'lt' | 'gte' | 'lte';
    field: string;
    value: unknown;
} | {
    op: 'in' | 'notIn';
    field: string;
    value: unknown[];
} | {
    op: 'isSet' | 'isNotSet';
    field: string;
};
export type FormulaExpression = {
    kind: 'literal';
    value: number | string;
} | {
    kind: 'field_ref';
    fieldKey: string;
} | {
    kind: 'sum';
    of: FormulaExpression[];
} | {
    kind: 'product';
    of: FormulaExpression[];
} | {
    kind: 'subtract';
    left: FormulaExpression;
    right: FormulaExpression;
} | {
    kind: 'divide';
    left: FormulaExpression;
    right: FormulaExpression;
} | {
    kind: 'min';
    of: FormulaExpression[];
} | {
    kind: 'max';
    of: FormulaExpression[];
} | {
    kind: 'power';
    base: FormulaExpression;
    exponent: FormulaExpression;
} | {
    kind: 'root';
    of: FormulaExpression;
    degree: FormulaExpression;
} | {
    kind: 'abs';
    of: FormulaExpression;
} | {
    kind: 'round';
    of: FormulaExpression;
    places?: number;
} | {
    kind: 'floor';
    of: FormulaExpression;
} | {
    kind: 'ceil';
    of: FormulaExpression;
} | {
    kind: 'sum_section';
    sectionKey: string;
    rowFieldKey: string;
} | {
    kind: 'count_section';
    sectionKey: string;
} | {
    kind: 'avg_section';
    sectionKey: string;
    rowFieldKey: string;
} | {
    kind: 'min_section';
    sectionKey: string;
    rowFieldKey: string;
} | {
    kind: 'max_section';
    sectionKey: string;
    rowFieldKey: string;
} | {
    kind: 'concat';
    of: FormulaExpression[];
    separator?: string;
} | {
    kind: 'if';
    condition: LogicRule;
    then: FormulaExpression;
    else: FormulaExpression;
} | {
    kind: 'entity_attr';
    pickerFieldKey: string;
    attrKey: string;
};
export declare const formulaExpressionSchema: z.ZodType<FormulaExpression>;
export type DefaultValueExpression = {
    kind: 'literal';
    value: unknown;
} | {
    kind: 'today';
} | {
    kind: 'now';
} | {
    kind: 'current_user_person_id';
} | {
    kind: 'current_user_name';
} | {
    kind: 'expression';
    expr: FormulaExpression;
};
export declare const defaultValueExpressionSchema: z.ZodType<DefaultValueExpression>;
export declare const fieldTypeSchema: z.ZodEnum<{
    number: "number";
    text: "text";
    long_text: "long_text";
    currency: "currency";
    percentage: "percentage";
    slider: "slider";
    date: "date";
    datetime: "datetime";
    time: "time";
    gps: "gps";
    email: "email";
    phone: "phone";
    url: "url";
    rich_text: "rich_text";
    address: "address";
    qr_scanner: "qr_scanner";
    table: "table";
    radio: "radio";
    checkbox_group: "checkbox_group";
    select: "select";
    multi_select: "multi_select";
    ranking: "ranking";
    pass_fail_na: "pass_fail_na";
    rating: "rating";
    yes_no_comment: "yes_no_comment";
    traffic_light: "traffic_light";
    matrix: "matrix";
    person_picker: "person_picker";
    multi_person_picker: "multi_person_picker";
    customer_picker: "customer_picker";
    project_picker: "project_picker";
    site_picker: "site_picker";
    area_picker: "area_picker";
    gl_account: "gl_account";
    party: "party";
    photo: "photo";
    photo_upload: "photo_upload";
    photo_ai: "photo_ai";
    photo_annotated: "photo_annotated";
    file: "file";
    video: "video";
    audio: "audio";
    sketch: "sketch";
    signature: "signature";
    typed_attestation: "typed_attestation";
    formula: "formula";
    risk_matrix: "risk_matrix";
    lookup: "lookup";
    data_table: "data_table";
    metric: "metric";
    heading: "heading";
    paragraph: "paragraph";
    divider: "divider";
}>;
export type FieldType = z.infer<typeof fieldTypeSchema>;
export declare const PARTY_PICKER_KINDS: readonly ["any", "customer", "vendor", "employee"];
export type PartyPickerKind = (typeof PARTY_PICKER_KINDS)[number];
export type TableColumnType = 'text' | 'number' | 'select' | 'checkbox' | 'date';
export declare const tableColumnSchema: z.ZodObject<{
    key: z.ZodString;
    label: z.ZodString;
    type: z.ZodEnum<{
        number: "number";
        text: "text";
        date: "date";
        select: "select";
        checkbox: "checkbox";
    }>;
    options: z.ZodOptional<z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>;
export type TableColumn = z.infer<typeof tableColumnSchema>;
export declare const tableConfigSchema: z.ZodObject<{
    columns: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        label: z.ZodString;
        type: z.ZodEnum<{
            number: "number";
            text: "text";
            date: "date";
            select: "select";
            checkbox: "checkbox";
        }>;
        options: z.ZodOptional<z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            label: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>>;
    rowMode: z.ZodDefault<z.ZodEnum<{
        fixed: "fixed";
        addable: "addable";
    }>>;
    minRows: z.ZodOptional<z.ZodNumber>;
    maxRows: z.ZodOptional<z.ZodNumber>;
    rows: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>;
export type TableConfig = z.infer<typeof tableConfigSchema>;
export declare const matrixConfigSchema: z.ZodObject<{
    rows: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        label: z.ZodString;
    }, z.core.$strip>>;
    scale: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type MatrixConfig = z.infer<typeof matrixConfigSchema>;
export declare const fieldValidationSchema: z.ZodObject<{
    required: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
    min: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    max: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    minLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    maxLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    pattern: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    message: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    options: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
    }, z.core.$strip>>>>;
    allowOther: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
}, z.core.$strip>;
export type FieldValidation = z.infer<typeof fieldValidationSchema>;
export type ChoiceOption = {
    value: string;
    label: I18nString;
};
export declare const dataAggregateFnSchema: z.ZodEnum<{
    min: "min";
    max: "max";
    count: "count";
    sum: "sum";
    avg: "avg";
}>;
export type DataAggregateFn = z.infer<typeof dataAggregateFnSchema>;
export declare const dataDisplaySchema: z.ZodEnum<{
    number: "number";
    bar: "bar";
    pie: "pie";
}>;
export type DataDisplay = z.infer<typeof dataDisplaySchema>;
export declare const dataBindingSchema: z.ZodObject<{
    sourceKey: z.ZodString;
    valueColumn: z.ZodOptional<z.ZodString>;
    labelColumn: z.ZodOptional<z.ZodString>;
    filterByField: z.ZodOptional<z.ZodString>;
    filterColumn: z.ZodOptional<z.ZodString>;
    autofill: z.ZodOptional<z.ZodArray<z.ZodObject<{
        column: z.ZodString;
        targetFieldId: z.ZodString;
    }, z.core.$strip>>>;
    where: z.ZodOptional<z.ZodArray<z.ZodObject<{
        column: z.ZodString;
        value: z.ZodUnknown;
    }, z.core.$strip>>>;
    columns: z.ZodOptional<z.ZodArray<z.ZodString>>;
    selectable: z.ZodOptional<z.ZodEnum<{
        none: "none";
        single: "single";
        multi: "multi";
    }>>;
    aggregate: z.ZodOptional<z.ZodObject<{
        fn: z.ZodEnum<{
            min: "min";
            max: "max";
            count: "count";
            sum: "sum";
            avg: "avg";
        }>;
        column: z.ZodOptional<z.ZodString>;
        groupBy: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    display: z.ZodOptional<z.ZodEnum<{
        number: "number";
        bar: "bar";
        pie: "pie";
    }>>;
    limit: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type DataBinding = z.infer<typeof dataBindingSchema>;
export declare const formFieldSchema: z.ZodObject<{
    id: z.ZodString;
    type: z.ZodEnum<{
        number: "number";
        text: "text";
        long_text: "long_text";
        currency: "currency";
        percentage: "percentage";
        slider: "slider";
        date: "date";
        datetime: "datetime";
        time: "time";
        gps: "gps";
        email: "email";
        phone: "phone";
        url: "url";
        rich_text: "rich_text";
        address: "address";
        qr_scanner: "qr_scanner";
        table: "table";
        radio: "radio";
        checkbox_group: "checkbox_group";
        select: "select";
        multi_select: "multi_select";
        ranking: "ranking";
        pass_fail_na: "pass_fail_na";
        rating: "rating";
        yes_no_comment: "yes_no_comment";
        traffic_light: "traffic_light";
        matrix: "matrix";
        person_picker: "person_picker";
        multi_person_picker: "multi_person_picker";
        customer_picker: "customer_picker";
        project_picker: "project_picker";
        site_picker: "site_picker";
        area_picker: "area_picker";
        gl_account: "gl_account";
        party: "party";
        photo: "photo";
        photo_upload: "photo_upload";
        photo_ai: "photo_ai";
        photo_annotated: "photo_annotated";
        file: "file";
        video: "video";
        audio: "audio";
        sketch: "sketch";
        signature: "signature";
        typed_attestation: "typed_attestation";
        formula: "formula";
        risk_matrix: "risk_matrix";
        lookup: "lookup";
        data_table: "data_table";
        metric: "metric";
        heading: "heading";
        paragraph: "paragraph";
        divider: "divider";
    }>;
    label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
    helpText: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
    required: z.ZodOptional<z.ZodBoolean>;
    showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
    validation: z.ZodOptional<z.ZodObject<{
        required: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
        min: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        max: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        minLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        maxLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        pattern: z.ZodOptional<z.ZodOptional<z.ZodString>>;
        message: z.ZodOptional<z.ZodOptional<z.ZodString>>;
        options: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
        }, z.core.$strip>>>>;
        allowOther: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
    }, z.core.$strip>>;
    config: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    binding: z.ZodOptional<z.ZodObject<{
        sourceKey: z.ZodString;
        valueColumn: z.ZodOptional<z.ZodString>;
        labelColumn: z.ZodOptional<z.ZodString>;
        filterByField: z.ZodOptional<z.ZodString>;
        filterColumn: z.ZodOptional<z.ZodString>;
        autofill: z.ZodOptional<z.ZodArray<z.ZodObject<{
            column: z.ZodString;
            targetFieldId: z.ZodString;
        }, z.core.$strip>>>;
        where: z.ZodOptional<z.ZodArray<z.ZodObject<{
            column: z.ZodString;
            value: z.ZodUnknown;
        }, z.core.$strip>>>;
        columns: z.ZodOptional<z.ZodArray<z.ZodString>>;
        selectable: z.ZodOptional<z.ZodEnum<{
            none: "none";
            single: "single";
            multi: "multi";
        }>>;
        aggregate: z.ZodOptional<z.ZodObject<{
            fn: z.ZodEnum<{
                min: "min";
                max: "max";
                count: "count";
                sum: "sum";
                avg: "avg";
            }>;
            column: z.ZodOptional<z.ZodString>;
            groupBy: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        display: z.ZodOptional<z.ZodEnum<{
            number: "number";
            bar: "bar";
            pie: "pie";
        }>>;
        limit: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    formula: z.ZodOptional<z.ZodType<FormulaExpression, unknown, z.core.$ZodTypeInternals<FormulaExpression, unknown>>>;
    defaultValue: z.ZodOptional<z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>>;
    colSpan: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type FormField = z.infer<typeof formFieldSchema>;
export declare const canvasItemSchema: z.ZodObject<{
    i: z.ZodString;
    x: z.ZodNumber;
    y: z.ZodNumber;
    w: z.ZodNumber;
    h: z.ZodNumber;
}, z.core.$strip>;
export type CanvasItem = z.infer<typeof canvasItemSchema>;
export declare const canvasLayoutSchema: z.ZodObject<{
    cols: z.ZodDefault<z.ZodNumber>;
    rowHeight: z.ZodDefault<z.ZodNumber>;
    items: z.ZodArray<z.ZodObject<{
        i: z.ZodString;
        x: z.ZodNumber;
        y: z.ZodNumber;
        w: z.ZodNumber;
        h: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type CanvasLayout = z.infer<typeof canvasLayoutSchema>;
export declare const formSectionSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
    description: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
    showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
    repeating: z.ZodOptional<z.ZodBoolean>;
    minRows: z.ZodOptional<z.ZodNumber>;
    maxRows: z.ZodOptional<z.ZodNumber>;
    rowLabelTemplate: z.ZodOptional<z.ZodString>;
    layout: z.ZodOptional<z.ZodObject<{
        columns: z.ZodNumber;
        gap: z.ZodOptional<z.ZodEnum<{
            sm: "sm";
            md: "md";
            lg: "lg";
        }>>;
    }, z.core.$strip>>;
    canvas: z.ZodOptional<z.ZodObject<{
        cols: z.ZodDefault<z.ZodNumber>;
        rowHeight: z.ZodDefault<z.ZodNumber>;
        items: z.ZodArray<z.ZodObject<{
            i: z.ZodString;
            x: z.ZodNumber;
            y: z.ZodNumber;
            w: z.ZodNumber;
            h: z.ZodNumber;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    step: z.ZodOptional<z.ZodString>;
    tabId: z.ZodOptional<z.ZodString>;
    fields: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        type: z.ZodEnum<{
            number: "number";
            text: "text";
            long_text: "long_text";
            currency: "currency";
            percentage: "percentage";
            slider: "slider";
            date: "date";
            datetime: "datetime";
            time: "time";
            gps: "gps";
            email: "email";
            phone: "phone";
            url: "url";
            rich_text: "rich_text";
            address: "address";
            qr_scanner: "qr_scanner";
            table: "table";
            radio: "radio";
            checkbox_group: "checkbox_group";
            select: "select";
            multi_select: "multi_select";
            ranking: "ranking";
            pass_fail_na: "pass_fail_na";
            rating: "rating";
            yes_no_comment: "yes_no_comment";
            traffic_light: "traffic_light";
            matrix: "matrix";
            person_picker: "person_picker";
            multi_person_picker: "multi_person_picker";
            customer_picker: "customer_picker";
            project_picker: "project_picker";
            site_picker: "site_picker";
            area_picker: "area_picker";
            gl_account: "gl_account";
            party: "party";
            photo: "photo";
            photo_upload: "photo_upload";
            photo_ai: "photo_ai";
            photo_annotated: "photo_annotated";
            file: "file";
            video: "video";
            audio: "audio";
            sketch: "sketch";
            signature: "signature";
            typed_attestation: "typed_attestation";
            formula: "formula";
            risk_matrix: "risk_matrix";
            lookup: "lookup";
            data_table: "data_table";
            metric: "metric";
            heading: "heading";
            paragraph: "paragraph";
            divider: "divider";
        }>;
        label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
        helpText: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
        required: z.ZodOptional<z.ZodBoolean>;
        showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
        validation: z.ZodOptional<z.ZodObject<{
            required: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
            min: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            max: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            minLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            maxLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            pattern: z.ZodOptional<z.ZodOptional<z.ZodString>>;
            message: z.ZodOptional<z.ZodOptional<z.ZodString>>;
            options: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
            }, z.core.$strip>>>>;
            allowOther: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
        }, z.core.$strip>>;
        config: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        binding: z.ZodOptional<z.ZodObject<{
            sourceKey: z.ZodString;
            valueColumn: z.ZodOptional<z.ZodString>;
            labelColumn: z.ZodOptional<z.ZodString>;
            filterByField: z.ZodOptional<z.ZodString>;
            filterColumn: z.ZodOptional<z.ZodString>;
            autofill: z.ZodOptional<z.ZodArray<z.ZodObject<{
                column: z.ZodString;
                targetFieldId: z.ZodString;
            }, z.core.$strip>>>;
            where: z.ZodOptional<z.ZodArray<z.ZodObject<{
                column: z.ZodString;
                value: z.ZodUnknown;
            }, z.core.$strip>>>;
            columns: z.ZodOptional<z.ZodArray<z.ZodString>>;
            selectable: z.ZodOptional<z.ZodEnum<{
                none: "none";
                single: "single";
                multi: "multi";
            }>>;
            aggregate: z.ZodOptional<z.ZodObject<{
                fn: z.ZodEnum<{
                    min: "min";
                    max: "max";
                    count: "count";
                    sum: "sum";
                    avg: "avg";
                }>;
                column: z.ZodOptional<z.ZodString>;
                groupBy: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
            display: z.ZodOptional<z.ZodEnum<{
                number: "number";
                bar: "bar";
                pie: "pie";
            }>>;
            limit: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        formula: z.ZodOptional<z.ZodType<FormulaExpression, unknown, z.core.$ZodTypeInternals<FormulaExpression, unknown>>>;
        defaultValue: z.ZodOptional<z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>>;
        colSpan: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type FormSection = z.infer<typeof formSectionSchema>;
export declare const formWorkflowStepSchema: z.ZodObject<{
    key: z.ZodString;
    title: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
    assignee: z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"literal">;
        userId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"expression">;
        expr: z.ZodString;
    }, z.core.$strip>], "type">;
    signatureRequired: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type FormWorkflowStep = z.infer<typeof formWorkflowStepSchema>;
export declare const hardFailRuleSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"any_field_eq">;
    fieldKeys: z.ZodArray<z.ZodString>;
    value: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"any_field_in">;
    fieldKeys: z.ZodArray<z.ZodString>;
    values: z.ZodArray<z.ZodString>;
}, z.core.$strip>], "kind">;
export type HardFailRule = z.infer<typeof hardFailRuleSchema>;
export declare const scoreRoutingSchema: z.ZodObject<{
    scoreFormula: z.ZodOptional<z.ZodType<FormulaExpression, unknown, z.core.$ZodTypeInternals<FormulaExpression, unknown>>>;
    thresholdScore: z.ZodOptional<z.ZodNumber>;
    hardFailRules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"any_field_eq">;
        fieldKeys: z.ZodArray<z.ZodString>;
        value: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"any_field_in">;
        fieldKeys: z.ZodArray<z.ZodString>;
        values: z.ZodArray<z.ZodString>;
    }, z.core.$strip>], "kind">>>;
}, z.core.$strip>;
export type ScoreRouting = z.infer<typeof scoreRoutingSchema>;
export type SchemaIssue = {
    path: Array<string | number>;
    message: string;
};
export declare const CHOICE_FIELD_TYPES: Set<"number" | "text" | "long_text" | "currency" | "percentage" | "slider" | "date" | "datetime" | "time" | "gps" | "email" | "phone" | "url" | "rich_text" | "address" | "qr_scanner" | "table" | "radio" | "checkbox_group" | "select" | "multi_select" | "ranking" | "pass_fail_na" | "rating" | "yes_no_comment" | "traffic_light" | "matrix" | "person_picker" | "multi_person_picker" | "customer_picker" | "project_picker" | "site_picker" | "area_picker" | "gl_account" | "party" | "photo" | "photo_upload" | "photo_ai" | "photo_annotated" | "file" | "video" | "audio" | "sketch" | "signature" | "typed_attestation" | "formula" | "risk_matrix" | "lookup" | "data_table" | "metric" | "heading" | "paragraph" | "divider">;
export declare function textValidationHardLimit(type: FieldType): number | null;
/**
 * Return why a designer-authored regular expression is unsafe, or null when
 * it is safe to execute against a bounded response string.
 *
 * JavaScript RegExp has no execution timeout. Quantified groups, lookarounds,
 * and backreferences can introduce catastrophic backtracking, so form
 * patterns deliberately support a conservative regular subset: an anchored
 * expression made from literals, character classes, and exact `{n}`
 * repetition. Variable repetition and alternation are excluded because even
 * individually simple overlapping branches can create polynomial or
 * exponential ReDoS. This
 * still covers practical fixed-format masks such as employee numbers and
 * postal codes without making submission validation a DoS primitive.
 */
export declare function validationPatternError(pattern: string): string | null;
export declare const formSchemaV1: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    title: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
    description: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
    sections: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
        description: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
        showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
        repeating: z.ZodOptional<z.ZodBoolean>;
        minRows: z.ZodOptional<z.ZodNumber>;
        maxRows: z.ZodOptional<z.ZodNumber>;
        rowLabelTemplate: z.ZodOptional<z.ZodString>;
        layout: z.ZodOptional<z.ZodObject<{
            columns: z.ZodNumber;
            gap: z.ZodOptional<z.ZodEnum<{
                sm: "sm";
                md: "md";
                lg: "lg";
            }>>;
        }, z.core.$strip>>;
        canvas: z.ZodOptional<z.ZodObject<{
            cols: z.ZodDefault<z.ZodNumber>;
            rowHeight: z.ZodDefault<z.ZodNumber>;
            items: z.ZodArray<z.ZodObject<{
                i: z.ZodString;
                x: z.ZodNumber;
                y: z.ZodNumber;
                w: z.ZodNumber;
                h: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        step: z.ZodOptional<z.ZodString>;
        tabId: z.ZodOptional<z.ZodString>;
        fields: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            type: z.ZodEnum<{
                number: "number";
                text: "text";
                long_text: "long_text";
                currency: "currency";
                percentage: "percentage";
                slider: "slider";
                date: "date";
                datetime: "datetime";
                time: "time";
                gps: "gps";
                email: "email";
                phone: "phone";
                url: "url";
                rich_text: "rich_text";
                address: "address";
                qr_scanner: "qr_scanner";
                table: "table";
                radio: "radio";
                checkbox_group: "checkbox_group";
                select: "select";
                multi_select: "multi_select";
                ranking: "ranking";
                pass_fail_na: "pass_fail_na";
                rating: "rating";
                yes_no_comment: "yes_no_comment";
                traffic_light: "traffic_light";
                matrix: "matrix";
                person_picker: "person_picker";
                multi_person_picker: "multi_person_picker";
                customer_picker: "customer_picker";
                project_picker: "project_picker";
                site_picker: "site_picker";
                area_picker: "area_picker";
                gl_account: "gl_account";
                party: "party";
                photo: "photo";
                photo_upload: "photo_upload";
                photo_ai: "photo_ai";
                photo_annotated: "photo_annotated";
                file: "file";
                video: "video";
                audio: "audio";
                sketch: "sketch";
                signature: "signature";
                typed_attestation: "typed_attestation";
                formula: "formula";
                risk_matrix: "risk_matrix";
                lookup: "lookup";
                data_table: "data_table";
                metric: "metric";
                heading: "heading";
                paragraph: "paragraph";
                divider: "divider";
            }>;
            label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
            helpText: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
            required: z.ZodOptional<z.ZodBoolean>;
            showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
            validation: z.ZodOptional<z.ZodObject<{
                required: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
                min: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                max: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                minLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                maxLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                pattern: z.ZodOptional<z.ZodOptional<z.ZodString>>;
                message: z.ZodOptional<z.ZodOptional<z.ZodString>>;
                options: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodObject<{
                    value: z.ZodString;
                    label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
                }, z.core.$strip>>>>;
                allowOther: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
            }, z.core.$strip>>;
            config: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            binding: z.ZodOptional<z.ZodObject<{
                sourceKey: z.ZodString;
                valueColumn: z.ZodOptional<z.ZodString>;
                labelColumn: z.ZodOptional<z.ZodString>;
                filterByField: z.ZodOptional<z.ZodString>;
                filterColumn: z.ZodOptional<z.ZodString>;
                autofill: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    column: z.ZodString;
                    targetFieldId: z.ZodString;
                }, z.core.$strip>>>;
                where: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    column: z.ZodString;
                    value: z.ZodUnknown;
                }, z.core.$strip>>>;
                columns: z.ZodOptional<z.ZodArray<z.ZodString>>;
                selectable: z.ZodOptional<z.ZodEnum<{
                    none: "none";
                    single: "single";
                    multi: "multi";
                }>>;
                aggregate: z.ZodOptional<z.ZodObject<{
                    fn: z.ZodEnum<{
                        min: "min";
                        max: "max";
                        count: "count";
                        sum: "sum";
                        avg: "avg";
                    }>;
                    column: z.ZodOptional<z.ZodString>;
                    groupBy: z.ZodOptional<z.ZodString>;
                }, z.core.$strip>>;
                display: z.ZodOptional<z.ZodEnum<{
                    number: "number";
                    bar: "bar";
                    pie: "pie";
                }>>;
                limit: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            formula: z.ZodOptional<z.ZodType<FormulaExpression, unknown, z.core.$ZodTypeInternals<FormulaExpression, unknown>>>;
            defaultValue: z.ZodOptional<z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>>;
            colSpan: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    tabs: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
    }, z.core.$strip>>>;
    workflow: z.ZodOptional<z.ZodObject<{
        steps: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            title: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
            assignee: z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"literal">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"expression">;
                expr: z.ZodString;
            }, z.core.$strip>], "type">;
            signatureRequired: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strip>>;
        scoreRouting: z.ZodOptional<z.ZodObject<{
            scoreFormula: z.ZodOptional<z.ZodType<FormulaExpression, unknown, z.core.$ZodTypeInternals<FormulaExpression, unknown>>>;
            thresholdScore: z.ZodOptional<z.ZodNumber>;
            hardFailRules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"any_field_eq">;
                fieldKeys: z.ZodArray<z.ZodString>;
                value: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"any_field_in">;
                fieldKeys: z.ZodArray<z.ZodString>;
                values: z.ZodArray<z.ZodString>;
            }, z.core.$strip>], "kind">>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    pdf: z.ZodOptional<z.ZodObject<{
        css: z.ZodOptional<z.ZodString>;
        header: z.ZodOptional<z.ZodString>;
        footer: z.ZodOptional<z.ZodString>;
        pageSize: z.ZodOptional<z.ZodEnum<{
            A4: "A4";
            Letter: "Letter";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type FormSchemaV1 = z.infer<typeof formSchemaV1>;
/** Canonical schema alias retained for import compatibility. */
export declare const formSchemaV1Schema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    title: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
    description: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
    sections: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
        description: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
        showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
        repeating: z.ZodOptional<z.ZodBoolean>;
        minRows: z.ZodOptional<z.ZodNumber>;
        maxRows: z.ZodOptional<z.ZodNumber>;
        rowLabelTemplate: z.ZodOptional<z.ZodString>;
        layout: z.ZodOptional<z.ZodObject<{
            columns: z.ZodNumber;
            gap: z.ZodOptional<z.ZodEnum<{
                sm: "sm";
                md: "md";
                lg: "lg";
            }>>;
        }, z.core.$strip>>;
        canvas: z.ZodOptional<z.ZodObject<{
            cols: z.ZodDefault<z.ZodNumber>;
            rowHeight: z.ZodDefault<z.ZodNumber>;
            items: z.ZodArray<z.ZodObject<{
                i: z.ZodString;
                x: z.ZodNumber;
                y: z.ZodNumber;
                w: z.ZodNumber;
                h: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        step: z.ZodOptional<z.ZodString>;
        tabId: z.ZodOptional<z.ZodString>;
        fields: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            type: z.ZodEnum<{
                number: "number";
                text: "text";
                long_text: "long_text";
                currency: "currency";
                percentage: "percentage";
                slider: "slider";
                date: "date";
                datetime: "datetime";
                time: "time";
                gps: "gps";
                email: "email";
                phone: "phone";
                url: "url";
                rich_text: "rich_text";
                address: "address";
                qr_scanner: "qr_scanner";
                table: "table";
                radio: "radio";
                checkbox_group: "checkbox_group";
                select: "select";
                multi_select: "multi_select";
                ranking: "ranking";
                pass_fail_na: "pass_fail_na";
                rating: "rating";
                yes_no_comment: "yes_no_comment";
                traffic_light: "traffic_light";
                matrix: "matrix";
                person_picker: "person_picker";
                multi_person_picker: "multi_person_picker";
                customer_picker: "customer_picker";
                project_picker: "project_picker";
                site_picker: "site_picker";
                area_picker: "area_picker";
                gl_account: "gl_account";
                party: "party";
                photo: "photo";
                photo_upload: "photo_upload";
                photo_ai: "photo_ai";
                photo_annotated: "photo_annotated";
                file: "file";
                video: "video";
                audio: "audio";
                sketch: "sketch";
                signature: "signature";
                typed_attestation: "typed_attestation";
                formula: "formula";
                risk_matrix: "risk_matrix";
                lookup: "lookup";
                data_table: "data_table";
                metric: "metric";
                heading: "heading";
                paragraph: "paragraph";
                divider: "divider";
            }>;
            label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
            helpText: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
            required: z.ZodOptional<z.ZodBoolean>;
            showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
            validation: z.ZodOptional<z.ZodObject<{
                required: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
                min: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                max: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                minLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                maxLength: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
                pattern: z.ZodOptional<z.ZodOptional<z.ZodString>>;
                message: z.ZodOptional<z.ZodOptional<z.ZodString>>;
                options: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodObject<{
                    value: z.ZodString;
                    label: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
                }, z.core.$strip>>>>;
                allowOther: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
            }, z.core.$strip>>;
            config: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            binding: z.ZodOptional<z.ZodObject<{
                sourceKey: z.ZodString;
                valueColumn: z.ZodOptional<z.ZodString>;
                labelColumn: z.ZodOptional<z.ZodString>;
                filterByField: z.ZodOptional<z.ZodString>;
                filterColumn: z.ZodOptional<z.ZodString>;
                autofill: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    column: z.ZodString;
                    targetFieldId: z.ZodString;
                }, z.core.$strip>>>;
                where: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    column: z.ZodString;
                    value: z.ZodUnknown;
                }, z.core.$strip>>>;
                columns: z.ZodOptional<z.ZodArray<z.ZodString>>;
                selectable: z.ZodOptional<z.ZodEnum<{
                    none: "none";
                    single: "single";
                    multi: "multi";
                }>>;
                aggregate: z.ZodOptional<z.ZodObject<{
                    fn: z.ZodEnum<{
                        min: "min";
                        max: "max";
                        count: "count";
                        sum: "sum";
                        avg: "avg";
                    }>;
                    column: z.ZodOptional<z.ZodString>;
                    groupBy: z.ZodOptional<z.ZodString>;
                }, z.core.$strip>>;
                display: z.ZodOptional<z.ZodEnum<{
                    number: "number";
                    bar: "bar";
                    pie: "pie";
                }>>;
                limit: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            formula: z.ZodOptional<z.ZodType<FormulaExpression, unknown, z.core.$ZodTypeInternals<FormulaExpression, unknown>>>;
            defaultValue: z.ZodOptional<z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>>;
            colSpan: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    tabs: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
    }, z.core.$strip>>>;
    workflow: z.ZodOptional<z.ZodObject<{
        steps: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            title: z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>;
            assignee: z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"literal">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"expression">;
                expr: z.ZodString;
            }, z.core.$strip>], "type">;
            signatureRequired: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strip>>;
        scoreRouting: z.ZodOptional<z.ZodObject<{
            scoreFormula: z.ZodOptional<z.ZodType<FormulaExpression, unknown, z.core.$ZodTypeInternals<FormulaExpression, unknown>>>;
            thresholdScore: z.ZodOptional<z.ZodNumber>;
            hardFailRules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"any_field_eq">;
                fieldKeys: z.ZodArray<z.ZodString>;
                value: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"any_field_in">;
                fieldKeys: z.ZodArray<z.ZodString>;
                values: z.ZodArray<z.ZodString>;
            }, z.core.$strip>], "kind">>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    pdf: z.ZodOptional<z.ZodObject<{
        css: z.ZodOptional<z.ZodString>;
        header: z.ZodOptional<z.ZodString>;
        footer: z.ZodOptional<z.ZodString>;
        pageSize: z.ZodOptional<z.ZodEnum<{
            A4: "A4";
            Letter: "Letter";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type ParseFormSchemaResult = {
    ok: true;
    schema: FormSchemaV1;
} | {
    ok: false;
    issues: SchemaIssue[];
};
/** Parse untrusted persisted or imported schema data without throwing. */
export declare function parseFormSchema(input: unknown): ParseFormSchemaResult;
/** Smallest useful schema accepted by both legacy apps and the shared builder. */
export declare function emptyFormSchema(title?: I18nString): FormSchemaV1;
export declare function validateFormSchema(input: unknown): FormSchemaV1;
export declare function lintFormSchema(schema: FormSchemaV1): string[];
//# sourceMappingURL=schema.d.ts.map