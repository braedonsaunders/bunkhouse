/**
 * Validate the canonical same-origin capability URL returned by an attachment
 * uploader. When an id is supplied, the URL must refer to that exact record.
 */
export declare function isApplicationAttachmentUrl(value: string, attachmentId?: string): boolean;
/** Normalize links accepted by the rich-document storage boundary. */
export declare function normalizeDocumentHref(value: string): string | null;
//# sourceMappingURL=document-url.d.ts.map