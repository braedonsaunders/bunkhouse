import { z } from 'zod';
import { type DefaultValueExpression, type LogicRule } from './schema.js';
import { type EvalContext } from './evaluator.js';
import type { FlowSubjectProfile } from './business-flow-subjects.js';
export declare const assigneeTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"user">;
    userId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"role">;
    role: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"submitter">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"supervisor">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"field">;
    field: z.ZodString;
}, z.core.$strip>], "type">;
export type AssigneeTarget = z.infer<typeof assigneeTargetSchema>;
export declare const recipientTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"user">;
    userId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"role">;
    role: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"submitter">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"supervisor">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"field">;
    field: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"email">;
    email: z.ZodString;
}, z.core.$strip>], "type">;
export type RecipientTarget = z.infer<typeof recipientTargetSchema>;
export declare const triggerDataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    trigger: z.ZodLiteral<"on_create">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_update">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_submit">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"before_post">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"after_post">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"before_void">;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"status_change">;
    from: z.ZodOptional<z.ZodString>;
    to: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"on_field_value">;
    rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"scheduled">;
    cron: z.ZodString;
    tz: z.ZodOptional<z.ZodString>;
    select: z.ZodOptional<z.ZodObject<{
        rule: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
        limit: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    trigger: z.ZodLiteral<"manual">;
    buttonId: z.ZodString;
    label: z.ZodString;
    confirm: z.ZodOptional<z.ZodString>;
    requirePermission: z.ZodOptional<z.ZodString>;
    showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
}, z.core.$strip>], "trigger">;
export type TriggerData = z.infer<typeof triggerDataSchema>;
export type TriggerKind = TriggerData['trigger'];
export declare const actionDataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    action: z.ZodLiteral<"send_email">;
    to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"user">;
        userId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"supervisor">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"field">;
        field: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"email">;
        email: z.ZodString;
    }, z.core.$strip>], "type">>;
    subject: z.ZodString;
    body: z.ZodString;
    attachPdf: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"notify">;
    to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"user">;
        userId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"supervisor">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"field">;
        field: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"email">;
        email: z.ZodString;
    }, z.core.$strip>], "type">>;
    title: z.ZodString;
    body: z.ZodOptional<z.ZodString>;
    href: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"set_field">;
    field: z.ZodString;
    value: z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"change_status">;
    to: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"post_document">;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"lock_record">;
    reason: z.ZodOptional<z.ZodString>;
    exemptRoles: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"unlock_record">;
}, z.core.$strip>], "action">;
export type ActionData = z.infer<typeof actionDataSchema>;
export type ActionKind = ActionData['action'];
export declare const gateDataSchema: z.ZodObject<{
    title: z.ZodString;
    assignees: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"user">;
        userId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"supervisor">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"field">;
        field: z.ZodString;
    }, z.core.$strip>], "type">>;
    mode: z.ZodEnum<{
        any: "any";
        all: "all";
    }>;
    signatureRequired: z.ZodOptional<z.ZodBoolean>;
    preventSelfApproval: z.ZodOptional<z.ZodBoolean>;
    reminderAfterHours: z.ZodOptional<z.ZodNumber>;
    escalateAfterHours: z.ZodOptional<z.ZodNumber>;
    escalateTo: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"user">;
        userId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"role">;
        role: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"submitter">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"supervisor">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"field">;
        field: z.ZodString;
    }, z.core.$strip>], "type">>;
}, z.core.$strip>;
export type GateData = z.infer<typeof gateDataSchema>;
export declare const automationNodeSchema: z.ZodObject<{
    id: z.ZodString;
    position: z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
    }, z.core.$strip>;
    data: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"trigger">;
        trigger: z.ZodDiscriminatedUnion<[z.ZodObject<{
            trigger: z.ZodLiteral<"on_create">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_update">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_submit">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"before_post">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"after_post">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"before_void">;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"status_change">;
            from: z.ZodOptional<z.ZodString>;
            to: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"on_field_value">;
            rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"scheduled">;
            cron: z.ZodString;
            tz: z.ZodOptional<z.ZodString>;
            select: z.ZodOptional<z.ZodObject<{
                rule: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
                limit: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            trigger: z.ZodLiteral<"manual">;
            buttonId: z.ZodString;
            label: z.ZodString;
            confirm: z.ZodOptional<z.ZodString>;
            requirePermission: z.ZodOptional<z.ZodString>;
            showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
        }, z.core.$strip>], "trigger">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"condition">;
        rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
        label: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"action">;
        action: z.ZodDiscriminatedUnion<[z.ZodObject<{
            action: z.ZodLiteral<"send_email">;
            to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"user">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"supervisor">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"field">;
                field: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"email">;
                email: z.ZodString;
            }, z.core.$strip>], "type">>;
            subject: z.ZodString;
            body: z.ZodString;
            attachPdf: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"notify">;
            to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"user">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"supervisor">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"field">;
                field: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"email">;
                email: z.ZodString;
            }, z.core.$strip>], "type">>;
            title: z.ZodString;
            body: z.ZodOptional<z.ZodString>;
            href: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"set_field">;
            field: z.ZodString;
            value: z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"change_status">;
            to: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"post_document">;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"lock_record">;
            reason: z.ZodOptional<z.ZodString>;
            exemptRoles: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>, z.ZodObject<{
            action: z.ZodLiteral<"unlock_record">;
        }, z.core.$strip>], "action">;
        label: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"gate">;
        gate: z.ZodObject<{
            title: z.ZodString;
            assignees: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"user">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"supervisor">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"field">;
                field: z.ZodString;
            }, z.core.$strip>], "type">>;
            mode: z.ZodEnum<{
                any: "any";
                all: "all";
            }>;
            signatureRequired: z.ZodOptional<z.ZodBoolean>;
            preventSelfApproval: z.ZodOptional<z.ZodBoolean>;
            reminderAfterHours: z.ZodOptional<z.ZodNumber>;
            escalateAfterHours: z.ZodOptional<z.ZodNumber>;
            escalateTo: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"user">;
                userId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"role">;
                role: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"submitter">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"supervisor">;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"field">;
                field: z.ZodString;
            }, z.core.$strip>], "type">>;
        }, z.core.$strip>;
    }, z.core.$strip>], "kind">;
}, z.core.$strip>;
export type AutomationNode = z.infer<typeof automationNodeSchema>;
export declare const automationEdgeSchema: z.ZodObject<{
    id: z.ZodString;
    source: z.ZodString;
    target: z.ZodString;
    sourceHandle: z.ZodOptional<z.ZodEnum<{
        then: "then";
        else: "else";
        next: "next";
        approve: "approve";
        reject: "reject";
    }>>;
}, z.core.$strip>;
export type AutomationEdge = z.infer<typeof automationEdgeSchema>;
export declare const MAX_FLOW_NODES = 200;
export declare const MAX_FLOW_EDGES = 400;
export declare const automationGraphSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    nodes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        position: z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, z.core.$strip>;
        data: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"trigger">;
            trigger: z.ZodDiscriminatedUnion<[z.ZodObject<{
                trigger: z.ZodLiteral<"on_create">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_update">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_submit">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"before_post">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"after_post">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"before_void">;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"status_change">;
                from: z.ZodOptional<z.ZodString>;
                to: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"on_field_value">;
                rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"scheduled">;
                cron: z.ZodString;
                tz: z.ZodOptional<z.ZodString>;
                select: z.ZodOptional<z.ZodObject<{
                    rule: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
                    limit: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                trigger: z.ZodLiteral<"manual">;
                buttonId: z.ZodString;
                label: z.ZodString;
                confirm: z.ZodOptional<z.ZodString>;
                requirePermission: z.ZodOptional<z.ZodString>;
                showIf: z.ZodOptional<z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>>;
            }, z.core.$strip>], "trigger">;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"condition">;
            rule: z.ZodType<LogicRule, unknown, z.core.$ZodTypeInternals<LogicRule, unknown>>;
            label: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"action">;
            action: z.ZodDiscriminatedUnion<[z.ZodObject<{
                action: z.ZodLiteral<"send_email">;
                to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"user">;
                    userId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"role">;
                    role: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"supervisor">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"field">;
                    field: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"email">;
                    email: z.ZodString;
                }, z.core.$strip>], "type">>;
                subject: z.ZodString;
                body: z.ZodString;
                attachPdf: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"notify">;
                to: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"user">;
                    userId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"role">;
                    role: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"supervisor">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"field">;
                    field: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"email">;
                    email: z.ZodString;
                }, z.core.$strip>], "type">>;
                title: z.ZodString;
                body: z.ZodOptional<z.ZodString>;
                href: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"set_field">;
                field: z.ZodString;
                value: z.ZodType<DefaultValueExpression, unknown, z.core.$ZodTypeInternals<DefaultValueExpression, unknown>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"change_status">;
                to: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"post_document">;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"lock_record">;
                reason: z.ZodOptional<z.ZodString>;
                exemptRoles: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>, z.ZodObject<{
                action: z.ZodLiteral<"unlock_record">;
            }, z.core.$strip>], "action">;
            label: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"gate">;
            gate: z.ZodObject<{
                title: z.ZodString;
                assignees: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"user">;
                    userId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"role">;
                    role: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"supervisor">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"field">;
                    field: z.ZodString;
                }, z.core.$strip>], "type">>;
                mode: z.ZodEnum<{
                    any: "any";
                    all: "all";
                }>;
                signatureRequired: z.ZodOptional<z.ZodBoolean>;
                preventSelfApproval: z.ZodOptional<z.ZodBoolean>;
                reminderAfterHours: z.ZodOptional<z.ZodNumber>;
                escalateAfterHours: z.ZodOptional<z.ZodNumber>;
                escalateTo: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"user">;
                    userId: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"role">;
                    role: z.ZodString;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"submitter">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"supervisor">;
                }, z.core.$strip>, z.ZodObject<{
                    type: z.ZodLiteral<"field">;
                    field: z.ZodString;
                }, z.core.$strip>], "type">>;
            }, z.core.$strip>;
        }, z.core.$strip>], "kind">;
    }, z.core.$strip>>;
    edges: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        source: z.ZodString;
        target: z.ZodString;
        sourceHandle: z.ZodOptional<z.ZodEnum<{
            then: "then";
            else: "else";
            next: "next";
            approve: "approve";
            reject: "reject";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type AutomationGraph = z.infer<typeof automationGraphSchema>;
export declare function emptyAutomationGraph(): AutomationGraph;
/**
 * Substitute `{{field}}` tokens in email/notification templates with the
 * record's header values from the EvalContext. Unknown/empty fields render as
 * '' (never "undefined"). Pure string work — HTML escaping is the DELIVERY
 * side's job (the engine escapes per transport).
 */
export declare function interpolateTemplate(template: string, ctx: EvalContext): string;
/**
 * The concrete runtime event the engine dispatches into the planner. Carries
 * the trigger kind plus the event data needed to match trigger-node config
 * (status transition endpoints, which manual button was clicked, which
 * scheduled nodes are due via `opts.triggerNodeIds`).
 */
export type FlowEventSource = 'ui' | 'api' | 'sync' | 'script' | 'schedule' | 'close_automation';
export type TriggerEvent = ({
    kind: 'on_create';
} | {
    kind: 'on_update';
    previousTotal?: string | number | null;
    totalChanged?: boolean;
    changedFields?: string[];
    changedLineFields?: string[];
    old?: Record<string, unknown>;
} | {
    kind: 'on_submit';
} | {
    kind: 'before_post';
} | {
    kind: 'after_post';
} | {
    kind: 'before_void';
} | {
    kind: 'status_change';
    from?: string | null;
    to: string;
} | {
    kind: 'on_field_value';
} | {
    kind: 'scheduled';
} | {
    kind: 'manual';
    buttonId?: string;
}) & {
    source?: FlowEventSource;
};
export type PlannedGate = {
    nodeId: string;
    gate: GateData;
};
export type PlannedAction = {
    nodeId: string;
    action: ActionData;
};
export type AutomationPlan = {
    actions: ActionData[];
    actionNodes: PlannedAction[];
    gates: PlannedGate[];
};
/**
 * Plan the Actions + Gates reached from EVERY trigger node matching `event`.
 * Pure: the caller performs the side effects server-side.
 *
 * A graph may legitimately carry several triggers of the same kind (multiple
 * manual buttons, several `on_field_value` branches with different rules, or
 * distinct `status_change` transitions). Each satisfied trigger contributes
 * its downstream branch; the branches are collected together so a shared
 * `seen` set dedupes any actions two triggers converge on. Planning only the
 * first matching node would silently drop the rest.
 *
 * Trigger-specific selection:
 *   • `manual` — when `event.buttonId` is supplied, plan just that button;
 *     otherwise plan every manual button (rare, but well-defined).
 *   • `on_field_value` — a node fires only when its own rule passes against
 *     `evalCtx`.
 *   • `status_change` — the node's `to` (and optional `from`) filter must
 *     match the event's transition, so a `from: X → to: Y` node does not fire
 *     on `Z → Y`. A node with neither filter fires on every transition.
 *   • `scheduled` — pass `opts.triggerNodeIds` with the node ids whose cron is
 *     due so an hourly and a weekly schedule on one graph fire independently.
 */
export declare function planAutomation(graph: AutomationGraph, event: TriggerEvent, evalCtx: EvalContext, opts?: {
    /** Restrict same-kind planning to these exact trigger node ids. */
    triggerNodeIds?: string[];
}): AutomationPlan;
/**
 * Resume a paused flow from a Gate's `approve` / `reject` branch after the
 * assignee quorum decides. Returns the downstream Actions + any further Gates.
 */
export declare function planFromGate(graph: AutomationGraph, gateNodeId: string, branch: 'approve' | 'reject', evalCtx: EvalContext): AutomationPlan;
/**
 * Structural + vocabulary lint for a flow graph. `fieldIds` are the header
 * field keys the subject exposes (usually `profile.fields` keys); when a
 * `FlowSubjectProfile` is supplied, triggers/actions/statuses outside the
 * subject's vocabulary and non-writable `set_field` targets are rejected too.
 * Returns human-readable error strings; empty ⇒ the graph is publishable.
 */
export declare function lintAutomationGraph(graph: AutomationGraph, fieldIds: Set<string>, profile?: FlowSubjectProfile): string[];
/** The action vocabulary a scheduled trigger's branch may use at runtime. */
export declare function scheduledSafeActions(hasRecordSelect: boolean): Set<ActionKind>;
/**
 * Scheduled triggers execute off the worker's scheduler tick, not in a web
 * request with a live record mutation pipeline. The tick's executor is
 * narrow — email + in-app notify, plus set_field when the trigger declares a
 * record `select` (fan-out gives each run a real record). Reject branches
 * that would otherwise save successfully and then silently no-op — gates
 * (nothing to pause) and status pipelines (change_status / post_document).
 */
export declare function lintWorkerTriggerCompatibility(graph: AutomationGraph): string[];
export type { DefaultValueExpression, LogicRule };
//# sourceMappingURL=business-automation.d.ts.map