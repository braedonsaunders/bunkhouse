import type { TriggerKind, ActionKind } from './business-automation.js';
/** Coarse value type of a subject field — drives the LogicBuilder editor. */
export type FlowFieldType = 'text' | 'number' | 'bool' | 'date' | 'enum' | 'user';
/** A lifecycle status a subject's records move through. */
export type FlowStatusDef = {
    value: string;
    label: string;
};
/**
 * A merge token / condition field exposed by a subject. `writable` marks
 * header fields a flow may persist into via `set_field` — everything else is
 * read-only from a flow's point of view.
 */
export type FlowFieldDef = {
    key: string;
    label: string;
    type: FlowFieldType;
    writable?: boolean;
    /** Closed vocabulary for enum-like condition values. The builder renders
     * these as choices instead of accepting typo-prone free text. */
    options?: FlowFieldOption[];
};
export type FlowFieldOption = {
    value: string;
    label: string;
};
export type FlowSubjectProfile = {
    /** Subject discriminator, e.g. a document kind: 'invoice', 'bill', 'journal'. */
    subjectKind: string;
    /** Human label used in lint messages + canvas chrome. */
    label: string;
    /** Trigger kinds the subject dispatches (its lifecycle hook sites). */
    triggers: TriggerKind[];
    /** Action kinds the subject's adapter can execute. */
    actions: ActionKind[];
    /** Lifecycle statuses — allowed values for status_change / change_status. */
    statuses: FlowStatusDef[];
    /** Field tokens for conditions, {{interpolation}}, and `field` targets. */
    fields: FlowFieldDef[];
    /** Role names offered by the assignee/recipient `role` target picker. */
    roles?: string[];
};
/** The field keys a profile exposes — the `fieldIds` for `lintAutomationGraph`. */
export declare function profileFieldIds(profile: FlowSubjectProfile): Set<string>;
//# sourceMappingURL=business-flow-subjects.d.ts.map