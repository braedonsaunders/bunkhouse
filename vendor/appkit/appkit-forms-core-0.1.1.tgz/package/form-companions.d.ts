import type { I18nString } from './schema.js';
import { type AppLocale } from '@appkit/i18n';
/** Content-only field types that carry no mergeable value. */
export declare const SKIP_FIELD_TYPES: Set<string>;
/** Resolve an i18n label using the active user and tenant fallback locales. */
export declare function labelText(l: I18nString | undefined, fallback: string, locale?: AppLocale, tenantDefault?: AppLocale): string;
export declare function hasTextCompanion(type: string): boolean;
/** Sketch stores `{url}` — the URL is exposed as `<id>_image`. */
export declare function hasImageCompanion(type: string): boolean;
/** Object-valued photo fields whose attachments nest under `.attachments`. */
export declare function hasPhotosCompanion(type: string): boolean;
/** Array-of-AttachedFile fields — raw rows already carry {url, filename}. */
export declare function isAttachmentArrayField(type: string): boolean;
//# sourceMappingURL=form-companions.d.ts.map