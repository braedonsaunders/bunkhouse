// Flow SUBJECTS — the small abstraction that lets ONE Flows engine + ONE
// canvas drive every automatable record kind (invoices, bills, journals,
// purchase orders, …).
//
// A `FlowSubjectProfile` is pure data describing what a subject offers: which
// triggers/actions are valid, which lifecycle statuses exist, and the field
// "tokens" available for conditions, {{interpolation}}, and recipient/assignee
// `field` targets. The builder canvas renders against this profile;
// `lintAutomationGraph(graph, fieldIds, profile)` rejects anything outside it
// at author time. Server-side behaviour lives in the matching subject adapter
// (engine/src/flows/registry.ts).
//
// This business-document vocabulary is isolated from the safety automation
// profile so applications opt into only the domain semantics they need.
/** The field keys a profile exposes — the `fieldIds` for `lintAutomationGraph`. */
export function profileFieldIds(profile) {
    return new Set(profile.fields.map((f) => f.key));
}
//# sourceMappingURL=business-flow-subjects.js.map