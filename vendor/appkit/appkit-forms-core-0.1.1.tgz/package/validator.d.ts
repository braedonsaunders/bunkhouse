import { type FieldValueMap } from './evaluator.js';
import { type FormField, type FormSchemaV1 } from './schema.js';
export type ValidationError = {
    fieldId: string;
    sectionId?: string;
    message: string;
};
/**
 * Validate a response payload against the form schema.
 * Stage = 'draft' relaxes 'required' checks; 'submit' enforces them.
 *
 * The payload shape mirrors what the filler submits: top-level field values
 * keyed by field id, plus each repeating section's rows stored as an array
 * under the SECTION id. Row-level errors use the filler's composite key
 * convention `${sectionId}.${rowIndex}.${fieldId}` so they land on the right
 * row input in the UI.
 */
export declare function validateResponse(schema: FormSchemaV1, values: FieldValueMap, stage?: 'draft' | 'submit'): ValidationError[];
/**
 * Validate one field value. This is the shared browser/server boundary; callers
 * that validate drafts should pass `draft` to relax completion requirements
 * while still rejecting malformed values.
 */
export declare function validateFieldValue(field: FormField, value: unknown, stage?: 'draft' | 'submit'): string | null;
//# sourceMappingURL=validator.d.ts.map