/** Native entities that support tenant-defined custom fields. */
export type CustomFieldEntityKind = 'equipment' | 'ppe' | 'person' | 'location';
export declare const CUSTOM_FIELD_ENTITY_KINDS: readonly ["equipment", "ppe", "person", "location"];
/** Allowlisted field types for custom fields (subset of the form registry). */
export type CustomFieldType = 'text' | 'textarea' | 'number' | 'date' | 'datetime' | 'boolean' | 'select' | 'multi_select' | 'url' | 'email' | 'phone';
export declare const CUSTOM_FIELD_TYPES: readonly ["text", "textarea", "number", "date", "datetime", "boolean", "select", "multi_select", "url", "email", "phone"];
/** The runtime value shape stored in `metadata.custom[key]`. */
export type CustomFieldValueKind = 'string' | 'number' | 'boolean' | 'string_array';
export type CustomFieldOption = {
    value: string;
    label: string;
};
export type CustomFieldConfig = {
    /** Choices for `select` / `multi_select`. */
    options?: CustomFieldOption[];
    /** Optional unit suffix shown beside `number` inputs (e.g. "ppm", "%", "kg"). */
    unit?: string | null;
    /** Optional numeric bounds / step for `number`. */
    min?: number | null;
    max?: number | null;
    step?: number | null;
    /** Optional placeholder for text-like inputs. */
    placeholder?: string | null;
};
/** A definition as the runtime needs it to validate, coerce and render a value. */
export type CustomFieldDefinition = {
    key: string;
    label: string;
    helpText?: string | null;
    fieldType: CustomFieldType;
    required: boolean;
    config: CustomFieldConfig | null;
};
export type CustomFieldTypeMeta = {
    type: CustomFieldType;
    label: string;
    description: string;
    valueKind: CustomFieldValueKind;
    /** Whether the type is backed by an option list. */
    hasOptions: boolean;
    /** Whether a unit suffix is meaningful. */
    supportsUnit: boolean;
    /** Whether min/max/step are meaningful. */
    supportsRange: boolean;
    /** Whether the rendered input supports placeholder text. */
    supportsPlaceholder: boolean;
};
export declare const CUSTOM_FIELD_TYPE_META: Record<CustomFieldType, CustomFieldTypeMeta>;
/** The reserved key on a record's `metadata` jsonb that holds custom values. */
export declare const CUSTOM_FIELD_METADATA_NAMESPACE: "custom";
/** Shared server and input bounds for the metadata-backed custom-field layer. */
export declare const CUSTOM_FIELD_LIMITS: {
    readonly label: 200;
    readonly helpText: 2000;
    readonly groupLabel: 200;
    readonly unit: 64;
    readonly placeholder: 500;
    readonly options: 100;
    readonly optionValue: 128;
    readonly optionLabel: 200;
    readonly text: 10000;
    readonly textarea: 100000;
    readonly url: 2048;
    readonly email: 320;
    readonly phone: 100;
};
/**
 * Derive a stable machine key from a human label. Lower-cased, non-alnum runs
 * collapsed to `_`, leading digit prefixed, clamped to 63 chars. Returns
 * `'field'` for an empty/garbage label so callers always get a valid key.
 */
export declare function slugifyCustomFieldKey(label: string): string;
export declare function isValidCustomFieldKey(key: string): boolean;
/** Read the custom-value map off a record's metadata jsonb. */
export declare function readCustomFieldValues(metadata: Record<string, unknown> | null | undefined): Record<string, unknown>;
export type CoerceResult = {
    ok: true;
    value: string | number | boolean | string[] | null;
} | {
    ok: false;
    error: string;
};
/**
 * Validate + coerce a raw string (as it arrives from a form submission) into
 * the typed value stored in `metadata.custom[key]`. `multi_select` raw values
 * are a JSON-encoded string array. An empty raw value clears the field to
 * `null` (unless the field is required, which is an error for value-bearing
 * types — booleans always accept their `false` state).
 */
export declare function coerceCustomFieldValue(def: CustomFieldDefinition, raw: string): CoerceResult;
/**
 * Normalise / sanitise a raw config object for a given type — drop irrelevant
 * keys and de-dupe option values. Used by the designer save action so a stored
 * config never carries fields that don't apply to the chosen type.
 */
export declare function normalizeCustomFieldConfig(type: CustomFieldType, config: CustomFieldConfig | null | undefined): CustomFieldConfig | null;
//# sourceMappingURL=custom-fields.d.ts.map