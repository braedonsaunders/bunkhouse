import type { FormSchemaV1 } from './schema.js';
export type ExtractedParticipant = {
    personId: string;
    signed: boolean;
    fieldId: string;
    sectionId: string;
    role: string | null;
};
/**
 * Build the per-section row arrays for repeating sections from a flat response
 * `data` map. (Repeating sections store their rows under the section id.)
 */
export declare function hoistRows(schema: FormSchemaV1, data: Record<string, unknown>): Record<string, Array<Record<string, unknown>>>;
/**
 * Extract participants from a submitted response. Sources:
 *  - top-level `person_picker` / `multi_person_picker` fields, and
 *  - repeating sections that contain a `person_picker` (the toolbox attendee
 *    shape): one participant per row, `signed` = the row's first signature
 *    field is filled, `role` = the row's first select/radio value.
 * Deduplicated to one row per person (signed = signed anywhere).
 */
export declare function extractParticipants(schema: FormSchemaV1, values: Record<string, unknown>, rows?: Record<string, Array<Record<string, unknown>>>): ExtractedParticipant[];
//# sourceMappingURL=participants.d.ts.map