import type { FormSchemaV1 } from './schema.js';
type FormResponseValues = Record<string, unknown>;
type FormResponseRows = Record<string, Array<Record<string, unknown>>>;
/**
 * Sanitize every rich-text response value described by a form schema.
 *
 * Top-level fields are stored by field id. Repeating-section fields are stored
 * inside the row array under the section id. Unknown keys are removed after a
 * caller validates the raw payload; malformed known values are preserved for
 * field validation. The input is never mutated.
 */
export declare function normalizeFormResponseData(schema: FormSchemaV1, values: FormResponseValues): FormResponseValues;
/** Normalize the filler's split draft shape without mutating either map. */
export declare function normalizeFormResponseDraftData(schema: FormSchemaV1, values: FormResponseValues, rows: FormResponseRows): {
    values: FormResponseValues;
    rows: FormResponseRows;
};
/**
 * Validate a URL before handing it to contentEditable's createLink command.
 * DOMPurify remains the final render/storage boundary; this prevents a
 * dangerous link from existing in the live editor even transiently.
 */
export declare function normalizeRichTextLinkUrl(value: string): string | null;
export {};
//# sourceMappingURL=response-normalize.d.ts.map