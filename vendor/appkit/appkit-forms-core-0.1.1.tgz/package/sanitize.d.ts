export { isApplicationAttachmentUrl, normalizeDocumentHref } from './document-url.js';
export type SanitizeDocumentOptions = {
    /** Permit only server-minted, same-origin attachment capability images. */
    allowApplicationImages?: boolean;
};
/**
 * Sanitize rich-text document HTML for safe storage and rendering.
 * Returns '' for nullish input. Idempotent — safe to run on write and on render.
 */
export declare function sanitizeDocumentHtml(html: string | null | undefined, options?: SanitizeDocumentOptions): string;
//# sourceMappingURL=sanitize.d.ts.map