export type EmailAttachmentPayload = {
    filename: string;
    /** Base64-encoded file contents. */
    content: string;
    contentType?: string;
};
export type EmailDeliveryInput = {
    to: string | string[];
    subject: string;
    html: string;
    text: string;
    attachments?: EmailAttachmentPayload[];
};
export type NormalizedEmailDeliveryInput = Omit<EmailDeliveryInput, 'to'> & {
    to: string[];
};
/**
 * Provider-neutral ceilings applied before a payload enters Redis and again
 * before a provider request is allocated. The 10 MiB decoded attachment cap
 * leaves room for base64 and MIME overhead below common 20–25 MiB provider
 * limits.
 */
export declare const EMAIL_DELIVERY_LIMITS: {
    readonly recipientsPerEnqueue: 1000;
    readonly htmlBytes: number;
    readonly textBytes: number;
    readonly attachments: 10;
    readonly attachmentBytes: number;
    readonly totalAttachmentBytes: number;
    readonly filenameBytes: 255;
    readonly contentTypeBytes: 255;
};
/**
 * Provider-compatible ASCII mailbox validation for envelope/sender addresses.
 * Deliberately excludes quoted local parts and Unicode because not every
 * supported provider accepts them (SendGrid rejects Unicode From addresses).
 */
export declare function isValidEmailAddress(value: string): boolean;
/**
 * Validate and normalize an outbound message without allocating decoded
 * attachments. Recipient de-duplication is case-insensitive, while the first
 * supplied mailbox spelling is retained for delivery.
 */
export declare function normalizeEmailDeliveryInput(input: EmailDeliveryInput, options?: {
    requireSingleRecipient?: boolean;
}): NormalizedEmailDeliveryInput;
//# sourceMappingURL=delivery-input.d.ts.map