export { EMAIL_SUBJECT_LIMITS, normalizeEmailSubject } from './subject.js';
/**
 * Hard resource ceilings for the synchronous render path. These limits are
 * deliberately shared by email templates and the PDF templates that reuse the
 * block renderer: malformed or unexpectedly large persisted input must fail
 * before it can monopolize a web or worker process.
 */
export declare const EMAIL_RENDER_LIMITS: {
    readonly tokens: 20000;
    readonly astNodes: 20000;
    readonly nestingDepth: 32;
    readonly loopIterations: 10000;
    readonly expressionChars: 256;
    readonly hiddenHtmlDepth: 32;
    readonly subjectChars: 998;
    readonly subjectBytes: 998;
    readonly templateChars: 1000000;
    readonly mergeValueChars: 1000000;
    readonly renderOutputChars: 4000000;
    readonly plainTextChars: 2000000;
};
export declare function escapeHtml(s: string): string;
/** Stringify a merge value; if it looks like HTML, reduce it to plain text. */
export declare function plainValue(v: unknown): string;
/**
 * Replace `{{ token }}` occurrences with values[token] (reduced to plain text —
 * see {@link plainValue}). When `escapeHtml` is set, only the SUBSTITUTED VALUE
 * is HTML-escaped (the surrounding template is left intact) — use that when
 * interpolating into trusted HTML. Scalar-only — for collections / conditionals
 * use {@link renderTemplate}.
 */
export declare function interpolate(tpl: string, values: Record<string, unknown>, opts?: {
    escapeHtml?: boolean;
}): string;
/**
 * Render an authored template that may contain {{#each}} / {{#if}} blocks and
 * dotted paths, against `values`. Scalar `{{token}}` output is byte-identical to
 * {@link interpolate}. When `escapeHtml` is set, substituted values are escaped
 * (use {@link `{{{raw}}}`} to opt a field out, e.g. a sanitized rich-text field).
 * Untrusted integration boundaries set `allowRawValues: false`, which treats
 * triple-brace values as ordinary escaped data too.
 */
export declare function renderTemplate(tpl: string, values: Record<string, unknown>, opts?: {
    escapeHtml?: boolean;
    allowRawValues?: boolean;
}): string;
export declare function expandRepeatMarkers(html: string): string;
/** Derive a readable plain-text body from rendered HTML (for the text/* part). */
export declare function htmlToPlainText(html: string): string;
export declare function sanitizeEmailHtml(html: string): string;
/** Sanitize an embeddable body fragment without adding document wrappers. */
export declare function sanitizeEmailFragment(html: string): string;
/**
 * Sanitize a tokenized integration-email fragment and prove that every token
 * is in text content. This prevents a record value from becoming a URL, CSS,
 * event attribute, or other active markup context after save-time sanitizing.
 */
export declare function sanitizeTokenizedEmailFragment(html: string): string;
/** Optional call-to-action button appended to an inline email. */
export type EmailCta = {
    url: string;
    label: string;
};
export type RenderableEmail = {
    mode: 'inline';
    subject: string;
    bodyTemplate: string;
    cta?: EmailCta;
    brandName?: string;
} | {
    mode: 'template' | 'design';
    subjectTemplate: string;
    compiledHtml: string;
};
export type RenderedEmail = {
    subject: string;
    html: string;
    text: string;
};
export declare function renderEmail(spec: RenderableEmail, values: Record<string, unknown>): RenderedEmail;
//# sourceMappingURL=index.d.ts.map