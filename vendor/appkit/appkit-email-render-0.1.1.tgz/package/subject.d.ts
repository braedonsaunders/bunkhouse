export declare const EMAIL_SUBJECT_LIMITS: {
    readonly subjectChars: 998;
    readonly subjectBytes: 998;
};
/** Collapse transport-significant whitespace and enforce the RFC line ceiling. */
export declare function normalizeEmailSubject(value: string): string;
//# sourceMappingURL=subject.d.ts.map