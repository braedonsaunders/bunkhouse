# @appkit/email-render

Framework-neutral email template rendering, sanitization, delivery input normalization, and subject handling.

## Install

```bash
pnpm add @appkit/email-render
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
