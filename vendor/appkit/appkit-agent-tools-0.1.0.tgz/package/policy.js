import { createHash } from 'node:crypto';
import { isSafeAgentTool } from './manifest.js';
export const DEFAULT_AGENT_TOOL_POLICY = {
    install: 'approval',
    execute: 'allow_safe',
    pendingTtlMs: 24 * 60 * 60 * 1000,
    grantTtlMs: 60 * 60 * 1000,
    grantUses: 1,
};
/**
 * A stable digest of exactly what is being requested. Two requests share a
 * scope only when they are the same question, so a grant issued for
 * `rg --json needle` never silently covers `rg --files -0`.
 */
export function agentToolScope(input) {
    const detail = input.approvalScope === 'command'
        ? { command: input.detail.command ?? null }
        : input.detail;
    const canonical = JSON.stringify([input.action, input.toolId, stableValue(detail)]);
    return createHash('sha256').update(canonical).digest('hex').slice(0, 32);
}
function stableValue(value) {
    if (Array.isArray(value))
        return value.map(stableValue);
    if (value && typeof value === 'object') {
        return Object.fromEntries(Object.entries(value)
            .sort(([left], [right]) => left.localeCompare(right))
            .map(([key, entry]) => [key, stableValue(entry)]));
    }
    return value;
}
/** Whether a pending request has sat unanswered past its window. */
export function isPendingApprovalExpired(approval, now) {
    return approval.status === 'pending' && new Date(approval.expiresAt).getTime() <= now.getTime();
}
/**
 * Whether an approved grant is still good. A grant that has run out of time or
 * uses is spent — this is what keeps a single "yes" from authorizing a tool
 * forever.
 */
export function isGrantUsable(approval, now) {
    if (approval.status !== 'approved')
        return false;
    if (approval.grantExpiresAt && new Date(approval.grantExpiresAt).getTime() <= now.getTime()) {
        return false;
    }
    return approval.usesRemaining === undefined || approval.usesRemaining > 0;
}
/** The terminal status a spent grant should be written back as. */
export function spentGrantStatus(approval, now) {
    if (approval.grantExpiresAt && new Date(approval.grantExpiresAt).getTime() <= now.getTime()) {
        return 'expired';
    }
    return 'exhausted';
}
/**
 * Decide an action against policy alone, before any stored grant is consulted.
 * `'ask'` means the runtime should look for a usable grant and file a request
 * if it finds none.
 */
export function evaluateAgentToolPolicy(input) {
    switch (input.mode) {
        case 'deny':
            return {
                outcome: 'deny',
                reason: `Policy does not permit ${input.action} for managed tools.`,
            };
        case 'allow_all':
            return { outcome: 'allow', reason: 'Policy permits this without review.' };
        case 'allow_safe':
            return isSafeAgentTool(input.manifest)
                ? {
                    outcome: 'allow',
                    reason: 'Low-risk, network-isolated tool permitted without review.',
                }
                : {
                    outcome: 'ask',
                    reason: input.manifest.requiresNetwork
                        ? `${input.manifest.name} reaches the network, so it needs review.`
                        : `${input.manifest.name} is ${input.manifest.risk} risk, so it needs review.`,
                };
        case 'approval':
            return { outcome: 'ask', reason: `Policy requires review for every ${input.action}.` };
    }
}
//# sourceMappingURL=policy.js.map