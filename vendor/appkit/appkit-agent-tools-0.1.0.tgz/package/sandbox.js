import { DEFAULT_PROCESS_PATH, isProcessSandboxSupported, spawnBubblewrappedProcess, } from '@appkit/process-sandbox';
import { AgentToolError } from './manifest.js';
export const DEFAULT_MAX_OUTPUT_BYTES = 64 * 1024;
/**
 * The production runner. Output is capped per stream so a chatty tool cannot
 * flood the caller — an agent's context window is the usual destination.
 */
export function createProcessSandboxRunner(options = {}) {
    const maxOutputBytes = options.maxOutputBytes ?? DEFAULT_MAX_OUTPUT_BYTES;
    return async (command) => {
        if (!isProcessSandboxSupported({ bubblewrapPath: options.bubblewrapPath })) {
            throw new AgentToolError('Managed tools require the Linux process sandbox, which is unavailable on this host.');
        }
        const startedAt = Date.now();
        const child = spawnBubblewrappedProcess({
            command: command.command,
            args: command.args,
            cwd: command.cwd,
            writablePaths: command.writablePaths,
            ...(command.readOnlyPaths ? { readOnlyPaths: command.readOnlyPaths } : {}),
            ...(options.readOnlyPaths && !command.readOnlyPaths
                ? { readOnlyPaths: options.readOnlyPaths }
                : {}),
            ...(options.maskedPaths ? { maskedPaths: options.maskedPaths } : {}),
            environment: { PATH: DEFAULT_PROCESS_PATH, ...command.environment },
            network: command.network,
            ...(command.limits ? { limits: command.limits } : {}),
            ...(options.bubblewrapPath ? { bubblewrapPath: options.bubblewrapPath } : {}),
            ...(options.prlimitPath ? { prlimitPath: options.prlimitPath } : {}),
            ...(options.launcherIdentity ? { launcherIdentity: options.launcherIdentity } : {}),
            stdio: ['ignore', 'pipe', 'pipe'],
        });
        let stdout = '';
        let stderr = '';
        let truncated = false;
        const collect = (append, current) => (chunk) => {
            const room = maxOutputBytes - current().length;
            if (room <= 0) {
                truncated = true;
                return;
            }
            const text = chunk.toString('utf8');
            if (text.length > room)
                truncated = true;
            append(text.slice(0, room));
        };
        child.stdout?.on('data', collect((text) => { stdout += text; }, () => stdout));
        child.stderr?.on('data', collect((text) => { stderr += text; }, () => stderr));
        const outcome = await new Promise((resolvePromise) => {
            let settled = false;
            const settle = (value) => {
                if (settled)
                    return;
                settled = true;
                clearTimeout(timer);
                resolvePromise(value);
            };
            const timer = setTimeout(() => {
                child.kill('SIGKILL');
                settle({ status: 'timeout', exitCode: null });
            }, command.timeoutMs);
            child.once('error', (error) => {
                stderr = stderr.length > 0 ? `${stderr}\n${error.message}` : error.message;
                settle({ status: 'failed', exitCode: null });
            });
            child.once('exit', (code) => {
                settle({ status: code === 0 ? 'completed' : 'failed', exitCode: code });
            });
        });
        return {
            ...outcome,
            stdout,
            stderr,
            truncated,
            durationMs: Date.now() - startedAt,
        };
    };
}
//# sourceMappingURL=sandbox.js.map