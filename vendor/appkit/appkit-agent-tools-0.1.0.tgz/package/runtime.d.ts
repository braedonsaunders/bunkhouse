import { type AgentToolManifest } from './manifest.js';
import { type AgentToolPolicy } from './policy.js';
import type { SandboxRunner } from './sandbox.js';
import type { AgentToolApproval, AgentToolRecord, AgentToolRun, AgentToolStore } from './store.js';
/** Roots a `binary-path` manifest may point into unless the host says otherwise. */
export declare const DEFAULT_ALLOWED_BINARY_ROOTS: readonly ["/bin", "/sbin", "/usr/bin", "/usr/sbin", "/usr/local/bin", "/usr/local/sbin", "/opt"];
export declare const DEFAULT_EXECUTION_TIMEOUT_MS = 60000;
export declare const DEFAULT_INSTALL_TIMEOUT_MS = 300000;
export declare const DEFAULT_HEALTH_TIMEOUT_MS = 20000;
export interface AgentToolAuditEntry {
    tenantId: string;
    toolId: string;
    action: 'register' | 'install' | 'health' | 'execute' | 'approval_requested' | 'approval_decided';
    actor: string;
    message: string;
    context: Record<string, unknown>;
    at: string;
}
export interface AgentToolRuntimeOptions {
    store: AgentToolStore;
    /** How commands actually run. Use `createProcessSandboxRunner()` in production. */
    runner: SandboxRunner;
    /**
     * Absolute root for npm installs. Each tool gets
     * `<installRoot>/<tenantId>/<toolId>`, so tenants never share bytes.
     */
    installRoot: string;
    /** Resolves the tenant's policy. Defaults to `DEFAULT_AGENT_TOOL_POLICY`. */
    policy?: (tenantId: string) => Promise<AgentToolPolicy> | AgentToolPolicy;
    allowedBinaryRoots?: readonly string[];
    npmExecutable?: string;
    /** Registry the install runs against. Omitted means npm's own default. */
    npmRegistryUrl?: string;
    now?: () => Date;
    newId?: () => string;
    audit?: (entry: AgentToolAuditEntry) => Promise<void> | void;
}
export interface AgentToolInstallInput {
    tenantId: string;
    toolId: string;
    actor: string;
    reason?: string;
}
export interface AgentToolExecuteInput {
    tenantId: string;
    toolId: string;
    /** A command name the manifest declares. */
    command: string;
    argv?: string[];
    /** Absolute writable directory the command runs in — the only writable place. */
    workdir: string;
    timeoutMs?: number;
    installIfMissing?: boolean;
    healthCheckBeforeRun?: boolean;
    actor: string;
    reason?: string;
}
export type AgentToolLifecycleResult = {
    outcome: 'ok';
    tool: AgentToolRecord;
    summary: string;
} | {
    outcome: 'blocked';
    approval: AgentToolApproval;
    summary: string;
} | {
    outcome: 'denied';
    reason: string;
    summary: string;
} | {
    outcome: 'failed';
    error: string;
    summary: string;
};
export type AgentToolExecutionResult = {
    outcome: 'ran';
    run: AgentToolRun;
    summary: string;
} | {
    outcome: 'blocked';
    approval: AgentToolApproval;
    summary: string;
} | {
    outcome: 'denied';
    reason: string;
    summary: string;
} | {
    outcome: 'unavailable';
    reason: string;
    summary: string;
};
export interface AgentToolRuntime {
    /** Put a manifest on a tenant's shelf, or update the one already there. */
    register(tenantId: string, manifest: AgentToolManifest, actor?: string): Promise<AgentToolRecord>;
    list(tenantId: string): Promise<AgentToolRecord[]>;
    get(tenantId: string, toolId: string): Promise<AgentToolRecord | undefined>;
    install(input: AgentToolInstallInput): Promise<AgentToolLifecycleResult>;
    checkHealth(tenantId: string, toolId: string): Promise<AgentToolLifecycleResult>;
    execute(input: AgentToolExecuteInput): Promise<AgentToolExecutionResult>;
    listApprovals(tenantId: string): Promise<AgentToolApproval[]>;
    approve(input: {
        tenantId: string;
        approvalId: string;
        decidedBy: string;
        reason?: string;
    }): Promise<AgentToolApproval | undefined>;
    deny(input: {
        tenantId: string;
        approvalId: string;
        decidedBy: string;
        reason?: string;
    }): Promise<AgentToolApproval | undefined>;
    /** Sweep unanswered requests and spent grants past their windows. */
    expireStale(tenantId: string): Promise<number>;
    listRuns(tenantId: string, filter?: {
        toolId?: string;
        limit?: number;
    }): Promise<AgentToolRun[]>;
}
export declare function createAgentToolRuntime(options: AgentToolRuntimeOptions): AgentToolRuntime;
//# sourceMappingURL=runtime.d.ts.map