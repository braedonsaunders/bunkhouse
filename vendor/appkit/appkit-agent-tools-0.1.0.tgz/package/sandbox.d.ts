import { type ProcessSandboxLauncherIdentity, type ProcessSandboxLimits, type ProcessSandboxNetwork } from '@appkit/process-sandbox';
/** One isolated command, fully resolved and ready to run. */
export interface SandboxCommand {
    command: string;
    args: string[];
    cwd: string;
    writablePaths: string[];
    readOnlyPaths?: string[];
    environment: Record<string, string>;
    network: ProcessSandboxNetwork;
    limits?: ProcessSandboxLimits;
    timeoutMs: number;
}
export interface SandboxResult {
    status: 'completed' | 'failed' | 'timeout';
    exitCode: number | null;
    stdout: string;
    stderr: string;
    /** Whether either stream hit the cap and was cut. */
    truncated: boolean;
    durationMs: number;
}
/**
 * How the runtime actually runs things. The default implementation goes through
 * `@appkit/process-sandbox`; tests and non-Linux hosts substitute their own,
 * which is the only supported way to run this package's lifecycle without
 * bubblewrap.
 */
export type SandboxRunner = (command: SandboxCommand) => Promise<SandboxResult>;
export interface ProcessSandboxRunnerOptions {
    bubblewrapPath?: string;
    prlimitPath?: string;
    launcherIdentity?: ProcessSandboxLauncherIdentity;
    readOnlyPaths?: readonly string[];
    maskedPaths?: readonly string[];
    /** Bytes retained per stream before output is cut. */
    maxOutputBytes?: number;
}
export declare const DEFAULT_MAX_OUTPUT_BYTES: number;
/**
 * The production runner. Output is capped per stream so a chatty tool cannot
 * flood the caller — an agent's context window is the usual destination.
 */
export declare function createProcessSandboxRunner(options?: ProcessSandboxRunnerOptions): SandboxRunner;
//# sourceMappingURL=sandbox.d.ts.map