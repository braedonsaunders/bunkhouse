import { type AgentToolManifest } from './manifest.js';
import type { AgentToolAction, AgentToolApproval } from './store.js';
/**
 * What happens when an agent asks to install or run a tool.
 *
 * - `deny` — refused outright, no request filed.
 * - `approval` — always asks a human.
 * - `allow_safe` — proceeds for low-risk, network-isolated tools; asks for the rest.
 * - `allow_all` — proceeds.
 */
export type AgentToolPolicyMode = 'deny' | 'approval' | 'allow_safe' | 'allow_all';
export interface AgentToolPolicy {
    /** Governs adding a tool to the host. */
    install: AgentToolPolicyMode;
    /** Governs running one. */
    execute: AgentToolPolicyMode;
    /** How long an unanswered request stays actionable. */
    pendingTtlMs: number;
    /** How long an answered grant remains usable before it must be asked again. */
    grantTtlMs: number;
    /** How many executions one approved grant permits. */
    grantUses: number;
}
export declare const DEFAULT_AGENT_TOOL_POLICY: AgentToolPolicy;
export type AgentToolGateOutcome = 
/** Proceed. `approval` is present when a grant authorized it. */
{
    decision: 'allow';
    approval?: AgentToolApproval;
}
/** Refused by policy or by a human. Asking again changes nothing. */
 | {
    decision: 'deny';
    reason: string;
    approval?: AgentToolApproval;
}
/** A human has been asked. The caller stops and reports the pending request. */
 | {
    decision: 'await_approval';
    approval: AgentToolApproval;
    reason: string;
};
/**
 * A stable digest of exactly what is being requested. Two requests share a
 * scope only when they are the same question, so a grant issued for
 * `rg --json needle` never silently covers `rg --files -0`.
 */
export declare function agentToolScope(input: {
    action: AgentToolAction;
    toolId: string;
    /** Command and argv for an execution; version for an install. */
    detail: Record<string, unknown>;
    approvalScope?: 'exact-argv' | 'command';
}): string;
/** Whether a pending request has sat unanswered past its window. */
export declare function isPendingApprovalExpired(approval: AgentToolApproval, now: Date): boolean;
/**
 * Whether an approved grant is still good. A grant that has run out of time or
 * uses is spent — this is what keeps a single "yes" from authorizing a tool
 * forever.
 */
export declare function isGrantUsable(approval: AgentToolApproval, now: Date): boolean;
/** The terminal status a spent grant should be written back as. */
export declare function spentGrantStatus(approval: AgentToolApproval, now: Date): 'expired' | 'exhausted';
/**
 * Decide an action against policy alone, before any stored grant is consulted.
 * `'ask'` means the runtime should look for a usable grant and file a request
 * if it finds none.
 */
export declare function evaluateAgentToolPolicy(input: {
    mode: AgentToolPolicyMode;
    manifest: AgentToolManifest;
    action: AgentToolAction;
}): {
    outcome: 'allow' | 'deny' | 'ask';
    reason: string;
};
//# sourceMappingURL=policy.d.ts.map