import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { AgentToolStore } from './store.js';
/**
 * Postgres-backed persistence. Pass a tenant-scoped `db` from `@appkit/db` so
 * row-level security is the outer boundary and these predicates are the inner
 * one.
 */
export declare function createDrizzleAgentToolStore<TSchema extends Record<string, unknown>>(db: NodePgDatabase<TSchema>): AgentToolStore;
//# sourceMappingURL=drizzle.d.ts.map