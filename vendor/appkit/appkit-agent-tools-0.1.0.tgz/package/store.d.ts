import type { AgentToolManifest } from './manifest.js';
export type AgentToolStatus = 'not_installed' | 'installing' | 'installed' | 'error';
export type AgentToolHealth = 'unknown' | 'healthy' | 'degraded' | 'unavailable';
export type AgentToolAction = 'install' | 'execute';
/**
 * The lifecycle of a request to do something a policy would not permit
 * unilaterally.
 *
 * `approved` is not terminal: a grant carries its own expiry and use count, so
 * an answer given once does not authorize the same action forever.
 */
export type AgentToolApprovalStatus = 'pending' | 'approved' | 'denied' | 'expired' | 'exhausted';
export type AgentToolRunStatus = 'completed' | 'failed' | 'timeout' | 'blocked';
/** A tool as this tenant has it: what it is, and what state it is actually in. */
export interface AgentToolRecord {
    id: string;
    tenantId: string;
    /** The manifest id. Unique per tenant. */
    toolId: string;
    manifest: AgentToolManifest;
    enabled: boolean;
    status: AgentToolStatus;
    health: AgentToolHealth;
    /** Where an npm tool was installed. Absent for image binaries. */
    installDir?: string;
    /** Resolved absolute executable per declared command name. */
    binPaths: Record<string, string>;
    installedVersion?: string;
    lastError?: string;
    lastInstalledAt?: string;
    lastCheckedAt?: string;
    lastRunAt?: string;
    createdAt: string;
    updatedAt: string;
}
export interface AgentToolApproval {
    id: string;
    tenantId: string;
    toolId: string;
    action: AgentToolAction;
    status: AgentToolApprovalStatus;
    /**
     * A stable digest of exactly what was asked for. A grant only ever covers the
     * scope it was issued against, so a different command or argument vector is a
     * different question.
     */
    scope: string;
    request: Record<string, unknown>;
    reason: string;
    requestedBy: string;
    requestedAt: string;
    /** When the unanswered request goes stale. */
    expiresAt: string;
    decidedBy?: string;
    decidedAt?: string;
    decisionReason?: string;
    /** When an approved grant stops being usable. */
    grantExpiresAt?: string;
    /** Executions still permitted under an approved grant. */
    usesRemaining?: number;
}
/** One entry in the append-only record of what a tool actually did. */
export interface AgentToolRun {
    id: string;
    tenantId: string;
    toolId: string;
    command: string;
    argv: string[];
    status: AgentToolRunStatus;
    exitCode: number | null;
    stdout: string;
    stderr: string;
    /** Whether output hit the cap and was cut. */
    truncated: boolean;
    durationMs: number;
    actor: string;
    approvalId?: string;
    startedAt: string;
}
export interface AgentToolApprovalFilter {
    toolId?: string;
    action?: AgentToolAction;
    status?: AgentToolApprovalStatus;
}
export interface AgentToolRunFilter {
    toolId?: string;
    limit?: number;
}
/**
 * Persistence for the runtime. Every method is tenant-scoped; the runtime never
 * reaches past this interface, so an application can back it with the in-memory
 * adapter, the Drizzle adapter, or its own.
 */
export interface AgentToolStore {
    listTools(tenantId: string): Promise<AgentToolRecord[]>;
    getTool(tenantId: string, toolId: string): Promise<AgentToolRecord | undefined>;
    upsertTool(record: AgentToolRecord): Promise<AgentToolRecord>;
    listApprovals(tenantId: string, filter?: AgentToolApprovalFilter): Promise<AgentToolApproval[]>;
    getApproval(tenantId: string, id: string): Promise<AgentToolApproval | undefined>;
    upsertApproval(approval: AgentToolApproval): Promise<AgentToolApproval>;
    /**
     * Spend one use of an approved grant and return the updated row, or
     * `undefined` when there was nothing left to spend.
     *
     * This is a distinct method rather than a read-modify-write by the runtime so
     * that a database adapter can make it a single conditional statement. Two
     * concurrent runs must not both consume the last use of a grant.
     */
    consumeGrant(tenantId: string, id: string): Promise<AgentToolApproval | undefined>;
    recordRun(run: AgentToolRun): Promise<AgentToolRun>;
    listRuns(tenantId: string, filter?: AgentToolRunFilter): Promise<AgentToolRun[]>;
}
/**
 * A process-local store. Real deployments use the Drizzle adapter; this one
 * keeps tests, the playground, and single-process tooling free of a database.
 */
export declare function createMemoryAgentToolStore(): AgentToolStore;
//# sourceMappingURL=store.d.ts.map