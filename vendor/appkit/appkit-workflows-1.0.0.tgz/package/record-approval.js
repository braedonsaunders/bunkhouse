export class RecordApprovalRequestError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.name = 'RecordApprovalRequestError';
        this.status = status;
    }
}
/**
 * Source-compatible HTTP adapter. Its defaults preserve the production route
 * and request body contract while allowing hosts to relocate both endpoints.
 */
export function createHttpRecordApprovalAdapter({ stateEndpoint = '/api/flows/record-state', decisionEndpoint = '/api/flows/gates/decide', fetcher = globalThis.fetch, } = {}) {
    return {
        async load({ subjectKind, subjectId }, signal) {
            const query = new URLSearchParams({ subjectKind, subjectId });
            const response = await fetcher(`${stateEndpoint}?${query}`, { signal });
            if (response.status === 404)
                return null;
            const data = await readJson(response);
            if (!response.ok) {
                throw new RecordApprovalRequestError(readError(data, 'Unable to load approval state.'), response.status);
            }
            return data;
        },
        async decide({ gateId, decision, comment }) {
            const response = await fetcher(decisionEndpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ gateId, decision, comment }),
            });
            const data = await readJson(response);
            if (response.status === 409)
                return { outcome: 'already-decided' };
            if (!response.ok) {
                throw new RecordApprovalRequestError(readError(data, 'Unable to record approval decision.'), response.status);
            }
            if (isRecord(data) && data.resumed === null)
                return { outcome: 'waiting' };
            return { outcome: decision };
        },
    };
}
/** Browser-local implementation with the same state transitions as the HTTP seam. */
export function createMemoryRecordApprovalAdapter({ seed = [], actor = 'Current user', now = () => new Date(), createId = () => crypto.randomUUID(), } = {}) {
    const states = new Map();
    function reset(next) {
        states.clear();
        for (const item of next) {
            states.set(subjectKey(item), { state: cloneState(item.state), quorum: item.quorum ?? 'all' });
        }
    }
    reset(seed);
    return {
        reset,
        inspect(subject) {
            const entry = states.get(subjectKey(subject));
            return entry ? cloneState(entry.state) : null;
        },
        async load(subject) {
            const entry = states.get(subjectKey(subject));
            return entry ? cloneState(entry.state) : null;
        },
        async decide(input) {
            const entry = states.get(subjectKey(input));
            const state = entry?.state;
            const actionGateId = state?.approvalState.myActions?.gateId;
            const pending = state?.approvalState.pendingWith.find((entry) => entry.gateId === input.gateId);
            if (!state || !pending || actionGateId !== input.gateId)
                return { outcome: 'already-decided' };
            state.approvalState.pendingWith = state.approvalState.pendingWith.filter((entry) => entry.gateId !== input.gateId);
            state.approvalState.myActions = null;
            state.history.push({
                id: createId(),
                type: input.decision,
                actor,
                comment: input.comment ?? null,
                at: now().toISOString(),
                title: state.history.findLast((entry) => entry.type === 'requested' && entry.actor === pending.name)?.title,
            });
            if (input.decision === 'approved' &&
                entry.quorum === 'all' &&
                state.approvalState.pendingWith.length > 0)
                return { outcome: 'waiting' };
            state.approvalState.pendingWith = [];
            state.approvalState.status = input.decision;
            return { outcome: input.decision };
        },
    };
}
function subjectKey(subject) {
    return `${subject.subjectKind}\u0000${subject.subjectId}`;
}
function cloneState(state) {
    return structuredClone(state);
}
async function readJson(response) {
    try {
        return await response.json();
    }
    catch {
        return undefined;
    }
}
function readError(data, fallback) {
    return isRecord(data) && typeof data.error === 'string' ? data.error : fallback;
}
function isRecord(value) {
    return typeof value === 'object' && value !== null;
}
//# sourceMappingURL=record-approval.js.map