import * as React from 'react';
import type { AutomationGraph } from '@appkit/forms-core/safety-automation';
import type { FlowSubjectProfile } from '@appkit/forms-core/safety-flow-subjects';
export type FlowSubjectRef = {
    type: FlowSubjectProfile['subjectType'];
    key: string;
};
export type WorkflowStudioAdapter = {
    create: (subject: FlowSubjectRef, name: string) => Promise<{
        ok: boolean;
        id?: string;
        error?: string;
    }>;
    remove: (id: string) => Promise<{
        ok: boolean;
        error?: string;
    }>;
    rename: (id: string, name: string) => Promise<{
        ok: boolean;
        error?: string;
    }>;
    save: (id: string, graph: AutomationGraph) => Promise<{
        ok: boolean;
        error?: string;
    }>;
    setEnabled: (id: string, enabled: boolean) => Promise<{
        ok: boolean;
        error?: string;
    }>;
    generate?: (id: string, prompt: string) => Promise<{
        ok: boolean;
        graph?: AutomationGraph;
        error?: string;
    }>;
};
export type WorkflowEmailDesignEditor = unknown;
export type WorkflowEmailDesignAdapter = {
    Editor: React.ComponentType<{
        initialHtml: string | null;
        mergeFields: Array<{
            key: string;
        }>;
        onReady: (editor: WorkflowEmailDesignEditor) => void;
    }>;
    compile: (editor: WorkflowEmailDesignEditor) => Promise<{
        ok: boolean;
        html?: string;
        sourceHtml?: string;
        error?: string;
    }>;
};
type EmailTemplateOption = {
    id: string;
    name: string;
};
type PdfTemplateOption = {
    id: string;
    name: string;
};
type TargetAppOption = {
    id: string;
    name: string;
};
export type RecipientOptions = {
    people: {
        id: string;
        name: string;
    }[];
    roles: {
        key: string;
        name: string;
    }[];
    departments: {
        id: string;
        name: string;
    }[];
    personGroups: {
        id: string;
        name: string;
    }[];
    contacts: {
        id: string;
        name: string;
        orgUnitName: string;
    }[];
    obligations: {
        id: string;
        name: string;
    }[];
    spreadsheetTemplates: {
        id: string;
        name: string;
    }[];
};
export type FlowSummary = {
    id: string;
    name: string;
    enabled: boolean;
    graph: AutomationGraph;
};
export type WorkflowTemplate = {
    key: string;
    label: string;
    description: string;
    build: () => AutomationGraph;
};
export declare function FlowsCanvas({ profile, emailTemplates, pdfTemplates, targetApps, recipientOptions, flows, canEdit, adapter, templates, emailDesign, embedded, backLink, }: {
    profile: FlowSubjectProfile;
    emailTemplates: EmailTemplateOption[];
    pdfTemplates?: PdfTemplateOption[];
    targetApps?: TargetAppOption[];
    recipientOptions?: RecipientOptions;
    flows: FlowSummary[];
    canEdit: boolean;
    adapter: WorkflowStudioAdapter;
    templates?: readonly WorkflowTemplate[];
    emailDesign?: WorkflowEmailDesignAdapter;
    embedded?: boolean;
    backLink?: React.ReactNode;
}): React.JSX.Element;
export {};
//# sourceMappingURL=workflow-studio.d.ts.map