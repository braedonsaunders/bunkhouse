'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { GeneratedText, useGeneratedTranslations, GeneratedValue, useGeneratedValueTranslations, } from './workflow-messages.js';
// Visual automation authoring canvas.
// Node graph: Trigger → Condition / Gate / Action. Conditions branch then/else;
// Gates (human approve/reject) branch approve/reject. Persistence and execution
// are supplied by the host adapter. Nodes are real React components, so the
// condition inspector reuses the shared LogicBuilder.
import * as React from 'react';
import { useCallback, useEffect, useMemo, useRef, useState, useTransition } from 'react';
import { addEdge, Background, Controls, Handle, MiniMap, Position, ReactFlow, useEdgesState, useNodesState, } from '@xyflow/react';
import { GitBranch, Mail, Pencil, Plus, Rocket, Save, ShieldCheck, Sparkles, Trash2, TriangleAlert, Workflow, X, Zap, } from 'lucide-react';
import { Button, Drawer, Input, Label, Select, SearchSelect, Textarea, toast } from '@appkit/ui';
import { emptyAutomationGraph, lintAutomationGraph, } from '@appkit/forms-core/safety-automation';
import { LogicBuilder } from '@appkit/forms';
const MAX_FLOW_NAME_LENGTH = 120;
const EMPTY_RECIPIENT_OPTIONS = {
    people: [],
    roles: [],
    departments: [],
    personGroups: [],
    contacts: [],
    obligations: [],
    spreadsheetTemplates: [],
};
const RECIPIENT_LABEL = {
    submitter: 'The submitter',
    submitter_manager: "The submitter's manager",
    record_person_manager: "The record person's manager",
    person: 'A specific person',
    role: 'Everyone in a role',
    department_manager: "A department's managers",
    person_group: 'A People group',
    literal: 'Specific email address(es)',
    field: 'A record field',
    person_group_for_record_person: "A People group in the record person's department",
    org_unit_contact: 'A contact for the record location',
    compliance_recipient: 'A recipient for a matching compliance assignment',
};
function defaultTarget(type, firstField) {
    switch (type) {
        case 'role':
            return { type: 'role', role: '' };
        case 'literal':
            return { type: 'literal', email: '' };
        case 'person':
            return { type: 'person', personId: '' };
        case 'department_manager':
            return { type: 'department_manager', departmentId: '' };
        case 'person_group':
            return { type: 'person_group', groupId: '' };
        case 'field':
            return { type: 'field', field: firstField };
        case 'person_group_for_record_person':
            return { type: 'person_group_for_record_person', groupId: '', personField: firstField };
        case 'record_person_manager':
            return { type: 'record_person_manager', personField: firstField };
        case 'org_unit_contact':
            return { type: 'org_unit_contact', contactId: '', orgUnitField: firstField };
        case 'compliance_recipient':
            return {
                type: 'compliance_recipient',
                obligationId: '',
                personField: firstField,
                recipient: { type: 'person', personId: '' },
            };
        case 'submitter_manager':
            return { type: 'submitter_manager' };
        default:
            return { type: 'submitter' };
    }
}
// Multi-recipient editor: any mix of submitter / person / manager / role /
// department managers / CSV emails / record field. Add + remove rows freely.
function RecipientsEditor({ to, onChange, readOnly, fieldIds, options, }) {
    const tGenerated = useGeneratedTranslations();
    const tGeneratedValue = useGeneratedValueTranslations();
    const rows = to.length > 0 ? to : [{ type: 'submitter' }];
    const update = (i, t) => onChange(rows.map((x, j) => (j === i ? t : x)));
    const peopleOpts = options.people.map((p) => ({ value: p.id, label: p.name }));
    const deptOpts = options.departments.map((d) => ({ value: d.id, label: d.name }));
    const personGroupOpts = options.personGroups.map((g) => ({ value: g.id, label: g.name }));
    const contactOpts = options.contacts.map((contact) => ({
        value: contact.id,
        label: contact.name,
        hint: contact.orgUnitName,
    }));
    const obligationOpts = options.obligations.map((obligation) => ({
        value: obligation.id,
        label: obligation.name,
    }));
    return (_jsx(Field, { label: tGenerated('m_0d99b2b56f8b5d'), children: _jsxs("div", { className: "space-y-2", children: [_jsx(GeneratedValue, { value: rows.map((t, i) => (_jsxs("div", { className: "space-y-1.5 rounded-md border border-border p-2", children: [_jsxs("div", { className: "flex items-center gap-1.5", children: [_jsx(Select, { value: t.type, disabled: readOnly, onChange: (e) => update(i, defaultTarget(e.target.value, fieldIds[0] ?? '')), children: Object.keys(RECIPIENT_LABEL).map((k) => (_jsx("option", { value: k, children: RECIPIENT_LABEL[k] }, k))) }), _jsx(GeneratedValue, { value: !readOnly && rows.length > 1 ? (_jsx("button", { type: "button", title: tGenerated('m_0d9b2e08c28452'), onClick: () => onChange(rows.filter((_, j) => j !== i)), className: "shrink-0 rounded p-1 text-fg-subtle hover:bg-danger-subtle hover:text-danger ", children: _jsx(X, { size: 14 }) })) : null })] }), _jsx(GeneratedValue, { value: t.type === 'person' ? (_jsx(SearchSelect, { value: t.personId, disabled: readOnly, options: peopleOpts, placeholder: tGenerated('m_0a302f85a5260b'), onChange: (v) => update(i, { type: 'person', personId: v }) })) : null }), _jsx(GeneratedValue, { value: t.type === 'record_person_manager' ? (_jsx(Select, { value: t.personField, disabled: readOnly, onChange: (event) => update(i, {
                                        type: 'record_person_manager',
                                        personField: event.target.value,
                                    }), children: fieldIds.map((field) => (_jsx("option", { value: field, children: field }, field))) })) : null }), _jsx(GeneratedValue, { value: t.type === 'person_group_for_record_person' ? (_jsxs("div", { className: "grid gap-2 sm:grid-cols-2", children: [_jsx(SearchSelect, { value: t.groupId, disabled: readOnly, options: personGroupOpts, placeholder: tGenerated('m_0ecfd22a8fb573'), onChange: (groupId) => update(i, { ...t, groupId }) }), _jsx(Select, { value: t.personField, disabled: readOnly, onChange: (event) => update(i, { ...t, personField: event.target.value }), children: fieldIds.map((field) => (_jsx("option", { value: field, children: field }, field))) })] })) : null }), _jsx(GeneratedValue, { value: t.type === 'org_unit_contact' ? (_jsxs("div", { className: "grid gap-2 sm:grid-cols-2", children: [_jsx(SearchSelect, { value: t.contactId, disabled: readOnly, options: contactOpts, placeholder: tGenerated('m_15593bf256f963'), onChange: (contactId) => update(i, { ...t, contactId }) }), _jsx(Select, { value: t.orgUnitField, disabled: readOnly, onChange: (event) => update(i, { ...t, orgUnitField: event.target.value }), children: fieldIds.map((field) => (_jsx("option", { value: field, children: field }, field))) })] })) : null }), _jsx(GeneratedValue, { value: t.type === 'compliance_recipient' ? (_jsxs("div", { className: "space-y-2", children: [_jsxs("div", { className: "grid gap-2 sm:grid-cols-2", children: [_jsx(SearchSelect, { value: t.obligationId, disabled: readOnly, options: obligationOpts, placeholder: tGenerated('m_1f1c58a54a4d66'), onChange: (obligationId) => update(i, { ...t, obligationId }) }), _jsx(Select, { value: t.personField, disabled: readOnly, onChange: (event) => update(i, { ...t, personField: event.target.value }), children: fieldIds.map((field) => (_jsx("option", { value: field, children: field }, field))) })] }), _jsxs("div", { className: "grid gap-2 sm:grid-cols-2", children: [_jsxs(Select, { value: t.recipient.type, disabled: readOnly, onChange: (event) => update(i, {
                                                        ...t,
                                                        recipient: event.target.value === 'literal'
                                                            ? { type: 'literal', email: '' }
                                                            : { type: 'person', personId: '' },
                                                    }), children: [_jsx("option", { value: "person", children: _jsx(GeneratedValue, { value: "A specific person" }) }), _jsx("option", { value: "literal", children: _jsx(GeneratedValue, { value: "Specific email address(es)" }) })] }), t.recipient.type === 'person' ? (_jsx(SearchSelect, { value: t.recipient.personId, disabled: readOnly, options: peopleOpts, placeholder: tGenerated('m_0e6e22a9a495b0'), onChange: (personId) => update(i, { ...t, recipient: { type: 'person', personId } }) })) : (_jsx(Input, { value: t.recipient.email, disabled: readOnly, placeholder: tGeneratedValue('name@example.com'), onChange: (event) => update(i, {
                                                        ...t,
                                                        recipient: { type: 'literal', email: event.target.value },
                                                    }) }))] })] })) : null }), _jsx(GeneratedValue, { value: t.type === 'department_manager' ? (_jsx(SearchSelect, { value: t.departmentId, disabled: readOnly, options: deptOpts, placeholder: tGenerated('m_1a73ab43e2b5d2'), onChange: (v) => update(i, { type: 'department_manager', departmentId: v }) })) : null }), _jsx(GeneratedValue, { value: t.type === 'person_group' ? (_jsx(SearchSelect, { value: t.groupId, disabled: readOnly, options: personGroupOpts, placeholder: tGenerated('m_0b6591278bf814'), onChange: (v) => update(i, { type: 'person_group', groupId: v }) })) : null }), _jsx(GeneratedValue, { value: t.type === 'role' ? (options.roles.length > 0 ? (_jsxs(Select, { value: t.role, disabled: readOnly, onChange: (e) => update(i, { type: 'role', role: e.target.value }), children: [_jsx("option", { value: "", children: '— choose a role —' }), options.roles.map((r) => (_jsx("option", { value: r.key, children: r.name }, r.key)))] })) : (_jsx(Input, { value: t.role, disabled: readOnly, placeholder: tGenerated('m_1f114a74597cfb'), onChange: (e) => update(i, { type: 'role', role: e.target.value }) }))) : null }), _jsx(GeneratedValue, { value: t.type === 'literal' ? (_jsx(Input, { value: t.email, disabled: readOnly, placeholder: tGenerated('m_05b63ccf241fff'), onChange: (e) => update(i, { type: 'literal', email: e.target.value }) })) : null }), _jsx(GeneratedValue, { value: t.type === 'field' ? (_jsx(Select, { value: t.field, disabled: readOnly, onChange: (e) => update(i, { type: 'field', field: e.target.value }), children: fieldIds.map((f) => (_jsx("option", { value: f, children: f }, f))) })) : null })] }, i))) }), _jsx(GeneratedValue, { value: !readOnly ? (_jsxs(Button, { variant: "outline", size: "sm", onClick: () => onChange([...rows, { type: 'submitter' }]), children: [_jsx(Plus, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_09417c94b44711" })] })) : null })] }) }));
}
const newId = (prefix) => `${prefix}_${globalThis.crypto.randomUUID()}`;
function toFlow(graph) {
    return {
        nodes: graph.nodes.map((n) => ({
            id: n.id,
            type: n.data.kind,
            position: n.position,
            data: n.data,
        })),
        edges: graph.edges.map((e) => ({
            id: e.id,
            source: e.source,
            target: e.target,
            sourceHandle: e.sourceHandle ?? null,
            label: e.sourceHandle && e.sourceHandle !== 'next' ? e.sourceHandle : undefined,
        })),
    };
}
function fromFlow(nodes, edges) {
    return {
        schemaVersion: 1,
        nodes: nodes.map((n) => ({
            id: n.id,
            position: { x: Math.round(n.position.x), y: Math.round(n.position.y) },
            data: n.data,
        })),
        edges: edges.map((e) => ({
            id: e.id,
            source: e.source,
            target: e.target,
            sourceHandle: e.sourceHandle ?? 'next',
        })),
    };
}
// --- Node summaries + components -------------------------------------------
function triggerSummary(t) {
    switch (t.trigger) {
        case 'on_submit':
            return 'On submit';
        case 'on_field_value':
            return 'When a field matches…';
        case 'status_change':
            return `Status → ${t.to}`;
        case 'scheduled':
            return `Scheduled (${t.cron})`;
        case 'session_overdue':
            return 'Session check-in overdue';
        case 'on_create':
            return 'On create';
        case 'on_sign':
            return 'On sign';
        case 'on_lock':
            return 'On lock / close';
        case 'on_unlock':
            return 'On unlock / reopen';
        case 'on_delete':
            return 'On delete';
        case 'manual':
            return `Button: ${t.label || 'Run flow'}`;
    }
}
const ACTION_LABEL = {
    send_email: 'Send email',
    create_capa: 'Create CAPA',
    create_incident: 'Create incident',
    notify_role: 'Notify role',
    set_field: 'Set field',
    flag_non_compliant: 'Flag non-compliant',
    webhook: 'Webhook',
    create_response: 'Start another form',
    analyze_photos: 'Analyze photos (AI)',
    start_monitored_session: 'Start monitored session',
    change_status: 'Change status',
    duplicate_record: 'Duplicate record',
    export_pdf: 'Export PDF',
};
const TRIGGER_LABEL = {
    on_submit: 'A record is submitted',
    on_field_value: 'A field matches a condition',
    status_change: 'Status changes',
    scheduled: 'On a schedule',
    session_overdue: 'A monitored session goes overdue',
    on_create: 'A record is created',
    on_sign: 'A record is signed',
    on_lock: 'A record is locked / closed',
    on_unlock: 'A record is unlocked / reopened',
    on_delete: 'A record is deleted',
    manual: 'A user clicks a button',
};
// Build a fresh TriggerData from a trigger kind (used by the picker + defaults).
function buildTrigger(v, firstField, firstStatus) {
    if (v === 'on_field_value')
        return { trigger: 'on_field_value', rule: { op: 'isSet', field: firstField } };
    if (v === 'status_change')
        return { trigger: 'status_change', to: firstStatus };
    if (v === 'scheduled')
        return { trigger: 'scheduled', cron: '0 8 * * 1' };
    if (v === 'manual')
        return {
            trigger: 'manual',
            buttonId: newId('btn'),
            label: 'Run flow',
        };
    return { trigger: v };
}
const CARD = 'rounded-lg border bg-surface px-3 py-2 text-xs shadow-sm w-48';
const HANDLE = { width: 9, height: 9 };
function TriggerNode({ data, selected }) {
    const d = data;
    return (_jsxs("div", { className: `${CARD} ${selected ? 'border-primary ring-1 ring-primary' : 'border-success'}`, children: [_jsxs("div", { className: "flex items-center gap-1.5 font-semibold text-success", children: [_jsx(Zap, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_1db1e5c9ca41ce" })] }), _jsx("div", { className: "mt-0.5 truncate text-fg-muted", children: _jsx(GeneratedValue, { value: triggerSummary(d.trigger) }) }), _jsx(Handle, { type: "source", position: Position.Right, id: "next", style: HANDLE })] }));
}
function ConditionNode({ data, selected }) {
    const d = data;
    return (_jsxs("div", { className: `${CARD} ${selected ? 'border-primary ring-1 ring-primary' : 'border-warning'}`, children: [_jsx(Handle, { type: "target", position: Position.Left, style: HANDLE }), _jsxs("div", { className: "flex items-center gap-1.5 font-semibold text-warning", children: [_jsx(GitBranch, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_0c33471afd0f99" })] }), _jsx("div", { className: "mt-0.5 truncate text-fg-muted", children: _jsx(GeneratedValue, { value: d.label || _jsx(GeneratedText, { id: "m_006e893d66b28d" }) }) }), _jsx(Handle, { type: "source", position: Position.Right, id: "then", style: { ...HANDLE, top: '38%' } }), _jsx(Handle, { type: "source", position: Position.Right, id: "else", style: { ...HANDLE, top: '70%' } })] }));
}
function GateNode({ data, selected }) {
    const d = data;
    return (_jsxs("div", { className: `${CARD} ${selected ? 'border-primary ring-1 ring-primary' : 'border-primary'}`, children: [_jsx(Handle, { type: "target", position: Position.Left, style: HANDLE }), _jsxs("div", { className: "flex items-center gap-1.5 font-semibold text-primary", children: [_jsx(ShieldCheck, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_0f7bb45f90ba7e" })] }), _jsx("div", { className: "mt-0.5 truncate text-fg-muted", children: _jsx(GeneratedValue, { value: d.gate.title || _jsx(GeneratedText, { id: "m_0abb67c4c65a36" }) }) }), _jsx(Handle, { type: "source", position: Position.Right, id: "approve", style: { ...HANDLE, top: '38%' } }), _jsx(Handle, { type: "source", position: Position.Right, id: "reject", style: { ...HANDLE, top: '70%' } })] }));
}
function ActionNode({ data, selected }) {
    const d = data;
    return (_jsxs("div", { className: `${CARD} ${selected ? 'border-primary ring-1 ring-primary' : 'border-info'}`, children: [_jsx(Handle, { type: "target", position: Position.Left, style: HANDLE }), _jsxs("div", { className: "flex items-center gap-1.5 font-semibold text-info", children: [_jsx(Mail, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_0bad495a7046e9" })] }), _jsx("div", { className: "mt-0.5 truncate text-fg-muted", children: _jsx(GeneratedValue, { value: ACTION_LABEL[d.action.action] }) }), _jsx(Handle, { type: "source", position: Position.Right, id: "next", style: HANDLE })] }));
}
// --- Default node data ------------------------------------------------------
function defaultData(kind, firstField, profile, actionFields) {
    switch (kind) {
        case 'trigger':
            return {
                kind: 'trigger',
                trigger: buildTrigger(profile.triggers[0] ?? 'on_submit', firstField, profile.statusValues?.[0] ?? 'submitted'),
            };
        case 'condition':
            return { kind: 'condition', rule: { op: 'isSet', field: firstField }, label: 'If…' };
        case 'gate':
            return {
                kind: 'gate',
                gate: { title: 'Supervisor approval', assignee: { type: 'submitter' } },
            };
        case 'action':
            return {
                kind: 'action',
                action: defaultAction(profile.actions[0] ?? 'send_email', actionFields),
            };
    }
}
// ---------------------------------------------------------------------------
function MiniToggle({ checked, disabled, onChange, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const tGenerated = useGeneratedTranslations();
    return (_jsx("button", { type: "button", role: "switch", "aria-checked": checked, disabled: disabled, title: tGeneratedValue(checked ? tGenerated('m_0c0c6c7a4b5bf5') : tGenerated('m_11bf1bf8c148ff')), onClick: (e) => {
            e.stopPropagation();
            onChange(!checked);
        }, className: `relative inline-flex h-4 w-7 shrink-0 items-center rounded-full transition ${checked ? 'bg-primary' : 'bg-border-strong'} ${disabled ? 'opacity-50' : ''}`, children: _jsx("span", { className: `inline-block h-3 w-3 transform rounded-full bg-surface shadow transition ${checked ? 'translate-x-3.5' : 'translate-x-0.5'}` }) }));
}
const DEFAULT_WORKFLOW_TEMPLATES = [
    {
        key: 'email_submitter',
        label: 'Email the submitter',
        description: 'On submit, send a confirmation email to whoever filled it out.',
        build: () => ({
            schemaVersion: 1,
            nodes: [
                {
                    id: 'trg',
                    position: { x: 60, y: 140 },
                    data: { kind: 'trigger', trigger: { trigger: 'on_submit' } },
                },
                {
                    id: 'act',
                    position: { x: 380, y: 140 },
                    data: {
                        kind: 'action',
                        action: {
                            action: 'send_email',
                            to: [{ type: 'submitter' }],
                            subject: 'Submission received',
                            bodyTemplate: 'Thanks — your submission has been received.',
                        },
                    },
                },
            ],
            edges: [{ id: 'e1', source: 'trg', target: 'act', sourceHandle: 'next' }],
        }),
    },
    {
        key: 'notify_role',
        label: 'Notify a team',
        description: 'On submit, send an in-app notification to a role you choose.',
        build: () => ({
            schemaVersion: 1,
            nodes: [
                {
                    id: 'trg',
                    position: { x: 60, y: 140 },
                    data: { kind: 'trigger', trigger: { trigger: 'on_submit' } },
                },
                {
                    id: 'act',
                    position: { x: 380, y: 140 },
                    data: {
                        kind: 'action',
                        action: { action: 'notify_role', role: '', message: 'A new submission needs review.' },
                    },
                },
            ],
            edges: [{ id: 'e1', source: 'trg', target: 'act', sourceHandle: 'next' }],
        }),
    },
    {
        key: 'capa_noncompliant',
        label: 'CAPA when non-compliant',
        description: 'If the compliance score is below 80, open a corrective action.',
        build: () => ({
            schemaVersion: 1,
            nodes: [
                {
                    id: 'trg',
                    position: { x: 40, y: 160 },
                    data: { kind: 'trigger', trigger: { trigger: 'on_submit' } },
                },
                {
                    id: 'cnd',
                    position: { x: 320, y: 160 },
                    data: {
                        kind: 'condition',
                        rule: { op: 'lt', field: 'compliance_score', value: 80 },
                        label: 'Score below 80',
                    },
                },
                {
                    id: 'act',
                    position: { x: 620, y: 100 },
                    data: {
                        kind: 'action',
                        action: {
                            action: 'create_capa',
                            titleTemplate: 'Follow-up corrective action',
                            severity: 'high',
                        },
                    },
                },
            ],
            edges: [
                { id: 'e1', source: 'trg', target: 'cnd', sourceHandle: 'next' },
                { id: 'e2', source: 'cnd', target: 'act', sourceHandle: 'then' },
            ],
        }),
    },
    {
        key: 'approval',
        label: 'Require approval',
        description: 'On submit, pause for a supervisor to approve or reject.',
        build: () => ({
            schemaVersion: 1,
            nodes: [
                {
                    id: 'trg',
                    position: { x: 60, y: 140 },
                    data: { kind: 'trigger', trigger: { trigger: 'on_submit' } },
                },
                {
                    id: 'gat',
                    position: { x: 380, y: 140 },
                    data: {
                        kind: 'gate',
                        gate: { title: 'Supervisor approval', assignee: { type: 'role', role: '' } },
                    },
                },
            ],
            edges: [{ id: 'e1', source: 'trg', target: 'gat', sourceHandle: 'next' }],
        }),
    },
    {
        key: 'webhook',
        label: 'Send to a webhook',
        description: 'On submit, POST the response to an external URL (Zapier, Make, your API).',
        build: () => ({
            schemaVersion: 1,
            nodes: [
                {
                    id: 'trg',
                    position: { x: 60, y: 140 },
                    data: { kind: 'trigger', trigger: { trigger: 'on_submit' } },
                },
                {
                    id: 'act',
                    position: { x: 380, y: 140 },
                    data: { kind: 'action', action: { action: 'webhook', url: '', method: 'POST' } },
                },
            ],
            edges: [{ id: 'e1', source: 'trg', target: 'act', sourceHandle: 'next' }],
        }),
    },
    {
        key: 'monitored_session',
        label: 'Monitored session (lone worker)',
        description: 'On submit, start a recurring check-in timer; if a check-in is missed past the grace period, notify a role.',
        build: () => ({
            schemaVersion: 1,
            nodes: [
                {
                    id: 'trg',
                    position: { x: 60, y: 80 },
                    data: { kind: 'trigger', trigger: { trigger: 'on_submit' } },
                },
                {
                    id: 'mon',
                    position: { x: 380, y: 80 },
                    data: {
                        kind: 'action',
                        action: {
                            action: 'start_monitored_session',
                            intervalMinutes: 30,
                            graceMinutes: 10,
                            durationMinutes: 120,
                            requireGeo: true,
                        },
                    },
                },
                {
                    id: 'ovd',
                    position: { x: 60, y: 260 },
                    data: { kind: 'trigger', trigger: { trigger: 'session_overdue' } },
                },
                {
                    id: 'esc',
                    position: { x: 380, y: 260 },
                    data: {
                        kind: 'action',
                        action: {
                            action: 'notify_role',
                            role: '',
                            message: 'A monitored session check-in is overdue — follow up now.',
                            channel: 'in_app',
                        },
                    },
                },
            ],
            edges: [
                { id: 'e1', source: 'trg', target: 'mon', sourceHandle: 'next' },
                { id: 'e2', source: 'ovd', target: 'esc', sourceHandle: 'next' },
            ],
        }),
    },
];
export function FlowsCanvas({ profile, emailTemplates, pdfTemplates = [], targetApps = [], recipientOptions = EMPTY_RECIPIENT_OPTIONS, flows, canEdit, adapter, templates = DEFAULT_WORKFLOW_TEMPLATES, emailDesign, embedded = false, backLink, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const tGenerated = useGeneratedTranslations();
    // Subject-driven: triggers/actions/status/fields all come from the profile, so
    // the same canvas renders for a form template OR a native module.
    const subject = { type: profile.subjectType, key: profile.subjectKey };
    const subjectLabel = profile.label;
    const fieldIds = useMemo(() => profile.fields.map((f) => f.key), [profile]);
    const actionFields = useMemo(() => ({
        all: profile.fields.map((field) => field.key),
        writable: profile.fields
            .filter((field) => profile.subjectType === 'module' ? field.writable === true : field.writable !== false)
            .map((field) => field.key),
        photoSources: profile.fields.filter((field) => field.photoSource).map((field) => field.key),
        textOutputs: profile.fields.filter((field) => field.textOutput).map((field) => field.key),
        numeric: profile.fields
            .filter((field) => field.kind === 'number' &&
            (profile.subjectType === 'module' ? field.writable === true : field.writable !== false))
            .map((field) => field.key),
    }), [profile]);
    // Working graphs live in a ref keyed by flow id; switching flows captures the
    // current canvas into the ref and loads the target's graph. Save persists the
    // selected flow only (n8n-style). The sidebar list holds name/enabled.
    const graphs = useRef(new Map(flows.map((f) => [f.id, f.graph])));
    const [flowList, setFlowList] = useState(flows.map((f) => ({ id: f.id, name: f.name, enabled: f.enabled })));
    const [selectedFlowId, setSelectedFlowId] = useState(flows[0]?.id ?? null);
    const initial = useMemo(() => toFlow(flows[0]?.graph ?? emptyAutomationGraph()), [flows]);
    const [nodes, setNodes, onNodesChange] = useNodesState(initial.nodes);
    const [edges, setEdges, onEdgesChange] = useEdgesState(initial.edges);
    const [selectedNodeId, setSelectedNodeId] = useState(null);
    const [editingId, setEditingId] = useState(null);
    const [editName, setEditName] = useState('');
    const [pending, start] = useTransition();
    const [showAi, setShowAi] = useState(false);
    const [aiPrompt, setAiPrompt] = useState('');
    const [showTemplates, setShowTemplates] = useState(false);
    // Follow the app's dark theme so React Flow's canvas / controls / minimap /
    // edges render dark too (the `.dark` class is toggled by the theme switcher).
    const [isDark, setIsDark] = useState(false);
    useEffect(() => {
        const el = document.documentElement;
        const sync = () => setIsDark(el.classList.contains('dark'));
        sync();
        const obs = new MutationObserver(sync);
        obs.observe(el, { attributes: true, attributeFilter: ['class'] });
        return () => obs.disconnect();
    }, []);
    const nodeTypes = useMemo(() => ({ trigger: TriggerNode, condition: ConditionNode, gate: GateNode, action: ActionNode }), []);
    const availableFields = useMemo(() => profile.fields.map((f) => ({ id: f.key, label: f.label })), [profile]);
    const availableTemplates = useMemo(() => templates.filter((template) => {
        const graph = template.build();
        return lintAutomationGraph(graph, new Set(fieldIds), profile).length === 0;
    }), [fieldIds, profile, templates]);
    const selectedNode = nodes.find((n) => n.id === selectedNodeId) ?? null;
    const selectedFlow = flowList.find((f) => f.id === selectedFlowId) ?? null;
    const warnings = useMemo(() => selectedFlowId
        ? lintAutomationGraph(fromFlow(nodes, edges), new Set(fieldIds), profile)
        : [], [edges, fieldIds, nodes, profile, selectedFlowId]);
    const captureCurrent = useCallback(() => {
        if (selectedFlowId)
            graphs.current.set(selectedFlowId, fromFlow(nodes, edges));
    }, [selectedFlowId, nodes, edges]);
    const loadFlow = useCallback((id) => {
        const g = id ? (graphs.current.get(id) ?? emptyAutomationGraph()) : emptyAutomationGraph();
        const f = toFlow(g);
        setNodes(id ? f.nodes : []);
        setEdges(id ? f.edges : []);
        setSelectedNodeId(null);
        setSelectedFlowId(id);
    }, [setNodes, setEdges]);
    const selectFlow = (id) => {
        if (id === selectedFlowId)
            return;
        captureCurrent();
        loadFlow(id);
    };
    const addFlow = () => {
        start(async () => {
            const res = await adapter.create(subject, 'New flow');
            if (!res.ok || !res.id) {
                toast.error(tGeneratedValue(res.error ?? tGenerated('m_11eec81d216014')));
                return;
            }
            captureCurrent();
            graphs.current.set(res.id, emptyAutomationGraph());
            setFlowList((l) => [...l, { id: res.id, name: 'New flow', enabled: false }]);
            loadFlow(res.id);
            toast.success(tGenerated('m_07105e19c7e789'));
        });
    };
    const toggleEnabled = (id, enabled) => {
        setFlowList((l) => l.map((f) => (f.id === id ? { ...f, enabled } : f)));
        start(async () => {
            const result = await adapter.setEnabled(id, enabled);
            if (!result.ok) {
                setFlowList((list) => list.map((flow) => (flow.id === id ? { ...flow, enabled: !enabled } : flow)));
                toast.error(tGeneratedValue(result.error ??
                    (enabled ? tGenerated('m_02c65a444f151a') : tGenerated('m_1e6f44ac3a3238'))));
            }
        });
    };
    const commitRename = (id) => {
        const nm = editName.trim() || 'Flow';
        if (nm.length > MAX_FLOW_NAME_LENGTH) {
            toast.error(tGenerated('m_1e52dceb23405d', { value0: MAX_FLOW_NAME_LENGTH }));
            return;
        }
        const previousName = flowList.find((flow) => flow.id === id)?.name;
        setFlowList((l) => l.map((f) => (f.id === id ? { ...f, name: nm } : f)));
        setEditingId(null);
        start(async () => {
            const result = await adapter.rename(id, nm);
            if (!result.ok) {
                if (previousName) {
                    setFlowList((list) => list.map((flow) => (flow.id === id ? { ...flow, name: previousName } : flow)));
                }
                toast.error(tGeneratedValue(result.error ?? tGenerated('m_0245cf85678788')));
            }
        });
    };
    const removeFlow = (id) => {
        start(async () => {
            const result = await adapter.remove(id);
            if (!result.ok) {
                toast.error(tGeneratedValue(result.error ?? tGenerated('m_15741a97c1becc')));
                return;
            }
            graphs.current.delete(id);
            const next = flowList.filter((f) => f.id !== id);
            setFlowList(next);
            if (id === selectedFlowId)
                loadFlow(next[0]?.id ?? null);
            toast.success(tGenerated('m_0ac2f784b6e43b'));
        });
    };
    const onConnect = useCallback((c) => setEdges((eds) => addEdge({ ...c, id: newId('e') }, eds)), [setEdges]);
    const addNode = (kind) => {
        if (!selectedFlowId)
            return;
        const id = newId(kind);
        const node = {
            id,
            type: kind,
            position: { x: 80 + Math.random() * 240, y: 80 + Math.random() * 240 },
            data: defaultData(kind, fieldIds[0] ?? '', profile, actionFields),
        };
        setNodes((ns) => [...ns, node]);
        setSelectedNodeId(id);
    };
    const patchData = (id, data) => setNodes((ns) => ns.map((n) => (n.id === id ? { ...n, data } : n)));
    const removeNode = (id) => {
        setNodes((ns) => ns.filter((n) => n.id !== id));
        setEdges((es) => es.filter((e) => e.source !== id && e.target !== id));
        setSelectedNodeId(null);
    };
    const save = () => {
        if (!selectedFlowId)
            return;
        const graph = fromFlow(nodes, edges);
        graphs.current.set(selectedFlowId, graph);
        start(async () => {
            const res = await adapter.save(selectedFlowId, graph);
            if (!res.ok) {
                toast.error(tGeneratedValue(res.error ?? tGenerated('m_141dec99716e82')));
                return;
            }
            toast.success(tGenerated('m_03c918fe3c11b7'));
        });
    };
    const runAi = () => {
        if (!selectedFlowId) {
            toast.error(tGenerated('m_0776dc4696267a'));
            return;
        }
        start(async () => {
            if (!adapter.generate)
                return;
            const res = await adapter.generate(selectedFlowId, aiPrompt);
            if (!res.ok || !res.graph) {
                toast.error(tGeneratedValue(res.error ?? tGenerated('m_0a2bad9c653946')));
                return;
            }
            graphs.current.set(selectedFlowId, res.graph);
            const f = toFlow(res.graph);
            setNodes(f.nodes);
            setEdges(f.edges);
            setSelectedNodeId(null);
            setShowAi(false);
            toast.success(tGenerated('m_162609b68a9ac6'));
        });
    };
    const applyTemplate = (t) => {
        if (!selectedFlowId) {
            toast.error(tGenerated('m_0776dc4696267a'));
            return;
        }
        const graph = t.build();
        graphs.current.set(selectedFlowId, graph);
        const f = toFlow(graph);
        setNodes(f.nodes);
        setEdges(f.edges);
        setSelectedNodeId(null);
        setShowTemplates(false);
        toast.success(tGenerated('m_0e58c2382f9cda'));
    };
    return (_jsxs("div", { className: "flex h-full min-h-0", children: [_jsxs("aside", { className: "flex w-60 shrink-0 flex-col border-r border-border bg-bg-subtle", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-border px-3 py-2", children: [_jsxs("span", { className: "flex items-center gap-1.5 text-xs font-semibold tracking-wide text-fg-muted uppercase text-fg-subtle", children: [_jsx(Workflow, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_1a4786daa752b1" })] }), _jsx(GeneratedValue, { value: canEdit ? (_jsx("button", { type: "button", onClick: addFlow, disabled: pending, title: tGenerated('m_0c4753241b87b2'), className: "rounded p-1 text-fg-muted hover:bg-surface hover:text-fg disabled:opacity-50 text-fg-subtle  ", children: _jsx(Plus, { size: 15 }) })) : null }), warnings.length > 0 ? (_jsxs("details", { className: "absolute top-3 right-3 z-10 max-w-sm rounded-lg border border-warning/30 bg-warning-subtle/95 px-3 py-2 text-sm text-warning shadow-sm backdrop-blur", children: [_jsxs("summary", { className: "flex cursor-pointer list-none items-center gap-2 select-none", children: [_jsx(TriangleAlert, { size: 14, className: "shrink-0" }), _jsxs("span", { className: "font-medium", children: [warnings.length, " ", warnings.length === 1 ? 'warning' : 'warnings'] })] }), _jsx("ul", { className: "mt-1.5 list-disc space-y-0.5 pl-6 text-xs", children: warnings.map((warning, index) => (_jsx("li", { children: warning }, `${index}-${warning}`))) })] })) : null] }), _jsx("div", { className: "min-h-0 flex-1 space-y-1 overflow-y-auto p-2", children: _jsx(GeneratedValue, { value: flowList.length === 0 ? (_jsxs("div", { className: "px-2 py-6 text-center text-xs text-fg-subtle", children: [_jsx(GeneratedText, { id: "m_09b3b5bd8c347d" }), _jsx(GeneratedValue, { value: canEdit ? (_jsx("button", { onClick: addFlow, className: "mt-2 block w-full text-primary hover:underline", children: _jsx(GeneratedText, { id: "m_19bca60b6c1661" }) })) : null })] })) : (flowList.map((f) => {
                                const active = f.id === selectedFlowId;
                                return (_jsxs("div", { onClick: () => selectFlow(f.id), className: `group flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm ${active
                                        ? 'bg-surface shadow-sm ring-1 ring-primary'
                                        : 'hover:bg-surface-hover'}`, children: [_jsx(MiniToggle, { checked: f.enabled, disabled: !canEdit, onChange: (v) => toggleEnabled(f.id, v) }), _jsx(GeneratedValue, { value: editingId === f.id ? (_jsx("input", { autoFocus: true, value: editName, maxLength: MAX_FLOW_NAME_LENGTH, onClick: (e) => e.stopPropagation(), onChange: (e) => setEditName(e.target.value), onBlur: () => commitRename(f.id), onKeyDown: (e) => {
                                                    if (e.key === 'Enter')
                                                        commitRename(f.id);
                                                    if (e.key === 'Escape')
                                                        setEditingId(null);
                                                }, className: "min-w-0 flex-1 rounded border border-border-strong px-1 py-0.5 text-sm outline-none focus:border-primary" })) : (_jsx("span", { className: `min-w-0 flex-1 truncate ${f.enabled
                                                    ? 'text-fg'
                                                    : 'text-fg-subtle line-through text-fg-muted'}`, children: _jsx(GeneratedValue, { value: f.name }) })) }), _jsx(GeneratedValue, { value: canEdit && editingId !== f.id ? (_jsxs(_Fragment, { children: [_jsx("button", { type: "button", title: tGenerated('m_19a03337702a01'), onClick: (e) => {
                                                            e.stopPropagation();
                                                            setEditingId(f.id);
                                                            setEditName(f.name);
                                                        }, className: "opacity-0 transition group-hover:opacity-100", children: _jsx(Pencil, { size: 12, className: "text-fg-subtle hover:text-fg-muted" }) }), _jsx("button", { type: "button", title: tGenerated('m_15741a97c1becc'), onClick: (e) => {
                                                            e.stopPropagation();
                                                            removeFlow(f.id);
                                                        }, className: "opacity-0 transition group-hover:opacity-100", children: _jsx(Trash2, { size: 12, className: "text-fg-subtle hover:text-danger" }) })] })) : null })] }, f.id));
                            })) }) })] }), _jsxs("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col", children: [_jsxs("header", { className: "flex shrink-0 flex-wrap items-center justify-between gap-2 border-b border-border bg-surface px-4 py-2", children: [_jsxs("div", { className: "flex min-w-0 items-center gap-2 text-sm", children: [_jsx(GeneratedValue, { value: !embedded && backLink ? (_jsxs(_Fragment, { children: [backLink, _jsx("span", { className: "h-4 w-px bg-border" })] })) : null }), _jsxs("span", { className: "min-w-0 truncate", children: [_jsx(GeneratedValue, { value: embedded ? null : (_jsx("span", { className: "font-semibold", children: _jsx(GeneratedValue, { value: subjectLabel }) })) }), _jsx(GeneratedValue, { value: ' ' }), _jsxs("span", { className: embedded ? 'font-semibold text-fg' : 'text-fg-subtle', children: [_jsx(GeneratedValue, { value: embedded ? '' : '· ' }), _jsx(GeneratedValue, { value: selectedFlow ? selectedFlow.name : _jsx(GeneratedText, { id: "m_1a4786daa752b1" }) })] })] }), _jsx(GeneratedValue, { value: selectedFlow && !selectedFlow.enabled ? (_jsx("span", { className: "ml-2 rounded bg-bg-subtle px-1.5 py-0.5 text-[10px] font-medium text-fg-muted", children: _jsx(GeneratedText, { id: "m_0ea7ffe3f671e7" }) })) : null })] }), _jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [_jsx(GeneratedValue, { value: canEdit && selectedFlowId ? (_jsxs(_Fragment, { children: [_jsxs(Button, { variant: "outline", size: "sm", onClick: () => addNode('trigger'), children: [_jsx(Plus, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_1db1e5c9ca41ce" })] }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => addNode('condition'), children: [_jsx(Plus, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_0c33471afd0f99" })] }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => addNode('gate'), children: [_jsx(Plus, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_0f7bb45f90ba7e" })] }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => addNode('action'), children: [_jsx(Plus, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_0bad495a7046e9" })] })] })) : null }), _jsx(GeneratedValue, { value: canEdit && selectedFlowId ? (_jsxs(Button, { variant: "outline", size: "sm", onClick: () => setShowTemplates(true), children: [_jsx(Rocket, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_0a19e6387037d4" })] })) : null }), _jsx(GeneratedValue, { value: adapter.generate && selectedFlowId ? (_jsxs(Button, { variant: "outline", size: "sm", onClick: () => setShowAi(true), disabled: pending, children: [_jsx(Sparkles, { size: 13 }), " ", _jsx(GeneratedText, { id: "m_1e0a86199c09df" })] })) : null }), _jsx(GeneratedValue, { value: canEdit && selectedFlowId ? (_jsxs(Button, { size: "sm", onClick: save, disabled: pending, children: [_jsx(Save, { size: 13 }), ' ', _jsx(GeneratedValue, { value: pending ? (_jsx(GeneratedText, { id: "m_106811f2aac664" })) : (_jsx(GeneratedText, { id: "m_19e6bff894c3c7" })) })] })) : null })] })] }), _jsxs("div", { className: "relative min-h-0 flex-1", children: [_jsx(GeneratedValue, { value: selectedFlowId ? (_jsxs(ReactFlow, { nodes: nodes, edges: edges, onNodesChange: onNodesChange, onEdgesChange: onEdgesChange, onConnect: onConnect, onNodeClick: (_, n) => setSelectedNodeId(n.id), onPaneClick: () => setSelectedNodeId(null), nodeTypes: nodeTypes, nodesConnectable: canEdit, colorMode: isDark ? 'dark' : 'light', fitView: true, fitViewOptions: { padding: 0.3, maxZoom: 0.8 }, minZoom: 0.2, proOptions: { hideAttribution: true }, children: [_jsx(Background, {}), _jsx(Controls, { showInteractive: false }), _jsx(MiniMap, { pannable: true, zoomable: true })] })) : (_jsx("div", { className: "flex h-full items-center justify-center", children: _jsxs("div", { className: "rounded-xl border border-dashed border-border-strong bg-surface p-6 text-center", children: [_jsx("p", { className: "text-sm font-medium text-fg", children: _jsx(GeneratedText, { id: "m_1abfbb4f0b4f36" }) }), _jsx("p", { className: "mt-1 max-w-xs text-xs text-fg-muted", children: _jsx(GeneratedText, { id: "m_028d6ce274ccaa" }) })] }) })) }), _jsx(GeneratedValue, { value: selectedFlowId && nodes.length === 0 ? (_jsx("div", { className: "pointer-events-none absolute inset-0 flex items-center justify-center p-4", children: _jsxs("div", { className: "pointer-events-auto w-full max-w-lg rounded-xl border border-dashed border-border-strong bg-surface/95 p-5 text-center shadow-sm", children: [_jsx("p", { className: "text-sm font-semibold text-fg", children: _jsx(GeneratedText, { id: "m_1df84b29521519" }) }), _jsx("p", { className: "mt-1 text-xs text-fg-muted", children: _jsx(GeneratedText, { id: "m_139d4c0c9f7be0" }) }), _jsx(GeneratedValue, { value: canEdit ? (_jsx("div", { className: "mt-3 grid grid-cols-1 gap-2 text-left sm:grid-cols-2", children: _jsx(GeneratedValue, { value: availableTemplates.map((t) => (_jsxs("button", { type: "button", onClick: () => applyTemplate(t), className: "rounded-lg border border-border bg-surface p-2.5 transition hover:border-primary hover:bg-primary-subtle/40", children: [_jsx("div", { className: "text-xs font-semibold text-fg", children: _jsx(GeneratedValue, { value: t.label }) }), _jsx("div", { className: "mt-0.5 text-[11px] leading-snug text-fg-muted", children: _jsx(GeneratedValue, { value: t.description }) })] }, t.key))) }) })) : null })] }) })) : null })] })] }), _jsx(Drawer, { open: selectedNode != null, onClose: () => setSelectedNodeId(null), title: tGeneratedValue(selectedNode
                    ? tGenerated('m_0a45a3f047a285', { value0: selectedNode.data.kind })
                    : tGenerated('m_03a66f9d34ac7b')), size: "sm", footer: selectedNode && canEdit ? (_jsxs(Button, { variant: "outline", onClick: () => removeNode(selectedNode.id), children: [_jsx(Trash2, { size: 14, className: "text-danger" }), " ", _jsx(GeneratedText, { id: "m_09838d30eb3121" })] })) : null, children: _jsx(GeneratedValue, { value: selectedNode ? (_jsx(NodeInspector, { data: selectedNode.data, fieldIds: fieldIds, actionFields: actionFields, availableFields: availableFields, profile: profile, emailTemplates: emailTemplates, pdfTemplates: pdfTemplates, targetApps: targetApps, recipientOptions: recipientOptions, emailDesign: emailDesign, readOnly: !canEdit, onChange: (d) => patchData(selectedNode.id, d) })) : null }) }), _jsx(Drawer, { open: showTemplates, onClose: () => setShowTemplates(false), title: tGenerated('m_01a6df8deac3ad'), description: tGenerated('m_127e5a438a4764'), size: "sm", children: _jsxs("div", { className: "space-y-2", children: [_jsx(GeneratedValue, { value: availableTemplates.map((t) => (_jsxs("button", { type: "button", onClick: () => applyTemplate(t), className: "block w-full rounded-lg border border-border bg-surface p-3 text-left transition hover:border-primary hover:bg-primary-subtle/40", children: [_jsx("div", { className: "text-sm font-semibold text-fg", children: _jsx(GeneratedValue, { value: t.label }) }), _jsx("div", { className: "mt-0.5 text-xs leading-snug text-fg-muted", children: _jsx(GeneratedValue, { value: t.description }) })] }, t.key))) }), _jsx("p", { className: "pt-1 text-[11px] text-fg-subtle text-fg-muted", children: _jsx(GeneratedText, { id: "m_0be1be4daf3028" }) })] }) }), _jsx(Drawer, { open: showAi, onClose: () => setShowAi(false), title: tGenerated('m_0c24b0e0c8e0fa'), description: tGenerated('m_0d4729dfb8d8fa'), size: "sm", footer: _jsxs(_Fragment, { children: [_jsx(Button, { variant: "outline", onClick: () => setShowAi(false), disabled: pending, children: _jsx(GeneratedText, { id: "m_112e2e8ecda428" }) }), _jsxs(Button, { onClick: runAi, disabled: pending || aiPrompt.trim().length < 4, children: [_jsx(Sparkles, { size: 14 }), ' ', _jsx(GeneratedValue, { value: pending ? (_jsx(GeneratedText, { id: "m_11beb293de9d2d" })) : (_jsx(GeneratedText, { id: "m_1dbb9f90b1c6f2" })) })] })] }), children: _jsxs("div", { className: "space-y-2", children: [_jsx(Textarea, { rows: 4, value: aiPrompt, placeholder: tGenerated('m_01e855ecae74db'), onChange: (e) => setAiPrompt(e.target.value) }), _jsx("p", { className: "text-[11px] text-fg-subtle text-fg-muted", children: _jsx(GeneratedText, { id: "m_06e04a2aa58e1f" }) })] }) })] }));
}
// --- Inspector (per-kind editing) ------------------------------------------
function NodeInspector({ data, fieldIds, actionFields, availableFields, profile, emailTemplates, pdfTemplates, targetApps, recipientOptions, emailDesign, readOnly, onChange, }) {
    const tGenerated = useGeneratedTranslations();
    if (data.kind === 'trigger') {
        const t = data.trigger;
        return (_jsxs("div", { className: "space-y-3", children: [_jsx(Field, { label: tGenerated('m_13cc128f69897c'), children: _jsx(Select, { value: t.trigger, disabled: readOnly, onChange: (e) => {
                            const v = e.target.value;
                            onChange({
                                kind: 'trigger',
                                trigger: buildTrigger(v, fieldIds[0] ?? '', profile.statusValues?.[0] ?? 'submitted'),
                            });
                        }, children: profile.triggers.map((tk) => (_jsx("option", { value: tk, children: TRIGGER_LABEL[tk] }, tk))) }) }), _jsx(GeneratedValue, { value: t.trigger === 'on_field_value' ? (_jsx(Field, { label: tGenerated('m_19a82ebc42ebe3'), children: _jsx(LogicBuilder, { rule: t.rule, availableFields: availableFields, onChange: (rule) => onChange({
                                kind: 'trigger',
                                trigger: {
                                    trigger: 'on_field_value',
                                    rule: rule ?? { op: 'isSet', field: fieldIds[0] ?? '' },
                                },
                            }) }) })) : null }), _jsx(GeneratedValue, { value: t.trigger === 'status_change' ? (_jsx(Field, { label: tGenerated('m_0b5f0bfe110fb9'), children: _jsx(Select, { value: t.to, disabled: readOnly, onChange: (e) => onChange({
                                kind: 'trigger',
                                trigger: { trigger: 'status_change', to: e.target.value },
                            }), children: (profile.statusValues ?? ['submitted']).map((s) => (_jsx("option", { value: s, children: s.replace(/_/g, ' ') }, s))) }) })) : null }), _jsx(GeneratedValue, { value: t.trigger === 'scheduled' ? (_jsx(Field, { label: tGenerated('m_18651428376053'), children: _jsx(Input, { value: t.cron, disabled: readOnly, onChange: (e) => onChange({
                                kind: 'trigger',
                                trigger: { ...t, cron: e.target.value },
                            }) }) })) : null }), _jsx(GeneratedValue, { value: t.trigger === 'manual' ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "text-[11px] text-fg-muted", children: _jsx(GeneratedText, { id: "m_0acdcecd1c4f9c" }) }), _jsx(Field, { label: tGenerated('m_18b7c648c39e28'), children: _jsx(Input, { value: t.label, disabled: readOnly, placeholder: tGenerated('m_120d9d75eb5980'), onChange: (e) => onChange({ kind: 'trigger', trigger: { ...t, label: e.target.value } }) }) }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(Field, { label: tGenerated('m_03cf3a97d03fef'), children: _jsxs(Select, { value: t.variant ?? 'default', disabled: readOnly, onChange: (e) => onChange({
                                                kind: 'trigger',
                                                trigger: {
                                                    ...t,
                                                    variant: e.target.value,
                                                },
                                            }), children: [_jsx("option", { value: "default", children: 'Primary' }), _jsx("option", { value: "outline", children: 'Outline' }), _jsx("option", { value: "secondary", children: 'Secondary' }), _jsx("option", { value: "destructive", children: 'Destructive' })] }) }), _jsx(Field, { label: tGenerated('m_158279b74f9a6e'), children: _jsx(Input, { value: t.icon ?? '', disabled: readOnly, placeholder: tGenerated('m_1498caf65a85c4'), onChange: (e) => onChange({
                                                kind: 'trigger',
                                                trigger: {
                                                    ...t,
                                                    icon: e.target.value.trim() ? e.target.value : undefined,
                                                },
                                            }) }) })] }), _jsx(Field, { label: tGenerated('m_01066829ab2176'), children: _jsx(Input, { value: t.confirm ?? '', disabled: readOnly, placeholder: tGenerated('m_1c97926a04b9c7'), onChange: (e) => onChange({
                                        kind: 'trigger',
                                        trigger: {
                                            ...t,
                                            confirm: e.target.value.trim() ? e.target.value : undefined,
                                        },
                                    }) }) }), _jsx(Field, { label: tGenerated('m_126e942baf656b'), children: _jsx(Input, { type: "number", value: t.order ?? '', disabled: readOnly, placeholder: tGenerated('m_0f137cab523375'), onChange: (e) => {
                                        const raw = e.target.value.trim();
                                        const n = raw === '' ? undefined : Number.parseInt(raw, 10);
                                        onChange({
                                            kind: 'trigger',
                                            trigger: {
                                                ...t,
                                                order: Number.isFinite(n) ? n : undefined,
                                            },
                                        });
                                    } }) }), _jsxs(Field, { label: tGenerated('m_0ef7e5f0c544da'), children: [_jsx(LogicBuilder, { rule: t.showIf, availableFields: availableFields, onChange: (rule) => onChange({ kind: 'trigger', trigger: { ...t, showIf: rule ?? undefined } }) }), _jsxs("p", { className: "mt-1 text-[11px] text-fg-subtle text-fg-muted", children: [_jsx(GeneratedText, { id: "m_01a3b7ba2ed936" }), _jsx(GeneratedValue, { value: ' ' }), _jsx("span", { className: "font-mono", children: _jsx(GeneratedValue, { value: t.buttonId }) })] })] })] })) : null })] }));
    }
    if (data.kind === 'condition') {
        return (_jsxs("div", { className: "space-y-3", children: [_jsx(Field, { label: tGenerated('m_1d088977412efb'), children: _jsx(Input, { value: data.label ?? '', disabled: readOnly, onChange: (e) => onChange({ ...data, label: e.target.value }) }) }), _jsx(Field, { label: tGenerated('m_16a46bc46302d1'), children: _jsx(LogicBuilder, { rule: data.rule, availableFields: availableFields, onChange: (rule) => onChange({ ...data, rule: rule ?? { op: 'isSet', field: fieldIds[0] ?? '' } }) }) })] }));
    }
    if (data.kind === 'gate') {
        const g = data.gate;
        return (_jsxs("div", { className: "space-y-3", children: [_jsx(Field, { label: tGenerated('m_0decefd558c355'), children: _jsx(Input, { value: g.title, disabled: readOnly, onChange: (e) => onChange({ kind: 'gate', gate: { ...g, title: e.target.value } }) }) }), _jsx(Field, { label: tGenerated('m_1f4ba956f2ba0f'), children: _jsxs(Select, { value: g.assignee.type, disabled: readOnly, onChange: (e) => onChange({
                            kind: 'gate',
                            gate: {
                                ...g,
                                assignee: e.target.value === 'role' ? { type: 'role', role: '' } : { type: 'submitter' },
                            },
                        }), children: [_jsx("option", { value: "submitter", children: 'The submitter' }), _jsx("option", { value: "role", children: 'A role' })] }) }), _jsx(GeneratedValue, { value: g.assignee.type === 'role' ? (_jsx(Field, { label: tGenerated('m_1099c1fe8b6614'), children: _jsx(Input, { value: g.assignee.role, disabled: readOnly, onChange: (e) => onChange({
                                kind: 'gate',
                                gate: { ...g, assignee: { type: 'role', role: e.target.value } },
                            }) }) })) : null }), _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx("input", { type: "checkbox", checked: !!g.signatureRequired, disabled: readOnly, onChange: (e) => onChange({ kind: 'gate', gate: { ...g, signatureRequired: e.target.checked } }) }), _jsx(GeneratedText, { id: "m_02ffe91f500dc8" })] })] }));
    }
    // action
    return (_jsx(ActionInspector, { data: data, fieldIds: fieldIds, actionFields: actionFields, availableFields: availableFields, actions: profile.actions, emailTemplates: emailTemplates, pdfTemplates: pdfTemplates, targetApps: targetApps, recipientOptions: recipientOptions, emailDesign: emailDesign, readOnly: readOnly, onChange: onChange }));
}
function ActionInspector({ data, fieldIds, actionFields, availableFields, actions, emailTemplates, pdfTemplates, targetApps, recipientOptions, emailDesign, readOnly, onChange, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    const tGenerated = useGeneratedTranslations();
    const a = data.action;
    const set = (action) => onChange({ kind: 'action', action });
    const actionChoices = actions.length
        ? actions
        : Object.keys(ACTION_LABEL);
    // send_email "design" (one-off) mode — a full-screen drag-and-drop builder.
    const EmailDesignBuilder = emailDesign?.Editor;
    const [designOpen, setDesignOpen] = useState(false);
    const [designBusy, setDesignBusy] = useState(false);
    const designRef = useRef(null);
    const saveDesign = async () => {
        const ed = designRef.current;
        if (!ed || !emailDesign || a.action !== 'send_email')
            return;
        setDesignBusy(true);
        try {
            const res = await emailDesign.compile(ed);
            if (!res.ok || !res.html || !res.sourceHtml) {
                toast.error(tGeneratedValue(res.error ?? tGenerated('m_002d59b20693c5')));
                return;
            }
            set({ ...a, mode: 'design', sourceHtml: res.sourceHtml, compiledHtml: res.html });
            setDesignOpen(false);
        }
        finally {
            setDesignBusy(false);
        }
    };
    return (_jsxs("div", { className: "space-y-3", children: [_jsx(GeneratedValue, { value: designOpen ? (_jsxs("div", { className: "fixed inset-0 z-[60] flex flex-col bg-surface bg-bg", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-border px-4 py-2", children: [_jsx("span", { className: "text-sm font-semibold text-fg", children: _jsx(GeneratedText, { id: "m_1d8534a5e92ce6" }) }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Button, { variant: "outline", size: "sm", onClick: () => setDesignOpen(false), children: _jsx(GeneratedText, { id: "m_112e2e8ecda428" }) }), _jsx(Button, { size: "sm", disabled: designBusy, onClick: saveDesign, children: _jsx(GeneratedValue, { value: designBusy ? (_jsx(GeneratedText, { id: "m_106811f2aac664" })) : (_jsx(GeneratedText, { id: "m_1f0e1a82c4aae4" })) }) })] })] }), _jsx("div", { className: "min-h-0 flex-1", children: EmailDesignBuilder ? _jsx(EmailDesignBuilder, { initialHtml: a.action === 'send_email' ? (a.sourceHtml ?? null) : null, mergeFields: fieldIds.map((f) => ({ key: f })), onReady: (ed) => {
                                    designRef.current = ed;
                                } }) : null })] })) : null }), _jsx(Field, { label: tGenerated('m_0bad495a7046e9'), children: _jsx(Select, { value: a.action, disabled: readOnly, onChange: (e) => set(defaultAction(e.target.value, actionFields)), children: actionChoices.map((k) => (_jsx("option", { value: k, children: ACTION_LABEL[k] }, k))) }) }), _jsx(GeneratedValue, { value: a.action === 'send_email' ? (_jsxs(_Fragment, { children: [_jsx(RecipientsEditor, { to: a.to, onChange: (to) => set({ ...a, to }), readOnly: readOnly, fieldIds: fieldIds, options: recipientOptions }), _jsx(Field, { label: tGenerated('m_079594be6652a8'), children: _jsxs(Select, { value: a.channel ?? 'email', disabled: readOnly, onChange: (e) => set({ ...a, channel: e.target.value }), children: [_jsx("option", { value: "email", children: 'Email' }), _jsx("option", { value: "sms", children: 'SMS (text)' }), _jsx("option", { value: "in_app", children: 'In-app notification' })] }) }), _jsx(Field, { label: tGeneratedValue((a.channel ?? 'email') === 'email'
                                ? tGenerated('m_03a92a8bba62c3')
                                : tGenerated('m_12449ce6dd3e47')), children: _jsxs(Select, { value: a.mode ?? 'inline', disabled: readOnly, onChange: (e) => set({ ...a, mode: e.target.value }), children: [_jsx("option", { value: "inline", children: 'Write it here' }), _jsx("option", { value: "template", children: 'Use a saved template' }), _jsx("option", { value: "design", children: 'Design one (drag & drop)' })] }) }), _jsx(GeneratedValue, { value: (a.mode ?? 'inline') === 'design' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_1928431de4aaf1'), children: _jsx(Input, { value: a.subjectTemplate ?? '', disabled: readOnly, onChange: (e) => set({ ...a, subjectTemplate: e.target.value }) }) }), _jsx(Button, { variant: "outline", size: "sm", disabled: readOnly, onClick: () => setDesignOpen(true), children: _jsx(GeneratedValue, { value: a.compiledHtml ? (_jsx(GeneratedText, { id: "m_1ed448916bb007" })) : (_jsx(GeneratedText, { id: "m_1f13f5c3b87576" })) }) }), _jsx(GeneratedValue, { value: a.compiledHtml ? (_jsx("p", { className: "text-xs text-success", children: _jsx(GeneratedText, { id: "m_1a12949487d961" }) })) : (_jsx("p", { className: "text-xs text-fg-subtle", children: _jsx(GeneratedText, { id: "m_00021f60b601ff" }) })) })] })) : (a.mode ?? 'inline') === 'template' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_13704e4d90cde4'), children: _jsxs(Select, { value: a.templateId ?? '', disabled: readOnly, onChange: (e) => set({ ...a, templateId: e.target.value }), children: [_jsx("option", { value: "", children: '— choose a template —' }), emailTemplates.map((t) => (_jsx("option", { value: t.id, children: t.name }, t.id)))] }) }), _jsx(GeneratedValue, { value: emailTemplates.length === 0 ? (_jsx("p", { className: "text-xs text-fg-subtle", children: _jsx(GeneratedText, { id: "m_01725f4d4cbece" }) })) : null }), _jsx(Field, { label: tGenerated('m_0a88689556c4a0'), children: _jsx(Input, { value: a.subjectOverride ?? '', disabled: readOnly, onChange: (e) => set({ ...a, subjectOverride: e.target.value }) }) })] })) : (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_1928431de4aaf1'), children: _jsx(Input, { value: a.subject ?? '', disabled: readOnly, onChange: (e) => set({ ...a, subject: e.target.value }) }) }), _jsx(Field, { label: tGenerated('m_18d98590ba5c28'), children: _jsx(Textarea, { rows: 4, value: a.bodyTemplate ?? '', disabled: readOnly, onChange: (e) => set({ ...a, bodyTemplate: e.target.value }) }) })] })) }), _jsx(Field, { label: tGenerated('m_04c18d4965cadc'), children: _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx("input", { type: "checkbox", checked: !!a.attachPdf, disabled: readOnly, onChange: (e) => set({ ...a, attachPdf: e.target.checked }), className: "h-4 w-4 rounded border-border-strong text-primary focus:ring-primary" }), _jsx(GeneratedText, { id: "m_1afb19e2a3fd62" })] }) }), _jsx(GeneratedValue, { value: a.attachPdf ? (_jsx(Field, { label: tGenerated('m_0728ad8d6726a2'), children: _jsxs(Select, { value: a.pdfTemplateId
                                        ? `tpl:${a.pdfTemplateId}`
                                        : a.pdfFormat === 'summary'
                                            ? 'builtin:summary'
                                            : 'builtin:auto', disabled: readOnly, onChange: (e) => {
                                        const v = e.target.value;
                                        if (v.startsWith('tpl:')) {
                                            set({ ...a, pdfTemplateId: v.slice(4), pdfFormat: undefined });
                                        }
                                        else if (v === 'builtin:summary') {
                                            set({ ...a, pdfTemplateId: undefined, pdfFormat: 'summary' });
                                        }
                                        else {
                                            set({ ...a, pdfTemplateId: undefined, pdfFormat: undefined });
                                        }
                                    }, children: [_jsxs("optgroup", { label: tGenerated('m_09bfd82959f8d2'), children: [_jsx("option", { value: "builtin:auto", children: 'Assigned PDF template (falls back to the field summary)' }), _jsx("option", { value: "builtin:summary", children: 'Field summary (key / value table)' })] }), pdfTemplates.length > 0 ? (_jsx("optgroup", { label: tGenerated('m_1bf56760eea2b5'), children: pdfTemplates.map((t) => (_jsx("option", { value: `tpl:${t.id}`, children: t.name }, t.id))) })) : null] }) })) : null }), _jsxs("div", { className: "space-y-3 rounded-lg border border-border p-3", children: [_jsxs("div", { className: "flex items-center justify-between gap-3", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-fg", children: _jsx(GeneratedText, { id: "m_091185429bbc1c" }) }), _jsx("p", { className: "text-xs text-fg-muted", children: _jsx(GeneratedText, { id: "m_16eed28e441ee2" }) })] }), _jsxs(Button, { type: "button", variant: "secondary", size: "sm", disabled: readOnly || recipientOptions.spreadsheetTemplates.length === 0, onClick: () => {
                                                const template = recipientOptions.spreadsheetTemplates[0];
                                                if (!template)
                                                    return;
                                                set({
                                                    ...a,
                                                    spreadsheetAttachments: [
                                                        ...(a.spreadsheetAttachments ?? []),
                                                        { templateAttachmentId: template.id },
                                                    ],
                                                });
                                            }, children: [_jsx(Plus, { className: "mr-1 h-4 w-4" }), _jsx(GeneratedText, { id: "m_114fd68aa28e60" })] })] }), recipientOptions.spreadsheetTemplates.length === 0 ? (_jsx("p", { className: "text-xs text-fg-muted", children: _jsx(GeneratedText, { id: "m_1ed36573238d1d" }) })) : null, (a.spreadsheetAttachments ?? []).map((attachment, index) => (_jsxs("div", { className: "space-y-3 rounded-md bg-bg-subtle p-3 bg-surface/50", children: [_jsxs("div", { className: "flex items-end gap-2", children: [_jsx("div", { className: "min-w-0 flex-1", children: _jsx(Field, { label: tGenerated('m_0d5b3e3dbea5a7'), children: _jsx(Select, { value: attachment.templateAttachmentId, disabled: readOnly, onChange: (event) => {
                                                                const next = [...(a.spreadsheetAttachments ?? [])];
                                                                next[index] = {
                                                                    ...attachment,
                                                                    templateAttachmentId: event.target.value,
                                                                };
                                                                set({ ...a, spreadsheetAttachments: next });
                                                            }, children: recipientOptions.spreadsheetTemplates.map((template) => (_jsx("option", { value: template.id, children: template.name }, template.id))) }) }) }), _jsx(Button, { type: "button", variant: "ghost", size: "icon", "aria-label": tGenerated('m_1300a5099634f1'), disabled: readOnly, onClick: () => {
                                                        const next = (a.spreadsheetAttachments ?? []).filter((_, itemIndex) => itemIndex !== index);
                                                        set({ ...a, spreadsheetAttachments: next.length > 0 ? next : undefined });
                                                    }, children: _jsx(Trash2, { className: "h-4 w-4" }) })] }), _jsx(Field, { label: tGenerated('m_1566168cfca5cb'), children: _jsx(Input, { value: attachment.filename ?? '', placeholder: tGenerated('m_14dfc66e74338e'), disabled: readOnly, onChange: (event) => {
                                                    const next = [...(a.spreadsheetAttachments ?? [])];
                                                    next[index] = {
                                                        ...attachment,
                                                        filename: event.target.value || undefined,
                                                    };
                                                    set({ ...a, spreadsheetAttachments: next });
                                                } }) }), _jsxs("div", { children: [_jsx("p", { className: "mb-2 text-xs font-medium text-fg", children: _jsx(GeneratedText, { id: "m_05928758fdadda" }) }), _jsx(LogicBuilder, { rule: attachment.when, availableFields: availableFields, onChange: (rule) => {
                                                        const next = [...(a.spreadsheetAttachments ?? [])];
                                                        next[index] = { ...attachment, when: rule };
                                                        set({ ...a, spreadsheetAttachments: next });
                                                    } })] })] }, `${attachment.templateAttachmentId}:${index}`)))] })] })) : null }), _jsx(GeneratedValue, { value: a.action === 'create_capa' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_1b31092e597972'), children: _jsx(Input, { value: a.titleTemplate, disabled: readOnly, onChange: (e) => set({ ...a, titleTemplate: e.target.value }) }) }), _jsx(Field, { label: tGenerated('m_168b365cc671bf'), children: _jsx(Select, { value: a.severity ?? 'medium', disabled: readOnly, onChange: (e) => set({
                                    ...a,
                                    severity: e.target.value,
                                }), children: ['low', 'medium', 'high', 'critical'].map((s) => (_jsx("option", { value: s, children: s }, s))) }) }), _jsx(Field, { label: tGenerated('m_0b8592c90b3997'), children: _jsx(Input, { type: "number", value: a.dueInDays ?? '', disabled: readOnly, onChange: (e) => set({
                                    ...a,
                                    dueInDays: e.target.value === '' ? undefined : Number(e.target.value),
                                }) }) })] })) : null }), _jsx(GeneratedValue, { value: a.action === 'create_incident' ? (_jsx(Field, { label: tGenerated('m_1b31092e597972'), children: _jsx(Input, { value: a.titleTemplate, disabled: readOnly, onChange: (e) => set({ ...a, titleTemplate: e.target.value }) }) })) : null }), _jsx(GeneratedValue, { value: a.action === 'notify_role' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_1099c1fe8b6614'), children: _jsx(Input, { value: a.role, disabled: readOnly, onChange: (e) => set({ ...a, role: e.target.value }) }) }), _jsx(Field, { label: tGenerated('m_0e4ff640f8e7d6'), children: _jsx(Input, { value: a.message, disabled: readOnly, onChange: (e) => set({ ...a, message: e.target.value }) }) })] })) : null }), _jsx(GeneratedValue, { value: a.action === 'set_field' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_1dfe960eaa6224'), children: _jsxs(Select, { value: a.field, disabled: readOnly, onChange: (e) => set({ ...a, field: e.target.value }), children: [_jsx("option", { value: "", children: '— pick a field —' }), actionFields.writable.map((f) => (_jsx("option", { value: f, children: f }, f)))] }) }), _jsx(Field, { label: tGenerated('m_1cc0e5e7b5f442'), children: _jsx(Input, { value: a.value.kind === 'literal' ? String(a.value.value ?? '') : '', disabled: readOnly, onChange: (e) => set({ ...a, value: { kind: 'literal', value: e.target.value } }) }) })] })) : null }), _jsx(GeneratedValue, { value: a.action === 'flag_non_compliant' ? (_jsx(Field, { label: tGenerated('m_1cd0901d5dfe1a'), children: _jsx(Input, { value: a.reason ?? '', disabled: readOnly, onChange: (e) => set({ ...a, reason: e.target.value }) }) })) : null }), _jsx(GeneratedValue, { value: a.action === 'webhook' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_165a381fa8ae74'), children: _jsx(Input, { value: a.url, disabled: readOnly, onChange: (e) => set({ ...a, url: e.target.value }) }) }), _jsx(Field, { label: tGenerated('m_0984e05d5d435f'), children: _jsxs(Select, { value: a.method, disabled: readOnly, onChange: (e) => set({ ...a, method: e.target.value }), children: [_jsx("option", { value: "POST", children: 'POST' }), _jsx("option", { value: "PUT", children: 'PUT' })] }) })] })) : null }), _jsx(GeneratedValue, { value: a.action === 'create_response' ? (_jsxs(Field, { label: tGenerated('m_057778f7de97cd'), children: [_jsx(SearchSelect, { value: a.templateId, disabled: readOnly, options: targetApps.map((app) => ({ value: app.id, label: app.name })), placeholder: tGenerated('m_1cc7bc088003bc'), sheetTitle: "Target app", ariaLabel: "Target app", onChange: (templateId) => set({ ...a, templateId }) }), _jsx("p", { className: "mt-1 text-[11px] text-fg-subtle text-fg-muted", children: _jsx(GeneratedText, { id: "m_0569fdc1833cbf" }) })] })) : null }), _jsx(GeneratedValue, { value: a.action === 'analyze_photos' ? (_jsxs(_Fragment, { children: [_jsx(Field, { label: tGenerated('m_0bb985b1bd9e88'), children: _jsxs(Select, { value: a.fieldId, disabled: readOnly, onChange: (e) => set({ ...a, fieldId: e.target.value }), children: [_jsx("option", { value: "", children: '— pick a field —' }), actionFields.photoSources.map((f) => (_jsx("option", { value: f, children: f }, f)))] }) }), _jsx(Field, { label: tGenerated('m_108b4cbe4ba75e'), children: _jsxs(Select, { value: a.storeInField ?? '', disabled: readOnly, onChange: (e) => set({ ...a, storeInField: e.target.value || undefined }), children: [_jsx("option", { value: "", children: '— none —' }), actionFields.textOutputs.map((f) => (_jsx("option", { value: f, children: f }, f)))] }) }), _jsxs("label", { className: "flex items-center gap-2 text-xs", children: [_jsx("input", { type: "checkbox", checked: !!a.createCapaOnHazard, disabled: readOnly, onChange: (e) => set({ ...a, createCapaOnHazard: e.target.checked }) }), _jsx(GeneratedText, { id: "m_1fb66407994e0c" })] }), _jsx(GeneratedValue, { value: a.createCapaOnHazard ? (_jsx(Field, { label: tGenerated('m_0ac24b7d0c1efa'), children: _jsxs(Select, { value: a.minSeverity ?? 'medium', disabled: readOnly, onChange: (e) => set({ ...a, minSeverity: e.target.value }), children: [_jsx("option", { value: "low", children: 'Low and above' }), _jsx("option", { value: "medium", children: 'Medium and above' }), _jsx("option", { value: "high", children: 'High only' })] }) })) : null })] })) : null }), _jsx(GeneratedValue, { value: a.action === 'start_monitored_session' ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "text-[11px] text-fg-muted", children: _jsx(GeneratedText, { id: "m_06251479eec41c" }) }), _jsx(MonitorNum, { label: tGenerated('m_059b9458e92a71'), value: a.intervalMinutes, fieldKey: a.intervalFieldKey, fieldIds: actionFields.numeric, readOnly: readOnly, onValue: (v) => set({ ...a, intervalMinutes: Math.max(1, v) }), onField: (k) => set({ ...a, intervalFieldKey: k }) }), _jsx(MonitorNum, { label: tGenerated('m_1bc3a7ded730b8'), value: a.graceMinutes, fieldKey: a.graceFieldKey, fieldIds: actionFields.numeric, readOnly: readOnly, onValue: (v) => set({ ...a, graceMinutes: Math.max(0, v) }), onField: (k) => set({ ...a, graceFieldKey: k }) }), _jsx(MonitorNum, { label: tGenerated('m_0d9d758963404e'), value: a.durationMinutes ?? 0, fieldKey: a.durationFieldKey, fieldIds: actionFields.numeric, readOnly: readOnly, onValue: (v) => set({ ...a, durationMinutes: Math.max(0, v) }), onField: (k) => set({ ...a, durationFieldKey: k }) }), _jsxs("label", { className: "flex items-center gap-2 text-xs text-fg", children: [_jsx("input", { type: "checkbox", checked: !!a.requireGeo, disabled: readOnly, onChange: (e) => set({ ...a, requireGeo: e.target.checked }) }), _jsx(GeneratedText, { id: "m_1d75b79556863c" })] })] })) : null })] }));
}
// Number input that can be a fixed value OR bound to a submitted number field —
// used by the start_monitored_session inspector for interval/grace/duration.
function MonitorNum({ label, value, fieldKey, fieldIds, readOnly, onValue, onField, }) {
    const tGeneratedValue = useGeneratedValueTranslations();
    return (_jsx(Field, { label: tGeneratedValue(label), children: _jsxs("div", { className: "flex items-center gap-1.5", children: [_jsx(Input, { type: "number", min: "0", className: "h-8 w-20", value: String(value), disabled: readOnly || !!fieldKey, onChange: (e) => onValue(Math.floor(Number(e.target.value) || 0)) }), _jsx("span", { className: "text-xs text-fg-subtle text-fg-muted", children: _jsx(GeneratedText, { id: "m_0e0bbc9cd7e263" }) }), _jsxs(Select, { className: "h-8 flex-1", value: fieldKey ?? '', disabled: readOnly, onChange: (e) => onField(e.target.value || undefined), children: [_jsx("option", { value: "", children: '— fixed value —' }), fieldIds.map((f) => (_jsxs("option", { value: f, children: ['bind:', " ", f] }, f)))] })] }) }));
}
function defaultAction(kind, fields) {
    switch (kind) {
        case 'send_email':
            return { action: 'send_email', to: [{ type: 'submitter' }], subject: '', bodyTemplate: '' };
        case 'create_capa':
            return { action: 'create_capa', titleTemplate: '', severity: 'medium' };
        case 'create_incident':
            return { action: 'create_incident', titleTemplate: '' };
        case 'notify_role':
            return { action: 'notify_role', role: '', message: '' };
        case 'set_field':
            return {
                action: 'set_field',
                field: fields.writable[0] ?? '',
                value: { kind: 'literal', value: '' },
            };
        case 'flag_non_compliant':
            return { action: 'flag_non_compliant' };
        case 'webhook':
            return { action: 'webhook', url: '', method: 'POST' };
        case 'create_response':
            return { action: 'create_response', templateId: '' };
        case 'analyze_photos':
            return { action: 'analyze_photos', fieldId: fields.photoSources[0] ?? '' };
        case 'start_monitored_session':
            return {
                action: 'start_monitored_session',
                intervalMinutes: 30,
                graceMinutes: 10,
                durationMinutes: 120,
                requireGeo: false,
            };
        case 'change_status':
            return { action: 'change_status', to: '' };
        case 'duplicate_record':
            return { action: 'duplicate_record' };
        case 'export_pdf':
            return { action: 'export_pdf' };
    }
}
function Field({ label, children }) {
    return (_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { className: "text-xs", children: _jsx(GeneratedValue, { value: label }) }), _jsx(GeneratedValue, { value: children })] }));
}
//# sourceMappingURL=workflow-studio.js.map