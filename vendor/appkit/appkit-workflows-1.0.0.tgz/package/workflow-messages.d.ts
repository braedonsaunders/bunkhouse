import * as React from 'react';
export type WorkflowMessages = Record<string, string>;
export declare function WorkflowMessagesProvider({ messages, children, }: {
    messages: WorkflowMessages;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function useGeneratedTranslations(): (id: string, values?: Record<string, unknown>) => string;
export declare function useGeneratedValueTranslations(): <T>(value: T) => T;
export declare function GeneratedText({ id, values }: {
    id: string;
    values?: Record<string, unknown>;
}): React.JSX.Element;
export declare function GeneratedValue({ value }: {
    value: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=workflow-messages.d.ts.map