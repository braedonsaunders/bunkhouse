export type WorkflowDecision = 'approved' | 'rejected';
export type WorkflowGateStatus = 'pending' | WorkflowDecision | 'cancelled' | 'escalated';
export type WorkflowQuorum = 'any' | 'all';
export type WorkflowRunStatus = 'running' | 'waiting' | 'completed' | 'failed' | 'cancelled';
export type WorkflowAction = {
    kind: 'action';
    key: string;
    type: string;
    input?: Record<string, unknown>;
};
export type WorkflowGate = {
    kind: 'gate';
    key: string;
    assigneeIds: string[];
    quorum?: WorkflowQuorum;
    input?: Record<string, unknown>;
    onApprove?: WorkflowPlan;
    onReject?: WorkflowPlan;
};
export type WorkflowStep = WorkflowAction | WorkflowGate;
export type WorkflowPlan = {
    steps: WorkflowStep[];
};
export type WorkflowRun = {
    id: string;
    tenantId: string;
    workflowKey: string;
    subjectType: string;
    subjectId: string;
    status: WorkflowRunStatus;
    context: Record<string, unknown>;
    error?: string;
};
export type WorkflowGateRecord = {
    id: string;
    runId: string;
    gateKey: string;
    assigneeId: string;
    quorum: WorkflowQuorum;
    status: WorkflowGateStatus;
    gate: WorkflowGate;
    decidedAt?: Date;
};
export type WorkflowActionHandler = (args: {
    run: WorkflowRun;
    action: WorkflowAction;
    signal?: AbortSignal;
}) => Promise<unknown>;
export type WorkflowActionRegistry = Readonly<Record<string, WorkflowActionHandler>>;
/** Durable seam: the host owns transactions, locking, and tenancy. */
export interface WorkflowStore {
    createRun(input: Omit<WorkflowRun, 'id' | 'status'>): Promise<WorkflowRun>;
    getRun(runId: string): Promise<WorkflowRun | null>;
    setRunStatus(runId: string, status: WorkflowRunStatus, error?: string): Promise<void>;
    /** Atomically flips waiting → running. Exactly one concurrent gate decision may resume. */
    claimRunResume(runId: string): Promise<boolean>;
    claimAction(runId: string, actionKey: string): Promise<boolean>;
    completeAction(runId: string, actionKey: string, output: unknown): Promise<void>;
    failAction(runId: string, actionKey: string, error: string): Promise<void>;
    createGateGroup(runId: string, gate: WorkflowGate): Promise<WorkflowGateRecord[]>;
    listGateGroup(runId: string, gateKey: string): Promise<WorkflowGateRecord[]>;
    decideGate(gateId: string, assigneeId: string, decision: WorkflowDecision): Promise<WorkflowGateRecord | null>;
    cancelGates(gateIds: readonly string[]): Promise<void>;
}
export interface WorkflowPlanner<TEvent = unknown> {
    plan(event: TEvent): Promise<{
        workflowKey: string;
        subjectType: string;
        subjectId: string;
        context?: Record<string, unknown>;
        plan: WorkflowPlan;
    } | null>;
}
export type WorkflowRuntime = {
    store: WorkflowStore;
    actions: WorkflowActionRegistry;
    signal?: AbortSignal;
};
export declare function dispatchWorkflow<TEvent>(runtime: WorkflowRuntime, tenantId: string, planner: WorkflowPlanner<TEvent>, event: TEvent): Promise<WorkflowRun | null>;
export declare function executeWorkflowPlan(runtime: WorkflowRuntime, run: WorkflowRun, plan: WorkflowPlan): Promise<void>;
export declare function decideWorkflowGate(runtime: WorkflowRuntime, args: {
    gateId: string;
    assigneeId: string;
    decision: WorkflowDecision;
    gate?: WorkflowGate;
    canDecide?: (assigneeId: string) => boolean | Promise<boolean>;
}): Promise<'waiting' | WorkflowDecision>;
export declare function resolveQuorumOutcome(quorum: WorkflowQuorum, decision: WorkflowDecision, siblings: readonly Pick<WorkflowGateRecord, 'id' | 'status'>[]): {
    resume: WorkflowDecision | null;
    cancelIds: string[];
};
/** Deterministic in-memory reference store for tests, previews, and edge runtimes. */
export declare function createMemoryWorkflowStore(): WorkflowStore & {
    runs: Map<string, WorkflowRun>;
    gates: Map<string, WorkflowGateRecord>;
    actionOutputs: Map<string, unknown>;
};
//# sourceMappingURL=runtime.d.ts.map