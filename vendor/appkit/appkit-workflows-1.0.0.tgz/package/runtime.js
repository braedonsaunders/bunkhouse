export async function dispatchWorkflow(runtime, tenantId, planner, event) {
    const planned = await planner.plan(event);
    if (!planned)
        return null;
    const run = await runtime.store.createRun({
        tenantId,
        workflowKey: planned.workflowKey,
        subjectType: planned.subjectType,
        subjectId: planned.subjectId,
        context: planned.context ?? {},
    });
    await executeWorkflowPlan(runtime, run, planned.plan);
    return await runtime.store.getRun(run.id);
}
export async function executeWorkflowPlan(runtime, run, plan) {
    await runtime.store.setRunStatus(run.id, 'running');
    try {
        for (const step of plan.steps) {
            if (runtime.signal?.aborted)
                throw runtime.signal.reason instanceof Error
                    ? runtime.signal.reason
                    : new Error('Workflow aborted');
            if (step.kind === 'gate') {
                if (step.assigneeIds.length === 0)
                    throw new Error(`Gate ${step.key} has no assignees`);
                await runtime.store.createGateGroup(run.id, step);
                await runtime.store.setRunStatus(run.id, 'waiting');
                return;
            }
            const handler = runtime.actions[step.type];
            if (!handler)
                throw new Error(`No workflow action handler registered for ${step.type}`);
            if (!(await runtime.store.claimAction(run.id, step.key)))
                continue;
            try {
                const output = await handler({
                    run,
                    action: step,
                    signal: runtime.signal,
                });
                await runtime.store.completeAction(run.id, step.key, output);
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                await runtime.store.failAction(run.id, step.key, message);
                throw error;
            }
        }
        await runtime.store.setRunStatus(run.id, 'completed');
    }
    catch (error) {
        await runtime.store.setRunStatus(run.id, 'failed', error instanceof Error ? error.message : String(error));
        throw error;
    }
}
export async function decideWorkflowGate(runtime, args) {
    if (args.canDecide && !(await args.canDecide(args.assigneeId)))
        throw new Error('Not authorized to decide this workflow gate');
    const decided = await runtime.store.decideGate(args.gateId, args.assigneeId, args.decision);
    if (!decided)
        throw new Error('Workflow gate is unavailable or already decided');
    const siblings = await runtime.store.listGateGroup(decided.runId, decided.gateKey);
    const outcome = resolveQuorumOutcome(decided.quorum, args.decision, siblings);
    if (!outcome.resume)
        return 'waiting';
    await runtime.store.cancelGates(outcome.cancelIds);
    if (!(await runtime.store.claimRunResume(decided.runId)))
        return outcome.resume;
    const run = await runtime.store.getRun(decided.runId);
    if (!run)
        throw new Error('Workflow run no longer exists');
    const gate = args.gate ?? decided.gate;
    await executeWorkflowPlan(runtime, run, outcome.resume === 'approved'
        ? (gate.onApprove ?? { steps: [] })
        : (gate.onReject ?? { steps: [] }));
    return outcome.resume;
}
export function resolveQuorumOutcome(quorum, decision, siblings) {
    const cancellable = siblings
        .filter((sibling) => sibling.status === 'pending' || sibling.status === 'escalated')
        .map((sibling) => sibling.id);
    if (quorum === 'any')
        return { resume: decision, cancelIds: cancellable };
    if (decision === 'rejected')
        return { resume: 'rejected', cancelIds: cancellable };
    if (siblings.some((sibling) => sibling.status === 'pending'))
        return { resume: null, cancelIds: [] };
    return {
        resume: siblings.some((sibling) => sibling.status === 'rejected')
            ? 'rejected'
            : 'approved',
        cancelIds: cancellable,
    };
}
/** Deterministic in-memory reference store for tests, previews, and edge runtimes. */
export function createMemoryWorkflowStore() {
    const runs = new Map();
    const gates = new Map();
    const actionOutputs = new Map();
    const claimed = new Set();
    return {
        runs,
        gates,
        actionOutputs,
        async createRun(input) {
            const run = {
                ...input,
                id: crypto.randomUUID(),
                status: 'running',
            };
            runs.set(run.id, run);
            return run;
        },
        async getRun(id) {
            return runs.get(id) ?? null;
        },
        async setRunStatus(id, status, error) {
            const run = runs.get(id);
            if (!run)
                throw new Error('Workflow run not found');
            runs.set(id, { ...run, status, ...(error ? { error } : {}) });
        },
        async claimRunResume(id) {
            const run = runs.get(id);
            if (!run || run.status !== 'waiting')
                return false;
            runs.set(id, { ...run, status: 'running' });
            return true;
        },
        async claimAction(runId, key) {
            const ref = `${runId}:${key}`;
            if (claimed.has(ref))
                return false;
            claimed.add(ref);
            return true;
        },
        async completeAction(runId, key, output) {
            actionOutputs.set(`${runId}:${key}`, output);
        },
        async failAction(runId, key, error) {
            const ref = `${runId}:${key}`;
            actionOutputs.set(ref, { error });
            claimed.delete(ref);
        },
        async createGateGroup(runId, gate) {
            const existing = [...gates.values()].filter((row) => row.runId === runId && row.gateKey === gate.key);
            if (existing.length)
                return existing;
            return gate.assigneeIds.map((assigneeId) => {
                const row = {
                    id: crypto.randomUUID(),
                    runId,
                    gateKey: gate.key,
                    assigneeId,
                    quorum: gate.quorum ?? 'any',
                    status: 'pending',
                    gate,
                };
                gates.set(row.id, row);
                return row;
            });
        },
        async listGateGroup(runId, gateKey) {
            return [...gates.values()].filter((row) => row.runId === runId && row.gateKey === gateKey);
        },
        async decideGate(id, assigneeId, decision) {
            const row = gates.get(id);
            if (!row || row.assigneeId !== assigneeId || row.status !== 'pending')
                return null;
            const decided = { ...row, status: decision, decidedAt: new Date() };
            gates.set(id, decided);
            return decided;
        },
        async cancelGates(ids) {
            for (const id of ids) {
                const row = gates.get(id);
                if (row && (row.status === 'pending' || row.status === 'escalated'))
                    gates.set(id, { ...row, status: 'cancelled' });
            }
        },
    };
}
//# sourceMappingURL=runtime.js.map