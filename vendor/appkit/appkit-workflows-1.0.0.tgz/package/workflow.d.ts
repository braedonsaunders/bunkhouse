export type WorkflowNodeData = {
    kind: string;
    label?: string;
    [key: string]: unknown;
};
export type WorkflowNode<TData extends WorkflowNodeData = WorkflowNodeData> = {
    id: string;
    position: {
        x: number;
        y: number;
    };
    data: TData;
};
export type WorkflowEdge = {
    id: string;
    source: string;
    target: string;
    sourceHandle?: string;
};
export type WorkflowGraph<TData extends WorkflowNodeData = WorkflowNodeData> = {
    schemaVersion: 1;
    nodes: WorkflowNode<TData>[];
    edges: WorkflowEdge[];
};
export type WorkflowNodeDefinition<TData extends WorkflowNodeData = WorkflowNodeData> = {
    kind: TData['kind'];
    label: string;
    description?: string;
    group?: string;
    branches?: string[];
    create: () => TData;
};
export declare const emptyWorkflowGraph: <TData extends WorkflowNodeData>() => WorkflowGraph<TData>;
export declare const workflowNodeId: (kind: string) => string;
export declare function lintWorkflowGraph<TData extends WorkflowNodeData>(graph: WorkflowGraph<TData>, definitions: readonly WorkflowNodeDefinition<TData>[]): string[];
export declare function hasCycle(graph: WorkflowGraph): boolean;
export declare function removeWorkflowNode<TData extends WorkflowNodeData>(graph: WorkflowGraph<TData>, id: string): WorkflowGraph<TData>;
export declare function updateWorkflowNode<TData extends WorkflowNodeData>(graph: WorkflowGraph<TData>, id: string, data: TData): WorkflowGraph<TData>;
export type WorkflowGraphLimits = {
    maxBytes?: number;
    maxNodes?: number;
    maxEdges?: number;
    maxIdLength?: number;
    requireTrigger?: boolean;
};
/** Persistence-boundary validation for durable workflow definitions. */
export declare function validateWorkflowGraph(graph: WorkflowGraph, limits?: WorkflowGraphLimits): string[];
//# sourceMappingURL=workflow.d.ts.map