import * as React from 'react';
import { type PromptDialogOptions } from '@appkit/ui';
import { type ApprovalEventType, type RecordApprovalAdapter, type RecordApprovalState, type RecordApprovalSubject } from './record-approval.js';
export interface ApprovalFlowLabels {
    approve: string;
    reject: string;
    rejectTitle: string;
    rejectReasonLabel: string;
    pendingWith(names: string): string;
    alreadyDecided: string;
    decisionFailed: string;
    waitingOthers: string;
    approved: string;
    rejected: string;
    historyTitle: string;
    event(type: ApprovalEventType): string;
    delegatedBadge: string;
    escalatedBadge: string;
}
export interface ApprovalFeedback {
    info(message: string): void;
    success(message: string): void;
    error(message: string): void;
}
export interface RecordApprovalProviderProps {
    adapter: RecordApprovalAdapter;
    children: React.ReactNode;
    labels?: Partial<ApprovalFlowLabels>;
    locale?: string;
    feedback?: ApprovalFeedback;
    /** Host refresh seam, for example an App Router `router.refresh`. */
    onRefresh?: () => void | Promise<void>;
}
export declare function RecordApprovalProvider({ adapter, children, labels, locale, feedback, onRefresh, }: RecordApprovalProviderProps): React.JSX.Element;
export type RecordApprovalSnapshot = {
    state: RecordApprovalState | null;
    loading: boolean;
    error: Error | null;
};
/** Re-fetches every mounted record approval surface, preserving the source API. */
export declare function refreshApprovalState(): Promise<void>;
export declare function useRecordApprovalStateResult(subjectKind: string, subjectId: string, adapterOverride?: RecordApprovalAdapter): RecordApprovalSnapshot;
/** Source-compatible state hook. Use the result variant when loading/error UI is needed. */
export declare function useRecordApprovalState(subjectKind: string, subjectId: string, adapterOverride?: RecordApprovalAdapter): RecordApprovalState | null;
export interface ApprovalActionsProps extends RecordApprovalSubject {
    adapter?: RecordApprovalAdapter;
    labels?: Partial<ApprovalFlowLabels>;
    requestReason?: (options: PromptDialogOptions) => Promise<string | null>;
    onRefresh?: () => void | Promise<void>;
}
export declare function ApprovalActions({ subjectKind, subjectId, adapter: adapterOverride, labels: labelOverrides, requestReason, onRefresh, }: ApprovalActionsProps): React.JSX.Element | null;
export interface ApprovalHistoryProps extends RecordApprovalSubject {
    adapter?: RecordApprovalAdapter;
    labels?: Partial<ApprovalFlowLabels>;
    locale?: string;
    defaultOpen?: boolean;
}
export declare function ApprovalHistory({ subjectKind, subjectId, adapter, labels: labelOverrides, locale, defaultOpen, }: ApprovalHistoryProps): React.JSX.Element | null;
export declare function formatApprovalRelativeTime(iso: string, locale: string, now?: number): string;
//# sourceMappingURL=record-approval-react.d.ts.map