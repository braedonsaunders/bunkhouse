'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowUpRight, CheckCircle2, ChevronDown, ChevronRight, Send, UserCheck, UserPlus, Users, XCircle, } from 'lucide-react';
import { Badge, Button, promptDialog, toast } from '@appkit/ui';
import { createHttpRecordApprovalAdapter, } from './record-approval.js';
const defaultLabels = {
    approve: 'Approve',
    reject: 'Reject',
    rejectTitle: 'Reject approval',
    rejectReasonLabel: 'Reason for rejection',
    pendingWith: (names) => `Pending with ${names}`,
    alreadyDecided: 'This approval was already decided.',
    decisionFailed: 'The approval decision could not be saved.',
    waitingOthers: 'Decision saved. Waiting for the other approvers.',
    approved: 'Approved',
    rejected: 'Rejected',
    historyTitle: 'Approvals',
    event: (type) => ({
        submitted: 'Submitted',
        requested: 'Approval requested',
        approved: 'Approved',
        rejected: 'Rejected',
        escalated: 'Escalated',
        delegated: 'Delegated',
    })[type],
    delegatedBadge: 'Delegated',
    escalatedBadge: 'Escalated',
};
const defaultFeedback = {
    info: (message) => toast.info(message),
    success: (message) => toast.success(message),
    error: (message) => toast.error(message),
};
const defaultAdapter = createHttpRecordApprovalAdapter();
const ApprovalContext = React.createContext({
    adapter: defaultAdapter,
    labels: defaultLabels,
    locale: 'en',
    feedback: defaultFeedback,
});
export function RecordApprovalProvider({ adapter, children, labels, locale = 'en', feedback = defaultFeedback, onRefresh, }) {
    const value = React.useMemo(() => ({ adapter, labels: { ...defaultLabels, ...labels }, locale, feedback, onRefresh }), [adapter, labels, locale, feedback, onRefresh]);
    return _jsx(ApprovalContext.Provider, { value: value, children: children });
}
const initialSnapshot = { state: null, loading: false, error: null };
const storesByAdapter = new WeakMap();
const activeStores = new Set();
function getStore(adapter, subject) {
    let adapterStores = storesByAdapter.get(adapter);
    if (!adapterStores) {
        adapterStores = new Map();
        storesByAdapter.set(adapter, adapterStores);
    }
    const key = `${subject.subjectKind}\u0000${subject.subjectId}`;
    const existing = adapterStores.get(key);
    if (existing)
        return existing;
    let snapshot = initialSnapshot;
    let loaded = false;
    let pending = null;
    const listeners = new Set();
    const emit = () => {
        for (const listener of listeners)
            listener();
    };
    const store = {
        adapter,
        subject: { ...subject },
        subscribe(listener) {
            listeners.add(listener);
            activeStores.add(store);
            if (!loaded && !pending)
                void store.refresh();
            return () => {
                listeners.delete(listener);
                if (listeners.size === 0) {
                    activeStores.delete(store);
                    adapterStores.delete(key);
                }
            };
        },
        getSnapshot: () => snapshot,
        async refresh() {
            if (pending)
                return pending;
            snapshot = { ...snapshot, loading: true, error: null };
            emit();
            pending = adapter
                .load(subject)
                .then((state) => {
                loaded = true;
                snapshot = { state, loading: false, error: null };
            })
                .catch((error) => {
                loaded = true;
                snapshot = {
                    state: snapshot.state,
                    loading: false,
                    error: error instanceof Error ? error : new Error(String(error)),
                };
            })
                .finally(() => {
                pending = null;
                emit();
            });
            return pending;
        },
    };
    adapterStores.set(key, store);
    return store;
}
/** Re-fetches every mounted record approval surface, preserving the source API. */
export async function refreshApprovalState() {
    await Promise.all([...activeStores].map((store) => store.refresh()));
}
export function useRecordApprovalStateResult(subjectKind, subjectId, adapterOverride) {
    const context = React.useContext(ApprovalContext);
    const adapter = adapterOverride ?? context.adapter;
    const store = React.useMemo(() => getStore(adapter, { subjectKind, subjectId }), [adapter, subjectKind, subjectId]);
    return React.useSyncExternalStore(store.subscribe, store.getSnapshot, () => initialSnapshot);
}
/** Source-compatible state hook. Use the result variant when loading/error UI is needed. */
export function useRecordApprovalState(subjectKind, subjectId, adapterOverride) {
    return useRecordApprovalStateResult(subjectKind, subjectId, adapterOverride).state;
}
export function ApprovalActions({ subjectKind, subjectId, adapter: adapterOverride, labels: labelOverrides, requestReason = promptDialog, onRefresh, }) {
    const context = React.useContext(ApprovalContext);
    const adapter = adapterOverride ?? context.adapter;
    const labels = { ...context.labels, ...labelOverrides };
    const snapshot = useRecordApprovalStateResult(subjectKind, subjectId, adapter);
    const store = React.useMemo(() => getStore(adapter, { subjectKind, subjectId }), [adapter, subjectKind, subjectId]);
    const [busy, setBusy] = React.useState(false);
    const decide = React.useCallback(async (decision) => {
        const gateId = snapshot.state?.approvalState.myActions?.gateId;
        if (!gateId)
            return;
        let comment;
        if (decision === 'rejected') {
            const reason = await requestReason({
                title: labels.rejectTitle,
                label: labels.rejectReasonLabel,
                confirmLabel: labels.reject,
            });
            if (!reason)
                return;
            comment = reason;
        }
        setBusy(true);
        try {
            const result = await adapter.decide({ subjectKind, subjectId, gateId, decision, comment });
            if (result.outcome === 'already-decided')
                context.feedback.info(labels.alreadyDecided);
            else if (result.outcome === 'waiting')
                context.feedback.success(labels.waitingOthers);
            else
                context.feedback.success(result.outcome === 'approved' ? labels.approved : labels.rejected);
            await store.refresh();
            await (onRefresh ?? context.onRefresh)?.();
        }
        catch (error) {
            context.feedback.error(error instanceof Error && error.message ? error.message : labels.decisionFailed);
        }
        finally {
            setBusy(false);
        }
    }, [adapter, context, labels, onRefresh, requestReason, snapshot.state, store, subjectId, subjectKind]);
    const state = snapshot.state;
    if (!state || (!state.approvalState.myActions && state.approvalState.pendingWith.length === 0))
        return null;
    if (state.approvalState.myActions) {
        return (_jsxs(_Fragment, { children: [_jsx(Button, { disabled: busy, onClick: () => void decide('approved'), className: "bg-success text-success-fg hover:bg-success/90 active:bg-success/80", children: labels.approve }), _jsx(Button, { variant: "outline", disabled: busy, onClick: () => void decide('rejected'), children: labels.reject })] }));
    }
    const names = state.approvalState.pendingWith.map((pending) => pending.name).join(', ');
    const text = labels.pendingWith(names);
    return (_jsxs("span", { className: "inline-flex max-w-64 items-center gap-1.5 truncate rounded-full border border-warning/30 bg-warning-subtle px-2.5 py-1 text-xs font-medium text-warning", title: text, children: [_jsx(Users, { className: "size-3.5 shrink-0", "aria-hidden": "true" }), _jsx("span", { className: "truncate", children: text })] }));
}
const eventIcon = {
    submitted: Send,
    requested: UserPlus,
    approved: CheckCircle2,
    rejected: XCircle,
    escalated: ArrowUpRight,
    delegated: UserCheck,
};
const eventTone = {
    submitted: 'text-fg-muted',
    requested: 'text-fg-muted',
    approved: 'text-success',
    rejected: 'text-danger',
    escalated: 'text-warning',
    delegated: 'text-fg-muted',
};
export function ApprovalHistory({ subjectKind, subjectId, adapter, labels: labelOverrides, locale, defaultOpen = true, }) {
    const context = React.useContext(ApprovalContext);
    const labels = { ...context.labels, ...labelOverrides };
    const state = useRecordApprovalState(subjectKind, subjectId, adapter);
    const [open, setOpen] = React.useState(defaultOpen);
    const history = state?.history ?? [];
    if (history.length === 0)
        return null;
    const Chevron = open ? ChevronDown : ChevronRight;
    return (_jsxs("section", { className: "overflow-hidden rounded-lg border border-border", children: [_jsxs("button", { type: "button", onClick: () => setOpen((value) => !value), "aria-expanded": open, className: "flex w-full items-center gap-2 px-3 py-2 text-left text-sm font-medium text-fg transition-colors hover:bg-surface-hover", children: [_jsx(Chevron, { className: "size-4 text-fg-subtle", "aria-hidden": "true" }), labels.historyTitle, _jsx("span", { className: "text-xs font-normal text-fg-subtle", children: history.length })] }), open ? (_jsx("ol", { className: "divide-y divide-border-subtle border-t border-border", children: history.map((entry) => (_jsx(ApprovalHistoryRow, { entry: entry, labels: labels, locale: locale ?? context.locale }, entry.id))) })) : null] }));
}
function ApprovalHistoryRow({ entry, labels, locale, }) {
    const Icon = eventIcon[entry.type];
    return (_jsxs("li", { className: "flex items-start gap-2.5 px-3 py-2", children: [_jsx(Icon, { className: `mt-0.5 size-4 shrink-0 ${eventTone[entry.type]}`, "aria-hidden": "true" }), _jsxs("div", { className: "min-w-0 flex-1 text-sm", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-x-2 gap-y-0.5", children: [_jsx("span", { className: "font-medium text-fg", children: labels.event(entry.type) }), entry.actor ? _jsx("span", { className: "text-fg-muted", children: entry.actor }) : null, entry.title ? _jsx("span", { className: "truncate text-xs text-fg-subtle", children: entry.title }) : null, entry.delegated ? _jsx(Badge, { variant: "outline", children: labels.delegatedBadge }) : null, entry.type === 'escalated' ? _jsx(Badge, { variant: "warning", children: labels.escalatedBadge }) : null, _jsx("span", { className: "ml-auto shrink-0 text-xs text-fg-subtle", title: new Date(entry.at).toLocaleString(locale), children: formatApprovalRelativeTime(entry.at, locale) })] }), entry.comment ? (_jsx("p", { className: `mt-0.5 text-xs ${entry.type === 'rejected' ? 'text-danger' : 'text-fg-muted'}`, children: entry.comment })) : null] })] }));
}
const relativeUnits = [
    ['year', 31_536_000],
    ['month', 2_592_000],
    ['week', 604_800],
    ['day', 86_400],
    ['hour', 3_600],
    ['minute', 60],
];
export function formatApprovalRelativeTime(iso, locale, now = Date.now()) {
    const seconds = (new Date(iso).getTime() - now) / 1000;
    if (Number.isNaN(seconds))
        return '';
    const formatter = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });
    for (const [unit, size] of relativeUnits) {
        if (Math.abs(seconds) >= size)
            return formatter.format(Math.round(seconds / size), unit);
    }
    return formatter.format(Math.round(seconds), 'second');
}
//# sourceMappingURL=record-approval-react.js.map