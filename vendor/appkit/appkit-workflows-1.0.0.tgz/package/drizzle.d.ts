import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { WorkflowStore } from './runtime.js';
type Db = NodePgDatabase<Record<string, never>>;
export declare function createDrizzleWorkflowStore(db: Db, tenantId: string): WorkflowStore;
export {};
//# sourceMappingURL=drizzle.d.ts.map