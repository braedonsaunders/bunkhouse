import type { WorkflowDecision, WorkflowQuorum } from './runtime.js';
export type ApprovalEventType = 'submitted' | 'requested' | 'approved' | 'rejected' | 'escalated' | 'delegated';
export interface PendingWithEntry {
    name: string;
    gateId?: string;
    /** ISO timestamp the assignment has been waiting since. */
    since: string;
}
export interface ApprovalHistoryEntry {
    id: string;
    type: ApprovalEventType;
    /** Display name of the actor, or the assignee for a request event. */
    actor: string | null;
    comment: string | null;
    /** ISO timestamp. */
    at: string;
    title?: string;
    delegated?: boolean;
}
export interface RecordApprovalState {
    approvalState: {
        status: string;
        pendingWith: PendingWithEntry[];
        myActions: {
            gateId?: string;
        } | null;
    };
    history: ApprovalHistoryEntry[];
}
export type RecordApprovalSubject = {
    subjectKind: string;
    subjectId: string;
};
export type RecordApprovalDecisionInput = RecordApprovalSubject & {
    gateId: string;
    decision: WorkflowDecision;
    comment?: string;
};
export type RecordApprovalDecisionResult = {
    outcome: 'already-decided';
} | {
    outcome: 'waiting';
} | {
    outcome: WorkflowDecision;
};
/** Application boundary for record status, viewer authorization, and decisions. */
export interface RecordApprovalAdapter {
    load(subject: RecordApprovalSubject, signal?: AbortSignal): Promise<RecordApprovalState | null>;
    decide(input: RecordApprovalDecisionInput): Promise<RecordApprovalDecisionResult>;
}
export declare class RecordApprovalRequestError extends Error {
    readonly status: number;
    constructor(message: string, status: number);
}
export interface HttpRecordApprovalAdapterOptions {
    stateEndpoint?: string;
    decisionEndpoint?: string;
    fetcher?: typeof fetch;
}
/**
 * Source-compatible HTTP adapter. Its defaults preserve the production route
 * and request body contract while allowing hosts to relocate both endpoints.
 */
export declare function createHttpRecordApprovalAdapter({ stateEndpoint, decisionEndpoint, fetcher, }?: HttpRecordApprovalAdapterOptions): RecordApprovalAdapter;
export interface MemoryRecordApprovalSeed extends RecordApprovalSubject {
    state: RecordApprovalState;
    /** Gate-group quorum used to project the next record state. Defaults to all. */
    quorum?: WorkflowQuorum;
}
export interface MemoryRecordApprovalAdapterOptions {
    seed?: readonly MemoryRecordApprovalSeed[];
    actor?: string | null;
    now?: () => Date;
    createId?: () => string;
}
export interface MemoryRecordApprovalAdapter extends RecordApprovalAdapter {
    reset(seed: readonly MemoryRecordApprovalSeed[]): void;
    inspect(subject: RecordApprovalSubject): RecordApprovalState | null;
}
/** Browser-local implementation with the same state transitions as the HTTP seam. */
export declare function createMemoryRecordApprovalAdapter({ seed, actor, now, createId, }?: MemoryRecordApprovalAdapterOptions): MemoryRecordApprovalAdapter;
//# sourceMappingURL=record-approval.d.ts.map