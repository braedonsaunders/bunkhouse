export const emptyWorkflowGraph = () => ({ schemaVersion: 1, nodes: [], edges: [] });
export const workflowNodeId = (kind) => `${kind}_${globalThis.crypto.randomUUID()}`;
export function lintWorkflowGraph(graph, definitions) {
    const errors = [];
    const definitionMap = new Map(definitions.map((definition) => [definition.kind, definition]));
    const ids = new Set();
    for (const node of graph.nodes) {
        if (ids.has(node.id))
            errors.push(`Duplicate node id: ${node.id}`);
        ids.add(node.id);
        if (!definitionMap.has(node.data.kind))
            errors.push(`Node ${node.id} has unknown kind "${node.data.kind}"`);
        if (!Number.isFinite(node.position.x) || !Number.isFinite(node.position.y))
            errors.push(`Node ${node.id} has an invalid position`);
    }
    const edgeIds = new Set();
    for (const edge of graph.edges) {
        if (edgeIds.has(edge.id))
            errors.push(`Duplicate edge id: ${edge.id}`);
        edgeIds.add(edge.id);
        if (!ids.has(edge.source))
            errors.push(`Edge ${edge.id} has an unknown source`);
        if (!ids.has(edge.target))
            errors.push(`Edge ${edge.id} has an unknown target`);
        const source = graph.nodes.find((node) => node.id === edge.source);
        const branches = source ? definitionMap.get(source.data.kind)?.branches : undefined;
        if (edge.sourceHandle && branches?.length && !branches.includes(edge.sourceHandle))
            errors.push(`Edge ${edge.id} has an invalid source branch`);
    }
    if (hasCycle(graph))
        errors.push('Workflow contains a cycle');
    return errors;
}
export function hasCycle(graph) {
    const outgoing = new Map();
    for (const edge of graph.edges)
        outgoing.set(edge.source, [...(outgoing.get(edge.source) ?? []), edge.target]);
    const visiting = new Set();
    const visited = new Set();
    const walk = (id) => { if (visiting.has(id))
        return true; if (visited.has(id))
        return false; visiting.add(id); for (const next of outgoing.get(id) ?? [])
        if (walk(next))
            return true; visiting.delete(id); visited.add(id); return false; };
    return graph.nodes.some((node) => walk(node.id));
}
export function removeWorkflowNode(graph, id) { return { ...graph, nodes: graph.nodes.filter((node) => node.id !== id), edges: graph.edges.filter((edge) => edge.source !== id && edge.target !== id) }; }
export function updateWorkflowNode(graph, id, data) { return { ...graph, nodes: graph.nodes.map((node) => node.id === id ? { ...node, data } : node) }; }
/** Persistence-boundary validation for durable workflow definitions. */
export function validateWorkflowGraph(graph, limits = {}) {
    const maxBytes = limits.maxBytes ?? 1024 * 1024;
    const maxNodes = limits.maxNodes ?? 250;
    const maxEdges = limits.maxEdges ?? 500;
    const maxIdLength = limits.maxIdLength ?? 128;
    const errors = [];
    let bytes = Number.POSITIVE_INFINITY;
    try {
        bytes = new TextEncoder().encode(JSON.stringify(graph)).byteLength;
    }
    catch {
        errors.push('Workflow graph is not serializable');
    }
    if (bytes > maxBytes)
        errors.push(`Workflow graph exceeds the ${maxBytes} byte storage limit`);
    if (graph.nodes.length > maxNodes)
        errors.push(`Workflow graph cannot contain more than ${maxNodes} nodes`);
    if (graph.edges.length > maxEdges)
        errors.push(`Workflow graph cannot contain more than ${maxEdges} edges`);
    const nodeIds = new Set();
    for (const node of graph.nodes) {
        if (!node.id || node.id.length > maxIdLength || nodeIds.has(node.id))
            errors.push('Workflow graph contains an invalid or duplicate node id');
        nodeIds.add(node.id);
    }
    if ((limits.requireTrigger ?? true) && graph.nodes.length > 0 && !graph.nodes.some((node) => node.data.kind === 'trigger'))
        errors.push('Workflow graph must contain a trigger');
    const edgeIds = new Set();
    for (const edge of graph.edges) {
        if (!edge.id || edge.id.length > maxIdLength || edgeIds.has(edge.id))
            errors.push('Workflow graph contains an invalid or duplicate edge id');
        if (!nodeIds.has(edge.source) || !nodeIds.has(edge.target))
            errors.push('Workflow graph contains an edge to a missing node');
        edgeIds.add(edge.id);
    }
    return [...new Set(errors)];
}
//# sourceMappingURL=workflow.js.map