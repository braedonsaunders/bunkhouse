# @appkit/workflows

Durable workflow graphs, replay-safe actions, approval gates, and optional React and Drizzle adapters.

## Install

```bash
pnpm add @appkit/workflows
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
