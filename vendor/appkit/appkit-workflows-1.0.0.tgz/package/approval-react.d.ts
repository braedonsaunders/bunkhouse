export * from './record-approval-react.js';
//# sourceMappingURL=approval-react.d.ts.map