import * as React from 'react';
import { type WorkflowGraph, type WorkflowNodeData, type WorkflowNodeDefinition } from './workflow.js';
export type WorkflowBuilderProps<TData extends WorkflowNodeData> = {
    value: WorkflowGraph<TData>;
    onChange: (graph: WorkflowGraph<TData>) => void;
    definitions: readonly WorkflowNodeDefinition<TData>[];
    renderInspector: (input: {
        node: {
            id: string;
            data: TData;
        };
        update: (data: TData) => void;
        remove: () => void;
    }) => React.ReactNode;
    validate?: (graph: WorkflowGraph<TData>) => string[];
    className?: string;
    readOnly?: boolean;
    emptyTitle?: string;
    emptyDescription?: string;
};
export declare function WorkflowBuilder<TData extends WorkflowNodeData>({ value, onChange, definitions, renderInspector, validate, className, readOnly, emptyTitle, emptyDescription }: WorkflowBuilderProps<TData>): React.JSX.Element;
//# sourceMappingURL=workflow-builder.d.ts.map