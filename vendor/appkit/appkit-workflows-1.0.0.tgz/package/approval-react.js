export * from './record-approval-react.js';
//# sourceMappingURL=approval-react.js.map