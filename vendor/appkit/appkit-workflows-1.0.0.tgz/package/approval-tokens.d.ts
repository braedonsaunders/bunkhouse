import type { WorkflowDecision } from './runtime.js';
export declare const APPROVAL_TOKEN_TTL_MS: number;
export type ApprovalTokenClaims = {
    gateId: string;
    decision: WorkflowDecision;
    assigneeId: string;
    expiresAt: number;
};
export declare function createApprovalTokenCodec(options: {
    secret: string;
    baseUrl?: string;
    actionPath?: string;
    now?: () => number;
}): {
    create: (claims: Omit<ApprovalTokenClaims, "expiresAt"> & {
        expiresAt?: number;
    }) => string;
    verify: (token: string) => ApprovalTokenClaims | null;
    urls: (gateId: string, assigneeId: string) => {
        approveUrl: string;
        rejectUrl: string;
    };
};
//# sourceMappingURL=approval-tokens.d.ts.map