import * as React from 'react';
export interface PagedColumn<T> {
    key: string;
    header: React.ReactNode;
    align?: 'left' | 'right';
    cell: (row: T) => React.ReactNode;
    /** Text used for client-side search matching. */
    search?: (row: T) => string;
}
export interface PagedTableLabels {
    searchPlaceholder: string;
    searchLabel: string;
    showing: (from: number, to: number, total: number) => React.ReactNode;
    prev: string;
    next: string;
    pageOf: (page: number, pages: number) => React.ReactNode;
}
export interface PagedTableProps<T> {
    rows: T[];
    columns: PagedColumn<T>[];
    pageSize?: number;
    searchable?: boolean;
    empty: React.ReactNode;
    rowKey: (row: T, index: number) => string;
    rowClassName?: (row: T) => string | undefined;
    labels?: Partial<PagedTableLabels>;
}
/**
 * Client-side searched and paginated table for bounded data already loaded
 * into a page or drawer. The call surface matches the production reference;
 * only localized copy and semantic tokens are injected/generalized.
 */
export declare function PagedTable<T>({ rows, columns, pageSize, searchable, empty, rowKey, rowClassName, labels: labelOverrides, }: PagedTableProps<T>): React.JSX.Element;
//# sourceMappingURL=paged-table.d.ts.map