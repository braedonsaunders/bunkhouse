# @appkit/oauth

OAuth 2.1 client for connecting to MCP and other API servers — protected-resource discovery (RFC 9728), authorization-server metadata (RFC 8414), dynamic client registration (RFC 7591), PKCE, code exchange, and refresh, over hardened public-HTTPS egress.

## Install

```bash
pnpm add @appkit/oauth
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
