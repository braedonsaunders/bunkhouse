/**
 * The OAuth 2.1 client half of connecting to a protected API server — built
 * for MCP servers, whose specification composes RFC 9728 (protected-resource
 * metadata), RFC 8414 (authorization-server metadata), RFC 7591 (dynamic
 * client registration), PKCE, and RFC 8707 (resource indicators).
 *
 * The package is deliberately storage-free: it discovers, registers,
 * exchanges, and refreshes, and the application decides how client
 * registrations and tokens are persisted (sealed, in AppKit applications).
 * Browser-facing state (the `state` parameter, session binding) is likewise
 * the application's responsibility.
 */
export type OAuthAuthorization = {
    /** The RFC 8707 resource indicator tokens are requested for — the server URL. */
    resource: string;
    /** The authorization server's issuer identifier. */
    issuer: string;
    authorizationEndpoint: string;
    tokenEndpoint: string;
    /** Present when the server offers RFC 7591 dynamic client registration. */
    registrationEndpoint?: string;
    scopesSupported?: string[];
};
export type OAuthClient = {
    clientId: string;
    /** Confidential clients only; omitted for public (PKCE-only) registrations. */
    clientSecret?: string;
};
export type OAuthTokens = {
    accessToken: string;
    tokenType: string;
    refreshToken?: string;
    /** Epoch milliseconds the access token expires at, when a lifetime was reported. */
    expiresAt?: number;
    scope?: string;
};
/** RFC 9728 well-known candidates for a protected resource, most specific first. */
export declare function protectedResourceMetadataUrls(serverUrl: string): string[];
/** RFC 8414 / OpenID Connect well-known candidates for an issuer, in order. */
export declare function authorizationServerMetadataUrls(issuer: string): string[];
/**
 * Work out how to sign in to a protected server: read its protected-resource
 * metadata to find the authorization server (falling back to the server's own
 * origin when it publishes none), then read that server's metadata for the
 * endpoints. Throws a readable explanation when the server does not offer
 * OAuth at all.
 */
export declare function discoverAuthorization(serverUrl: string): Promise<OAuthAuthorization>;
/**
 * Register this application with the authorization server (RFC 7591) as a
 * public client — PKCE carries the proof, so no client secret exists to store.
 * Servers that require pre-registered clients simply omit the registration
 * endpoint; the caller should then ask the operator for a client ID.
 */
export declare function registerClient(input: {
    authorization: OAuthAuthorization;
    redirectUri: string;
    clientName: string;
    scope?: string;
}): Promise<OAuthClient>;
/** A fresh PKCE pair (S256). The verifier stays server-side until the exchange. */
export declare function createPkce(): {
    verifier: string;
    challenge: string;
    method: 'S256';
};
/** The consent URL the operator's browser is sent to. */
export declare function buildAuthorizationUrl(input: {
    authorization: OAuthAuthorization;
    clientId: string;
    redirectUri: string;
    codeChallenge: string;
    state: string;
    scope?: string;
}): string;
/** Trade the authorization code for tokens (PKCE verifier proves possession). */
export declare function exchangeAuthorizationCode(input: {
    authorization: Pick<OAuthAuthorization, 'tokenEndpoint' | 'resource'>;
    client: OAuthClient;
    code: string;
    codeVerifier: string;
    redirectUri: string;
}): Promise<OAuthTokens>;
/**
 * Mint a fresh access token from the stored refresh token. Servers may rotate
 * the refresh token; when the result carries one, the caller must persist it
 * before the new access token is used for anything.
 */
export declare function refreshTokens(input: {
    authorization: Pick<OAuthAuthorization, 'tokenEndpoint' | 'resource'>;
    client: OAuthClient;
    refreshToken: string;
    scope?: string;
}): Promise<OAuthTokens>;
export { assertPublicHttpsEndpoint } from './egress.js';
//# sourceMappingURL=index.d.ts.map