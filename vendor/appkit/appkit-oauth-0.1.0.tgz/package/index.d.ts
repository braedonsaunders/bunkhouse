/**
 * The OAuth 2.1 client half of connecting to a protected API server — built
 * for MCP servers, whose specification composes RFC 9728 (protected-resource
 * metadata), RFC 8414 (authorization-server metadata), RFC 7591 (dynamic
 * client registration), PKCE, and RFC 8707 (resource indicators).
 *
 * The package is deliberately storage-free: it discovers, registers,
 * exchanges, and refreshes, and the application decides how client
 * registrations and tokens are persisted (sealed, in AppKit applications).
 * Browser-facing state (the `state` parameter, session binding) is likewise
 * the application's responsibility.
 */
export type OAuthAuthorization = {
    /** The RFC 8707 resource indicator tokens are requested for — the server URL. */
    resource: string;
    /** The authorization server's issuer identifier. */
    issuer: string;
    authorizationEndpoint: string;
    tokenEndpoint: string;
    /** Present when the server offers RFC 7591 dynamic client registration. */
    registrationEndpoint?: string;
    scopesSupported?: string[];
    /** RFC 8414 `grant_types_supported` — which flows this server will run. */
    grantTypesSupported?: string[];
    /** RFC 8414 `token_endpoint_auth_methods_supported`. */
    tokenEndpointAuthMethodsSupported?: string[];
    /**
     * RFC 8414 `token_endpoint_auth_signing_alg_values_supported` — the algorithms
     * a `private_key_jwt` client assertion may be signed with. Worth reading
     * rather than assuming: servers that mandate RSA-PSS (NetSuite) reject an
     * RS256 assertion as `invalid_grant`, which is indistinguishable from a wrong
     * key unless the caller was told the algorithm up front.
     */
    tokenEndpointAuthSigningAlgValuesSupported?: string[];
};
export type OAuthClient = {
    clientId: string;
    /** Confidential clients only; omitted for public (PKCE-only) registrations. */
    clientSecret?: string;
};
export type OAuthTokens = {
    accessToken: string;
    tokenType: string;
    refreshToken?: string;
    /** Epoch milliseconds the access token expires at, when a lifetime was reported. */
    expiresAt?: number;
    scope?: string;
};
/** RFC 9728 well-known candidates for a protected resource, most specific first. */
export declare function protectedResourceMetadataUrls(serverUrl: string): string[];
/** RFC 8414 / OpenID Connect well-known candidates for an issuer, in order. */
export declare function authorizationServerMetadataUrls(issuer: string): string[];
/**
 * Work out how to sign in to a protected server: read its protected-resource
 * metadata to find the authorization server (falling back to the server's own
 * origin when it publishes none), then read that server's metadata for the
 * endpoints. Throws a readable explanation when the server does not offer
 * OAuth at all.
 */
export declare function discoverAuthorization(serverUrl: string): Promise<OAuthAuthorization>;
/**
 * Register this application with the authorization server (RFC 7591) as a
 * public client — PKCE carries the proof, so no client secret exists to store.
 * Servers that require pre-registered clients simply omit the registration
 * endpoint; the caller should then ask the operator for a client ID.
 */
export declare function registerClient(input: {
    authorization: OAuthAuthorization;
    redirectUri: string;
    clientName: string;
    scope?: string;
}): Promise<OAuthClient>;
/** A fresh PKCE pair (S256). The verifier stays server-side until the exchange. */
export declare function createPkce(): {
    verifier: string;
    challenge: string;
    method: 'S256';
};
/** The consent URL the operator's browser is sent to. */
export declare function buildAuthorizationUrl(input: {
    authorization: OAuthAuthorization;
    clientId: string;
    redirectUri: string;
    codeChallenge: string;
    state: string;
    scope?: string;
}): string;
/** Trade the authorization code for tokens (PKCE verifier proves possession). */
export declare function exchangeAuthorizationCode(input: {
    authorization: Pick<OAuthAuthorization, 'tokenEndpoint' | 'resource'>;
    client: OAuthClient;
    code: string;
    codeVerifier: string;
    redirectUri: string;
}): Promise<OAuthTokens>;
/**
 * Mint a fresh access token from the stored refresh token. Servers may rotate
 * the refresh token; when the result carries one, the caller must persist it
 * before the new access token is used for anything.
 */
export declare function refreshTokens(input: {
    authorization: Pick<OAuthAuthorization, 'tokenEndpoint' | 'resource'>;
    client: OAuthClient;
    refreshToken: string;
    scope?: string;
}): Promise<OAuthTokens>;
/**
 * The JWS algorithms a client assertion may be signed with. Servers advertise
 * what they accept in `token_endpoint_auth_signing_alg_values_supported`; RSA
 * keys sign PS256 or RS256, EC keys sign the ES family.
 */
export declare const CLIENT_ASSERTION_ALGORITHMS: readonly ["PS256", "RS256", "ES256", "ES384", "ES512"];
export type ClientAssertionAlgorithm = (typeof CLIENT_ASSERTION_ALGORITHMS)[number];
export declare function isClientAssertionAlgorithm(value: string): value is ClientAssertionAlgorithm;
/**
 * A confidential client that proves itself with a signed assertion instead of
 * a shared secret (RFC 7523 `private_key_jwt`). The private key never leaves
 * this process; the authorization server holds only the matching certificate.
 */
export type PrivateKeyJwtClient = {
    clientId: string;
    /** PEM-encoded private key (PKCS#8 or PKCS#1). */
    privateKey: string;
    algorithm: ClientAssertionAlgorithm;
    /**
     * The assertion's `kid` header, when the server identifies the certificate
     * by one — NetSuite's Certificate ID, issued when the public certificate is
     * mapped to an entity and role.
     */
    keyId?: string;
};
/**
 * Build the RFC 7523 client assertion proving control of the client's key.
 * Exported so a caller can verify a key parses and signs before storing it,
 * without spending a token request to find out.
 */
export declare function createClientAssertion(input: {
    client: PrivateKeyJwtClient;
    /** The assertion's audience — the token endpoint it will be presented to. */
    audience: string;
}): string;
/**
 * Mint an access token with the client-credentials grant, authenticating with
 * a `private_key_jwt` assertion.
 *
 * This flow issues no refresh token, and that is the point of reaching for it:
 * there is no rotating credential to persist, race, or let lapse. The standing
 * secret is the key pair, whose certificate the operator rotates on their own
 * schedule. Every call mints from scratch, so a failure is transient rather
 * than terminal — unlike a refresh token, which is destroyed by its own use.
 */
export declare function mintClientCredentialsToken(input: {
    authorization: Pick<OAuthAuthorization, 'tokenEndpoint' | 'resource'>;
    client: PrivateKeyJwtClient;
    scope?: string;
}): Promise<OAuthTokens>;
export { assertPublicHttpsEndpoint } from './egress.js';
//# sourceMappingURL=index.d.ts.map