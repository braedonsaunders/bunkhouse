export declare function assertPublicHttpsEndpoint(url: URL): Promise<void>;
/** GET a JSON document from a public HTTPS URL; null when the URL 404s or
 *  serves something that is not JSON — callers try the next candidate. */
export declare function getJson(endpoint: string): Promise<Record<string, unknown> | null>;
export type TokenEndpointResponse = {
    access_token?: string;
    token_type?: string;
    refresh_token?: string;
    expires_in?: number;
    scope?: string;
    error?: string;
    error_description?: string;
};
/** Form-POST to a token endpoint; the OAuth error body becomes the message. */
export declare function postForm(endpoint: string, form: URLSearchParams): Promise<TokenEndpointResponse>;
/** POST a JSON document (dynamic client registration). */
export declare function postJson(endpoint: string, body: Record<string, unknown>): Promise<Record<string, unknown>>;
//# sourceMappingURL=egress.d.ts.map