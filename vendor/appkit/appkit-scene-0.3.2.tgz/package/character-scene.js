'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from '@appkit/ui';
import { DEFAULT_WALKING_CONFIG, LOBBY_GROUND, } from './config.js';
import { useElementSize } from './use-animation-frame.js';
import { WalkingCharacter } from './walking-character.js';
/**
 * A stage where characters live: a backdrop, a receding floor, and any number
 * of characters that walk, idle, and sort by depth. Data comes from the
 * application; the scene owns only geometry and motion.
 */
export function CharacterScene({ characters, ground = LOBBY_GROUND, config, children, art, contentZone, onSelect, baseCharacterSize = 150, className, height = 420, }) {
    const [ref, size] = useElementSize();
    const positions = React.useRef(new Map());
    const walking = React.useMemo(() => {
        const zones = [...(config?.exclusionZones ?? DEFAULT_WALKING_CONFIG.exclusionZones)];
        if (contentZone)
            zones.push(contentZone);
        return { ...DEFAULT_WALKING_CONFIG, ...config, exclusionZones: zones };
    }, [config, contentZone]);
    const handlePosition = React.useCallback((id, position) => {
        positions.current.set(id, position);
    }, []);
    const getOtherPositions = React.useCallback((excludeId) => {
        const others = [];
        for (const [id, position] of positions.current)
            if (id !== excludeId)
                others.push(position);
        return others;
    }, []);
    return (_jsxs("div", { ref: ref, className: cn('relative w-full overflow-hidden rounded-xl border border-border', className), style: { height }, children: [_jsx("div", { className: "absolute inset-0", style: { background: backgroundOf(ground.backdropStyle) } }), _jsx("div", { className: "absolute inset-x-0 bottom-0", style: { top: `${ground.horizonY}%`, background: backgroundOf(ground.groundStyle) } }), art ? (_jsx("div", { className: "absolute inset-0 z-[5]", children: art })) : (_jsx("div", { className: "absolute inset-x-0 h-px opacity-40", style: { top: `${ground.horizonY}%`, background: 'var(--color-border)' } })), size.width > 0
                ? characters.map((character) => (_jsx(WalkingCharacter, { character: character, ground: ground, config: walking, containerWidth: size.width, containerHeight: size.height, baseSize: baseCharacterSize, onPositionChange: handlePosition, getOtherPositions: getOtherPositions, ...(onSelect ? { onSelect } : {}) }, character.id)))
                : null, children ? _jsx("div", { className: "relative z-[90] h-full", children: children }) : null] }));
}
function backgroundOf(style) {
    if (style.css)
        return style.css;
    return `linear-gradient(to bottom, ${(style.colors ?? []).join(', ')})`;
}
//# sourceMappingURL=character-scene.js.map