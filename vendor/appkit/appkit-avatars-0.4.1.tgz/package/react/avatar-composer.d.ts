import * as React from 'react';
import { type AvatarComposition, type AvatarPart, type AvatarPartCategory } from '../composition.js';
export declare function AvatarComposer({ composition: initialComposition, parts, categories, onChange, onSave, saving, saveLabel, stageWidth, subjectName, generateAction, }: {
    composition: AvatarComposition;
    parts: readonly AvatarPart[];
    categories: readonly AvatarPartCategory[];
    /** Fires on every committed edit — the caller holds the current document. */
    onChange?: (composition: AvatarComposition) => void;
    /** When given, the composer shows a save button and hands back the document. */
    onSave?: (composition: AvatarComposition) => void;
    saving?: boolean;
    saveLabel?: string;
    stageWidth?: number;
    subjectName?: string;
    /** A route into part generation, shown when the library is thin. */
    generateAction?: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=avatar-composer.d.ts.map