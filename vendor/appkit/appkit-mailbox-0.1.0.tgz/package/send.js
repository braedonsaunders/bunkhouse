import nodemailer from 'nodemailer';
function bracket(id) {
    return id.startsWith('<') ? id : `<${id}>`;
}
/**
 * Send one message over the mailbox's SMTP endpoint. Reply threading is the
 * caller's contract: pass the answered Message-ID and the full chain so every
 * client threads the conversation correctly.
 */
export async function sendMail(conn, args) {
    const transport = nodemailer.createTransport({
        host: conn.smtp.host,
        port: conn.smtp.port,
        secure: conn.smtp.secure,
        auth: { user: conn.username, pass: conn.password },
    });
    try {
        const info = await transport.sendMail({
            from: args.fromName ? { name: args.fromName, address: conn.address } : conn.address,
            to: args.to.map((a) => (a.name ? { name: a.name, address: a.address } : a.address)),
            cc: args.cc?.map((a) => (a.name ? { name: a.name, address: a.address } : a.address)),
            subject: args.subject,
            text: args.text,
            html: args.html,
            inReplyTo: args.inReplyTo ? bracket(args.inReplyTo) : undefined,
            references: args.references?.length ? args.references.map(bracket).join(' ') : undefined,
        });
        return {
            messageId: info.messageId.replace(/^<|>$/g, ''),
            sentAt: new Date(),
        };
    }
    finally {
        transport.close();
    }
}
/** Connectivity check for the connect flow: does SMTP accept our login? */
export async function verifySmtp(conn) {
    const transport = nodemailer.createTransport({
        host: conn.smtp.host,
        port: conn.smtp.port,
        secure: conn.smtp.secure,
        auth: { user: conn.username, pass: conn.password },
    });
    try {
        await transport.verify();
    }
    finally {
        transport.close();
    }
}
//# sourceMappingURL=send.js.map