export { syncMailbox, verifyImap } from './sync.js';
export { sendMail, verifySmtp } from './send.js';
export type { ImapCursor, InboundMessage, MailAddress, MailboxConnection, MailboxStore, SendMailArgs, SendMailResult, SyncResult, } from './types.js';
//# sourceMappingURL=index.d.ts.map