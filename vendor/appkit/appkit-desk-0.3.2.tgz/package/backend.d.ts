/**
 * The backend port and its default Cloud Hypervisor implementation.
 *
 * `DeskBackend` is the seam that keeps the package testable without a
 * hypervisor: the host asks a backend to boot a `DeskLaunchPlan` and gets a
 * `DeskMachine` — a request/response channel to the in-guest agent plus an
 * event subscription. CI and non-KVM developer machines inject an in-memory
 * fake; production uses `cloudHypervisorBackend`, whose process-spawning glue
 * is deliberately thin because everything that can be pure lives in the plan
 * builder and the protocol module.
 */
import { type ChildProcess } from 'node:child_process';
import type { Duplex } from 'node:stream';
import { DeskError, type DeskLaunchPlan, type DeskLauncherIdentity } from './plan.js';
import { type GuestCommand, type GuestEventMessage } from './protocol.js';
/**
 * A request that was in flight when the guest connection dropped.
 *
 * Distinct from a plain `DeskError` because the caller's next move is
 * different: this request may ALREADY HAVE RUN. The frame reached the guest,
 * and whether the guest executed it before the channel went away is not
 * knowable from the host. An `exec` may have sent mail; a `click` may have
 * landed. So the transport refuses to guess — it names the ambiguity and lets
 * the caller decide whether the operation is safe to repeat. Anything that
 * rejects with a plain `DeskError` instead never reached the guest at all.
 */
export declare class DeskRequestFateUnknownError extends DeskError {
    readonly name: string;
}
/**
 * What happened to the transport underneath a machine.
 *
 * `reconnected` means the host lost the guest channel mid-lease and got it
 * back; the desk is usable again. It is NOT a promise that the guest is
 * unchanged — see the note on `onConnectionChange`. `lost` means it will not
 * come back on this VM and the desk needs a fresh boot.
 */
export type DeskConnectionChange = {
    state: 'reconnected';
    deskId: string;
    /** How the previous connection went away. */
    reason: string;
    /** Wall-clock time the desk spent with no channel to its guest. */
    downtimeMs: number;
    /** Reconnects this machine has survived, including this one. */
    reconnects: number;
} | {
    state: 'lost';
    deskId: string;
    /** Why it is gone for good: the VMM exited, or the window ran out. */
    reason: string;
};
/** A booted microVM as the host sees it: one desk, one guest-agent channel. */
export interface DeskMachine {
    readonly deskId: string;
    /**
     * Send one request to the in-guest agent and await its correlated result.
     *
     * Rejects with `DeskError` when the guest reports an error, the request
     * times out, or the connection is gone for good — in that last case the
     * request never left the host, so repeating it is safe.
     *
     * A connection lost mid-lease is re-established rather than fatal: a call
     * that arrives while that is happening WAITS for it instead of failing.
     * A call that was already in flight when the channel dropped rejects with
     * `DeskRequestFateUnknownError`, because the host cannot tell whether the
     * guest ran it.
     */
    request(command: GuestCommand, options?: {
        timeoutMs?: number;
    }): Promise<unknown>;
    /**
     * Subscribe to unsolicited guest events (job exits, frames, focus changes).
     *
     * Subscriptions belong to the machine, not to the socket under it, so they
     * survive a reconnect. What does NOT survive is the guest's own capture
     * state: a guest agent that restarted has no screen, no frame encoder and
     * no video encoder, and a subscriber will simply stop receiving. Watch
     * `onConnectionChange` to notice.
     */
    subscribe(listener: (event: GuestEventMessage) => void): () => void;
    /**
     * Watch the transport under this machine.
     *
     * Optional: a backend whose channel cannot drop has nothing to report. The
     * default backend reports every reconnect, because a reconnect that leaves
     * no trace turns a guest agent restarting every few minutes into a desk that
     * misbehaves for reasons nobody can find.
     */
    onConnectionChange?(listener: (change: DeskConnectionChange) => void): () => void;
    /** Stop the VM. Idempotent; resolves once the VMM process has exited. */
    shutdown(): Promise<void>;
}
export interface DeskBackend {
    boot(plan: DeskLaunchPlan): Promise<DeskMachine>;
}
export type DeskProcessLauncher = (command: string, args: readonly string[], options: {
    identity?: DeskLauncherIdentity;
}) => ChildProcess;
export interface CloudHypervisorBackendOptions {
    /** Spawns the VMM and image tooling; injectable for tests. */
    launcher?: DeskProcessLauncher;
    /** Opens the host side of the vsock Unix socket; injectable for tests. */
    connect?: (socketPath: string) => Duplex;
    platform?: NodeJS.Platform;
    idFactory?: () => string;
    requestTimeoutMs?: number;
    connectTimeoutMs?: number;
    connectRetryDelayMs?: number;
    /** Bound on a single handshake attempt; see attemptHandshake. */
    handshakeTimeoutMs?: number;
    /**
     * How long a machine keeps trying to get its guest channel back after an
     * unexpected drop before declaring the desk lost. Bounded on purpose: the
     * VMM is still alive so a reconnect is cheap and usually fast, but retrying
     * forever against a guest that is never coming back is worse than failing.
     */
    reconnectWindowMs?: number;
    /**
     * First delay between reconnect attempts. It doubles toward a ceiling, so
     * this is the fast first poll rather than the steady rate. Separate from
     * `connectRetryDelayMs`, which is sized for a guest that is still cold
     * booting; here the guest was up a moment ago.
     */
    reconnectRetryDelayMs?: number;
    killGraceMs?: number;
    guestAgentPort?: number;
}
export declare function createCloudHypervisorBackend(options?: CloudHypervisorBackendOptions): DeskBackend;
/** The default backend: real Cloud Hypervisor over a real vsock socket. */
export declare const cloudHypervisorBackend: DeskBackend;
//# sourceMappingURL=backend.d.ts.map