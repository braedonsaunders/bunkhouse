/**
 * The framed JSON protocol spoken between the host and the in-guest agent
 * over vsock. Everything here is pure encode/decode/validate — no sockets, no
 * processes — so the security-critical parsing is unit-testable on any
 * platform, and both the host backend and the guest agent share one message
 * vocabulary.
 *
 * Wire format: a 4-byte big-endian length prefix followed by that many bytes
 * of UTF-8 JSON. Frame sizes are bounded; a peer declaring an oversized frame
 * is a protocol violation and the connection must be dropped, not resynced.
 */
import { Buffer } from 'node:buffer';
import type { A11yNode, DeskFrameFormat, DeskHandoverScope, DeskPoint, DeskPointerButton, DeskVideoChunkKind, WindowInfo } from './events.js';
export declare const FRAME_HEADER_BYTES = 4;
export declare const DEFAULT_MAX_FRAME_BYTES: number;
/** The vsock port the in-guest agent listens on. */
export declare const GUEST_AGENT_VSOCK_PORT = 5252;
export declare class DeskProtocolError extends Error {
    readonly name = "DeskProtocolError";
}
export type GuestInput = {
    type: 'move';
    x: number;
    y: number;
} | {
    type: 'click';
    x: number;
    y: number;
    button: DeskPointerButton;
} | {
    type: 'type';
    text: string;
} | {
    type: 'key';
    combo: string;
} | {
    type: 'scroll';
    x: number;
    y: number;
    dx: number;
    dy: number;
} | {
    type: 'drag';
    from: DeskPoint;
    to: DeskPoint;
};
/** A request body, before the transport assigns its correlation id. */
export type GuestCommand = {
    op: 'ping';
} | {
    op: 'capabilities';
} | {
    op: 'exec';
    command: string;
    args?: readonly string[];
    cwd?: string;
    env?: Readonly<Record<string, string>>;
    timeoutMs?: number;
} | {
    op: 'job-start';
    command: string;
    args?: readonly string[];
    cwd?: string;
    env?: Readonly<Record<string, string>>;
} | {
    op: 'job-signal';
    jobId: string;
    signal: 'SIGTERM' | 'SIGKILL';
} | {
    op: 'screen-start';
    width: number;
    height: number;
} | {
    op: 'screen-stop';
} | {
    op: 'observe';
} | {
    op: 'input';
    input: GuestInput;
} | {
    op: 'a11y-invoke';
    nodeId: string;
    action: string;
} | {
    op: 'launch';
    appId: string;
    args?: readonly string[];
} | {
    op: 'clipboard-read';
} | {
    op: 'clipboard-write';
    text: string;
} | {
    op: 'frames-start';
    fps: number;
    width: number;
    height: number;
    /** Omitted lets the guest choose; a guest that predates this ignores it. */
    format?: DeskFrameFormat;
} | {
    op: 'frames-stop';
} | {
    op: 'video-start';
    fps: number;
    width: number;
    height: number;
} | {
    op: 'video-stop';
} | {
    op: 'handover-begin';
    ttlMs: number;
    scope: DeskHandoverScope;
} | {
    op: 'handover-end';
};
export type GuestOp = GuestCommand['op'];
export type GuestRequest = GuestCommand & {
    id: string;
};
export type GuestResponse = {
    id: string;
    ok: true;
    result: unknown;
} | {
    id: string;
    ok: false;
    error: string;
};
/** Unsolicited guest-to-host messages: job exits, frames, focus changes. */
export type GuestEventMessage = {
    event: 'job-exit';
    jobId: string;
    exitCode: number | null;
    signal: string | null;
} | {
    event: 'frame';
    seq: number;
    width: number;
    height: number;
    data: string;
    /**
     * How `data` is encoded. Absent on the wire means `png`: frames were
     * PNG-only before this field existed, so an older guest paired with a
     * newer host keeps working rather than having its every frame rejected.
     */
    format: DeskFrameFormat;
} | {
    event: 'video-chunk';
    seq: number;
    kind: DeskVideoChunkKind;
    /** RFC 6381, e.g. `avc1.42C020`, read out of the bytes by the guest. */
    codec: string;
    width: number;
    height: number;
    /**
     * Whether a `media` chunk begins at a sync sample. Only a chunk that does
     * can start or resume a decoder; `init` chunks report false because the
     * question does not apply to them.
     */
    keyframe: boolean;
    data: string;
} | {
    event: 'window-focus';
    window: WindowInfo;
};
export type HostBoundMessage = GuestResponse | GuestEventMessage;
/** The wire shape of an exec result, before the host turns it into a snapshot. */
export interface GuestExecResult {
    exitCode: number | null;
    signal: string | null;
    stdout: string;
    stderr: string;
    truncated: boolean;
}
/** The wire shape of an observation; `png` is base64. */
export interface GuestObservation {
    png: string;
    width: number;
    height: number;
    a11y: A11yNode | null;
    windows: WindowInfo[];
    focused: WindowInfo | null;
}
/** Encode one message as a length-prefixed JSON frame. */
export declare function encodeFrame(message: unknown, maxFrameBytes?: number): Buffer;
/**
 * Incremental frame decoder. Feed it arbitrary chunk boundaries; it returns
 * every complete parsed JSON value. A declared frame length beyond the bound
 * or a body that is not valid JSON throws — framing violations are fatal to
 * the connection because there is no way to resynchronize a byte stream whose
 * lengths cannot be trusted.
 */
export declare class FrameDecoder {
    #private;
    constructor(options?: {
        maxFrameBytes?: number;
    });
    push(chunk: Buffer): unknown[];
}
/** Validate a host-to-guest request. Unknown ops and malformed fields throw. */
export declare function parseGuestRequest(value: unknown): GuestRequest;
export declare function parseGuestInput(value: unknown): GuestInput;
/** Validate a guest-to-host message: a correlated response or an event. */
export declare function parseHostBoundMessage(value: unknown): HostBoundMessage;
/** Validate the result payload of an `exec` response. */
export declare function parseExecResult(value: unknown): GuestExecResult;
/** Validate the result payload of a `job-start` response. */
export declare function parseJobStarted(value: unknown): {
    jobId: string;
};
/** Validate the result payload of an `observe` response. */
export declare function parseObservation(value: unknown): GuestObservation;
/** Validate the result payload of a `handover-begin` response. */
export declare function parseHandoverBegun(value: unknown): {
    url: string;
};
/** Validate the result payload of a `clipboard-read` response. */
export declare function parseClipboardText(value: unknown): string;
/** Validate the result payload of a `capabilities` response. */
export declare function parseCapabilities(value: unknown): {
    virtioGpu: boolean;
};
export declare function parseWindowInfo(value: unknown): WindowInfo;
//# sourceMappingURL=protocol.d.ts.map