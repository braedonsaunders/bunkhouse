export declare const DEFAULT_VMM_PATH = "/usr/bin/cloud-hypervisor";
export declare const DEFAULT_KVM_PATH = "/dev/kvm";
export declare const DEFAULT_QEMU_IMG_PATH = "/usr/bin/qemu-img";
export declare const DEFAULT_RUNTIME_DIR = "/run/appkit-desk";
export declare const DEFAULT_MEMORY_MB = 384;
export declare const DEFAULT_VCPUS = 2;
export declare const DEFAULT_KERNEL_CMDLINE = "root=/dev/vda rw quiet";
/**
 * Every failure this package raises. The `name` is annotated as `string`
 * rather than left to infer its literal so a subclass can narrow the meaning
 * of a failure — see `DeskRequestFateUnknownError` — without callers losing
 * the one `instanceof DeskError` they already check.
 */
export declare class DeskError extends Error {
    readonly name: string;
}
export interface DeskLauncherIdentity {
    /** Host/container UID used to invoke the VMM and image tooling. */
    uid: number;
    /** Host/container GID used to invoke the VMM and image tooling. */
    gid: number;
}
export interface DeskLaunchPlanOptions {
    deskId: string;
    vmmPath?: string;
    kvmPath?: string;
    qemuImgPath?: string;
    /** Absolute path of the kernel image the microVM boots. */
    kernelPath: string;
    /**
     * Absolute path of an initramfs. Required whenever the kernel loads its
     * root-filesystem or virtio drivers as modules — a stock distro cloud kernel
     * panics with "VFS: Unable to mount root fs" if it boots without one. Omit
     * only for a kernel with virtio_blk/ext4 built in.
     */
    initramfsPath?: string;
    /** Absolute path of the golden raw base image every desk clones. */
    baseImagePath: string;
    /** Absolute path of this desk's copy-on-write overlay (a raw reflink clone). */
    overlayPath: string;
    memoryMb?: number;
    vcpus?: number;
    /** Guest vsock context ID; must be unique among resident desks. */
    vsockCid: number;
    /** Directory holding the vsock and API control sockets. */
    runtimeDir?: string;
    /** Host TAP device name; derived from the CID when omitted. */
    tapDevice?: string;
    /** Guest MAC address; derived from the CID when omitted. */
    macAddress?: string;
    kernelCmdline?: string;
    launcherIdentity?: DeskLauncherIdentity;
}
/**
 * The complete Cloud Hypervisor invocation as inspectable data. Nothing here
 * has been spawned: tests, audit logs, and readiness screens can assert on the
 * exact argv a desk would boot with.
 */
export interface DeskLaunchPlan {
    deskId: string;
    vmm: {
        command: string;
        args: string[];
    };
    overlay: {
        path: string;
        basePath: string;
        /** The overlay-creation step, or `null` when the overlay already exists. */
        create: {
            command: string;
            args: string[];
        } | null;
    };
    vsock: {
        cid: number;
        socketPath: string;
    };
    api: {
        socketPath: string;
    };
    tap: {
        device: string;
        mac: string;
    };
    memoryMb: number;
    vcpus: number;
    kernelPath: string;
    /** Resolved initramfs path, or `null` when the kernel needs none. */
    initramfsPath: string | null;
    kernelCmdline: string;
    launcherIdentity?: DeskLauncherIdentity;
}
/**
 * Whether this host can run desks at all: Linux, a usable `/dev/kvm`, and the
 * Cloud Hypervisor binary. All three checks are injectable and the answer is
 * fail-closed — a host missing any of them gets no desk capability rather
 * than a degraded one.
 */
export declare function isDeskSupported(options?: {
    platform?: NodeJS.Platform;
    kvmPath?: string;
    vmmPath?: string;
    pathExists?: (path: string) => boolean;
}): boolean;
/** Validate a desk identifier, which is used in socket paths and device names. */
export declare function cleanDeskId(value: string): string;
/**
 * Build the deterministic Cloud Hypervisor launch plan without spawning
 * anything. Fail closed: a missing `/dev/kvm`, VMM binary, kernel, base image,
 * or overlay directory throws instead of producing a plan that cannot boot.
 */
export declare function buildDeskLaunchPlan(options: DeskLaunchPlanOptions, dependencies?: {
    pathExists?: (path: string) => boolean;
    deviceExists?: (path: string) => boolean;
}): DeskLaunchPlan;
export declare function cleanLauncherIdentity(identity: DeskLauncherIdentity | undefined): DeskLauncherIdentity | undefined;
//# sourceMappingURL=plan.d.ts.map