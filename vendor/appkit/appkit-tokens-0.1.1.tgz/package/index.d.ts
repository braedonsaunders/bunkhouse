/**
 * JS access to the design tokens — for consumers that can't read CSS variables:
 * chart libraries, <canvas>, PDF/email renderers, server-side image generation.
 *
 * The CSS in `tokens.css` is the source of truth for the *running app*; this
 * mirrors the same values for non-DOM contexts. Keep them in sync.
 */
export type ThemeMode = 'light' | 'dark';
/** Semantic token names, mode-independent. */
export type ColorToken = 'bg' | 'bg-subtle' | 'surface' | 'surface-hover' | 'elevated' | 'overlay' | 'fg' | 'fg-muted' | 'fg-subtle' | 'border' | 'border-strong' | 'border-subtle' | 'primary' | 'primary-hover' | 'primary-active' | 'primary-fg' | 'primary-subtle' | 'signature-surface' | 'signature-ink' | 'danger' | 'danger-fg' | 'danger-subtle' | 'warning' | 'warning-fg' | 'warning-subtle' | 'success' | 'success-fg' | 'success-subtle' | 'info' | 'info-fg' | 'info-subtle' | 'ring';
/** sRGB channels as `[r, g, b]`, mirroring the CSS `--ch-*` triples. */
type Channels = readonly [number, number, number];
export declare const palette: Record<ThemeMode, Record<ColorToken, Channels>>;
/** Resolve a semantic token to a CSS `rgb()` / `rgba()` string. */
export declare function color(token: ColorToken, mode?: ThemeMode, alpha?: number): string;
/** Resolve a semantic token to six-digit hex for renderers such as PDFKit
 * that do not accept modern space-separated CSS rgb() syntax. */
export declare function hexColor(token: ColorToken, mode?: ThemeMode): string;
/** Motion tokens — mirror of the CSS `--ease-*` / `--duration-*` values. */
export declare const motion: {
    readonly ease: {
        readonly out: "cubic-bezier(0.22, 1, 0.36, 1)";
        readonly inOut: "cubic-bezier(0.65, 0, 0.35, 1)";
        readonly spring: "cubic-bezier(0.34, 1.56, 0.64, 1)";
    };
    readonly duration: {
        readonly fast: 120;
        readonly base: 180;
        readonly slow: 320;
    };
};
export declare const radius: {
    readonly sm: "0.375rem";
    readonly md: "0.5rem";
    readonly lg: "0.625rem";
    readonly xl: "0.875rem";
};
export {};
//# sourceMappingURL=index.d.ts.map