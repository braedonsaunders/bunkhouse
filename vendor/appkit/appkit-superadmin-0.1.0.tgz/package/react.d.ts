import * as React from 'react';
import type { PlatformSessionRecord, PlatformUserRecord } from './types.js';
/**
 * Server-action friendly result contract: the application owns the actions
 * (authorization, persistence, revalidation) and the components render state,
 * collect input, and surface outcomes.
 */
export type SuperadminActionResult = {
    ok: true;
    message?: string;
} | {
    ok: false;
    message: string;
};
export type PlatformUsersActions = {
    createUser(input: {
        name: string;
        email: string;
        password: string;
        isSuperAdmin?: boolean;
    }): Promise<SuperadminActionResult>;
    updateUser(userId: string, input: {
        name?: string;
        isActive?: boolean;
        isSuperAdmin?: boolean;
        emailVerified?: boolean;
    }): Promise<SuperadminActionResult>;
    setPassword(userId: string, password: string): Promise<SuperadminActionResult>;
    revokeUserSessions(userId: string): Promise<SuperadminActionResult>;
};
export type PlatformUsersAdminProps = {
    users: PlatformUserRecord[];
    /** The signed-in operator, so their own row is labeled and guarded in copy. */
    currentUserId?: string;
    actions: PlatformUsersActions;
    title?: string;
    description?: string;
};
/**
 * Instance-operator user administration: every account that can sign in to
 * the platform, with activation, super-admin standing, credentials, and
 * session controls.
 */
export declare function PlatformUsersAdmin({ users, currentUserId, actions, title, description, }: PlatformUsersAdminProps): React.JSX.Element;
export type PlatformSessionsActions = {
    revokeSession(sessionId: string): Promise<SuperadminActionResult>;
};
export type PlatformSessionsAdminProps = {
    sessions: PlatformSessionRecord[];
    actions: PlatformSessionsActions;
    title?: string;
    description?: string;
};
/** Live sessions across the installation, with per-session revocation. */
export declare function PlatformSessionsAdmin({ sessions, actions, title, description, }: PlatformSessionsAdminProps): React.JSX.Element;
//# sourceMappingURL=react.d.ts.map