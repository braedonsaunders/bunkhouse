import type { PlatformUserRecord, SuperadminPersistence, SuperadminService, SuperadminServiceOptions } from './types.js';
export type MemoryUserSeed = {
    id: string;
    name: string;
    email: string;
    image?: string | null;
    emailVerified?: boolean;
    isActive?: boolean;
    isSuperAdmin?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
};
export type MemorySessionSeed = {
    id: string;
    userId: string;
    createdAt?: Date;
    expiresAt?: Date;
    ipAddress?: string | null;
    userAgent?: string | null;
};
export type MemorySuperadminState = {
    users: Map<string, Omit<PlatformUserRecord, 'hasCredential' | 'activeSessionCount' | 'lastSeenAt'>>;
    /** userId → password hash */
    credentials: Map<string, string>;
    sessions: Map<string, {
        id: string;
        userId: string;
        createdAt: Date;
        expiresAt: Date;
        ipAddress: string | null;
        userAgent: string | null;
    }>;
};
export type MemorySuperadminPersistence = SuperadminPersistence & {
    state: MemorySuperadminState;
};
/** In-memory persistence adapter for tests, previews, and local tooling. */
export declare function createMemorySuperadminPersistence(seed?: {
    users?: MemoryUserSeed[];
    credentials?: Record<string, string>;
    sessions?: MemorySessionSeed[];
}, clock?: {
    now?: () => Date;
    id?: () => string;
}): MemorySuperadminPersistence;
/** Complete in-memory service — the shape tests and previews consume. */
export declare function createMemorySuperadminService(seed?: Parameters<typeof createMemorySuperadminPersistence>[0], options?: Partial<Omit<SuperadminServiceOptions, 'persistence'>> & {
    now?: () => Date;
    id?: () => string;
}): {
    service: SuperadminService;
    persistence: MemorySuperadminPersistence;
};
//# sourceMappingURL=memory.d.ts.map