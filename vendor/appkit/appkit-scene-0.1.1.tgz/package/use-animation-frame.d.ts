import * as React from 'react';
/**
 * A requestAnimationFrame loop that pauses when the tab is hidden or the
 * caller says the scene is off-screen, and hands the callback a clamped
 * delta so a long pause never teleports characters.
 */
export declare function useSceneAnimationFrame(callback: (deltaMs: number) => void, active: boolean): void;
/** Measured size of an element, kept current across resizes. */
export declare function useElementSize<T extends HTMLElement>(): [React.RefObject<T | null>, {
    width: number;
    height: number;
}];
//# sourceMappingURL=use-animation-frame.d.ts.map