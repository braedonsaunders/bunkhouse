import { type SandboxLimits } from '@appkit/sandbox';
export declare const SCRIPT_KINDS: readonly ["event", "scheduled", "endpoint", "bulk", "client"];
export type ScriptKind = (typeof SCRIPT_KINDS)[number];
export type ScriptRunStatus = 'ok' | 'aborted' | 'error' | 'timeout';
export interface ScriptIdentity {
    id: string;
    name: string;
    role?: string;
}
export interface ScriptTenant {
    id: string;
    name: string;
    locale?: string;
    timezone?: string;
    metadata?: Record<string, unknown>;
}
export interface ScriptContext {
    trigger: string;
    tenant: ScriptTenant;
    user?: ScriptIdentity;
    subject?: {
        type: string;
        id?: string;
        data: Record<string, unknown>;
        lines?: Record<string, unknown>[];
    };
    request?: {
        method: string;
        path?: string;
        query: Record<string, string>;
        body: unknown;
    };
    input?: unknown;
}
export interface ScriptDefinition {
    id: string;
    tenantId: string;
    name: string;
    kind: ScriptKind;
    triggerPoint: string;
    subjectType: string | null;
    endpointSlug: string | null;
    source: string;
    cron: string | null;
    timezone: string;
    nextRunAt: Date | null;
    lastRunAt: Date | null;
    timeoutMs: number;
    unitBudget: number;
    sortOrder: number;
    isActive: boolean;
}
export interface ScriptRun {
    id?: string;
    tenantId: string;
    scriptId: string;
    targetType: string | null;
    targetId: string | null;
    status: ScriptRunStatus;
    logs: string[];
    errorMessage: string | null;
    returned?: unknown;
    changes?: Record<string, unknown>;
    units: number;
    durationMs: number;
    at: Date;
}
export interface ScriptOutcome {
    status: ScriptRunStatus;
    changes?: Record<string, unknown>;
    returned?: unknown;
    abortReason?: string;
    logs: string[];
    units: number;
    durationMs: number;
}
export interface ScriptDataAdapter {
    /** Execute through a tenant-bound, read-only query surface. */
    query?(statement: string, options: {
        maxRows: number;
        timeoutMs: number;
    }): Promise<unknown[]>;
    load?(type: string, id: string): Promise<unknown>;
    search?(type: string, filters: Record<string, unknown>, options: {
        limit: number;
    }): Promise<unknown[]>;
    /** App-defined, capability-scoped writes and service calls. */
    functions?: Record<string, {
        cost: number;
        handler: (args: unknown[], context: ScriptContext) => Promise<unknown> | unknown;
    }>;
}
export interface ScriptStore {
    listForTrigger(input: {
        tenantId: string;
        triggerPoint: string;
        subjectType?: string | null;
    }): Promise<ScriptDefinition[]>;
    findById(tenantId: string, scriptId: string): Promise<ScriptDefinition | null>;
    findEndpoint(tenantId: string, slug: string): Promise<ScriptDefinition | null>;
    listScheduled(tenantId: string): Promise<ScriptDefinition[]>;
    recordRun(run: ScriptRun): Promise<void>;
    updateSchedule(scriptId: string, input: {
        lastRunAt?: Date;
        nextRunAt?: Date | null;
    }): Promise<void>;
}
export interface RunScriptOptions extends SandboxLimits {
    definition?: Pick<ScriptDefinition, 'timeoutMs' | 'unitBudget'>;
    source: string;
    context: ScriptContext;
    adapters?: ScriptDataAdapter;
    /** Header/subject keys that a returned `{ set }` may change. */
    mutableFields?: Iterable<string>;
    /** Defaults to triggers beginning with `before_`. */
    allowAbort?: boolean;
    globalName?: string;
    /** Preserve an existing authored context shape during a consuming-app cutover. */
    sandboxInput?: unknown;
    /** Additional frozen values exposed on the configured sandbox global. */
    hostValues?: Record<string, unknown>;
}
export type ScriptRuntimeConfiguration = Pick<RunScriptOptions, 'globalName' | 'sandboxInput' | 'hostValues'>;
/** Execute one `main(ctx)` script with the production host API contract. */
export declare function runScript(options: RunScriptOptions): Promise<ScriptOutcome>;
/** Run matching active scripts in deterministic order and stop on failure. */
export declare function runTriggerScripts(options: {
    store: ScriptStore;
    context: ScriptContext;
    targetId?: string | null;
    adapters?: ScriptDataAdapter;
    mutableFields?: Iterable<string>;
    runtime?: (context: ScriptContext) => ScriptRuntimeConfiguration;
}): Promise<Array<ScriptOutcome & {
    scriptId: string;
    name: string;
}>>;
export declare function runScheduledScript(options: {
    store: ScriptStore;
    tenant: ScriptTenant;
    scriptId: string;
    adapters?: ScriptDataAdapter;
    now?: Date;
    runtime?: (context: ScriptContext) => ScriptRuntimeConfiguration;
}): Promise<ScriptOutcome & {
    scriptId: string;
    name: string;
}>;
export declare function runBulkScript(options: {
    store: ScriptStore;
    tenant: ScriptTenant;
    scriptId: string;
    adapters?: ScriptDataAdapter;
    runtime?: (context: ScriptContext) => ScriptRuntimeConfiguration;
}): Promise<ScriptOutcome & {
    scriptId: string;
    name: string;
}>;
export declare function runEndpointScript(options: {
    store: ScriptStore;
    tenant: ScriptTenant;
    user: ScriptIdentity;
    slug: string;
    request: NonNullable<ScriptContext['request']>;
    adapters?: ScriptDataAdapter;
    runtime?: (context: ScriptContext) => ScriptRuntimeConfiguration;
}): Promise<(ScriptOutcome & {
    scriptId: string;
    name: string;
}) | null>;
export declare function computeNextRunAt(cron: string, from?: Date, timezone?: string): Date | null;
export declare function refreshScheduledNextRuns(store: ScriptStore, tenantId: string, from?: Date): Promise<void>;
//# sourceMappingURL=index.d.ts.map