import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { ScriptRun, ScriptStore } from './index.js';
type Db = NodePgDatabase<Record<string, never>>;
export declare function createDrizzleScriptStore(db: Db): ScriptStore;
export { userScripts, scriptRuns, SCRIPT_TENANT_TABLES } from './schema.js';
export type { ScriptRun };
//# sourceMappingURL=drizzle.d.ts.map