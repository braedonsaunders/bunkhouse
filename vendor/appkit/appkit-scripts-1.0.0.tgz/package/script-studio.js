'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { Check, Code2, History, Play, Plus, Search, Settings2, Trash2 } from 'lucide-react';
import { Badge, Button, Drawer, Input, Label, Select, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, cn, } from '@appkit/ui';
const EVENT_TEMPLATE = `// The context is deeply frozen. All data access is capability-scoped.
function main(ctx) {
  app.log('running', ctx.trigger)
  if (ctx.subject && ctx.subject.data.needsReview) {
    return { set: { reviewStatus: 'required' } }
  }
}`;
const ENDPOINT_TEMPLATE = `function main(ctx) {
  app.log('request', ctx.request.method)
  return { ok: true, echo: ctx.request.body }
}`;
const SCHEDULED_TEMPLATE = `function main(ctx) {
  const rows = app.query('select approved work through the host read-only adapter')
  app.log('processed', rows.length, 'rows for', ctx.tenant.name)
  return { processed: rows.length }
}`;
export function ScriptStudio({ scripts, runs = {}, triggerOptions, subjectTypes = [], selectedId, onSelectedIdChange, onSave, onDelete, onRun, className, }) {
    const [internalSelected, setInternalSelected] = React.useState(null);
    const [query, setQuery] = React.useState('');
    const currentId = selectedId === undefined ? internalSelected : selectedId;
    const choose = (id) => {
        if (selectedId === undefined)
            setInternalSelected(id);
        onSelectedIdChange?.(id);
    };
    const selected = currentId && currentId !== 'new' ? scripts.find((script) => script.id === currentId) ?? null : null;
    const filtered = scripts.filter((script) => {
        const haystack = `${script.name} ${script.triggerPoint} ${script.subjectType ?? ''}`.toLowerCase();
        return haystack.includes(query.trim().toLowerCase());
    });
    return (_jsxs("div", { className: cn('space-y-4', className), children: [_jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [_jsxs("div", { className: "relative min-w-64 flex-1 sm:max-w-sm", children: [_jsx(Search, { "aria-hidden": true, className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: query, onChange: (event) => setQuery(event.currentTarget.value), placeholder: "Search scripts", className: "pl-9" })] }), _jsxs(Button, { onClick: () => choose('new'), children: [_jsx(Plus, { className: "size-4" }), " New script"] })] }), _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsxs(TableRow, { noAnimate: true, children: [_jsx(TableHead, { children: "Script" }), _jsx(TableHead, { children: "Trigger" }), _jsx(TableHead, { children: "Subject" }), _jsx(TableHead, { className: "text-right", children: "Runs" }), _jsx(TableHead, { children: "Last run" }), _jsx(TableHead, { children: "Status" })] }) }), _jsxs(TableBody, { children: [filtered.map((script) => (_jsxs(TableRow, { className: "cursor-pointer", onClick: () => choose(script.id), children: [_jsx(TableCell, { className: "font-medium text-fg", children: script.name }), _jsx(TableCell, { children: _jsx(Badge, { variant: "secondary", children: triggerLabel(script.triggerPoint, triggerOptions) }) }), _jsx(TableCell, { className: "text-fg-muted", children: subjectLabel(script.subjectType, subjectTypes) }), _jsx(TableCell, { className: "text-right tabular-nums", children: runs[script.id]?.length ?? 0 }), _jsx(TableCell, { className: "text-fg-muted", children: script.lastRunAt ? formatDate(script.lastRunAt) : 'Never' }), _jsx(TableCell, { children: _jsx(Badge, { variant: script.isActive ? 'success' : 'outline', children: script.isActive ? 'Active' : 'Disabled' }) })] }, script.id))), !filtered.length ? _jsx(TableRow, { children: _jsx(TableCell, { colSpan: 6, className: "py-12 text-center text-fg-muted", children: "No scripts match this view." }) }) : null] })] }), _jsx(ScriptEditorDrawer, { open: Boolean(currentId), script: selected, runs: selected ? runs[selected.id] ?? [] : [], triggerOptions: triggerOptions, subjectTypes: subjectTypes, onClose: () => choose(null), onSave: async (value) => { await onSave(value); choose(null); }, onDelete: async (id) => { await onDelete(id); choose(null); }, onRun: onRun }, currentId ?? 'closed')] }));
}
export function ScriptEditorDrawer({ open, script, runs, triggerOptions, subjectTypes, onClose, onSave, onDelete, onRun, }) {
    const [tab, setTab] = React.useState(script ? 'code' : 'general');
    const [value, setValue] = React.useState(() => toEditorValue(script, triggerOptions));
    const [busy, setBusy] = React.useState(false);
    const [runResult, setRunResult] = React.useState(null);
    const [selectedRun, setSelectedRun] = React.useState(0);
    const activeRuns = runResult && !runs.some((run) => sameRun(run, runResult)) ? [runResult, ...runs] : runs;
    const change = (key, next) => setValue((current) => ({ ...current, [key]: next }));
    const supportsSubject = value.kind === 'event' || value.kind === 'client';
    async function save() {
        setBusy(true);
        try {
            await onSave(value);
        }
        finally {
            setBusy(false);
        }
    }
    async function run() {
        if (!script)
            return;
        setBusy(true);
        try {
            const result = await onRun(script.id);
            if (result) {
                setRunResult(result);
                setSelectedRun(0);
            }
            setTab('log');
        }
        finally {
            setBusy(false);
        }
    }
    return (_jsxs(Drawer, { open: open, onClose: onClose, size: "2xl", initialFullscreen: true, title: script ? script.name : 'New script', description: "Governed JavaScript executed in an isolated QuickJS runtime.", headerActions: _jsxs(_Fragment, { children: [script && (script.kind === 'scheduled' || script.kind === 'bulk') ? _jsxs(Button, { size: "sm", variant: "outline", onClick: run, disabled: busy, children: [_jsx(Play, { className: "size-4" }), " Run now"] }) : null, script ? _jsxs(Button, { variant: "ghost", size: "sm", onClick: () => onDelete(script.id), disabled: busy, className: "text-danger hover:text-danger", children: [_jsx(Trash2, { className: "size-4" }), " Delete"] }) : null, _jsxs(Button, { onClick: save, disabled: busy || !value.name.trim() || !value.source.includes('function main'), children: [_jsx(Check, { className: "size-4" }), " ", script ? 'Save script' : 'Create script'] })] }), bodyClassName: "flex min-h-0 flex-col overflow-hidden p-0", footer: _jsxs("label", { className: "flex w-full items-center gap-2 text-sm", children: [_jsx("input", { type: "checkbox", checked: value.isActive, onChange: (event) => change('isActive', event.currentTarget.checked), className: "size-4 accent-primary" }), " Active"] }), children: [_jsxs("div", { className: "flex shrink-0 border-b border-border px-5", children: [_jsx(EditorTab, { active: tab === 'general', icon: _jsx(Settings2, {}), onClick: () => setTab('general'), children: "General" }), _jsx(EditorTab, { active: tab === 'code', icon: _jsx(Code2, {}), onClick: () => setTab('code'), children: "Code" }), _jsxs(EditorTab, { active: tab === 'runs', icon: _jsx(History, {}), onClick: () => setTab('runs'), children: ["Runs ", _jsx("span", { className: "tabular-nums", children: activeRuns.length })] }), _jsx(EditorTab, { active: tab === 'log', icon: _jsx(History, {}), onClick: () => setTab('log'), children: "Log" })] }), _jsxs("div", { className: "min-h-0 flex-1 overflow-auto p-6", children: [tab === 'general' ? (_jsxs("div", { className: "mx-auto grid max-w-3xl gap-5 sm:grid-cols-2", children: [_jsx(Field, { label: "Name", className: "sm:col-span-2", children: _jsx(Input, { value: value.name, onChange: (event) => change('name', event.currentTarget.value) }) }), _jsx(Field, { label: "Trigger", children: _jsx(Select, { value: value.triggerPoint, onChange: (event) => {
                                        const trigger = triggerOptions.find((option) => option.value === event.currentTarget.value);
                                        change('triggerPoint', event.currentTarget.value);
                                        if (trigger?.kind)
                                            change('kind', trigger.kind);
                                    }, children: triggerOptions.map((option) => _jsx("option", { value: option.value, children: option.label }, option.value)) }) }), _jsx(Field, { label: "Kind", children: _jsx(Input, { value: value.kind, readOnly: true, className: "bg-bg-subtle text-fg-muted" }) }), supportsSubject ? _jsx(Field, { label: "Subject type", children: _jsxs(Select, { value: value.subjectType ?? '', onChange: (event) => change('subjectType', event.currentTarget.value || null), children: [_jsx("option", { value: "", children: "All subjects" }), subjectTypes.map((option) => _jsx("option", { value: option.value, children: option.label }, option.value))] }) }) : null, value.kind === 'endpoint' ? _jsx(Field, { label: "Endpoint slug", children: _jsx(Input, { value: value.endpointSlug ?? '', onChange: (event) => change('endpointSlug', event.currentTarget.value || null) }) }) : null, value.kind === 'scheduled' ? _jsxs(_Fragment, { children: [_jsx(Field, { label: "Cron expression", children: _jsx(Input, { value: value.cron ?? '', onChange: (event) => change('cron', event.currentTarget.value || null) }) }), _jsx(Field, { label: "Timezone", children: _jsx(Input, { value: value.timezone, onChange: (event) => change('timezone', event.currentTarget.value) }) })] }) : null, _jsx(Field, { label: "Timeout (ms)", children: _jsx(Input, { type: "number", min: 1, max: 15000, value: value.timeoutMs, onChange: (event) => change('timeoutMs', Number(event.currentTarget.value)) }) }), _jsx(Field, { label: "Governance units", children: _jsx(Input, { type: "number", min: 1, value: value.unitBudget, onChange: (event) => change('unitBudget', Number(event.currentTarget.value)) }) }), _jsx(Field, { label: "Execution order", children: _jsx(Input, { type: "number", value: value.sortOrder, onChange: (event) => change('sortOrder', Number(event.currentTarget.value)) }) })] })) : null, tab === 'code' ? (_jsxs("div", { className: "flex min-h-[32rem] flex-col gap-3", children: [_jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 text-sm text-fg-muted", children: [_jsxs("span", { children: ["Define ", _jsx("code", { className: "rounded bg-bg-subtle px-1.5 py-0.5 text-fg", children: "function main(ctx)" }), "."] }), _jsx("span", { children: "QuickJS \u00B7 no ambient network, filesystem, process, or database" })] }), _jsx("div", { className: "min-h-[30rem] flex-1 overflow-hidden rounded-lg border border-border", children: _jsx(CodeMirror, { value: value.source, onChange: (source) => change('source', source), extensions: [javascript()], theme: "dark", minHeight: "480px", maxHeight: "calc(100vh - 16rem)", basicSetup: { lineNumbers: true, foldGutter: true, autocompletion: true } }) })] })) : null, tab === 'runs' ? _jsx(RunList, { runs: activeRuns, selected: selectedRun, onSelect: (index) => { setSelectedRun(index); setTab('log'); } }) : null, tab === 'log' ? _jsx(RunLog, { run: activeRuns[selectedRun], hasRuns: activeRuns.length > 0 }) : null] })] }));
}
function RunList({ runs, selected, onSelect }) {
    if (!runs.length)
        return _jsx("div", { className: "grid min-h-80 place-items-center text-sm text-fg-muted", children: "This script has not run yet." });
    return (_jsx("div", { className: "divide-y divide-border-subtle overflow-hidden rounded-lg border border-border", children: runs.map((item, index) => _jsxs("button", { type: "button", onClick: () => onSelect(index), className: cn('flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-surface-hover', selected === index && 'bg-primary-subtle'), children: [_jsx(Badge, { variant: item.status === 'ok' ? 'success' : item.status === 'aborted' ? 'warning' : 'destructive', children: item.status }), _jsxs("span", { className: "text-xs text-fg-muted", children: [formatDate(item.at), " \u00B7 ", item.durationMs, " ms \u00B7 ", item.units, " units"] }), item.errorMessage ? _jsx("span", { className: "min-w-0 flex-1 truncate text-xs text-danger", children: item.errorMessage }) : null] }, `${item.at.toISOString()}-${index}`)) }));
}
function RunLog({ run, hasRuns }) {
    if (!run)
        return _jsx("div", { className: "grid min-h-80 place-items-center text-sm text-fg-muted", children: hasRuns ? 'Select a run to inspect its log.' : 'This script has not run yet.' });
    return _jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-3", children: [_jsx(Badge, { variant: run.status === 'ok' ? 'success' : run.status === 'aborted' ? 'warning' : 'destructive', children: run.status }), _jsxs("span", { className: "text-xs text-fg-muted", children: [formatDate(run.at), " \u00B7 ", run.durationMs, " ms \u00B7 ", run.units, " units"] })] }), run.errorMessage ? _jsx("div", { className: "rounded-md border border-danger bg-danger-subtle p-3 text-sm text-danger", children: run.errorMessage }) : null, _jsx(LogBlock, { title: "Console", value: run.logs.join('\n') || 'No log output.' }), run.returned !== undefined ? _jsx(LogBlock, { title: "Return value", value: JSON.stringify(run.returned, null, 2) }) : null, run.changes ? _jsx(LogBlock, { title: "Proposed changes", value: JSON.stringify(run.changes, null, 2) }) : null] });
}
function EditorTab({ active, icon, onClick, children }) {
    return _jsxs("button", { type: "button", onClick: onClick, className: cn('flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium', active ? 'border-primary text-primary' : 'border-transparent text-fg-muted hover:text-fg'), children: [_jsx("span", { className: "[&>svg]:size-4", children: icon }), children] });
}
function Field({ label, className, children }) {
    return _jsxs("div", { className: cn('space-y-2', className), children: [_jsx(Label, { children: label }), children] });
}
function LogBlock({ title, value }) {
    return _jsxs("section", { className: "space-y-2", children: [_jsx("h3", { className: "text-xs font-semibold tracking-wide text-fg-muted uppercase", children: title }), _jsx("pre", { className: "max-h-72 overflow-auto whitespace-pre-wrap rounded-md bg-bg-subtle p-3 font-mono text-xs leading-5 text-fg", children: value })] });
}
function sameRun(left, right) {
    if (left.id && right.id)
        return left.id === right.id;
    return left.scriptId === right.scriptId && left.at.getTime() === right.at.getTime() && left.status === right.status;
}
function toEditorValue(script, triggerOptions) {
    if (script)
        return { ...script };
    const trigger = triggerOptions[0] ?? { value: 'before_save', kind: 'event' };
    const kind = trigger.kind ?? 'event';
    return {
        name: '',
        kind,
        triggerPoint: trigger.value,
        subjectType: null,
        endpointSlug: kind === 'endpoint' ? 'my-endpoint' : null,
        source: kind === 'endpoint' ? ENDPOINT_TEMPLATE : kind === 'scheduled' || kind === 'bulk' ? SCHEDULED_TEMPLATE : EVENT_TEMPLATE,
        cron: kind === 'scheduled' ? '0 * * * *' : null,
        timezone: 'UTC',
        timeoutMs: 2_000,
        unitBudget: 1_000,
        sortOrder: 100,
        isActive: true,
    };
}
function triggerLabel(value, options) {
    return options.find((option) => option.value === value)?.label ?? value.replaceAll('_', ' ');
}
function subjectLabel(value, options) {
    if (!value)
        return 'All subjects';
    return options.find((option) => option.value === value)?.label ?? value;
}
function formatDate(value) {
    return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(value);
}
//# sourceMappingURL=script-studio.js.map