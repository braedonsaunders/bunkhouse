import cronParser from 'cron-parser';
import { abort, forbidden, runSandbox } from '@appkit/sandbox';
export const SCRIPT_KINDS = ['event', 'scheduled', 'endpoint', 'bulk', 'client'];
/** Execute one `main(ctx)` script with the production host API contract. */
export async function runScript(options) {
    const adapters = options.adapters ?? {};
    const context = options.context;
    const globalName = options.globalName ?? 'app';
    const allowAbort = options.allowAbort ?? context.trigger.startsWith('before_');
    const functions = {
        abort: {
            cost: 0,
            handler: ([reason]) => {
                if (!allowAbort)
                    forbidden(`abort is not permitted for trigger ${context.trigger}`);
                return abort(String(reason ?? 'script aborted'));
            },
        },
        query: {
            cost: 10,
            handler: ([statement]) => {
                if (!adapters.query)
                    forbidden('read-only query capability is not granted');
                return adapters.query(String(statement), { maxRows: 5_000, timeoutMs: 5_000 });
            },
        },
        'record.load': {
            cost: 5,
            handler: ([type, id]) => {
                if (!adapters.load)
                    forbidden('record load capability is not granted');
                return adapters.load(String(type), String(id));
            },
        },
        search: {
            cost: 10,
            handler: ([type, filters]) => {
                if (!adapters.search)
                    forbidden('record search capability is not granted');
                return adapters.search(String(type), asRecord(filters), { limit: 1_000 });
            },
        },
    };
    for (const [name, definition] of Object.entries(adapters.functions ?? {})) {
        functions[name] = { cost: definition.cost, handler: (args) => definition.handler(args, context) };
    }
    const runtime = await runSandbox({
        source: options.source,
        entrypoint: 'main',
        input: options.sandboxInput ?? context,
        globalName,
        values: options.hostValues ?? { runtime: { tenant: context.tenant, trigger: context.trigger, user: context.user ?? null } },
        functions,
        timeoutMs: options.timeoutMs ?? options.definition?.timeoutMs,
        unitBudget: options.unitBudget ?? options.definition?.unitBudget,
        memoryBytes: options.memoryBytes,
        stackBytes: options.stackBytes,
    });
    if (runtime.status !== 'ok') {
        return {
            status: runtime.status === 'aborted' ? 'aborted' : runtime.status === 'timeout' ? 'timeout' : 'error',
            abortReason: runtime.error,
            logs: runtime.logs,
            units: runtime.units,
            durationMs: runtime.durationMs,
        };
    }
    const returned = runtime.value;
    const proposed = isRecord(returned) && isRecord(returned.set) ? returned.set : undefined;
    const changes = {};
    if (proposed) {
        const allowed = new Set(options.mutableFields ?? []);
        for (const [key, value] of Object.entries(proposed)) {
            if (!allowed.has(key)) {
                return {
                    status: 'aborted',
                    abortReason: `script tried to set non-whitelisted field "${key}"`,
                    logs: runtime.logs,
                    units: runtime.units,
                    durationMs: runtime.durationMs,
                };
            }
            changes[key] = value;
        }
    }
    return {
        status: 'ok',
        ...(Object.keys(changes).length ? { changes } : {}),
        returned,
        logs: runtime.logs,
        units: runtime.units,
        durationMs: runtime.durationMs,
    };
}
/** Run matching active scripts in deterministic order and stop on failure. */
export async function runTriggerScripts(options) {
    const subjectType = options.context.subject?.type ?? null;
    const definitions = await options.store.listForTrigger({
        tenantId: options.context.tenant.id,
        triggerPoint: options.context.trigger,
        subjectType,
    });
    const outcomes = [];
    for (const definition of [...definitions].filter((item) => item.isActive).sort(compareScripts)) {
        const outcome = await runScript({
            source: definition.source,
            definition,
            context: options.context,
            adapters: options.adapters,
            mutableFields: options.mutableFields,
            ...options.runtime?.(options.context),
        });
        outcomes.push({ scriptId: definition.id, name: definition.name, ...outcome });
        await persistOutcome(options.store, definition, options.context, options.targetId ?? null, outcome);
        if (outcome.status !== 'ok')
            break;
    }
    return outcomes;
}
export async function runScheduledScript(options) {
    const definition = await requireScript(options.store, options.tenant.id, options.scriptId);
    if (definition.kind !== 'scheduled')
        throw new Error('script is not scheduled');
    const context = { trigger: definition.triggerPoint, tenant: options.tenant };
    const outcome = await runScript({ source: definition.source, definition, context, adapters: options.adapters, allowAbort: false, ...options.runtime?.(context) });
    const at = options.now ?? new Date();
    await persistOutcome(options.store, definition, context, null, outcome, at);
    await options.store.updateSchedule(definition.id, {
        lastRunAt: at,
        nextRunAt: definition.cron ? computeNextRunAt(definition.cron, at, definition.timezone) : null,
    });
    return { scriptId: definition.id, name: definition.name, ...outcome };
}
export async function runBulkScript(options) {
    const definition = await requireScript(options.store, options.tenant.id, options.scriptId);
    if (definition.kind !== 'bulk')
        throw new Error('script is not a bulk script');
    const context = { trigger: definition.triggerPoint, tenant: options.tenant };
    const outcome = await runScript({ source: definition.source, context, adapters: options.adapters, timeoutMs: 15_000, unitBudget: Math.max(definition.unitBudget, 10_000), allowAbort: false, ...options.runtime?.(context) });
    await persistOutcome(options.store, definition, context, null, outcome);
    return { scriptId: definition.id, name: definition.name, ...outcome };
}
export async function runEndpointScript(options) {
    const definition = await options.store.findEndpoint(options.tenant.id, options.slug);
    if (!definition || !definition.isActive)
        return null;
    const context = { trigger: definition.triggerPoint, tenant: options.tenant, user: options.user, request: options.request };
    const outcome = await runScript({ source: definition.source, definition, context, adapters: options.adapters, allowAbort: false, ...options.runtime?.(context) });
    await persistOutcome(options.store, definition, context, null, outcome);
    return { scriptId: definition.id, name: definition.name, ...outcome };
}
export function computeNextRunAt(cron, from = new Date(), timezone = 'UTC') {
    try {
        return cronParser.parseExpression(cron, { currentDate: from, tz: timezone }).next().toDate();
    }
    catch {
        return null;
    }
}
export async function refreshScheduledNextRuns(store, tenantId, from = new Date()) {
    for (const script of await store.listScheduled(tenantId)) {
        await store.updateSchedule(script.id, { nextRunAt: script.cron ? computeNextRunAt(script.cron, from, script.timezone) : null });
    }
}
async function persistOutcome(store, definition, context, targetId, outcome, at = new Date()) {
    await store.recordRun({
        tenantId: context.tenant.id,
        scriptId: definition.id,
        targetType: context.subject?.type ?? definition.kind,
        targetId,
        status: outcome.status,
        logs: outcome.logs,
        errorMessage: outcome.status === 'ok' ? null : outcome.abortReason ?? outcome.status,
        returned: outcome.returned,
        changes: outcome.changes,
        units: outcome.units,
        durationMs: outcome.durationMs,
        at,
    });
    await store.updateSchedule(definition.id, { lastRunAt: at });
}
async function requireScript(store, tenantId, scriptId) {
    const script = await store.findById(tenantId, scriptId);
    if (!script)
        throw new Error('script not found');
    if (!script.isActive)
        throw new Error('script is disabled');
    return script;
}
function compareScripts(left, right) {
    return left.sortOrder - right.sortOrder || left.name.localeCompare(right.name) || left.id.localeCompare(right.id);
}
function asRecord(value) {
    return isRecord(value) ? value : {};
}
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
//# sourceMappingURL=index.js.map