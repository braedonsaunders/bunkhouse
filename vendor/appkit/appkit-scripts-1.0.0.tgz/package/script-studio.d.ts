import * as React from 'react';
import type { ScriptDefinition, ScriptKind, ScriptRun } from './index.js';
export interface ScriptEditorValue {
    id?: string;
    name: string;
    kind: ScriptKind;
    triggerPoint: string;
    subjectType: string | null;
    endpointSlug: string | null;
    source: string;
    cron: string | null;
    timezone: string;
    timeoutMs: number;
    unitBudget: number;
    sortOrder: number;
    isActive: boolean;
}
export interface ScriptStudioProps {
    scripts: ScriptDefinition[];
    runs?: Record<string, ScriptRun[]>;
    triggerOptions: Array<{
        value: string;
        label: string;
        kind?: ScriptKind;
    }>;
    subjectTypes?: Array<{
        value: string;
        label: string;
    }>;
    selectedId?: string | 'new' | null;
    onSelectedIdChange?: (id: string | 'new' | null) => void;
    onSave: (value: ScriptEditorValue) => Promise<void> | void;
    onDelete: (id: string) => Promise<void> | void;
    onRun: (id: string) => Promise<ScriptRun | void> | ScriptRun | void;
    className?: string;
}
export declare function ScriptStudio({ scripts, runs, triggerOptions, subjectTypes, selectedId, onSelectedIdChange, onSave, onDelete, onRun, className, }: ScriptStudioProps): React.JSX.Element;
export declare function ScriptEditorDrawer({ open, script, runs, triggerOptions, subjectTypes, onClose, onSave, onDelete, onRun, }: {
    open: boolean;
    script: ScriptDefinition | null;
    runs: ScriptRun[];
    triggerOptions: ScriptStudioProps['triggerOptions'];
    subjectTypes: NonNullable<ScriptStudioProps['subjectTypes']>;
    onClose: () => void;
    onSave: ScriptStudioProps['onSave'];
    onDelete: ScriptStudioProps['onDelete'];
    onRun: ScriptStudioProps['onRun'];
}): React.JSX.Element;
//# sourceMappingURL=script-studio.d.ts.map