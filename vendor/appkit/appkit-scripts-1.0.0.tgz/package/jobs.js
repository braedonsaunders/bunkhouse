import { runBulkScript, runScheduledScript } from './index.js';
/** Queue-neutral worker handler; BullMQ, serverless jobs, or a local worker can call the same function. */
export function createScriptJobHandler(options) {
    return async (job) => {
        const tenant = await options.loadTenant(job.tenantId);
        const adapters = await options.adapters?.(job.tenantId, job.actorId);
        const outcome = job.kind === 'bulk'
            ? await runBulkScript({ store: options.store, tenant, scriptId: job.scriptId, adapters })
            : await runScheduledScript({ store: options.store, tenant, scriptId: job.scriptId, adapters });
        return { status: outcome.status, durationMs: outcome.durationMs };
    };
}
//# sourceMappingURL=jobs.js.map