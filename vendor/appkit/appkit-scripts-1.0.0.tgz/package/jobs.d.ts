import { type ScriptDataAdapter, type ScriptStore, type ScriptTenant } from './index.js';
export interface ScriptJobData {
    tenantId: string;
    scriptId: string;
    kind: 'scheduled' | 'bulk';
    actorId?: string;
}
/** Queue-neutral worker handler; BullMQ, serverless jobs, or a local worker can call the same function. */
export declare function createScriptJobHandler(options: {
    store: ScriptStore;
    loadTenant: (tenantId: string) => Promise<ScriptTenant>;
    adapters?: (tenantId: string, actorId?: string) => Promise<ScriptDataAdapter> | ScriptDataAdapter;
}): (job: ScriptJobData) => Promise<{
    status: string;
    durationMs: number;
}>;
//# sourceMappingURL=jobs.d.ts.map