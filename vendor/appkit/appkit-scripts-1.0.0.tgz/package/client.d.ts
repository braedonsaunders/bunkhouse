export interface DeliveredClientScript {
    id: string;
    name: string;
    source: string;
}
export interface ClientScriptGate {
    ok: boolean;
    reason?: string;
    warnings: string[];
}
export interface ClientScriptEvaluation {
    id: string;
    name: string;
    result?: unknown;
    error?: string;
}
export interface ClientScriptRunner {
    run(subjectType: string, value: unknown): Promise<ClientScriptGate>;
    invalidate(subjectType?: string): void;
}
/**
 * Browser form hooks use a throwaway opaque-origin iframe. Failures fail open;
 * only an explicit `{ abort: string }` blocks the host save.
 */
export declare function createClientScriptRunner(options: {
    loadScripts: (subjectType: string) => Promise<DeliveredClientScript[]>;
    timeoutMs?: number;
    cacheMs?: number;
    onError?: (message: string, error?: unknown) => void;
}): ClientScriptRunner;
export declare function evaluateClientResults(results: ClientScriptEvaluation[], onError?: (message: string, error?: unknown) => void): ClientScriptGate;
//# sourceMappingURL=client.d.ts.map