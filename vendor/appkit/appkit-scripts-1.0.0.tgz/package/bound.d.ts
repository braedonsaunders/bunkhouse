import { type ScriptContext, type ScriptDataAdapter, type ScriptIdentity, type ScriptStore, type ScriptTenant } from './index.js';
export interface BoundScriptRuntimeOptions<TContext extends {
    trigger: string;
}> {
    store: ScriptStore;
    /** Resolve the package tenant key from the consuming application's context. */
    tenantId: (context: TContext) => string;
    /** Load the display/runtime tenant shape for scheduled, bulk, and endpoint work. */
    tenant: (tenantId: string) => Promise<ScriptTenant> | ScriptTenant;
    /** Build the consuming application's native context for jobs without an inbound context. */
    context: (input: {
        trigger: string;
        tenant: ScriptTenant;
        user?: ScriptIdentity;
        request?: NonNullable<ScriptContext['request']>;
    }) => TContext;
    /** Existing authored global name, supplied by the consuming application. */
    globalName: string;
    subjectType?: (context: TContext) => string | null;
    adapters?: (context: TContext) => ScriptDataAdapter | undefined;
    hostValues?: (context: TContext) => Record<string, unknown>;
    mutableFields?: Iterable<string>;
}
/**
 * Bind AppKit's governed engine to an application's existing context and
 * persistence seam. The returned methods intentionally use positional service
 * signatures so a consuming application can replace its current runtime import
 * without rewriting every caller or authored script.
 */
export declare function createBoundScriptRuntime<TContext extends {
    trigger: string;
}>(options: BoundScriptRuntimeOptions<TContext>): {
    runScript(source: string, context: TContext, timeoutMs: number): Promise<import("./index").ScriptOutcome & {
        set?: Record<string, unknown>;
    }>;
    runTriggerScripts(trigger: string, context: TContext, targetId: string): Promise<(import("./index").ScriptOutcome & {
        scriptId: string;
        name: string;
    } & {
        set?: Record<string, unknown>;
    })[]>;
    runScheduledScript(scriptId: string, tenantId: string): Promise<import("./index").ScriptOutcome & {
        scriptId: string;
        name: string;
    } & {
        set?: Record<string, unknown>;
    }>;
    runBulkScript(scriptId: string, tenantId: string): Promise<import("./index").ScriptOutcome & {
        scriptId: string;
        name: string;
    } & {
        set?: Record<string, unknown>;
    }>;
    runEndpointScript(slug: string, tenantId: string, user: ScriptIdentity, request: NonNullable<ScriptContext["request"]>): Promise<(import("./index").ScriptOutcome & {
        scriptId: string;
        name: string;
    } & {
        set?: Record<string, unknown>;
    }) | null>;
    refreshScheduledNextRuns: (tenantId: string) => Promise<void>;
};
//# sourceMappingURL=bound.d.ts.map