import { refreshScheduledNextRuns, runBulkScript, runEndpointScript, runScheduledScript, runScript, runTriggerScripts, } from './index.js';
/**
 * Bind AppKit's governed engine to an application's existing context and
 * persistence seam. The returned methods intentionally use positional service
 * signatures so a consuming application can replace its current runtime import
 * without rewriting every caller or authored script.
 */
export function createBoundScriptRuntime(options) {
    const runtime = (native) => ({
        globalName: options.globalName,
        sandboxInput: native,
        ...(options.hostValues ? { hostValues: options.hostValues(native) } : {}),
    });
    const coreContext = async (native) => {
        const tenant = await options.tenant(options.tenantId(native));
        const candidate = native;
        const subjectType = options.subjectType?.(native) ?? null;
        return {
            trigger: native.trigger,
            tenant,
            ...(candidate.user ? { user: candidate.user } : {}),
            ...(candidate.request ? { request: candidate.request } : {}),
            ...(subjectType ? { subject: { type: subjectType, data: {} } } : {}),
        };
    };
    return {
        async runScript(source, context, timeoutMs) {
            const core = await coreContext(context);
            const outcome = await runScript({
                source,
                context: core,
                timeoutMs,
                adapters: options.adapters?.(context),
                mutableFields: options.mutableFields,
                ...runtime(context),
            });
            return withSetAlias(outcome);
        },
        async runTriggerScripts(trigger, context, targetId) {
            const native = { ...context, trigger };
            const core = await coreContext(native);
            const outcomes = await runTriggerScripts({
                store: options.store,
                context: core,
                targetId,
                adapters: options.adapters?.(native),
                mutableFields: options.mutableFields,
                runtime: () => runtime(native),
            });
            return outcomes.map(withSetAlias);
        },
        async runScheduledScript(scriptId, tenantId) {
            const tenant = await options.tenant(tenantId);
            const native = options.context({ trigger: 'scheduled', tenant });
            return withSetAlias(await runScheduledScript({ store: options.store, tenant, scriptId, adapters: options.adapters?.(native), runtime: () => runtime(native) }));
        },
        async runBulkScript(scriptId, tenantId) {
            const tenant = await options.tenant(tenantId);
            const native = options.context({ trigger: 'bulk', tenant });
            return withSetAlias(await runBulkScript({ store: options.store, tenant, scriptId, adapters: options.adapters?.(native), runtime: () => runtime(native) }));
        },
        async runEndpointScript(slug, tenantId, user, request) {
            const tenant = await options.tenant(tenantId);
            const native = options.context({ trigger: 'endpoint', tenant, user, request });
            const outcome = await runEndpointScript({ store: options.store, tenant, user, slug, request, adapters: options.adapters?.(native), runtime: () => runtime(native) });
            return outcome ? withSetAlias(outcome) : null;
        },
        refreshScheduledNextRuns: (tenantId) => refreshScheduledNextRuns(options.store, tenantId),
    };
}
function withSetAlias(outcome) {
    return { ...outcome, ...(outcome.changes ? { set: outcome.changes } : {}) };
}
//# sourceMappingURL=bound.js.map