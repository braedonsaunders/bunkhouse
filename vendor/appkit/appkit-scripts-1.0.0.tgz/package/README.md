# @appkit/scripts

Governed event, scheduled, endpoint, bulk, and client scripting with QuickJS isolation, audit history, and optional React and Drizzle adapters.

## Install

```bash
pnpm add @appkit/scripts
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
