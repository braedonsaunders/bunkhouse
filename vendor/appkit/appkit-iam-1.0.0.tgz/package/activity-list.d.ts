import type { AuditEventRecord } from './types.js';
export declare function ActivityList({ events }: {
    events: AuditEventRecord[];
}): import("react").JSX.Element;
//# sourceMappingURL=activity-list.d.ts.map