import type { RoleScope, ScopeOptions } from './types.js';
export declare function ScopePicker({ value, onChange, options, name, disabled, }: {
    value: RoleScope;
    onChange?: (scope: RoleScope) => void;
    options?: ScopeOptions;
    name?: string;
    disabled?: boolean;
}): import("react").JSX.Element;
//# sourceMappingURL=scope-picker.d.ts.map