import * as React from 'react';
import type { IamAdminService, PermissionGroup, RoleRecord, ScopeOptions } from './types.js';
export type RoleAdminExtension = {
    key: string;
    label: string;
    render: (context: {
        role: RoleRecord;
        service: IamAdminService;
        refresh: () => Promise<void>;
    }) => React.ReactNode;
};
export type RolesAdminProps = {
    service: IamAdminService;
    permissionGroups: PermissionGroup[];
    scopeOptions?: ScopeOptions;
    title?: string;
    description?: string;
    canManage?: boolean;
    detailTabs?: RoleAdminExtension[];
    onError?: (error: unknown) => void;
};
/**
 * Production role administration: searchable list, full editor, permission
 * matrix, duplicate/delete protections, member assignment, and scoped access.
 */
export declare function RolesAdmin({ service, permissionGroups, scopeOptions, title, description, canManage, detailTabs, onError, }: RolesAdminProps): React.JSX.Element;
//# sourceMappingURL=roles-admin.d.ts.map