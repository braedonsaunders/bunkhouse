import type { AuditEventRecord, IamAdminService, MemberRecord, RoleRecord, RoleCapabilities, MemberCapabilities } from './types.js';
export type MemoryIamSeed = {
    roles?: RoleRecord[];
    members?: MemberRecord[];
    auditEvents?: AuditEventRecord[];
};
export type MemoryIamOptions = {
    actor?: {
        userId: string;
        name: string;
        isSuperAdmin?: boolean;
    };
    now?: () => Date;
    id?: () => string;
    /** Application policy for immutable root roles and other protected records. */
    roleCapabilities?: (role: RoleRecord) => RoleCapabilities;
    /** Application policy layered over the source-compatible self/super-admin guard. */
    memberCapabilities?: (member: MemberRecord) => MemberCapabilities;
    /** Reject role and override keys outside the application's catalogue. */
    permissionCatalogue?: readonly string[];
    /** Deliver or enqueue both initial and rotated invitations. */
    afterInvitePersisted?: (member: MemberRecord, reason: 'initial' | 'resend') => Promise<void>;
    maxBulkMembers?: number;
};
export declare class IamConflictError extends Error {
    readonly name = "IamConflictError";
}
export declare class IamNotFoundError extends Error {
    readonly name = "IamNotFoundError";
}
export declare class IamProtectedRecordError extends Error {
    readonly name = "IamProtectedRecordError";
}
/**
 * Complete, deterministic adapter for browser-only applications, tests, and
 * local-first products. It exercises the same mutations and protections as a
 * persistent adapter; callers can replace it without changing UI code.
 */
export declare function createMemoryIamService(seed?: MemoryIamSeed, options?: MemoryIamOptions): IamAdminService;
//# sourceMappingURL=memory.d.ts.map