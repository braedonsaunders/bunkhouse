'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, cn } from '@appkit/ui';
import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp } from 'lucide-react';
export function SortButton({ label, active, direction, onClick, }) {
    return (_jsxs("button", { type: "button", onClick: onClick, className: "inline-flex items-center gap-1 font-medium hover:text-fg", children: [label, active ? direction === 'asc' ? _jsx(ChevronUp, { size: 13 }) : _jsx(ChevronDown, { size: 13 }) : null] }));
}
export function ServicePagination({ page, perPage, total, onPage, }) {
    const pages = Math.max(1, Math.ceil(total / perPage));
    const first = total === 0 ? 0 : (page - 1) * perPage + 1;
    const last = Math.min(total, page * perPage);
    return (_jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 text-sm text-fg-muted", children: [_jsxs("span", { children: [first, "\u2013", last, " of ", total] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Button, { size: "sm", variant: "outline", disabled: page <= 1, onClick: () => onPage(page - 1), children: [_jsx(ChevronLeft, { size: 14 }), "Previous"] }), _jsxs("span", { className: cn('min-w-20 text-center tabular-nums', pages === 1 && 'text-fg-subtle'), children: ["Page ", Math.min(page, pages), " of ", pages] }), _jsxs(Button, { size: "sm", variant: "outline", disabled: page >= pages, onClick: () => onPage(page + 1), children: ["Next", _jsx(ChevronRight, { size: 14 })] })] })] }));
}
/** Load a bounded service catalogue across every page for pickers and bulk tools. */
export async function collectAll(load) {
    const rows = [];
    for (let page = 1; page <= 10_000; page += 1) {
        const result = await load(page, 100);
        rows.push(...result.rows);
        if (result.rows.length === 0 || rows.length >= result.total)
            return rows;
    }
    throw new Error('The IAM catalogue exceeded the supported pagination boundary.');
}
//# sourceMappingURL=admin-list.js.map