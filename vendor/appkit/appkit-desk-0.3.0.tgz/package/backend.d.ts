/**
 * The backend port and its default Cloud Hypervisor implementation.
 *
 * `DeskBackend` is the seam that keeps the package testable without a
 * hypervisor: the host asks a backend to boot a `DeskLaunchPlan` and gets a
 * `DeskMachine` — a request/response channel to the in-guest agent plus an
 * event subscription. CI and non-KVM developer machines inject an in-memory
 * fake; production uses `cloudHypervisorBackend`, whose process-spawning glue
 * is deliberately thin because everything that can be pure lives in the plan
 * builder and the protocol module.
 */
import { type ChildProcess } from 'node:child_process';
import type { Duplex } from 'node:stream';
import { type DeskLaunchPlan, type DeskLauncherIdentity } from './plan.js';
import { type GuestCommand, type GuestEventMessage } from './protocol.js';
/** A booted microVM as the host sees it: one desk, one guest-agent channel. */
export interface DeskMachine {
    readonly deskId: string;
    /**
     * Send one request to the in-guest agent and await its correlated result.
     * Rejects with `DeskError` when the guest reports an error, the request
     * times out, or the connection is gone.
     */
    request(command: GuestCommand, options?: {
        timeoutMs?: number;
    }): Promise<unknown>;
    /** Subscribe to unsolicited guest events (job exits, frames, focus changes). */
    subscribe(listener: (event: GuestEventMessage) => void): () => void;
    /** Stop the VM. Idempotent; resolves once the VMM process has exited. */
    shutdown(): Promise<void>;
}
export interface DeskBackend {
    boot(plan: DeskLaunchPlan): Promise<DeskMachine>;
}
export type DeskProcessLauncher = (command: string, args: readonly string[], options: {
    identity?: DeskLauncherIdentity;
}) => ChildProcess;
export interface CloudHypervisorBackendOptions {
    /** Spawns the VMM and image tooling; injectable for tests. */
    launcher?: DeskProcessLauncher;
    /** Opens the host side of the vsock Unix socket; injectable for tests. */
    connect?: (socketPath: string) => Duplex;
    platform?: NodeJS.Platform;
    idFactory?: () => string;
    requestTimeoutMs?: number;
    connectTimeoutMs?: number;
    connectRetryDelayMs?: number;
    /** Bound on a single handshake attempt; see attemptHandshake. */
    handshakeTimeoutMs?: number;
    killGraceMs?: number;
    guestAgentPort?: number;
}
export declare function createCloudHypervisorBackend(options?: CloudHypervisorBackendOptions): DeskBackend;
/** The default backend: real Cloud Hypervisor over a real vsock socket. */
export declare const cloudHypervisorBackend: DeskBackend;
//# sourceMappingURL=backend.d.ts.map