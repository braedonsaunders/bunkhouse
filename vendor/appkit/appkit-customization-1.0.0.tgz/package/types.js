/**
 * Transaction form + record list customization — shared type model.
 *
 * This package is the single source of truth for the SHAPE of a customized
 * form layout (FormLayoutConfig) and a saved list view (ListViewConfig), plus
 * the catalog of customizable record types and their fields (the registry).
 * It is framework-agnostic (no React, no db) so the schema layer stores it,
 * the engine validates it, and the web layer renders from it.
 *
 * The value store for custom fields remains custom_field_defs + each table's
 * `custom` jsonb (see web/lib/custom-fields). This package does NOT duplicate
 * that registry — it references custom fields by their stable `cf_<key>`.
 */
export const DEFAULT_PER_PAGE = 25;
//# sourceMappingURL=types.js.map