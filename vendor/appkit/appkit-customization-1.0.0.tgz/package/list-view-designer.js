'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useMemo, useState } from 'react';
import { ChevronDown, ChevronUp, Eye, EyeOff, GripVertical, Plus, Save, Trash2 } from 'lucide-react';
import { Button, Checkbox, Input, Label, Select, cn } from '@appkit/ui';
import { OPERATORS_BY_KIND, customFieldDefKey, isCustomFieldKey, } from './registry.js';
import { defaultListView } from './schema.js';
function humanize(value) {
    const leaf = value.split('.').at(-1) ?? value;
    return leaf
        .replace(/^_/, '')
        .replace(/_/g, ' ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/^./, (character) => character.toUpperCase());
}
function reorder(items, from, to) {
    if (to < 0 || to >= items.length)
        return items;
    const next = [...items];
    const [moved] = next.splice(from, 1);
    if (!moved)
        return items;
    next.splice(to, 0, moved);
    return next;
}
function ensureColumns(view, meta, fields) {
    const placed = new Set(view.columns.map((column) => column.key));
    for (const column of meta.listColumns) {
        if (!placed.has(column.key)) {
            view.columns.push({
                key: column.key,
                visible: !column.defaultHidden,
                width: column.defaultWidth ?? null,
                labelOverride: null,
            });
            placed.add(column.key);
        }
    }
    for (const field of fields.filter((candidate) => candidate.isActive && candidate.config.showInList)) {
        const key = `cf_${field.key}`;
        if (!placed.has(key))
            view.columns.push({ key, visible: true, width: null, labelOverride: null });
    }
    return view;
}
const OPERATOR_LABELS = {
    eq: 'is',
    ne: 'is not',
    in: 'is one of',
    not_in: 'is not one of',
    gte: 'is on or after',
    lte: 'is on or before',
    between: 'is between',
    contains: 'contains',
    is_set: 'is set',
    is_not_set: 'is not set',
};
export function ListViewDesigner({ recordType, meta, view: definition, fields = [], adapter, canManageOrganization = true, resolveLabel = (_messageKey, fallback) => fallback, onChange, onSaved, onDeleted, className, }) {
    if (meta.key !== recordType)
        throw new Error('ListViewDesigner record type does not match metadata');
    const initial = useMemo(() => ensureColumns(structuredClone(definition?.config ?? defaultListView(meta)), meta, fields), [definition, fields, meta]);
    const [name, setName] = useState(definition?.name ?? `${humanize(recordType)} list`);
    const [scope, setScope] = useState(definition?.scope ?? 'organization');
    const [isDefault, setIsDefault] = useState(definition?.isDefault ?? true);
    const [isActive, setIsActive] = useState(definition?.isActive ?? true);
    const [view, setView] = useState(initial);
    const [busy, setBusy] = useState(false);
    const [feedback, setFeedback] = useState(null);
    useEffect(() => onChange?.(view), [onChange, view]);
    const customByKey = useMemo(() => new Map(fields.map((field) => [field.key, field])), [fields]);
    const columnLabel = (key) => {
        if (isCustomFieldKey(key))
            return customByKey.get(customFieldDefKey(key))?.label ?? humanize(key);
        const column = meta.listColumns.find((candidate) => candidate.key === key);
        return column ? resolveLabel(column.labelKey, humanize(key)) : humanize(key);
    };
    const filterLabel = (key) => {
        const filter = meta.listFilters.find((candidate) => candidate.key === key);
        return filter ? resolveLabel(filter.labelKey, humanize(key)) : humanize(key);
    };
    const sortableColumns = meta.listColumns.filter((column) => column.sortable);
    const updateColumn = (index, patch) => setView((current) => {
        const next = structuredClone(current);
        next.columns[index] = { ...next.columns[index], ...patch };
        return next;
    });
    const updateFilter = (index, patch) => setView((current) => {
        const next = structuredClone(current);
        next.filters[index] = { ...next.filters[index], ...patch };
        return next;
    });
    async function save() {
        setBusy(true);
        setFeedback(null);
        try {
            const saved = await adapter.saveListView({
                id: definition?.id,
                recordType,
                name: name.trim(),
                scope,
                isDefault,
                isActive,
                config: view,
            });
            setFeedback('Saved');
            onSaved?.(saved);
        }
        catch (error) {
            setFeedback(error instanceof Error ? error.message : 'Could not save the view');
        }
        finally {
            setBusy(false);
        }
    }
    async function remove() {
        if (!definition?.id || !adapter.deleteListView)
            return;
        setBusy(true);
        setFeedback(null);
        try {
            await adapter.deleteListView(definition.id);
            onDeleted?.(definition.id);
        }
        catch (error) {
            setFeedback(error instanceof Error ? error.message : 'Could not delete the view');
        }
        finally {
            setBusy(false);
        }
    }
    return (_jsxs("section", { className: cn('flex h-full min-h-0 flex-col bg-bg', className), children: [_jsxs("header", { className: "flex flex-wrap items-center gap-3 border-b border-border bg-surface px-4 py-3", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("p", { className: "text-xs font-medium text-fg-muted", children: resolveLabel(meta.labelKey, humanize(recordType)) }), _jsx(Input, { value: name, onChange: (event) => setName(event.target.value), "aria-label": "List view name", className: "mt-1 h-8 max-w-md font-semibold" })] }), feedback ? _jsx("span", { className: "text-xs text-fg-muted", role: "status", children: feedback }) : null, definition?.id && adapter.deleteListView ? (_jsxs(Button, { variant: "ghost", size: "sm", disabled: busy, onClick: remove, children: [_jsx(Trash2, { className: "size-4" }), "Delete"] })) : null, _jsxs(Button, { size: "sm", disabled: busy || !name.trim(), onClick: save, children: [_jsx(Save, { className: "size-4" }), busy ? 'Saving…' : 'Save view'] })] }), _jsx("div", { className: "min-h-0 flex-1 overflow-y-auto overscroll-contain p-4", children: _jsxs("div", { className: "mx-auto max-w-5xl space-y-7 pb-8", children: [_jsxs("section", { className: "space-y-3", children: [_jsx("h2", { className: "text-xs font-semibold uppercase tracking-wide text-fg-muted", children: "Columns" }), _jsxs("div", { className: "overflow-x-auto rounded-lg border border-border bg-surface", children: [_jsxs("div", { className: "grid min-w-[680px] grid-cols-[minmax(180px,1fr)_minmax(150px,0.8fr)_96px_104px] gap-2 border-b border-border bg-bg-subtle px-3 py-2 text-xs font-semibold text-fg-muted", children: [_jsx("span", { children: "Column" }), _jsx("span", { children: "Label" }), _jsx("span", { children: "Width" }), _jsx("span", { className: "text-right", children: "Controls" })] }), _jsx("div", { className: "divide-y divide-border", children: view.columns.map((column, index) => {
                                                const locked = Boolean(meta.listColumns.find((candidate) => candidate.key === column.key)?.locked);
                                                return (_jsxs("div", { className: cn('grid min-w-[680px] grid-cols-[minmax(180px,1fr)_minmax(150px,0.8fr)_96px_104px] items-center gap-2 px-3 py-2', !column.visible && 'opacity-60'), children: [_jsxs("div", { className: "flex min-w-0 items-center gap-2", children: [_jsx(GripVertical, { className: "size-4 shrink-0 text-fg-subtle" }), _jsx("span", { className: "truncate text-sm font-medium text-fg", children: columnLabel(column.key) }), locked ? _jsx("span", { className: "rounded border border-border px-1.5 py-0.5 text-[10px] text-fg-muted", children: "Locked" }) : null] }), _jsx(Input, { value: column.labelOverride ?? '', disabled: locked, onChange: (event) => updateColumn(index, { labelOverride: event.target.value || null }), placeholder: columnLabel(column.key), "aria-label": `Rename ${columnLabel(column.key)}`, className: "h-8" }), _jsx(Input, { type: "number", min: 40, max: 800, value: column.width ?? '', onChange: (event) => updateColumn(index, { width: event.target.value ? Number(event.target.value) : null }), "aria-label": `${columnLabel(column.key)} width`, className: "h-8" }), _jsxs("div", { className: "flex justify-end", children: [_jsx(RowButton, { label: "Move column up", onClick: () => setView((current) => ({ ...current, columns: reorder(current.columns, index, index - 1) })), children: _jsx(ChevronUp, {}) }), _jsx(RowButton, { label: "Move column down", onClick: () => setView((current) => ({ ...current, columns: reorder(current.columns, index, index + 1) })), children: _jsx(ChevronDown, {}) }), _jsx(RowButton, { label: column.visible ? 'Hide column' : 'Show column', disabled: locked, onClick: () => updateColumn(index, { visible: !column.visible }), children: column.visible ? _jsx(Eye, {}) : _jsx(EyeOff, {}) })] })] }, column.key));
                                            }) })] })] }), _jsxs("section", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-center justify-between gap-3", children: [_jsx("h2", { className: "text-xs font-semibold uppercase tracking-wide text-fg-muted", children: "Filters" }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => setView((current) => {
                                                const next = structuredClone(current);
                                                const first = meta.listFilters[0];
                                                if (first) {
                                                    next.filters.push({
                                                        key: first.key,
                                                        operator: first.operators[0] ?? 'eq',
                                                        value: '',
                                                        to: null,
                                                    });
                                                }
                                                return next;
                                            }), children: [_jsx(Plus, { className: "size-4" }), "Add filter"] })] }), view.filters.length === 0 ? (_jsx("div", { className: "rounded-lg border border-dashed border-border p-5 text-sm text-fg-subtle", children: "No filters. This view includes every matching record." })) : (_jsx("div", { className: "space-y-2", children: view.filters.map((filter, index) => {
                                        const filterMeta = meta.listFilters.find((candidate) => candidate.key === filter.key);
                                        const operators = filterMeta?.operators ?? OPERATORS_BY_KIND.text;
                                        const value = Array.isArray(filter.value) ? filter.value.join(', ') : filter.value ?? '';
                                        return (_jsxs("div", { className: "grid gap-2 rounded-lg border border-border bg-surface p-3 sm:grid-cols-[minmax(150px,1fr)_minmax(130px,0.8fr)_minmax(150px,1fr)_minmax(120px,0.8fr)_32px]", children: [_jsx(Select, { value: filter.key, onChange: (event) => {
                                                        const nextMeta = meta.listFilters.find((candidate) => candidate.key === event.target.value);
                                                        updateFilter(index, {
                                                            key: event.target.value,
                                                            operator: nextMeta?.operators[0] ?? 'eq',
                                                            value: '',
                                                            to: null,
                                                        });
                                                    }, "aria-label": "Filter field", children: meta.listFilters.map((candidate) => (_jsx("option", { value: candidate.key, children: filterLabel(candidate.key) }, candidate.key))) }), _jsx(Select, { value: filter.operator, onChange: (event) => updateFilter(index, { operator: event.target.value }), "aria-label": "Filter operator", children: operators.map((operator) => _jsx("option", { value: operator, children: OPERATOR_LABELS[operator] }, operator)) }), filter.operator === 'is_set' || filter.operator === 'is_not_set' ? _jsx("span", {}) : filterMeta?.kind === 'boolean' ? (_jsxs(Select, { value: String(value), onChange: (event) => updateFilter(index, { value: event.target.value }), "aria-label": "Filter value", children: [_jsx("option", { value: "true", children: "Yes" }), _jsx("option", { value: "false", children: "No" })] })) : filterMeta?.kind === 'select' && filterMeta.options ? (_jsxs(Select, { value: String(value), onChange: (event) => updateFilter(index, { value: event.target.value }), "aria-label": "Filter value", children: [_jsx("option", { value: "", children: "Choose\u2026" }), filterMeta.options.map((option) => (_jsx("option", { value: option.value, children: option.labelKey ? resolveLabel(option.labelKey, humanize(option.value)) : humanize(option.value) }, option.value)))] })) : (_jsx(Input, { value: String(value), onChange: (event) => updateFilter(index, {
                                                        value: filter.operator === 'in' || filter.operator === 'not_in'
                                                            ? event.target.value.split(',').map((part) => part.trim()).filter(Boolean)
                                                            : event.target.value,
                                                    }), placeholder: filterMeta?.kind === 'entity_ref' ? 'Record ID' : 'Value', "aria-label": "Filter value" })), filter.operator === 'between' ? (_jsx(Input, { value: filter.to ?? '', onChange: (event) => updateFilter(index, { to: event.target.value }), placeholder: "To", "aria-label": "Filter upper bound" })) : _jsx("span", {}), _jsx(RowButton, { label: "Remove filter", onClick: () => setView((current) => {
                                                        const next = structuredClone(current);
                                                        next.filters.splice(index, 1);
                                                        return next;
                                                    }), children: _jsx(Trash2, {}) })] }, index));
                                    }) }))] }), _jsxs("section", { className: "grid gap-4 rounded-lg border border-border bg-surface p-4 sm:grid-cols-4", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Sort by" }), _jsxs(Select, { value: view.sort?.column ?? '', onChange: (event) => setView((current) => ({
                                                ...current,
                                                sort: event.target.value
                                                    ? { column: event.target.value, dir: current.sort?.dir ?? 'desc' }
                                                    : null,
                                            })), children: [_jsx("option", { value: "", children: "No sort" }), sortableColumns.map((column) => _jsx("option", { value: column.key, children: columnLabel(column.key) }, column.key))] })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Direction" }), _jsxs(Select, { value: view.sort?.dir ?? 'desc', disabled: !view.sort, onChange: (event) => setView((current) => ({
                                                ...current,
                                                sort: current.sort ? { ...current.sort, dir: event.target.value } : null,
                                            })), children: [_jsx("option", { value: "asc", children: "Ascending" }), _jsx("option", { value: "desc", children: "Descending" })] })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Rows per page" }), _jsx(Input, { type: "number", min: 5, max: 100, value: view.perPage ?? 25, onChange: (event) => setView((current) => ({ ...current, perPage: Number(event.target.value) || 25 })) })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Scope" }), _jsxs(Select, { value: scope, disabled: !canManageOrganization, onChange: (event) => setScope(event.target.value), children: [_jsx("option", { value: "user", children: "Only me" }), _jsx("option", { value: "organization", children: "Organization" })] })] })] }), _jsxs("div", { className: "flex flex-wrap items-center justify-between gap-4 rounded-lg border border-border bg-surface p-4", children: [_jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { checked: isActive, onChange: (event) => setIsActive(event.target.checked) }), "Active"] }), _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { checked: isDefault, onChange: (event) => setIsDefault(event.target.checked) }), "Default view"] })] })] }) })] }));
}
function RowButton({ label, onClick, disabled, children, }) {
    return (_jsx("button", { type: "button", "aria-label": label, title: label, disabled: disabled, onClick: onClick, className: "rounded-sm p-1 text-fg-subtle transition-colors hover:bg-surface-hover hover:text-fg disabled:pointer-events-none disabled:opacity-30", children: _jsx("span", { className: "[&>svg]:size-4", children: children }) }));
}
//# sourceMappingURL=list-view-designer.js.map