import { type ReactNode } from 'react';
import type { RecordTypeMeta } from './types.js';
import type { CustomFieldDefinition, CustomizationDesignerAdapter, CustomizationLabelResolver, FormDefinition, ListViewDefinition } from './designer-types.js';
export type CustomizationStudioMode = 'forms' | 'views' | 'fields';
export interface CustomizationStudioProps {
    adapter: CustomizationDesignerAdapter;
    forms: FormDefinition[];
    views: ListViewDefinition[];
    fields: CustomFieldDefinition[];
    recordTypes: readonly RecordTypeMeta[];
    initialRecordType?: string;
    initialMode?: CustomizationStudioMode;
    resolveLabel?: CustomizationLabelResolver;
    canManageOrganization?: boolean;
    roleOptions?: {
        value: string;
        label: string;
    }[];
    footer?: ReactNode;
    className?: string;
}
export declare function CustomizationStudio({ adapter, forms, views, fields, recordTypes, initialRecordType, initialMode, resolveLabel, canManageOrganization, roleOptions, footer, className, }: CustomizationStudioProps): import("react").JSX.Element;
//# sourceMappingURL=customization-studio.d.ts.map