import type { FormLayoutConfig, RecordTypeMeta } from './types.js';
import type { CustomFieldDefinition, CustomizationDesignerAdapter, CustomizationLabelResolver, FormDefinition } from './designer-types.js';
export interface FormDesignerProps {
    recordType: string;
    meta: RecordTypeMeta;
    form?: FormDefinition;
    fields?: CustomFieldDefinition[];
    adapter: Pick<CustomizationDesignerAdapter, 'saveForm' | 'deleteForm' | 'saveField'>;
    resolveLabel?: CustomizationLabelResolver;
    onChange?: (layout: FormLayoutConfig) => void;
    onSaved?: (definition: FormDefinition) => void;
    onDeleted?: (id: string) => void;
    className?: string;
}
export declare function FormDesigner({ recordType, meta, form, fields, adapter, resolveLabel, onChange, onSaved, onDeleted, className, }: FormDesignerProps): import("react").JSX.Element;
//# sourceMappingURL=form-designer.d.ts.map