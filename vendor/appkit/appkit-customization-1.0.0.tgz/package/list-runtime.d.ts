import type { FilterClause, ListColumnKind, ListColumnMeta, ListViewConfig, RecordTypeMeta } from './types.js';
import type { CustomizationRegistry } from './registry.js';
export interface SavedListView {
    id: string;
    recordType: string;
    name: string;
    scope: 'organization' | 'user';
    ownerId?: string | null;
    isDefault: boolean;
    isActive: boolean;
    config: ListViewConfig;
}
export interface ListViewStore {
    list(recordType: string, userId: string): Promise<SavedListView[]>;
    preferred(recordType: string, userId: string): Promise<string | null>;
    setPreferred?(recordType: string, userId: string, viewId: string | null): Promise<void>;
}
export interface ListViewActor {
    userId: string;
    canManageOrganizationViews?: boolean;
}
export interface SaveListViewInput {
    id?: string;
    recordType: string;
    name: string;
    scope: SavedListView['scope'];
    isDefault?: boolean;
    isActive?: boolean;
    config: ListViewConfig;
    actor: ListViewActor;
}
/** Complete saved-view persistence contract used by the extracted designers. */
export interface MutableListViewStore extends ListViewStore {
    save(input: SaveListViewInput): Promise<SavedListView>;
    remove(id: string, actor: ListViewActor): Promise<void>;
}
export declare function normalizeSavedListViewInput(input: SaveListViewInput, registry: CustomizationRegistry): Omit<SavedListView, 'id'>;
export declare function assertListViewWriteAllowed(view: Pick<SavedListView, 'scope' | 'ownerId'>, actor: ListViewActor): void;
export interface ResolvedListView {
    view: ListViewConfig;
    source: 'explicit' | 'user' | 'organization' | 'system';
    row: SavedListView | null;
    available: SavedListView[];
}
export interface DynamicListColumn {
    key: string;
    label: string;
    kind?: ListColumnKind;
    width?: number | null;
}
export interface ResolvedListColumn extends ListColumnMeta {
    label: string;
    width?: number;
}
export interface RecordListQuery<R extends Record<string, unknown>> {
    rows: R[];
    view: ListViewConfig;
    meta: RecordTypeMeta;
    search?: string;
    searchFields?: string[];
    filters?: FilterClause[];
    page?: number;
    perPage?: number;
}
export interface RecordListResult<R extends Record<string, unknown>> {
    rows: R[];
    total: number;
    page: number;
    perPage: number;
    pageCount: number;
}
/**
 * Preserve the source precedence exactly: explicit view, user preference,
 * organization default, first accessible view, then the supplied system view.
 */
export declare function resolveListView(options: {
    recordType: string;
    userId: string;
    explicitViewId?: string | null;
    systemView: ListViewConfig;
    store: ListViewStore;
    dynamicColumns?: DynamicListColumn[];
    meta: RecordTypeMeta;
}): Promise<ResolvedListView>;
/** Merge newly registered and live custom columns without disturbing user order. */
export declare function mergeListViewColumns(view: ListViewConfig, meta: RecordTypeMeta, dynamicColumns?: DynamicListColumn[]): ListViewConfig;
export declare function resolveListColumns(view: ListViewConfig, meta: RecordTypeMeta, labels: (messageKey: string, fallback: string) => string, dynamicColumns?: DynamicListColumn[]): ResolvedListColumn[];
/** Database-free execution for demos, local-first apps, and contract tests. */
export declare function queryRecordList<R extends Record<string, unknown>>(query: RecordListQuery<R>): RecordListResult<R>;
export declare function matchesFilter(value: unknown, filter: FilterClause): boolean;
//# sourceMappingURL=list-runtime.d.ts.map