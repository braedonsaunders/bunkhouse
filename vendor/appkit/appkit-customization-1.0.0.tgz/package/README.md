# @appkit/customization

Production form, custom-field, saved-view, and record-list runtime with React, memory, and Drizzle adapters.

## Install

```bash
pnpm add @appkit/customization
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
