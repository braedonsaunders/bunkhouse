'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowDown, ArrowUp, Check, ChevronDown, ChevronLeft, ChevronRight, Eye, Search, X } from 'lucide-react';
import { Badge, Button, EmptyState, Input, Popover, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, SubtabNav, cn, } from '@appkit/ui';
import { resolveListColumns, } from './list-runtime.js';
/**
 * Source record-list composition with every product concern injected: saved
 * views, search, compact filters, typed/sortable columns, drill-through,
 * actions, pagination, and optional page subtabs.
 */
export function RecordListView({ meta, view, rows, total, page, perPage, views = [], currentViewId, currentViewName = 'Default view', dynamicColumns = [], quickFilters = [], subtabs = [], activeSubtab, search = '', searchPlaceholder = 'Search', emptyTitle = 'No records', emptyDescription = 'There are no records in this view.', emptyAction, currency, canManageViews = false, resolveLabel = (_key, fallback) => fallback, rowKey, onSearchChange, onPageChange, onSortChange, onViewChange, onSetDefaultView, onCreateView, onManageViews, onSubtabChange, onOpenRow, statusVariant, renderCell, renderRowActions, className, }) {
    const columns = React.useMemo(() => resolveListColumns(view, meta, resolveLabel, dynamicColumns), [dynamicColumns, meta, resolveLabel, view]);
    const pageCount = Math.max(1, Math.ceil(total / perPage));
    return _jsxs("div", { className: cn('space-y-3', className), children: [subtabs.length ? _jsx(SubtabNav, { tabs: subtabs, active: activeSubtab ?? subtabs[0]?.key ?? '', onSelect: onSubtabChange, ariaLabel: "Record sections", className: "border-b border-border" }) : null, _jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [_jsx(ControlledSearch, { value: search, placeholder: searchPlaceholder, onChange: onSearchChange }), quickFilters.map((filter) => _jsx(QuickFilterMenu, { filter: filter }, filter.key)), views.length || canManageViews ? _jsx(SavedViewsMenu, { views: views, currentId: currentViewId ?? null, currentName: currentViewName, canManage: canManageViews, onChange: onViewChange, onSetDefault: onSetDefaultView, onCreate: onCreateView, onManage: onManageViews }) : null] }), total === 0 ? _jsx(EmptyState, { title: emptyTitle, description: emptyDescription, action: emptyAction }) : _jsxs(_Fragment, { children: [_jsxs(Table, { children: [_jsx(TableHeader, { children: _jsx(TableRow, { noAnimate: true, children: columns.map((column) => _jsx(RecordTableHead, { column: column, sort: view.sort, onSort: onSortChange }, column.key)) }) }), _jsx(TableBody, { children: rows.map((row) => _jsx(TableRow, { children: columns.map((column) => _jsx(RecordCell, { row: row, column: column, onOpen: onOpenRow, render: renderCell, actions: renderRowActions, currency: currency, statusVariant: statusVariant }, column.key)) }, rowKey(row))) })] }), _jsx(RecordPagination, { total: total, page: page, perPage: perPage, pageCount: pageCount, onChange: onPageChange })] })] });
}
function ControlledSearch({ value, placeholder, onChange }) {
    const [edit, setEdit] = React.useState(value);
    React.useEffect(() => setEdit(value), [value]);
    React.useEffect(() => {
        if (edit === value || !onChange)
            return;
        const handle = window.setTimeout(() => onChange(edit), 250);
        return () => window.clearTimeout(handle);
    }, [edit, onChange, value]);
    return _jsxs("div", { className: "relative w-full sm:w-72", children: [_jsx(Search, { className: "pointer-events-none absolute left-2.5 top-2 text-fg-subtle", size: 16 }), _jsx(Input, { type: "search", "aria-label": "Search", placeholder: placeholder, value: edit, onChange: (event) => setEdit(event.target.value), className: "h-8 pl-9 pr-9 [&::-webkit-search-cancel-button]:hidden" }), edit ? _jsx("button", { type: "button", "aria-label": "Clear search", onClick: () => setEdit(''), className: "absolute right-2.5 top-2 text-fg-subtle hover:text-fg", children: _jsx(X, { size: 16 }) }) : null] });
}
function QuickFilterMenu({ filter }) {
    const [open, setOpen] = React.useState(false);
    const active = filter.options.find((option) => option.value === filter.value);
    return _jsx(Popover, { open: open, onOpenChange: setOpen, align: "start", className: "min-w-52 p-1", trigger: _jsxs("button", { type: "button", "aria-haspopup": "listbox", "aria-expanded": open, onClick: () => setOpen((value) => !value), className: cn('inline-flex h-8 max-w-64 items-center gap-1.5 rounded-md border px-3 text-sm transition-colors', active ? 'border-primary/40 bg-primary-subtle text-primary' : 'border-border bg-surface text-fg hover:bg-surface-hover'), children: [_jsx("span", { className: active ? 'text-primary/80' : 'text-fg-muted', children: active ? `${filter.label}:` : filter.label }), active ? _jsx("span", { className: "truncate font-semibold", children: active.label }) : null, _jsx(ChevronDown, { className: cn('ml-auto size-3.5 text-fg-subtle transition-transform', open && 'rotate-180') })] }), children: _jsxs("div", { className: "max-h-72 overflow-auto", role: "listbox", children: [_jsx(MenuChoice, { label: filter.allLabel ?? 'All', selected: !filter.value, onClick: () => { filter.onChange(undefined); setOpen(false); } }), filter.options.map((option) => _jsx(MenuChoice, { label: option.label, count: option.count, selected: filter.value === option.value, onClick: () => { filter.onChange(option.value); setOpen(false); } }, option.value))] }) });
}
function SavedViewsMenu({ views, currentId, currentName, canManage, onChange, onSetDefault, onCreate, onManage }) {
    const [open, setOpen] = React.useState(false);
    const [busy, setBusy] = React.useState(false);
    const setDefault = async (id) => {
        setBusy(true);
        try {
            await onSetDefault?.(id);
            setOpen(false);
        }
        finally {
            setBusy(false);
        }
    };
    return _jsx(Popover, { open: open, onOpenChange: setOpen, align: "start", className: "w-64 p-0", trigger: _jsxs(Button, { variant: "outline", size: "sm", onClick: () => setOpen((value) => !value), "aria-expanded": open, "aria-haspopup": "menu", children: [_jsx("span", { className: "text-xs text-fg-muted", children: "View" }), _jsx("span", { className: "max-w-48 truncate font-medium", children: currentName }), _jsx(ChevronDown, { className: "size-3.5 text-fg-subtle" })] }), children: _jsxs("div", { className: "py-1 text-sm", role: "menu", children: [views.length ? views.map((view) => _jsxs("button", { type: "button", role: "menuitem", onClick: () => { onChange?.(view.id); setOpen(false); }, className: cn('flex w-full items-center gap-2 px-3 py-1.5 text-left hover:bg-surface-hover', view.id === currentId && 'text-primary'), children: [_jsx("span", { className: "flex-1 truncate", children: view.name }), view.scope === 'organization' ? _jsx("span", { className: "text-[10px] uppercase tracking-wide text-fg-subtle", children: "Shared" }) : null, view.isDefault ? _jsx("span", { className: "text-[10px] uppercase tracking-wide text-fg-subtle", children: "Default" }) : null, view.id === currentId ? _jsx(Check, { className: "size-3.5" }) : null] }, view.id)) : _jsx("div", { className: "px-3 py-2 text-fg-muted", children: "No saved views" }), _jsxs("div", { className: "mt-1 border-t border-border pt-1", children: [_jsx(MenuAction, { disabled: busy || !currentId || !onSetDefault, onClick: () => void setDefault(currentId), children: "Set as my default" }), _jsx(MenuAction, { disabled: busy || !onSetDefault, onClick: () => void setDefault(null), children: "Use organization default" }), canManage && onCreate ? _jsx(MenuAction, { emphasis: true, onClick: () => { onCreate(); setOpen(false); }, children: "New view" }) : null, canManage && onManage ? _jsx(MenuAction, { emphasis: true, onClick: () => { onManage(); setOpen(false); }, children: "Manage views" }) : null] })] }) });
}
function RecordTableHead({ column, sort, onSort }) {
    const sortable = Boolean(column.sortable && onSort);
    const active = sort?.column === column.key;
    const direction = active ? sort?.dir ?? 'desc' : 'desc';
    return _jsx(TableHead, { className: cn(column.kind === 'amount' && 'text-right', column.kind === 'actions' && 'w-px px-2 text-center'), style: column.width ? { width: column.width } : undefined, children: sortable ? _jsxs("button", { type: "button", onClick: () => onSort?.(column.key, active && direction === 'desc' ? 'asc' : 'desc'), className: cn('inline-flex items-center gap-1 hover:text-fg', column.kind === 'amount' && 'w-full justify-end'), "aria-label": `Sort by ${column.label}`, children: [column.label, active ? direction === 'asc' ? _jsx(ArrowUp, { className: "size-3" }) : _jsx(ArrowDown, { className: "size-3" }) : null] }) : column.label });
}
function RecordCell({ row, column, onOpen, render, actions, currency, statusVariant }) {
    const value = row[column.key];
    const custom = render?.({ row, column, value });
    const content = custom !== undefined ? custom : defaultCell(value, column.kind, row, onOpen, actions, currency, statusVariant);
    return _jsx(TableCell, { className: cn(column.kind === 'amount' && 'text-right tabular-nums', column.kind === 'reference' && 'font-mono text-[13px] font-semibold', column.kind === 'actions' && 'w-px whitespace-nowrap px-2 text-center'), children: content });
}
function defaultCell(value, kind, row, onOpen, actions, currency, statusVariant) {
    if (kind === 'actions')
        return actions?.(row) ?? (onOpen ? _jsx(Button, { size: "icon", variant: "ghost", onClick: () => onOpen(row), "aria-label": "Open record", children: _jsx(Eye, { className: "size-4" }) }) : null);
    if (value === null || value === undefined || value === '')
        return _jsx("span", { className: "text-fg-subtle", children: "\u2014" });
    if (kind === 'reference' && onOpen)
        return _jsx("button", { type: "button", onClick: () => onOpen(row), className: "text-primary hover:underline", children: display(value) });
    if (kind === 'amount')
        return typeof value === 'number'
            ? new Intl.NumberFormat(undefined, currency ? { style: 'currency', currency } : { maximumFractionDigits: 2 }).format(value)
            : display(value);
    if (kind === 'status')
        return _jsx(Badge, { variant: statusVariant?.(String(value), row) ?? 'secondary', children: humanize(String(value)) });
    if (kind === 'date') {
        const text = String(value);
        const date = value instanceof Date ? value : new Date(text);
        return Number.isNaN(date.getTime()) ? display(value) : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', ...(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(text) ? { timeZone: 'UTC' } : {}) }).format(date);
    }
    return display(value);
}
function RecordPagination({ total, page, perPage, pageCount, onChange }) {
    const from = total ? (page - 1) * perPage + 1 : 0;
    const to = Math.min(total, page * perPage);
    return _jsxs("div", { className: "flex items-center justify-between gap-2 px-3 py-2 text-sm text-fg-muted", children: [_jsx("span", { children: total ? _jsxs(_Fragment, { children: ["Showing ", _jsx("strong", { className: "font-medium text-fg", children: from.toLocaleString() }), "\u2013", _jsx("strong", { className: "font-medium text-fg", children: to.toLocaleString() }), " of ", _jsx("strong", { className: "font-medium text-fg", children: total.toLocaleString() })] }) : 'No results' }), pageCount > 1 ? _jsxs("div", { className: "flex items-center gap-1", children: [_jsxs(PageButton, { disabled: page <= 1, onClick: () => onChange?.(page - 1), children: [_jsx(ChevronLeft, { className: "size-3.5" }), "Prev"] }), _jsxs("span", { className: "px-2 text-fg-subtle", children: ["Page ", page, " of ", pageCount] }), _jsxs(PageButton, { disabled: page >= pageCount, onClick: () => onChange?.(page + 1), children: ["Next", _jsx(ChevronRight, { className: "size-3.5" })] })] }) : null] });
}
function MenuChoice({ label, count, selected, onClick }) { return _jsxs("button", { type: "button", role: "option", "aria-selected": selected, onClick: onClick, className: cn('flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm transition-colors', selected ? 'bg-primary-subtle font-medium text-primary' : 'text-fg hover:bg-surface-hover'), children: [_jsx(Check, { className: cn('size-3.5 shrink-0', !selected && 'text-transparent') }), _jsx("span", { className: "flex-1 truncate", children: label }), typeof count === 'number' ? _jsx("span", { className: "text-xs tabular-nums text-fg-subtle", children: count }) : null] }); }
function MenuAction({ children, disabled, emphasis, onClick }) { return _jsx("button", { type: "button", disabled: disabled, onClick: onClick, className: cn('w-full px-3 py-1.5 text-left hover:bg-surface-hover disabled:opacity-40', emphasis ? 'text-primary' : 'text-fg-muted'), children: children }); }
function PageButton({ children, disabled, onClick }) { return _jsx("button", { type: "button", disabled: disabled, onClick: onClick, className: "inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs text-fg hover:bg-surface-hover disabled:cursor-not-allowed disabled:text-fg-subtle", children: children }); }
function display(value) { return Array.isArray(value) ? value.join(', ') : value instanceof Date ? value.toISOString() : typeof value === 'object' ? JSON.stringify(value) : String(value); }
function humanize(value) { return value.replace(/_/g, ' ').replace(/^./, (character) => character.toUpperCase()); }
//# sourceMappingURL=record-list-view.js.map