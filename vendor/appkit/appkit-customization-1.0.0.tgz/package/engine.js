import { createCustomizationRegistry, } from './registry.js';
import { defaultFormLayout, defaultListView, lintFormLayout, lintListView, mergeRegisteredFieldsIntoLayout, parseFormLayout, parseListView, refreshDefaultFormLayout, } from './schema.js';
export function createCustomizationEngine(recordTypes) {
    const registry = createCustomizationRegistry(recordTypes);
    const requireRecordType = (recordType) => {
        const meta = registry.getRecordType(recordType);
        if (!meta)
            throw new Error(`unknown record type: ${recordType}`);
        return meta;
    };
    const engine = {
        registry,
        getRecordType: registry.getRecordType,
        defaultFormLayout(recordType) {
            return defaultFormLayout(requireRecordType(recordType));
        },
        defaultListView(recordType) {
            return defaultListView(requireRecordType(recordType));
        },
        mergeRegisteredFieldsIntoLayout(layout) {
            return mergeRegisteredFieldsIntoLayout(layout, requireRecordType(layout.recordType));
        },
        refreshDefaultFormLayout(layout) {
            return refreshDefaultFormLayout(layout, requireRecordType(layout.recordType));
        },
        lintFormLayout(layout) {
            return lintFormLayout(layout, registry);
        },
        lintListView(view) {
            return lintListView(view, registry);
        },
        parseFormLayout(input) {
            return parseFormLayout(input, registry);
        },
        parseListView(input) {
            return parseListView(input, registry);
        },
    };
    return Object.freeze(engine);
}
//# sourceMappingURL=engine.js.map