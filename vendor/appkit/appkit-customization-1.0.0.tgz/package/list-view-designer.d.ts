import type { ListViewConfig, RecordTypeMeta } from './types.js';
import type { CustomFieldDefinition, CustomizationDesignerAdapter, CustomizationLabelResolver, ListViewDefinition } from './designer-types.js';
export interface ListViewDesignerProps {
    recordType: string;
    meta: RecordTypeMeta;
    view?: ListViewDefinition;
    fields?: CustomFieldDefinition[];
    adapter: Pick<CustomizationDesignerAdapter, 'saveListView' | 'deleteListView'>;
    canManageOrganization?: boolean;
    resolveLabel?: CustomizationLabelResolver;
    onChange?: (config: ListViewConfig) => void;
    onSaved?: (definition: ListViewDefinition) => void;
    onDeleted?: (id: string) => void;
    className?: string;
}
export declare function ListViewDesigner({ recordType, meta, view: definition, fields, adapter, canManageOrganization, resolveLabel, onChange, onSaved, onDeleted, className, }: ListViewDesignerProps): import("react").JSX.Element;
//# sourceMappingURL=list-view-designer.d.ts.map