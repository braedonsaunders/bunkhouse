import * as React from 'react';
import { type BadgeProps, type SubtabItem } from '@appkit/ui';
import type { ListViewConfig, RecordTypeMeta } from './types.js';
import { type DynamicListColumn, type ResolvedListColumn, type SavedListView } from './list-runtime.js';
import type { CustomizationLabelResolver } from './designer-types.js';
export interface RecordListFilterOption {
    value: string;
    label: string;
    count?: number;
}
export interface RecordListQuickFilter {
    key: string;
    label: string;
    value?: string;
    options: RecordListFilterOption[];
    allLabel?: string;
    onChange: (value: string | undefined) => void;
}
export interface RecordListSubtab extends Omit<SubtabItem, 'label'> {
    label: string;
}
export interface RecordListViewProps<R extends Record<string, unknown>> {
    meta: RecordTypeMeta;
    view: ListViewConfig;
    rows: R[];
    total: number;
    page: number;
    perPage: number;
    views?: SavedListView[];
    currentViewId?: string | null;
    currentViewName?: string;
    dynamicColumns?: DynamicListColumn[];
    quickFilters?: RecordListQuickFilter[];
    subtabs?: RecordListSubtab[];
    activeSubtab?: string;
    search?: string;
    searchPlaceholder?: string;
    emptyTitle?: string;
    emptyDescription?: string;
    emptyAction?: React.ReactNode;
    currency?: string;
    canManageViews?: boolean;
    resolveLabel?: CustomizationLabelResolver;
    rowKey: (row: R) => React.Key;
    onSearchChange?: (value: string) => void;
    onPageChange?: (page: number) => void;
    onSortChange?: (column: string, direction: 'asc' | 'desc') => void;
    onViewChange?: (viewId: string) => void;
    onSetDefaultView?: (viewId: string | null) => Promise<void> | void;
    onCreateView?: () => void;
    onManageViews?: () => void;
    onSubtabChange?: (key: string) => void;
    onOpenRow?: (row: R) => void;
    statusVariant?: (value: string, row: R) => NonNullable<BadgeProps['variant']>;
    renderCell?: (context: {
        row: R;
        column: ResolvedListColumn;
        value: unknown;
    }) => React.ReactNode;
    renderRowActions?: (row: R) => React.ReactNode;
    className?: string;
}
/**
 * Source record-list composition with every product concern injected: saved
 * views, search, compact filters, typed/sortable columns, drill-through,
 * actions, pagination, and optional page subtabs.
 */
export declare function RecordListView<R extends Record<string, unknown>>({ meta, view, rows, total, page, perPage, views, currentViewId, currentViewName, dynamicColumns, quickFilters, subtabs, activeSubtab, search, searchPlaceholder, emptyTitle, emptyDescription, emptyAction, currency, canManageViews, resolveLabel, rowKey, onSearchChange, onPageChange, onSortChange, onViewChange, onSetDefaultView, onCreateView, onManageViews, onSubtabChange, onOpenRow, statusVariant, renderCell, renderRowActions, className, }: RecordListViewProps<R>): React.JSX.Element;
//# sourceMappingURL=record-list-view.d.ts.map