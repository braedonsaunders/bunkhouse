import { type CustomizationRegistry } from './registry.js';
import { type LintIssue, type ParseResult } from './schema.js';
import type { FormLayoutConfig, ListViewConfig, RecordTypeMeta } from './types.js';
/**
 * Catalogue-bound API for application cutovers. Configure record metadata once,
 * then retain the source-shaped record-type-key calls at every use site.
 */
export interface CustomizationEngine {
    readonly registry: CustomizationRegistry;
    getRecordType(recordType: string): RecordTypeMeta | undefined;
    defaultFormLayout(recordType: string): FormLayoutConfig;
    defaultListView(recordType: string): ListViewConfig;
    mergeRegisteredFieldsIntoLayout(layout: FormLayoutConfig): FormLayoutConfig;
    refreshDefaultFormLayout(layout: FormLayoutConfig): FormLayoutConfig;
    lintFormLayout(layout: FormLayoutConfig): LintIssue[];
    lintListView(view: ListViewConfig): LintIssue[];
    parseFormLayout(input: unknown): ParseResult<FormLayoutConfig>;
    parseListView(input: unknown): ParseResult<ListViewConfig>;
}
export declare function createCustomizationEngine(recordTypes: readonly RecordTypeMeta[]): CustomizationEngine;
//# sourceMappingURL=engine.d.ts.map