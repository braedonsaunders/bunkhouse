import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import { type MutableListViewStore } from './list-runtime.js';
import type { CustomizationRegistry } from './registry.js';
type Db = NodePgDatabase<Record<string, never>>;
export interface DrizzleListViewStoreOptions {
    tenantId: string;
    registry: CustomizationRegistry;
}
/**
 * Production saved-view repository. Bind it to an RLS-scoped database handle;
 * explicit tenant and owner predicates remain in every query as defense in
 * depth. Applications keep authorization policy outside the repository and
 * pass the resulting organization-management capability with each mutation.
 */
export declare function createDrizzleListViewStore(db: Db, options: DrizzleListViewStoreOptions): MutableListViewStore;
export { formLayouts, userFormPreferences, listViews, userListPreferences, LIST_VIEW_SCOPES, CUSTOMIZATION_TENANT_TABLES, } from './persistence-schema.js';
//# sourceMappingURL=drizzle.d.ts.map