import type { CustomFieldDefinition, CustomizationDesignerAdapter } from './designer-types.js';
export interface CustomFieldDesignerProps {
    recordType: string;
    level: 'header' | 'line';
    targets?: {
        recordType: string;
        label: string;
        supportsLines: boolean;
    }[];
    field?: CustomFieldDefinition;
    adapter: Pick<CustomizationDesignerAdapter, 'saveField' | 'deleteField'>;
    roleOptions?: {
        value: string;
        label: string;
    }[];
    onSaved?: (definition: CustomFieldDefinition) => void;
    onDeleted?: (id: string) => void;
    className?: string;
}
export declare function CustomFieldDesigner({ recordType, level, targets, field, adapter, roleOptions, onSaved, onDeleted, className, }: CustomFieldDesignerProps): import("react").JSX.Element;
//# sourceMappingURL=custom-field-designer.d.ts.map