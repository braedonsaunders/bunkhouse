/**
 * Application-supplied record catalogue boundary.
 *
 * Stored layouts and views refer to stable string keys. AppKit owns the
 * complete registry behavior, but not a consuming application's records,
 * labels, tables, routes, or lifecycle actions.
 */
import type { FieldMeta, FilterOperator, ListColumnMeta, ListFilterKind, ListFilterMeta, RecordTypeMeta } from './types.js';
/** Operators available for each filter kind. */
export declare const OPERATORS_BY_KIND: Record<ListFilterKind, readonly FilterOperator[]>;
export interface CustomFieldTarget {
    table: string | null;
    kind: string | undefined;
    lineTable: string | null;
    lineKind: string | undefined;
}
export interface CustomizationRegistry {
    readonly recordTypes: readonly RecordTypeMeta[];
    getRecordType(key: string): RecordTypeMeta | undefined;
    isBuiltInField(recordType: string, key: string): boolean;
    isBuiltInColumn(recordType: string, key: string): boolean;
    isBuiltInFilter(recordType: string, key: string): boolean;
    headerFieldMeta(recordType: string, key: string): FieldMeta | undefined;
    lineFieldMeta(recordType: string, key: string): FieldMeta | undefined;
    fieldMetaFor(recordType: string, key: string): FieldMeta | undefined;
    listColumnMeta(recordType: string, key: string): ListColumnMeta | undefined;
    listFilterMeta(recordType: string, key: string): ListFilterMeta | undefined;
    customFieldTargetFor(recordType: string): CustomFieldTarget;
}
/**
 * Bind the extracted customization engine to one application's catalogue.
 * Duplicate stable keys are rejected immediately instead of becoming
 * ambiguous persisted configuration later.
 */
export declare function createCustomizationRegistry(recordTypes: readonly RecordTypeMeta[]): CustomizationRegistry;
/** Is `key` a custom-field reference (`cf_<defKey>`)? */
export declare function isCustomFieldKey(key: string): boolean;
/** The custom field definition key portion of a `cf_<key>` reference. */
export declare function customFieldDefKey(key: string): string;
//# sourceMappingURL=registry.d.ts.map