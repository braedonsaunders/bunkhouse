/**
 * Zod validation for the customization config blobs, plus the system-default
 * builders and the cross-field linter. Server (API writes) parses + lints
 * authoritatively; the web designer uses the same schemas client-side so the
 * two can never disagree with the shared form contract.
 */
import { z } from "zod";
import { isCustomFieldKey, OPERATORS_BY_KIND } from "./registry.js";
import type { CustomizationRegistry } from './registry.js';
import type { FilterOperator, FormLayoutConfig, ListViewConfig, RecordTypeMeta } from "./types.js";
export declare const formLayoutConfigSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    defaultVisibilityVersion: z.ZodOptional<z.ZodLiteral<1>>;
    defaultLayoutVersion: z.ZodOptional<z.ZodLiteral<1>>;
    recordType: z.ZodString;
    header: z.ZodObject<{
        groups: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            fields: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                visible: z.ZodBoolean;
                labelOverride: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                required: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                colSpan: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    lines: z.ZodObject<{
        columns: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            visible: z.ZodBoolean;
            width: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            labelOverride: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    actions: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        visible: z.ZodBoolean;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const listViewConfigSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    recordType: z.ZodString;
    columns: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        visible: z.ZodBoolean;
        width: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        labelOverride: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>;
    filters: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        operator: z.ZodEnum<{
            eq: "eq";
            ne: "ne";
            in: "in";
            not_in: "not_in";
            gte: "gte";
            lte: "lte";
            between: "between";
            contains: "contains";
            is_set: "is_set";
            is_not_set: "is_not_set";
        }>;
        value: z.ZodOptional<z.ZodNullable<z.ZodUnion<readonly [z.ZodString, z.ZodArray<z.ZodString>]>>>;
        to: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>;
    sort: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        column: z.ZodString;
        dir: z.ZodEnum<{
            asc: "asc";
            desc: "desc";
        }>;
    }, z.core.$strip>>>;
    perPage: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>;
export interface LintIssue {
    path: string;
    message: string;
}
/**
 * Validate a parsed FormLayoutConfig against the registry: every referenced
 * field must be a known built-in for that record type or a `cf_<key>`; no
 * duplicate keys within a group; locked fields present and visible; required
 * flags only on overridable fields. Custom field existence is checked at the
 * API layer (the def set is per-org + dynamic).
 */
export declare function lintFormLayout(config: FormLayoutConfig, registry: CustomizationRegistry): LintIssue[];
/**
 * Validate a parsed ListViewConfig against the registry: columns and filters
 * reference known built-ins or `cf_<key>`; filter operators are allowed for the
 * field kind; sort column is a known sortable; required values present per
 * operator. Custom-field columns/filters existence is checked at the API layer.
 */
export declare function lintListView(config: ListViewConfig, registry: CustomizationRegistry): LintIssue[];
/**
 * The system-default form layout for a record type — the form as it renders
 * today (before customization). Used when neither the org nor the user has a
 * config: every built-in field present, visible, default labels, in registry
 * order. Custom fields are appended at render time by the web layer (they are
 * dynamic per org).
 */
export declare function defaultFormLayout(meta: RecordTypeMeta): FormLayoutConfig;
/**
 * Bring a persisted form layout forward when the registry gains built-in
 * fields or actions. Existing placements (including hidden fields, custom
 * order, labels, groups, and spans) remain untouched. New header fields are
 * inserted beside their nearest registered predecessor and inherit the
 * system-default placement, so adding a native field never strands saved
 * forms on an obsolete shape.
 */
export declare function mergeRegisteredFieldsIntoLayout(layout: FormLayoutConfig, meta: RecordTypeMeta): FormLayoutConfig;
/**
 * Apply the current system placement to a tenant's baseline form exactly once.
 * Built-in fields return to registry order and current spans, while visibility,
 * label, and required overrides survive. Custom fields remain in their chosen
 * groups. Named custom forms never pass through this baseline-only migration.
 */
export declare function refreshDefaultFormLayout(layout: FormLayoutConfig, meta: RecordTypeMeta): FormLayoutConfig;
/** The system-default list view: all columns (registry order), no filters. */
export declare function defaultListView(meta: RecordTypeMeta): ListViewConfig;
export interface ParseResult<T> {
    success: boolean;
    data?: T;
    issues: LintIssue[];
}
export declare function parseFormLayout(input: unknown, registry: CustomizationRegistry): ParseResult<FormLayoutConfig>;
export declare function parseListView(input: unknown, registry: CustomizationRegistry): ParseResult<ListViewConfig>;
export { isCustomFieldKey, OPERATORS_BY_KIND, type FilterOperator };
//# sourceMappingURL=schema.d.ts.map