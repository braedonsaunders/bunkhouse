import type { MutableListViewStore, SavedListView } from './list-runtime.js';
import type { CustomizationRegistry } from './registry.js';
export interface MemoryListViewStoreOptions {
    registry: CustomizationRegistry;
    views?: SavedListView[];
    preferences?: Iterable<readonly [string, string | null]>;
    createId?: () => string;
}
/**
 * Complete in-memory saved-view repository for database-free deployments,
 * tests, and local-first applications. Its authorization and default rules
 * match the Drizzle repository.
 */
export declare function createMemoryListViewStore(options: MemoryListViewStoreOptions): MutableListViewStore;
//# sourceMappingURL=memory.d.ts.map