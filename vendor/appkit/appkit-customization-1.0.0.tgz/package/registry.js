/**
 * Application-supplied record catalogue boundary.
 *
 * Stored layouts and views refer to stable string keys. AppKit owns the
 * complete registry behavior, but not a consuming application's records,
 * labels, tables, routes, or lifecycle actions.
 */
/** Operators available for each filter kind. */
export const OPERATORS_BY_KIND = {
    select: ['eq', 'ne', 'in', 'not_in'],
    multi_select: ['in', 'not_in', 'is_set', 'is_not_set'],
    entity_ref: ['eq', 'ne'],
    date: ['eq', 'gte', 'lte', 'between'],
    boolean: ['eq'],
    text: ['eq', 'contains', 'is_set', 'is_not_set'],
};
/**
 * Bind the extracted customization engine to one application's catalogue.
 * Duplicate stable keys are rejected immediately instead of becoming
 * ambiguous persisted configuration later.
 */
export function createCustomizationRegistry(recordTypes) {
    const records = recordTypes.map(cloneRecordType);
    const byKey = new Map();
    for (const record of records) {
        assertUniqueKey(byKey, record.key, 'record type');
        assertUniqueMembers(record.headerFields, `${record.key} header field`);
        assertUniqueMembers(record.lineFields, `${record.key} line field`);
        assertUniqueMembers(record.listColumns, `${record.key} list column`);
        assertUniqueMembers(record.listFilters, `${record.key} list filter`);
        assertUniqueMembers(record.formActions ?? [], `${record.key} form action`);
        byKey.set(record.key, record);
    }
    const getRecordType = (key) => byKey.get(key);
    const registry = {
        recordTypes: Object.freeze(records),
        getRecordType,
        isBuiltInField(recordType, key) {
            const meta = getRecordType(recordType);
            return Boolean(meta?.headerFields.some((field) => field.key === key)
                || meta?.lineFields.some((field) => field.key === key));
        },
        isBuiltInColumn(recordType, key) {
            return Boolean(getRecordType(recordType)?.listColumns.some((column) => column.key === key));
        },
        isBuiltInFilter(recordType, key) {
            return Boolean(getRecordType(recordType)?.listFilters.some((filter) => filter.key === key));
        },
        headerFieldMeta(recordType, key) {
            return getRecordType(recordType)?.headerFields.find((field) => field.key === key);
        },
        lineFieldMeta(recordType, key) {
            return getRecordType(recordType)?.lineFields.find((field) => field.key === key);
        },
        fieldMetaFor(recordType, key) {
            const meta = getRecordType(recordType);
            return meta?.headerFields.find((field) => field.key === key)
                ?? meta?.lineFields.find((field) => field.key === key);
        },
        listColumnMeta(recordType, key) {
            return getRecordType(recordType)?.listColumns.find((column) => column.key === key);
        },
        listFilterMeta(recordType, key) {
            return getRecordType(recordType)?.listFilters.find((filter) => filter.key === key);
        },
        customFieldTargetFor(recordType) {
            const meta = getRecordType(recordType);
            if (!meta)
                return { table: null, kind: undefined, lineTable: null, lineKind: undefined };
            return {
                table: meta.customFieldTable ?? null,
                kind: meta.customFieldKind ?? undefined,
                lineTable: meta.customFieldLineTable ?? null,
                lineKind: meta.customFieldLineKind ?? undefined,
            };
        },
    };
    return Object.freeze(registry);
}
/** Is `key` a custom-field reference (`cf_<defKey>`)? */
export function isCustomFieldKey(key) {
    return key.startsWith('cf_') && key.length > 3;
}
/** The custom field definition key portion of a `cf_<key>` reference. */
export function customFieldDefKey(key) {
    return isCustomFieldKey(key) ? key.slice(3) : key;
}
function assertUniqueKey(map, key, label) {
    if (!key.trim())
        throw new Error(`${label} key is required`);
    if (map.has(key))
        throw new Error(`duplicate ${label} key: ${key}`);
}
function assertUniqueMembers(items, label) {
    const seen = new Map();
    for (const item of items) {
        assertUniqueKey(seen, item.key, label);
        seen.set(item.key, true);
    }
}
function cloneRecordType(record) {
    return structuredClone(record);
}
//# sourceMappingURL=registry.js.map