'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useMemo, useState } from 'react';
import { ChevronDown, ChevronUp, Eye, EyeOff, GripVertical, Plus, Save, Trash2, X, } from 'lucide-react';
import { Badge, Button, Checkbox, Input, Label, Select, cn } from '@appkit/ui';
import { customFieldDefKey, isCustomFieldKey, } from './registry.js';
import { defaultFormLayout, mergeRegisteredFieldsIntoLayout } from './schema.js';
function nextId(prefix, used) {
    let index = 0;
    let id = `${prefix}${index}`;
    while (used.has(id)) {
        index += 1;
        id = `${prefix}${index}`;
    }
    return id;
}
function slugifyKey(label, used) {
    let base = label
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 48);
    if (!base)
        base = 'field';
    if (!/^[a-z]/.test(base))
        base = `f_${base}`;
    if (base.length < 2)
        base = `${base}_x`;
    let key = base;
    let index = 1;
    while (used.has(key)) {
        key = `${base}_${index}`;
        index += 1;
    }
    return key;
}
function humanize(value) {
    const leaf = value.split('.').at(-1) ?? value;
    return leaf
        .replace(/^_/, '')
        .replace(/_/g, ' ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/^./, (character) => character.toUpperCase());
}
function reorder(items, from, to) {
    if (to < 0 || to >= items.length)
        return items;
    const next = [...items];
    const [moved] = next.splice(from, 1);
    if (!moved)
        return items;
    next.splice(to, 0, moved);
    return next;
}
function ensureFieldsPlaced(layout, meta, headerFields, lineFields) {
    mergeRegisteredFieldsIntoLayout(layout, meta);
    const placedHeader = new Set(layout.header.groups.flatMap((group) => group.fields.map((field) => field.key)));
    const firstGroup = layout.header.groups[0];
    if (firstGroup) {
        for (const definition of headerFields) {
            const key = `cf_${definition.key}`;
            if (!placedHeader.has(key)) {
                firstGroup.fields.push({
                    key,
                    visible: true,
                    required: definition.isRequired ? true : null,
                    labelOverride: null,
                    colSpan: null,
                });
            }
        }
    }
    const placedLines = new Set(layout.lines.columns.map((column) => column.key));
    for (const definition of lineFields) {
        const key = `cf_${definition.key}`;
        if (!placedLines.has(key)) {
            layout.lines.columns.push({ key, visible: true, width: null, labelOverride: null });
        }
    }
    return layout;
}
const KIND_LABELS = {
    entity_ref: 'Lookup',
    reference: 'Lookup',
    dimension: 'Lookup',
    select: 'Dropdown',
    multi_select: 'Multi-select',
    date: 'Date',
    boolean: 'Checkbox',
    amount: 'Number',
    currency: 'Number',
    number: 'Number',
    tax: 'Tax',
    status: 'Status',
    long_text: 'Text area',
    text: 'Text',
};
export function FormDesigner({ recordType, meta, form, fields = [], adapter, resolveLabel = (_messageKey, fallback) => fallback, onChange, onSaved, onDeleted, className, }) {
    if (meta.key !== recordType)
        throw new Error('FormDesigner record type does not match metadata');
    const headerDefinitions = fields.filter((field) => field.level === 'header' && field.isActive);
    const lineDefinitions = fields.filter((field) => field.level === 'line' && field.isActive);
    const initial = useMemo(() => ensureFieldsPlaced(structuredClone(form?.layout ?? defaultFormLayout(meta)), meta, headerDefinitions, lineDefinitions), [form, headerDefinitions, lineDefinitions, meta]);
    const [name, setName] = useState(form?.name ?? `${humanize(recordType)} form`);
    const [isDefault, setIsDefault] = useState(form?.isDefault ?? true);
    const [isActive, setIsActive] = useState(form?.isActive ?? true);
    const [layout, setLayout] = useState(initial);
    const [customFields, setCustomFields] = useState(fields);
    const [busy, setBusy] = useState(false);
    const [feedback, setFeedback] = useState(null);
    useEffect(() => onChange?.(layout), [layout, onChange]);
    const customByKey = useMemo(() => new Map(customFields.map((definition) => [definition.key, definition])), [customFields]);
    const usedKeys = useMemo(() => new Set([
        ...layout.header.groups.flatMap((group) => group.fields.map((field) => field.key)),
        ...layout.lines.columns.map((column) => column.key),
    ]), [layout]);
    const fieldLabel = (key) => {
        if (isCustomFieldKey(key))
            return customByKey.get(customFieldDefKey(key))?.label ?? humanize(key);
        const field = meta.headerFields.find((candidate) => candidate.key === key)
            ?? meta.lineFields.find((candidate) => candidate.key === key);
        return field ? resolveLabel(field.labelKey, humanize(key)) : humanize(key);
    };
    const fieldKind = (key) => isCustomFieldKey(key)
        ? customByKey.get(customFieldDefKey(key))?.fieldType
        : (meta.headerFields.find((candidate) => candidate.key === key)
            ?? meta.lineFields.find((candidate) => candidate.key === key))?.kind;
    const updateField = (groupIndex, fieldIndex, patch) => setLayout((current) => {
        const next = structuredClone(current);
        next.header.groups[groupIndex].fields[fieldIndex] = {
            ...next.header.groups[groupIndex].fields[fieldIndex],
            ...patch,
        };
        return next;
    });
    const updateColumn = (columnIndex, patch) => setLayout((current) => {
        const next = structuredClone(current);
        next.lines.columns[columnIndex] = { ...next.lines.columns[columnIndex], ...patch };
        return next;
    });
    const updateAction = (actionIndex, patch) => setLayout((current) => {
        const next = structuredClone(current);
        next.actions[actionIndex] = { ...next.actions[actionIndex], ...patch };
        return next;
    });
    async function save() {
        setBusy(true);
        setFeedback(null);
        try {
            const saved = await adapter.saveForm({
                id: form?.id,
                recordType,
                name: name.trim(),
                isDefault,
                isActive,
                layout,
            });
            setFeedback('Saved');
            onSaved?.(saved);
        }
        catch (error) {
            setFeedback(error instanceof Error ? error.message : 'Could not save the form');
        }
        finally {
            setBusy(false);
        }
    }
    async function remove() {
        if (!form?.id || !adapter.deleteForm)
            return;
        setBusy(true);
        setFeedback(null);
        try {
            await adapter.deleteForm(form.id);
            onDeleted?.(form.id);
        }
        catch (error) {
            setFeedback(error instanceof Error ? error.message : 'Could not delete the form');
        }
        finally {
            setBusy(false);
        }
    }
    async function addCustomField(draft, level) {
        const definition = await adapter.saveField({
            ...draft,
            recordType,
            level,
            isActive: true,
            sortOrder: customFields.length,
        });
        setCustomFields((current) => [...current, definition]);
        setLayout((current) => {
            const next = structuredClone(current);
            if (level === 'header') {
                next.header.groups.at(-1)?.fields.push({
                    key: `cf_${definition.key}`,
                    visible: true,
                    required: definition.isRequired ? true : null,
                    labelOverride: null,
                    colSpan: null,
                });
            }
            else {
                next.lines.columns.push({
                    key: `cf_${definition.key}`,
                    visible: true,
                    width: null,
                    labelOverride: null,
                });
            }
            return next;
        });
    }
    return (_jsxs("section", { className: cn('flex h-full min-h-0 flex-col bg-bg', className), children: [_jsxs("header", { className: "flex flex-wrap items-center gap-3 border-b border-border bg-surface px-4 py-3", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("p", { className: "text-xs font-medium text-fg-muted", children: resolveLabel(meta.labelKey, humanize(recordType)) }), _jsx(Input, { value: name, onChange: (event) => setName(event.target.value), "aria-label": "Form name", className: "mt-1 h-8 max-w-md font-semibold" })] }), feedback ? _jsx("span", { className: "text-xs text-fg-muted", role: "status", children: feedback }) : null, form?.id && adapter.deleteForm ? (_jsxs(Button, { variant: "ghost", size: "sm", disabled: busy, onClick: remove, children: [_jsx(Trash2, { className: "size-4" }), "Delete"] })) : null, _jsxs(Button, { size: "sm", disabled: busy || !name.trim(), onClick: save, children: [_jsx(Save, { className: "size-4" }), busy ? 'Saving…' : 'Save form'] })] }), _jsx("div", { className: "min-h-0 flex-1 overflow-y-auto overscroll-contain p-4", children: _jsxs("div", { className: "mx-auto max-w-5xl space-y-7 pb-8", children: [_jsxs(EditorSection, { title: "Header fields", action: _jsxs(Button, { variant: "outline", size: "sm", onClick: () => setLayout((current) => {
                                    const next = structuredClone(current);
                                    next.header.groups.push({
                                        id: nextId('group', new Set(next.header.groups.map((group) => group.id))),
                                        label: '',
                                        fields: [],
                                    });
                                    return next;
                                }), children: [_jsx(Plus, { className: "size-4" }), "Add group"] }), children: [layout.header.groups.map((group, groupIndex) => (_jsxs("div", { className: "rounded-lg border border-border bg-surface p-3", children: [_jsxs("div", { className: "mb-3 flex items-center gap-2", children: [_jsx(Input, { value: group.label ?? '', onChange: (event) => setLayout((current) => {
                                                        const next = structuredClone(current);
                                                        next.header.groups[groupIndex].label = event.target.value;
                                                        return next;
                                                    }), placeholder: "Group label", "aria-label": `Group ${groupIndex + 1} label`, className: "h-8 flex-1" }), layout.header.groups.length > 1 ? (_jsx(Button, { variant: "ghost", size: "icon", "aria-label": "Remove group", onClick: () => setLayout((current) => {
                                                        const next = structuredClone(current);
                                                        const [removed] = next.header.groups.splice(groupIndex, 1);
                                                        if (removed)
                                                            next.header.groups[0].fields.push(...removed.fields);
                                                        return next;
                                                    }), children: _jsx(Trash2, { className: "size-4" }) })) : null] }), _jsxs("div", { className: "space-y-2", children: [group.fields.map((field, fieldIndex) => {
                                                    const metaField = meta.headerFields.find((candidate) => candidate.key === field.key);
                                                    return (_jsx(HeaderFieldRow, { field: field, label: fieldLabel(field.key), kindLabel: KIND_LABELS[fieldKind(field.key) ?? ''] ?? 'Text', locked: Boolean(metaField?.locked), requiredOverridable: Boolean(metaField?.requiredOverridable), groups: layout.header.groups, groupIndex: groupIndex, onChange: (patch) => updateField(groupIndex, fieldIndex, patch), onMove: (offset) => setLayout((current) => {
                                                            const next = structuredClone(current);
                                                            next.header.groups[groupIndex].fields = reorder(next.header.groups[groupIndex].fields, fieldIndex, fieldIndex + offset);
                                                            return next;
                                                        }), onMoveGroup: (targetIndex) => setLayout((current) => {
                                                            const next = structuredClone(current);
                                                            const [moved] = next.header.groups[groupIndex].fields.splice(fieldIndex, 1);
                                                            if (moved)
                                                                next.header.groups[targetIndex].fields.push(moved);
                                                            return next;
                                                        }) }, field.key));
                                                }), group.fields.length === 0 ? (_jsx("p", { className: "px-2 py-3 text-sm text-fg-subtle", children: "Move fields here or add a custom field." })) : null] })] }, group.id))), _jsx(InlineFieldCreator, { level: "header", usedKeys: usedKeys, onCreate: (draft) => addCustomField(draft, 'header') })] }), meta.lineFields.length > 0 || lineDefinitions.length > 0 ? (_jsxs(EditorSection, { title: "Line-item columns", description: "This is the editable line table used by the record form. Change order, visibility, labels, and grid widths.", children: [_jsxs("div", { className: "overflow-x-auto rounded-lg border border-border bg-surface", children: [_jsxs("div", { className: "grid min-w-[720px] grid-cols-[minmax(180px,1fr)_minmax(150px,0.8fr)_minmax(140px,0.6fr)_104px] gap-2 border-b border-border bg-bg-subtle px-3 py-2 text-xs font-semibold text-fg-muted", children: [_jsx("span", { children: "Column" }), _jsx("span", { children: "Label" }), _jsx("span", { children: "Grid width" }), _jsx("span", { className: "text-right", children: "Controls" })] }), _jsx("div", { className: "divide-y divide-border", children: layout.lines.columns.map((column, columnIndex) => (_jsx(LineColumnRow, { column: column, label: fieldLabel(column.key), kindLabel: KIND_LABELS[fieldKind(column.key) ?? ''] ?? 'Text', locked: Boolean(meta.lineFields.find((field) => field.key === column.key)?.locked), onChange: (patch) => updateColumn(columnIndex, patch), onMove: (offset) => setLayout((current) => {
                                                    const next = structuredClone(current);
                                                    next.lines.columns = reorder(next.lines.columns, columnIndex, columnIndex + offset);
                                                    return next;
                                                }) }, column.key))) })] }), _jsx(InlineFieldCreator, { level: "line", usedKeys: usedKeys, onCreate: (draft) => addCustomField(draft, 'line') })] })) : null, _jsx(EditorSection, { title: "Record actions", description: "Order and show the actions available on this record form.", children: _jsx("div", { className: "divide-y divide-border overflow-hidden rounded-lg border border-border bg-surface", children: layout.actions.map((action, actionIndex) => (_jsxs("div", { className: cn('flex items-center gap-2 px-3 py-2', !action.visible && 'opacity-60'), children: [_jsx(GripVertical, { className: "size-4 text-fg-subtle" }), _jsx("span", { className: "flex-1 text-sm font-medium text-fg", children: resolveLabel(meta.formActions?.find((candidate) => candidate.key === action.key)?.labelKey ?? action.key, humanize(action.key)) }), _jsx(IconControl, { label: "Move action up", onClick: () => setLayout((current) => ({ ...current, actions: reorder(current.actions, actionIndex, actionIndex - 1) })), children: _jsx(ChevronUp, {}) }), _jsx(IconControl, { label: "Move action down", onClick: () => setLayout((current) => ({ ...current, actions: reorder(current.actions, actionIndex, actionIndex + 1) })), children: _jsx(ChevronDown, {}) }), _jsx(IconControl, { label: action.visible ? 'Hide action' : 'Show action', onClick: () => updateAction(actionIndex, { visible: !action.visible }), children: action.visible ? _jsx(Eye, {}) : _jsx(EyeOff, {}) })] }, action.key))) }) }), _jsxs("div", { className: "flex flex-wrap items-center justify-between gap-4 rounded-lg border border-border bg-surface p-4", children: [_jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { checked: isActive, onChange: (event) => setIsActive(event.target.checked) }), "Active"] }), _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { checked: isDefault, onChange: (event) => setIsDefault(event.target.checked) }), "Default form"] })] })] }) })] }));
}
function EditorSection({ title, description, action, children, }) {
    return (_jsxs("section", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-end justify-between gap-3", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-xs font-semibold uppercase tracking-wide text-fg-muted", children: title }), description ? _jsx("p", { className: "mt-1 text-sm text-fg-subtle", children: description }) : null] }), action] }), children] }));
}
function KindChip({ children }) {
    return _jsx(Badge, { variant: "secondary", className: "text-[10px] uppercase tracking-wide", children: children });
}
function IconControl({ label, onClick, disabled, children, }) {
    return (_jsx("button", { type: "button", "aria-label": label, title: label, disabled: disabled, onClick: onClick, className: "rounded-sm p-1 text-fg-subtle transition-colors hover:bg-surface-hover hover:text-fg disabled:pointer-events-none disabled:opacity-30", children: _jsx("span", { className: "[&>svg]:size-4", children: children }) }));
}
function HeaderFieldRow({ field, label, kindLabel, locked, requiredOverridable, groups, groupIndex, onChange, onMove, onMoveGroup, }) {
    return (_jsxs("div", { className: cn('space-y-2 rounded-md border border-border-subtle bg-bg px-3 py-2', !field.visible && 'opacity-60'), children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(GripVertical, { className: "size-4 shrink-0 text-fg-subtle" }), _jsx("span", { className: "min-w-0 truncate text-sm font-medium text-fg", children: label }), _jsx(KindChip, { children: kindLabel }), locked ? _jsx(Badge, { variant: "outline", children: "Locked" }) : null, _jsxs("div", { className: "ml-auto flex items-center gap-0.5", children: [_jsx(IconControl, { label: "Move field up", onClick: () => onMove(-1), children: _jsx(ChevronUp, {}) }), _jsx(IconControl, { label: "Move field down", onClick: () => onMove(1), children: _jsx(ChevronDown, {}) }), _jsx(IconControl, { label: field.visible ? 'Hide field' : 'Show field', disabled: locked, onClick: () => onChange({ visible: !field.visible }), children: field.visible ? _jsx(Eye, {}) : _jsx(EyeOff, {}) })] })] }), _jsxs("div", { className: "grid gap-2 pl-6 sm:grid-cols-[minmax(160px,1fr)_96px_minmax(150px,0.7fr)_auto]", children: [_jsx(Input, { value: field.labelOverride ?? '', disabled: locked, onChange: (event) => onChange({ labelOverride: event.target.value || null }), placeholder: label, "aria-label": `Rename ${label}`, className: "h-8" }), _jsxs(Select, { value: String(field.colSpan ?? 1), onChange: (event) => onChange({ colSpan: Number(event.target.value) }), "aria-label": `${label} width`, className: "h-8", children: [_jsx("option", { value: "1", children: "1 col" }), _jsx("option", { value: "2", children: "2 cols" }), _jsx("option", { value: "3", children: "3 cols" }), _jsx("option", { value: "4", children: "4 cols" })] }), groups.length > 1 ? (_jsx(Select, { value: String(groupIndex), onChange: (event) => {
                            const target = Number(event.target.value);
                            if (target !== groupIndex)
                                onMoveGroup(target);
                        }, "aria-label": `Move ${label} to group`, className: "h-8", children: groups.map((group, index) => (_jsx("option", { value: index, children: group.label || `Group ${index + 1}` }, group.id))) })) : _jsx("span", {}), _jsxs("label", { className: "flex items-center gap-1.5 whitespace-nowrap text-xs text-fg-muted", children: [_jsx(Checkbox, { checked: Boolean(field.required), disabled: !requiredOverridable, onChange: () => onChange({ required: field.required ? null : true }) }), "Required"] })] })] }));
}
function LineColumnRow({ column, label, kindLabel, locked, onChange, onMove, }) {
    return (_jsxs("div", { className: cn('grid min-w-[720px] grid-cols-[minmax(180px,1fr)_minmax(150px,0.8fr)_minmax(140px,0.6fr)_104px] items-center gap-2 px-3 py-2', !column.visible && 'opacity-60'), children: [_jsxs("div", { className: "flex min-w-0 items-center gap-2", children: [_jsx(GripVertical, { className: "size-4 shrink-0 text-fg-subtle" }), _jsx("span", { className: "truncate text-sm font-medium text-fg", children: label }), _jsx(KindChip, { children: kindLabel }), locked ? _jsx(Badge, { variant: "outline", children: "Locked" }) : null] }), _jsx(Input, { value: column.labelOverride ?? '', disabled: locked, onChange: (event) => onChange({ labelOverride: event.target.value || null }), placeholder: label, "aria-label": `Rename ${label}`, className: "h-8" }), _jsx(Input, { value: column.width ?? '', onChange: (event) => onChange({ width: event.target.value || null }), placeholder: "minmax(120px, 1fr)", "aria-label": `${label} grid width`, className: "h-8 font-mono text-xs" }), _jsxs("div", { className: "flex justify-end", children: [_jsx(IconControl, { label: "Move column up", onClick: () => onMove(-1), children: _jsx(ChevronUp, {}) }), _jsx(IconControl, { label: "Move column down", onClick: () => onMove(1), children: _jsx(ChevronDown, {}) }), _jsx(IconControl, { label: column.visible ? 'Hide column' : 'Show column', disabled: locked, onClick: () => onChange({ visible: !column.visible }), children: column.visible ? _jsx(Eye, {}) : _jsx(EyeOff, {}) })] })] }));
}
const INLINE_FIELD_TYPES = [
    'text',
    'long_text',
    'number',
    'currency',
    'date',
    'boolean',
    'select',
    'multi_select',
];
function InlineFieldCreator({ level, usedKeys, onCreate, }) {
    const [open, setOpen] = useState(false);
    const [label, setLabel] = useState('');
    const [fieldType, setFieldType] = useState('text');
    const [options, setOptions] = useState('');
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState(null);
    const needsOptions = fieldType === 'select' || fieldType === 'multi_select';
    function reset() {
        setOpen(false);
        setLabel('');
        setFieldType('text');
        setOptions('');
        setError(null);
    }
    async function create() {
        const trimmed = label.trim();
        const parsedOptions = options.split(/[\n,]/).map((option) => option.trim()).filter(Boolean);
        if (!trimmed)
            return;
        if (needsOptions && parsedOptions.length === 0) {
            setError('Add at least one option.');
            return;
        }
        setBusy(true);
        setError(null);
        try {
            const usedDefinitions = new Set([...usedKeys].filter((key) => key.startsWith('cf_')).map((key) => key.slice(3)));
            await onCreate({
                key: slugifyKey(trimmed, usedDefinitions),
                label: trimmed,
                fieldType,
                config: needsOptions ? { options: parsedOptions } : {},
                isRequired: false,
            });
            reset();
        }
        catch (cause) {
            setError(cause instanceof Error ? cause.message : 'Could not create the field');
        }
        finally {
            setBusy(false);
        }
    }
    if (!open) {
        return (_jsxs(Button, { variant: "outline", size: "sm", onClick: () => setOpen(true), children: [_jsx(Plus, { className: "size-4" }), "Add ", level, " field"] }));
    }
    return (_jsxs("div", { className: "space-y-3 rounded-lg border border-dashed border-primary/40 bg-primary-subtle p-3", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("span", { className: "text-xs font-semibold uppercase tracking-wide text-fg", children: ["New ", level, " field"] }), _jsx(IconControl, { label: "Cancel field creation", onClick: reset, children: _jsx(X, {}) })] }), _jsxs("div", { className: "grid gap-3 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { children: "Label" }), _jsx(Input, { value: label, onChange: (event) => setLabel(event.target.value), autoFocus: true })] }), _jsxs("div", { className: "space-y-1", children: [_jsx(Label, { children: "Type" }), _jsx(Select, { value: fieldType, onChange: (event) => setFieldType(event.target.value), children: INLINE_FIELD_TYPES.map((type) => _jsx("option", { value: type, children: KIND_LABELS[type] }, type)) })] })] }), needsOptions ? (_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { children: "Options" }), _jsx(Input, { value: options, onChange: (event) => setOptions(event.target.value), placeholder: "Draft, Ready, Approved" })] })) : null, error ? _jsx("p", { className: "text-sm text-danger", children: error }) : null, _jsxs("div", { className: "flex justify-end gap-2", children: [_jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Cancel" }), _jsx(Button, { size: "sm", disabled: busy || !label.trim(), onClick: create, children: busy ? 'Adding…' : 'Add field' })] })] }));
}
//# sourceMappingURL=form-designer.js.map