'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { GripVertical, Plus, Save, Trash2, X } from 'lucide-react';
import { Badge, Button, Checkbox, Input, Label, Select, cn } from '@appkit/ui';
const FIELD_TYPES = [
    { value: 'text', label: 'Text', help: 'A single line of text.' },
    { value: 'long_text', label: 'Text area', help: 'Long-form notes or descriptions.' },
    { value: 'number', label: 'Number', help: 'A decimal number with optional bounds.' },
    { value: 'currency', label: 'Currency', help: 'A monetary value with optional bounds.' },
    { value: 'date', label: 'Date', help: 'A calendar date.' },
    { value: 'boolean', label: 'Checkbox', help: 'A yes or no value.' },
    { value: 'select', label: 'Dropdown', help: 'One value from an authored option set.' },
    { value: 'multi_select', label: 'Multi-select', help: 'Several values from an authored option set.' },
];
function slugify(value) {
    let key = value
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 60);
    if (!key)
        key = 'field';
    if (!/^[a-z]/.test(key))
        key = `f_${key}`;
    return key;
}
export function CustomFieldDesigner({ recordType, level, targets = [], field, adapter, roleOptions = [], onSaved, onDeleted, className, }) {
    const creating = !field;
    const [targetRecordType, setTargetRecordType] = useState(field?.recordType ?? recordType);
    const [targetLevel, setTargetLevel] = useState(field?.level ?? level);
    const [key, setKey] = useState(field?.key ?? '');
    const [label, setLabel] = useState(field?.label ?? '');
    const [fieldType, setFieldType] = useState(field?.fieldType ?? 'text');
    const [options, setOptions] = useState(field?.config.options ?? []);
    const [optionDraft, setOptionDraft] = useState('');
    const [helpText, setHelpText] = useState(field?.config.helpText ?? '');
    const [placeholder, setPlaceholder] = useState(field?.config.placeholder ?? '');
    const [defaultValue, setDefaultValue] = useState(field?.config.defaultValue ?? '');
    const [minValue, setMinValue] = useState(field?.config.min == null ? '' : String(field.config.min));
    const [maxValue, setMaxValue] = useState(field?.config.max == null ? '' : String(field.config.max));
    const [isRequired, setIsRequired] = useState(field?.isRequired ?? false);
    const [showInList, setShowInList] = useState(field?.config.showInList ?? false);
    const [displayMode, setDisplayMode] = useState(field?.config.displayMode ?? 'always');
    const [allowedRoles, setAllowedRoles] = useState(field?.config.allowedRoles ?? []);
    const [isActive, setIsActive] = useState(field?.isActive ?? true);
    const [busy, setBusy] = useState(false);
    const [feedback, setFeedback] = useState(null);
    const needsOptions = fieldType === 'select' || fieldType === 'multi_select';
    const numeric = fieldType === 'number' || fieldType === 'currency';
    function addOption() {
        const option = optionDraft.trim();
        if (option && !options.includes(option))
            setOptions((current) => [...current, option]);
        setOptionDraft('');
    }
    async function save() {
        if (!label.trim())
            return;
        if (needsOptions && options.length === 0) {
            setFeedback('Add at least one option.');
            return;
        }
        setBusy(true);
        setFeedback(null);
        try {
            const saved = await adapter.saveField({
                id: field?.id,
                recordType: targetRecordType,
                level: targetLevel,
                key: field?.key ?? (key || slugify(label)),
                label: label.trim(),
                fieldType,
                config: {
                    ...(needsOptions ? { options } : {}),
                    ...(helpText ? { helpText } : {}),
                    ...(placeholder && !needsOptions && fieldType !== 'boolean' ? { placeholder } : {}),
                    ...(defaultValue ? { defaultValue } : {}),
                    ...(numeric && minValue !== '' ? { min: Number(minValue) } : {}),
                    ...(numeric && maxValue !== '' ? { max: Number(maxValue) } : {}),
                    ...(showInList ? { showInList: true } : {}),
                    ...(displayMode !== 'always' ? { displayMode } : {}),
                    ...(allowedRoles.length > 0 ? { allowedRoles } : {}),
                },
                isRequired,
                isActive,
                sortOrder: field?.sortOrder ?? 0,
            });
            setFeedback('Saved');
            onSaved?.(saved);
        }
        catch (error) {
            setFeedback(error instanceof Error ? error.message : 'Could not save the field');
        }
        finally {
            setBusy(false);
        }
    }
    async function remove() {
        if (!field || !adapter.deleteField)
            return;
        setBusy(true);
        setFeedback(null);
        try {
            await adapter.deleteField(field.id);
            onDeleted?.(field.id);
        }
        catch (error) {
            setFeedback(error instanceof Error ? error.message : 'Could not delete the field');
        }
        finally {
            setBusy(false);
        }
    }
    return (_jsxs("section", { className: cn('flex h-full min-h-0 flex-col bg-bg', className), children: [_jsxs("header", { className: "flex flex-wrap items-center gap-3 border-b border-border bg-surface px-4 py-3", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("h2", { className: "font-semibold text-fg", children: creating ? 'New custom field' : `Edit ${field.label}` }), _jsxs("p", { className: "text-xs text-fg-muted", children: [targetRecordType.replace(/_/g, ' '), " \u00B7 ", targetLevel] })] }), feedback ? _jsx("span", { className: "text-xs text-fg-muted", role: "status", children: feedback }) : null, field && adapter.deleteField ? (_jsxs(Button, { variant: "ghost", size: "sm", disabled: busy, onClick: remove, children: [_jsx(Trash2, { className: "size-4" }), "Delete"] })) : null, _jsxs(Button, { size: "sm", disabled: busy || !label.trim() || (needsOptions && options.length === 0), onClick: save, children: [_jsx(Save, { className: "size-4" }), busy ? 'Saving…' : creating ? 'Create field' : 'Save field'] })] }), _jsx("div", { className: "min-h-0 flex-1 overflow-y-auto overscroll-contain p-4", children: _jsxs("div", { className: "mx-auto max-w-3xl space-y-6 pb-8", children: [_jsxs("div", { className: "rounded-lg border border-border bg-bg-subtle p-4", children: [_jsx("p", { className: "text-xs font-semibold uppercase tracking-wide text-fg-muted", children: "Applies to" }), creating && targets.length > 0 ? (_jsxs("div", { className: "mt-3 grid gap-3 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Record type" }), _jsx(Select, { value: targetRecordType, "aria-label": "Record type", onChange: (event) => {
                                                        const nextRecordType = event.target.value;
                                                        setTargetRecordType(nextRecordType);
                                                        if (!targets.find((target) => target.recordType === nextRecordType)?.supportsLines) {
                                                            setTargetLevel('header');
                                                        }
                                                    }, children: targets.map((target) => (_jsx("option", { value: target.recordType, children: target.label }, target.recordType))) })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Placement" }), _jsxs(Select, { value: targetLevel, "aria-label": "Placement", onChange: (event) => setTargetLevel(event.target.value), children: [_jsx("option", { value: "header", children: "Header field" }), targets.find((target) => target.recordType === targetRecordType)?.supportsLines ? (_jsx("option", { value: "line", children: "Line-item field" })) : null] })] })] })) : (_jsxs("div", { className: "mt-2 flex items-center gap-2", children: [_jsx(Badge, { variant: "secondary", children: targetRecordType.replace(/_/g, ' ') }), _jsx(Badge, { variant: "outline", children: targetLevel === 'header' ? 'Header field' : 'Line-item field' }), !creating ? _jsx("span", { className: "font-mono text-xs text-fg-subtle", children: field.key }) : null] }))] }), _jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Label" }), _jsx(Input, { value: label, onChange: (event) => setLabel(event.target.value), placeholder: "Field label" })] }), creating ? (_jsxs("div", { className: "space-y-1.5", children: [_jsxs(Label, { children: ["Field key ", _jsx("span", { className: "font-normal text-fg-subtle", children: "permanent" })] }), _jsx(Input, { value: key, onChange: (event) => setKey(slugify(event.target.value)), placeholder: label ? slugify(label) : 'field_key', className: "font-mono" })] })) : null] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Type" }), _jsx(Select, { "aria-label": "Field type", value: fieldType, onChange: (event) => setFieldType(event.target.value), children: FIELD_TYPES.map((type) => _jsx("option", { value: type.value, children: type.label }, type.value)) }), _jsx("p", { className: "text-xs text-fg-subtle", children: FIELD_TYPES.find((type) => type.value === fieldType)?.help })] }), needsOptions ? (_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: "Options" }), options.length > 0 ? (_jsx("ul", { className: "divide-y divide-border overflow-hidden rounded-md border border-border bg-surface", children: options.map((option, index) => (_jsxs("li", { className: "flex items-center gap-2 px-2.5 py-2 text-sm", children: [_jsx(GripVertical, { className: "size-4 text-fg-subtle" }), _jsx(Input, { value: option, onChange: (event) => setOptions((current) => current.map((item, itemIndex) => itemIndex === index ? event.target.value : item)), "aria-label": `Option ${index + 1}`, className: "h-8 flex-1" }), _jsx("button", { type: "button", "aria-label": `Remove ${option}`, onClick: () => setOptions((current) => current.filter((_, itemIndex) => itemIndex !== index)), className: "rounded-sm p-1 text-fg-subtle hover:bg-danger-subtle hover:text-danger", children: _jsx(X, { className: "size-4" }) })] }, `${option}-${index}`))) })) : _jsx("p", { className: "text-xs text-fg-subtle", children: "No options yet." }), _jsxs("div", { className: "flex gap-2", children: [_jsx(Input, { value: optionDraft, onChange: (event) => setOptionDraft(event.target.value), placeholder: "Add an option", onKeyDown: (event) => {
                                                if (event.key === 'Enter') {
                                                    event.preventDefault();
                                                    addOption();
                                                }
                                            } }), _jsxs(Button, { variant: "outline", onClick: addOption, children: [_jsx(Plus, { className: "size-4" }), "Add"] })] })] })) : null, _jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Help text" }), _jsx(Input, { value: helpText, onChange: (event) => setHelpText(event.target.value) })] }), !needsOptions && fieldType !== 'boolean' ? (_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Placeholder" }), _jsx(Input, { value: placeholder, onChange: (event) => setPlaceholder(event.target.value) })] })) : null, _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Default value" }), needsOptions ? (_jsxs(Select, { "aria-label": "Default value", value: defaultValue, onChange: (event) => setDefaultValue(event.target.value), children: [_jsx("option", { value: "", children: "None" }), options.map((option) => _jsx("option", { value: option, children: option }, option))] })) : (_jsx(Input, { type: fieldType === 'date' ? 'date' : 'text', inputMode: numeric ? 'decimal' : undefined, value: defaultValue, onChange: (event) => setDefaultValue(event.target.value) }))] }), numeric ? (_jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Minimum" }), _jsx(Input, { inputMode: "decimal", value: minValue, onChange: (event) => setMinValue(event.target.value) })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Maximum" }), _jsx(Input, { inputMode: "decimal", value: maxValue, onChange: (event) => setMaxValue(event.target.value) })] })] })) : null] }), _jsxs("div", { className: "flex flex-wrap gap-5 border-t border-border pt-4", children: [_jsx(Toggle, { checked: isRequired, onChange: setIsRequired, children: "Required" }), _jsx(Toggle, { checked: showInList, onChange: setShowInList, children: "Available in list views" }), _jsx(Toggle, { checked: isActive, onChange: setIsActive, children: "Active" })] }), _jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: "Display mode" }), _jsxs(Select, { "aria-label": "Display mode", value: displayMode, onChange: (event) => setDisplayMode(event.target.value), children: [_jsx("option", { value: "always", children: "Always" }), _jsx("option", { value: "create_only", children: "Create only" }), _jsx("option", { value: "edit_only", children: "Edit only" })] })] }), roleOptions.length > 0 ? (_jsxs("div", { className: "space-y-1.5", children: [_jsxs(Label, { children: ["Allowed roles ", _jsx("span", { className: "font-normal text-fg-subtle", children: "optional" })] }), _jsx("div", { className: "flex flex-wrap gap-2", children: roleOptions.map((role) => (_jsx(Toggle, { checked: allowedRoles.includes(role.value), onChange: (checked) => setAllowedRoles((current) => checked ? [...current, role.value] : current.filter((value) => value !== role.value)), compact: true, children: role.label }, role.value))) })] })) : null] })] }) })] }));
}
function Toggle({ checked, onChange, compact, children, }) {
    return (_jsxs("label", { className: cn('flex items-center gap-2 text-sm text-fg', compact && 'rounded-md border border-border px-2 py-1 text-xs'), children: [_jsx(Checkbox, { checked: checked, onChange: (event) => onChange(event.target.checked) }), children] }));
}
//# sourceMappingURL=custom-field-designer.js.map