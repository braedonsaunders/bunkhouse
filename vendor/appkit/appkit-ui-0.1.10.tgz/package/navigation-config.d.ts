/**
 * Framework-neutral tenant navigation configuration.
 *
 * Applications own their route registry and persistence. AppKit owns the
 * stable-key layout contract, reconciliation when new modules ship, and the
 * visibility/order projection consumed by shells and editors.
 */
export type NavigationRegistryItem = {
    /** Stable across releases and persisted by tenants. */
    key: string;
    label: string;
    description?: string;
    iconKey?: string;
    /**
     * Required destinations remain visible. Use this for the product home and
     * the screen that lets an administrator restore navigation.
     */
    required?: boolean;
};
export type NavigationItemConfig = {
    key: string;
    hidden?: boolean;
};
export type TenantNavigationConfig = {
    version: 1;
    items: NavigationItemConfig[];
    /**
     * Registry keys available when the config was saved. A key missing from this
     * stamp is newly shipped and is appended automatically. A known key omitted
     * from `items` remains omitted.
     */
    knownItemKeys?: string[];
};
export type ResolvedNavigationItem<T extends NavigationRegistryItem = NavigationRegistryItem> = T & {
    hidden: boolean;
};
export declare function buildDefaultNavigationConfig(registry: readonly NavigationRegistryItem[]): TenantNavigationConfig;
/**
 * Reconcile saved tenant state with the current application registry.
 *
 * This preserves tenant order, drops stale/duplicate entries, restores
 * required destinations, and appends modules shipped after the last save.
 */
export declare function reconcileNavigationConfig(config: TenantNavigationConfig | null | undefined, registry: readonly NavigationRegistryItem[]): TenantNavigationConfig;
export declare function stampKnownNavigationItems(config: TenantNavigationConfig, registry: readonly NavigationRegistryItem[]): TenantNavigationConfig;
export declare function resolveNavigationItems<T extends NavigationRegistryItem>(registry: readonly T[], config?: TenantNavigationConfig | null): ResolvedNavigationItem<T>[];
export declare function isTenantNavigationConfig(value: unknown): value is TenantNavigationConfig;
//# sourceMappingURL=navigation-config.d.ts.map