import * as React from 'react';
import { type SidebarNavGroup } from './sidebar-nav.js';
import { type LinkRender } from './link-context.js';
export declare function TopNav({ groups, pathname, linkRender, moreLabel, ariaLabel, className, itemClassName, activeItemClassName, inactiveItemClassName, }: {
    groups: SidebarNavGroup[];
    pathname: string;
    linkRender?: LinkRender;
    moreLabel?: string;
    ariaLabel?: string;
    className?: string;
    /** Shared typography/spacing overrides for every top-level navigation item. */
    itemClassName?: string;
    /** Overrides applied only to the active top-level item. */
    activeItemClassName?: string;
    /** Overrides applied only to inactive top-level items. */
    inactiveItemClassName?: string;
}): React.JSX.Element;
//# sourceMappingURL=top-nav.d.ts.map