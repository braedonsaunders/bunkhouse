import * as React from 'react';
/** Comparable value a column exposes for client-side ordering. */
export type PagedSortValue = string | number | Date | null | undefined;
export interface PagedColumn<T> {
    key: string;
    header: React.ReactNode;
    align?: 'left' | 'right';
    cell: (row: T) => React.ReactNode;
    /** Text used for client-side search matching. */
    search?: (row: T) => string;
    /**
     * Comparable value used for client-side ordering. Supplying it turns the
     * column header into a sort control; omit it for columns that can't be
     * ordered (actions, rendered composites without a natural key).
     */
    sortValue?: (row: T) => PagedSortValue;
}
export interface PagedTableSort {
    key: string;
    dir: 'asc' | 'desc';
}
export interface PagedTableLabels {
    searchPlaceholder: string;
    searchLabel: string;
    showing: (from: number, to: number, total: number) => React.ReactNode;
    prev: string;
    next: string;
    pageOf: (page: number, pages: number) => React.ReactNode;
    /** Shown in place of rows when a search matches nothing. */
    noResults: (query: string) => React.ReactNode;
    /** Accessible name for a column's sort control. */
    sortBy: (column: string) => string;
}
export interface PagedTableProps<T> {
    rows: T[];
    columns: PagedColumn<T>[];
    pageSize?: number;
    searchable?: boolean;
    empty: React.ReactNode;
    rowKey: (row: T, index: number) => string;
    rowClassName?: (row: T) => string | undefined;
    /** Initial ordering; the header controls take over from there. */
    defaultSort?: PagedTableSort;
    /** Row activation — makes rows clickable (open a drawer, navigate, select). */
    onRowClick?: (row: T) => void;
    labels?: Partial<PagedTableLabels>;
}
/**
 * Client-side searched, sorted, and paginated table for bounded data already
 * loaded into a page or drawer. The call surface matches the production
 * reference; only localized copy and semantic tokens are injected/generalized.
 */
export declare function PagedTable<T>({ rows, columns, pageSize, searchable, empty, rowKey, rowClassName, defaultSort, onRowClick, labels: labelOverrides, }: PagedTableProps<T>): React.JSX.Element;
//# sourceMappingURL=paged-table.d.ts.map