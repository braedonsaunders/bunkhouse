export type SignaturePadProps = {
    /** Current value as a PNG data-url, or `null` if empty. */
    value: string | null;
    /** Called with the new data-url after each completed stroke, or `null` on clear. */
    onChange: (value: string | null) => void;
    /** Disable drawing. Renders `value` (if any) as a static image. */
    disabled?: boolean;
    /** Canvas height in CSS pixels. Default 160. */
    height?: number;
    /** Extra classes on the outer wrapper. */
    className?: string;
    /** Accessibility label for the canvas. Default "Signature". */
    ariaLabel?: string;
};
export declare function SignaturePad({ value, onChange, disabled, height, className, ariaLabel, }: SignaturePadProps): import("react").JSX.Element;
//# sourceMappingURL=signature-pad.d.ts.map