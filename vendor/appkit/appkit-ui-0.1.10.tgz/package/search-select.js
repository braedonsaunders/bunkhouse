'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// SearchSelect — a slick, mobile-first searchable select / typeahead.
//   • Desktop: anchored dropdown (portaled to <body>) with a search box + kbd nav.
//   • Mobile (<lg): an iOS/Android-style bottom sheet with large tap targets.
// Animated, portal'd sheet, Esc + click-out + scroll-lock, disabled options,
// optgroup-style headers (via SelectOption.group), hints, clearable, remote mode.
// Fully tokenized; i18n strings are injectable props with English defaults.
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import { cn } from './utils.js';
export function SearchSelect({ value, onChange, options, placeholder = 'Select…', searchPlaceholder = 'Search…', disabled = false, clearable = false, emptyLabel, sheetTitle, ariaLabel, className, triggerClassName, searchable, remote = false, loading = false, statusMessage, statusTone = 'muted', onSearchChange, invalid = false, id, noneLabel = 'None', noMatchesLabel = 'No matches', searchingLabel = 'Searching…', selectLabel = 'Select', closeLabel = 'Close', }) {
    const [open, setOpen] = React.useState(false);
    const [query, setQuery] = React.useState('');
    const [highlight, setHighlight] = React.useState(0);
    const [isDesktop, setIsDesktop] = React.useState(true);
    const [mounted, setMounted] = React.useState(false);
    const wrapRef = React.useRef(null);
    const searchRef = React.useRef(null);
    const triggerRef = React.useRef(null);
    const dropRef = React.useRef(null);
    // The menu is anchored from the edge that touches the trigger: `top` when it
    // opens downward, `bottom` when it opens upward. Anchoring an upward menu by
    // its top would place it a full maxHeight above the trigger no matter how
    // short the list actually is — a three-option menu would float hundreds of
    // pixels clear of the field it belongs to.
    const [pos, setPos] = React.useState(null);
    function place() {
        const r = triggerRef.current?.getBoundingClientRect();
        if (r) {
            // Collision-aware: open upward when the space below is tight, and clamp
            // the list to the available viewport space either way.
            const margin = 8;
            const below = window.innerHeight - r.bottom - margin;
            const above = r.top - margin;
            const desired = 320;
            if (below >= Math.min(desired, 180) || below >= above) {
                setPos({ edge: 'top', offset: r.bottom + 6, left: r.left, width: r.width, maxHeight: Math.min(desired, below) });
            }
            else {
                setPos({
                    edge: 'bottom',
                    offset: Math.max(margin, window.innerHeight - r.top + 6),
                    left: r.left,
                    width: r.width,
                    maxHeight: Math.min(desired, above),
                });
            }
        }
    }
    React.useEffect(() => {
        setMounted(true);
        const mq = window.matchMedia('(min-width: 1024px)');
        const update = () => setIsDesktop(mq.matches);
        update();
        mq.addEventListener('change', update);
        return () => mq.removeEventListener('change', update);
    }, []);
    const allOptions = React.useMemo(() => (clearable ? [{ value: '', label: emptyLabel ?? noneLabel }, ...options] : options), [clearable, emptyLabel, noneLabel, options]);
    const selected = options.find((o) => o.value === value);
    const showEmpty = clearable && value === '' && !!emptyLabel;
    const display = selected?.label ?? (showEmpty ? emptyLabel : placeholder);
    const isPlaceholder = !selected && !showEmpty;
    const showSearch = searchable ?? (allOptions.length > 7 || allOptions.some((o) => o.group));
    const filtered = React.useMemo(() => {
        if (remote)
            return allOptions;
        const q = query.trim().toLowerCase();
        if (!q)
            return allOptions;
        return allOptions.filter((o) => o.label.toLowerCase().includes(q) || o.group?.toLowerCase().includes(q));
    }, [allOptions, query, remote]);
    function firstEnabled(items, start) {
        if (start >= 0 && start < items.length && !items[start]?.disabled)
            return start;
        const fwd = items.findIndex((o) => !o.disabled);
        return fwd === -1 ? 0 : fwd;
    }
    function openMenu() {
        if (disabled)
            return;
        setQuery('');
        onSearchChange?.('');
        setHighlight(firstEnabled(allOptions, allOptions.findIndex((o) => o.value === value)));
        place();
        setOpen(true);
        setTimeout(() => searchRef.current?.focus(), 60);
    }
    function choose(v) {
        onChange(v);
        setOpen(false);
    }
    React.useEffect(() => {
        if (!open || !isDesktop)
            return;
        function onDoc(e) {
            const target = e.target;
            if (wrapRef.current?.contains(target) || dropRef.current?.contains(target))
                return;
            setOpen(false);
        }
        document.addEventListener('mousedown', onDoc);
        return () => document.removeEventListener('mousedown', onDoc);
    }, [open, isDesktop]);
    React.useEffect(() => {
        if (!open || !isDesktop)
            return;
        place();
        const onMove = () => place();
        window.addEventListener('scroll', onMove, true);
        window.addEventListener('resize', onMove);
        return () => {
            window.removeEventListener('scroll', onMove, true);
            window.removeEventListener('resize', onMove);
        };
    }, [open, isDesktop]);
    React.useEffect(() => {
        if (!open)
            return;
        const nextEnabled = (from, dir) => {
            let index = from;
            while (true) {
                index += dir;
                if (index < 0 || index >= filtered.length)
                    return from;
                if (!filtered[index]?.disabled)
                    return index;
            }
        };
        function onKey(e) {
            if (e.key === 'Escape')
                setOpen(false);
            else if (e.key === 'ArrowDown') {
                e.preventDefault();
                setHighlight((h) => nextEnabled(h, 1));
            }
            else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setHighlight((h) => nextEnabled(h, -1));
            }
            else if (e.key === 'Enter') {
                e.preventDefault();
                const o = filtered[highlight];
                if (o && !o.disabled) {
                    onChange(o.value);
                    setOpen(false);
                }
            }
        }
        document.addEventListener('keydown', onKey);
        let restore;
        if (!isDesktop) {
            const prev = document.body.style.overflow;
            document.body.style.overflow = 'hidden';
            restore = () => {
                document.body.style.overflow = prev;
            };
        }
        return () => {
            document.removeEventListener('keydown', onKey);
            restore?.();
        };
    }, [filtered, highlight, isDesktop, onChange, open]);
    const optionList = (_jsxs(_Fragment, { children: [_jsxs("ul", { role: "listbox", className: "py-1", children: [filtered.length === 0 && !loading ? (_jsx("li", { role: "option", "aria-disabled": "true", className: "px-3 py-8 text-center text-sm text-fg-subtle", children: noMatchesLabel })) : null, filtered.map((o, i) => {
                        const active = o.value === value;
                        const prevGroup = i > 0 ? filtered[i - 1]?.group : undefined;
                        const header = o.group && o.group !== prevGroup ? o.group : null;
                        return (_jsxs("li", { role: "presentation", children: [header ? (_jsx("div", { className: "px-4 pb-1 pt-2.5 text-[11px] font-semibold tracking-wide text-fg-subtle uppercase lg:px-3", children: header })) : null, _jsxs("button", { type: "button", role: "option", "aria-selected": active, disabled: o.disabled, onMouseEnter: () => !o.disabled && setHighlight(i), onClick: () => !o.disabled && choose(o.value), className: cn('flex h-12 w-full items-center gap-2.5 px-4 text-left text-[15px] transition-colors lg:h-9 lg:px-3 lg:text-sm', o.disabled
                                        ? 'cursor-not-allowed text-fg-subtle'
                                        : i === highlight
                                            ? 'bg-primary-subtle'
                                            : 'active:bg-surface-hover', !o.disabled && (active ? 'font-medium text-primary' : 'text-fg')), children: [_jsxs("span", { className: "min-w-0 flex-1 truncate", children: [o.label, o.hint ? _jsx("span", { className: "ml-1.5 text-xs text-fg-subtle", children: o.hint }) : null] }), active ? _jsx(Check, { size: 17, className: "shrink-0 text-primary" }) : null] })] }, o.value || `__opt-${i}`));
                    })] }), loading || statusMessage ? (_jsx("div", { role: statusTone === 'error' ? 'alert' : 'status', className: cn('border-t border-border px-3 py-2 text-xs', statusTone === 'error' ? 'text-danger' : 'text-fg-muted'), children: loading ? searchingLabel : statusMessage })) : null] }));
    const searchBox = (largeText) => (_jsxs("div", { className: "relative px-3 pt-3", children: [_jsx(Search, { size: 16, className: "absolute left-6 top-1/2 -translate-y-1/2 text-fg-subtle" }), _jsx("input", { ref: searchRef, value: query, onChange: (e) => {
                    const next = e.target.value;
                    setQuery(next);
                    onSearchChange?.(next);
                    setHighlight(0);
                }, placeholder: searchPlaceholder, "aria-label": searchPlaceholder, "aria-busy": loading || undefined, className: cn('w-full rounded-lg border border-border bg-bg-subtle pl-9 pr-3 outline-none transition focus:border-primary focus:bg-surface focus:ring-2 focus:ring-ring/20', largeText ? 'h-11 text-base' : 'h-9 text-base sm:text-sm') })] }));
    return (_jsxs("div", { ref: wrapRef, className: cn('relative', className), children: [_jsxs("button", { ref: triggerRef, type: "button", id: id, onClick: () => (open ? setOpen(false) : openMenu()), disabled: disabled, "aria-label": ariaLabel, "aria-haspopup": "listbox", "aria-expanded": open, "aria-invalid": invalid || undefined, className: cn('flex h-10 w-full items-center gap-2 rounded-lg border border-border bg-surface px-3 text-left text-sm shadow-sm transition', 'focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/25', disabled && 'cursor-not-allowed bg-bg-subtle opacity-70', open && 'border-primary ring-2 ring-ring/25', invalid && 'border-danger focus:border-danger focus:ring-danger/30', triggerClassName), children: [_jsx("span", { className: cn('min-w-0 flex-1 truncate', isPlaceholder ? 'text-fg-subtle' : 'text-fg'), children: display }), _jsx(ChevronDown, { size: 16, className: cn('shrink-0 text-fg-subtle transition-transform', open && 'rotate-180') })] }), mounted && open && isDesktop && pos
                ? createPortal(_jsxs("div", { ref: dropRef, "data-ui-overlay": true, style: {
                        position: 'fixed',
                        [pos.edge]: pos.offset,
                        left: pos.left,
                        width: Math.max(pos.width, 208),
                        maxHeight: pos.maxHeight,
                    }, className: "z-[60] flex flex-col overflow-hidden rounded-xl border border-border bg-elevated shadow-lg", children: [showSearch ? searchBox(false) : null, _jsx("div", { className: cn('min-h-0 flex-1 overflow-y-auto', showSearch && 'mt-1'), children: optionList })] }), document.body)
                : null, mounted && !isDesktop
                ? createPortal(_jsx(AnimatePresence, { children: open ? (_jsxs("div", { "data-ui-overlay": true, className: "fixed inset-0 z-[60]", children: [_jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 0.15 }, className: "absolute inset-0 bg-overlay/40 backdrop-blur-[2px]", onClick: () => setOpen(false) }), _jsxs(motion.div, { initial: { y: '100%' }, animate: { y: 0 }, exit: { y: '100%' }, transition: { type: 'spring', damping: 34, stiffness: 340, mass: 0.8 }, className: "absolute inset-x-0 bottom-0 flex max-h-[82vh] flex-col rounded-t-2xl border-t border-border bg-surface shadow-lg", children: [_jsx("div", { className: "flex items-center justify-center pt-2.5", children: _jsx("span", { className: "h-1.5 w-10 rounded-full bg-border-strong" }) }), _jsxs("div", { className: "flex items-center justify-between px-4 pb-1 pt-2", children: [_jsx("span", { className: "text-base font-semibold text-fg", children: sheetTitle ?? selectLabel }), _jsx("button", { type: "button", onClick: () => setOpen(false), "aria-label": closeLabel, className: "rounded-md p-1.5 text-fg-muted hover:bg-surface-hover", children: _jsx(X, { size: 18 }) })] }), showSearch ? searchBox(true) : null, _jsx("div", { className: "mt-1 min-h-0 flex-1 overflow-y-auto pb-[max(0.75rem,env(safe-area-inset-bottom))]", children: optionList })] })] })) : null }), document.body)
                : null] }));
}
//# sourceMappingURL=search-select.js.map