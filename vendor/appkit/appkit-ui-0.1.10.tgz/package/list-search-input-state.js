export function createSearchInputEditState(urlValue) {
    return { value: urlValue, dirty: false };
}
export function applySearchInputEdit(value, urlValue, navigationPending) {
    return {
        value,
        // A pending navigation may still carry an older value even when the new
        // edit happens to equal the URL currently visible to this render.
        dirty: value !== urlValue || navigationPending,
    };
}
export function reconcileSearchInputUrl(state, urlValue, navigationPending) {
    if (state.dirty) {
        // While navigation is pending, URL values can arrive out of order. Keep
        // the user's latest edit authoritative. It becomes clean only after all
        // transitions settle with that exact value in the URL.
        if (!navigationPending && state.value === urlValue) {
            return { value: state.value, dirty: false };
        }
        return state;
    }
    // With no local edit, browser history and links remain authoritative.
    if (state.value === urlValue)
        return state;
    return { value: urlValue, dirty: false };
}
//# sourceMappingURL=list-search-input-state.js.map