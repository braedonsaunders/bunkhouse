import * as React from 'react';
export type GlobalSearchHit = {
    id: string;
    type: string;
    title: string;
    subtitle?: string;
    href: string;
    iconKey?: string;
    badge?: string;
    meta?: string;
};
export type GlobalSearchGroup = {
    id: string;
    label: string;
    hits: GlobalSearchHit[];
};
export type GlobalSearchResult = {
    groups: GlobalSearchGroup[];
    total: number;
};
export type GlobalSearchLabels = {
    placeholder: string;
    ariaLabel: string;
    clear: string;
    searching: string;
    noMatches: (query: string) => string;
    navigate: string;
    open: string;
    close: string;
    resultCount: (count: number) => string;
};
/** Production sibling search interaction with app-owned querying and navigation. */
export declare function GlobalSearch({ search, onNavigate, className, labels, minimumQueryLength, debounceMs, }: {
    search: (query: string, signal: AbortSignal) => Promise<GlobalSearchResult>;
    onNavigate: (hit: GlobalSearchHit) => void;
    className?: string;
    labels?: GlobalSearchLabels;
    minimumQueryLength?: number;
    debounceMs?: number;
}): React.JSX.Element;
//# sourceMappingURL=global-search.d.ts.map