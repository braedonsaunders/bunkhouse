'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import { Badge } from './badge.js';
import { Button } from './button.js';
import { Input } from './input.js';
import { Popover } from './popover.js';
import { cn } from './utils.js';
/**
 * Searchable multi-value picker for permissions, categories, tags, and other
 * bounded option sets. The selected value order follows the option registry so
 * apps get stable rendering even when values are supplied from persisted data.
 */
export function MultiSelect({ value, onChange, options, placeholder = 'Select…', searchPlaceholder = 'Search…', noMatchesLabel = 'No matches', clearLabel = 'Clear', selectAllLabel = 'Select all', disabled = false, clearable = true, maxVisibleValues = 3, id, ariaLabel, className, triggerClassName, }) {
    const [open, setOpen] = React.useState(false);
    const [search, setSearch] = React.useState('');
    const selected = React.useMemo(() => new Set(value), [value]);
    const selectedOptions = React.useMemo(() => options.filter((option) => selected.has(option.value)), [options, selected]);
    const enabledValues = React.useMemo(() => options.filter((option) => !option.disabled).map((option) => option.value), [options]);
    const filtered = React.useMemo(() => {
        const query = search.trim().toLowerCase();
        if (!query)
            return options;
        return options.filter((option) => [option.label, option.description, option.group]
            .filter(Boolean)
            .some((field) => field.toLowerCase().includes(query)));
    }, [options, search]);
    function toggle(option) {
        if (option.disabled)
            return;
        if (selected.has(option.value)) {
            onChange(value.filter((candidate) => candidate !== option.value));
            return;
        }
        onChange([...value, option.value]);
    }
    const visibleValues = selectedOptions.slice(0, Math.max(0, maxVisibleValues));
    const overflowCount = Math.max(0, selectedOptions.length - visibleValues.length);
    const allEnabledSelected = enabledValues.length > 0 && enabledValues.every((candidate) => selected.has(candidate));
    return (_jsx("div", { className: cn('w-full', className), children: _jsxs(Popover, { open: open, onOpenChange: (next) => {
                setOpen(next);
                if (!next)
                    setSearch('');
            }, align: "start", className: "w-[min(24rem,calc(100vw-2rem))] overflow-hidden p-0", trigger: _jsxs("button", { id: id, type: "button", "aria-label": ariaLabel, "aria-expanded": open, disabled: disabled, onClick: () => setOpen((current) => !current), className: cn('flex min-h-9 w-full items-center gap-1.5 rounded-md border border-border bg-surface px-3 py-1.5 text-left text-sm text-fg outline-none transition-colors', 'hover:border-border-strong focus-visible:ring-2 focus-visible:ring-ring/50', 'disabled:pointer-events-none disabled:opacity-50', triggerClassName), children: [_jsx("span", { className: "flex min-w-0 flex-1 flex-wrap gap-1", children: selectedOptions.length === 0 ? (_jsx("span", { className: "truncate text-fg-subtle", children: placeholder })) : (_jsxs(_Fragment, { children: [visibleValues.map((option) => (_jsx(Badge, { variant: "secondary", className: "max-w-full truncate", children: option.label }, option.value))), overflowCount > 0 ? _jsxs(Badge, { variant: "outline", children: ["+", overflowCount] }) : null] })) }), _jsx(ChevronDown, { className: "size-4 shrink-0 text-fg-subtle", "aria-hidden": true })] }), children: [_jsxs("div", { className: "border-b border-border p-2", children: [_jsxs("div", { className: "relative", children: [_jsx(Search, { className: "pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: search, onChange: (event) => setSearch(event.target.value), placeholder: searchPlaceholder, className: "h-8 pl-8 text-xs", autoFocus: true })] }), _jsxs("div", { className: "mt-2 flex items-center justify-between gap-2", children: [_jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => onChange(allEnabledSelected ? [] : enabledValues), disabled: enabledValues.length === 0, children: allEnabledSelected ? clearLabel : selectAllLabel }), clearable && value.length > 0 ? (_jsxs(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => onChange([]), children: [_jsx(X, { className: "size-3.5" }), clearLabel] })) : null] })] }), _jsx("div", { className: "max-h-72 overflow-y-auto p-1", children: filtered.length === 0 ? (_jsx("div", { className: "px-3 py-8 text-center text-sm text-fg-subtle", children: noMatchesLabel })) : (filtered.map((option) => {
                        const checked = selected.has(option.value);
                        return (_jsxs("button", { type: "button", role: "option", "aria-selected": checked, disabled: option.disabled, onClick: () => toggle(option), className: cn('flex w-full items-start gap-2.5 rounded-md px-2.5 py-2 text-left text-sm transition-colors', 'hover:bg-surface-hover disabled:pointer-events-none disabled:opacity-40', checked && 'bg-primary-subtle'), children: [_jsx("span", { className: cn('mt-0.5 grid size-4 shrink-0 place-items-center rounded border', checked
                                        ? 'border-primary bg-primary text-primary-fg'
                                        : 'border-border-strong bg-surface'), children: checked ? _jsx(Check, { className: "size-3", strokeWidth: 3, "aria-hidden": true }) : null }), _jsxs("span", { className: "min-w-0 flex-1", children: [_jsx("span", { className: "block truncate font-medium text-fg", children: option.label }), option.description ? (_jsx("span", { className: "mt-0.5 block truncate text-xs text-fg-muted", children: option.description })) : null] }), option.group ? (_jsx("span", { className: "shrink-0 text-[10px] font-medium tracking-wide text-fg-subtle uppercase", children: option.group })) : null] }, option.value));
                    })) })] }) }));
}
//# sourceMappingURL=multi-select.js.map