import * as React from 'react';
export type DialogSize = 'sm' | 'md' | 'lg' | 'xl';
export type DialogProps = {
    open: boolean;
    onClose: () => void;
    title?: React.ReactNode;
    description?: React.ReactNode;
    children?: React.ReactNode;
    footer?: React.ReactNode;
    size?: DialogSize;
    /** Hide the corner close button. */
    hideClose?: boolean;
    closeLabel?: string;
    /**
     * Give the panel a fixed working height and hand the body to the consumer as
     * a flex region with no padding. Use it when the content owns its own
     * toolbar/scroll/columns (an editor, a review pane) rather than being a short
     * block of prose — otherwise the dialog grows with its content and the page
     * behind it scrolls instead.
     */
    fullHeight?: boolean;
};
/** Centered modal dialog: backdrop, spring scale-in, focus trap, Esc/click-out. */
export declare function Dialog({ open, onClose, title, description, children, footer, size, hideClose, closeLabel, fullHeight, }: DialogProps): React.ReactPortal | null;
//# sourceMappingURL=dialog.d.ts.map