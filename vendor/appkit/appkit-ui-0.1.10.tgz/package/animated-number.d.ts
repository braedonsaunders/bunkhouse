import * as React from 'react';
export type AnimatedNumberProps = {
    value: number;
    from?: number;
    duration?: number;
    format?: (value: number) => string;
    className?: string;
    decimals?: number;
};
/** Byte-compatible sibling counter, with its default duration read from appkit's motion tokens. */
export declare function AnimatedNumber({ value, from, duration, format, className, decimals, }: AnimatedNumberProps): React.JSX.Element;
export declare function formatNumber(value: number, format?: (value: number) => string, decimals?: number): string;
//# sourceMappingURL=animated-number.d.ts.map