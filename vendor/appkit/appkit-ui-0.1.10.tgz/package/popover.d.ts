import * as React from 'react';
/**
 * Portal-based popover that escapes any overflow-hidden ancestor. The trigger
 * stays in place; the floating panel renders into <body> at a fixed position
 * computed from the trigger's rect and re-measured on scroll/resize.
 */
export declare function Popover({ trigger, open, onOpenChange, align, side, className, children, }: {
    trigger: React.ReactElement;
    open: boolean;
    onOpenChange: (open: boolean) => void;
    align?: 'start' | 'end';
    side?: 'top' | 'bottom' | 'left' | 'right';
    className?: string;
    children: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=popover.d.ts.map