import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from './utils.js';
export function Progress({ className, value, ...props }) {
    const clamped = value == null ? null : Math.max(0, Math.min(100, value));
    return (_jsx("div", { role: "progressbar", "aria-valuenow": clamped ?? undefined, "aria-valuemin": 0, "aria-valuemax": 100, className: cn('h-2 w-full overflow-hidden rounded-full bg-border-subtle', className), ...props, children: clamped == null ? (_jsx("div", { className: "h-full w-2/5 rounded-full bg-primary/80 [animation:appkit-indeterminate_1.2s_ease-in-out_infinite] motion-reduce:animate-none" })) : (_jsx("div", { className: "h-full rounded-full bg-primary transition-[width] duration-500 ease-out", style: { width: `${clamped}%` } })) }));
}
//# sourceMappingURL=progress.js.map