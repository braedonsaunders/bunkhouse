import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from './utils.js';
export const Checkbox = React.forwardRef(({ className, ...props }, ref) => (_jsx("input", { ref: ref, type: "checkbox", className: cn('size-4 shrink-0 rounded border-border accent-primary', 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 focus-visible:ring-offset-2 focus-visible:ring-offset-bg', 'disabled:cursor-not-allowed disabled:opacity-50', className), ...props })));
Checkbox.displayName = 'Checkbox';
//# sourceMappingURL=checkbox.js.map