import * as React from 'react';
export type SelectOption = {
    value: string;
    label: string;
    hint?: string;
    disabled?: boolean;
    /** Group header label; options sharing a group are batched under it. */
    group?: string;
};
export type SearchSelectProps = {
    value: string;
    onChange: (value: string) => void;
    options: SelectOption[];
    placeholder?: string;
    searchPlaceholder?: string;
    disabled?: boolean;
    /** Adds a leading empty option (e.g. "None"). */
    clearable?: boolean;
    emptyLabel?: string;
    /** Title at the top of the mobile bottom sheet. */
    sheetTitle?: string;
    ariaLabel?: string;
    className?: string;
    triggerClassName?: string;
    /** Force the search box on/off. Auto: shown when >7 options or any groups. */
    searchable?: boolean;
    /** Preserve server ordering + forward the query instead of local filtering. */
    remote?: boolean;
    loading?: boolean;
    statusMessage?: string;
    statusTone?: 'muted' | 'error';
    onSearchChange?: (query: string) => void;
    invalid?: boolean;
    id?: string;
    noneLabel?: string;
    noMatchesLabel?: string;
    searchingLabel?: string;
    selectLabel?: string;
    closeLabel?: string;
};
export declare function SearchSelect({ value, onChange, options, placeholder, searchPlaceholder, disabled, clearable, emptyLabel, sheetTitle, ariaLabel, className, triggerClassName, searchable, remote, loading, statusMessage, statusTone, onSearchChange, invalid, id, noneLabel, noMatchesLabel, searchingLabel, selectLabel, closeLabel, }: SearchSelectProps): React.JSX.Element;
//# sourceMappingURL=search-select.d.ts.map