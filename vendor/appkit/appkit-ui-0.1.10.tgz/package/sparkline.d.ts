export type SparklineTone = 'up' | 'down' | 'good' | 'bad' | 'neutral';
export type SparklineProps = {
    points: number[];
    tone?: SparklineTone;
    auto?: boolean;
    goodWhenRising?: boolean;
    dots?: boolean;
    stroke?: string;
    area?: boolean;
    strokeWidth?: number;
    className?: string;
    ariaLabel?: string;
    noTrendLabel?: string;
};
export declare function Sparkline({ points, tone, auto, goodWhenRising, dots, stroke, area, strokeWidth, className, ariaLabel, noTrendLabel, }: SparklineProps): import("react").JSX.Element;
//# sourceMappingURL=sparkline.d.ts.map