import * as React from 'react';
export type UiLinkComponent = React.ComponentType<React.AnchorHTMLAttributes<HTMLAnchorElement> & {
    href: string;
}>;
/** Inject an app router link once so appkit primitives never force full reloads. */
export declare function UiLinkProvider({ link, children, }: {
    link: UiLinkComponent;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function UiLink({ href, ...rest }: React.AnchorHTMLAttributes<HTMLAnchorElement> & {
    href: string;
}): React.JSX.Element;
/** How every navigation primitive renders one entry. */
export type LinkRender = (props: {
    href: string;
    children: React.ReactNode;
    className: string;
    title?: string;
    ariaCurrent?: 'page' | 'true';
    role?: string;
    dataWalkthrough?: string;
}) => React.ReactNode;
/**
 * The fallback every navigation primitive uses when the app passes no
 * `linkRender`. It resolves through `UiLink`, so a `UiLinkProvider` at the root
 * is enough to make the whole shell route client-side. A raw `<a>` here would
 * full-reload the document on every click, which tears down the router and
 * skips page transitions entirely.
 */
export declare const defaultLinkRender: LinkRender;
export type BackLinkProps = {
    href: string;
    label: string;
    className?: string;
};
export type BackLinkLike = React.ComponentType<BackLinkProps>;
export type BackLinkComponent = BackLinkLike;
/** Inject an app-aware history resolver for every PageHeader back link. */
export declare function UiBackLinkProvider({ backLink, children, }: {
    backLink: BackLinkLike;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function UiBackLink({ href, label, className }: BackLinkProps): React.JSX.Element;
//# sourceMappingURL=link-context.d.ts.map