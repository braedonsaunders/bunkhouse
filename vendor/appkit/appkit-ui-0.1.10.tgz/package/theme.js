'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { Monitor, Moon, Sun } from 'lucide-react';
import { cn } from './utils.js';
const ThemeContext = React.createContext(null);
const unavailableThemes = new Map();
function isTheme(value) {
    return value === 'light' || value === 'dark' || value === 'system';
}
export function ThemeProvider({ children, storageKey = 'theme', }) {
    const eventName = `appkit-theme-change:${storageKey}`;
    const readTheme = React.useCallback(() => {
        try {
            const stored = localStorage.getItem(storageKey);
            return isTheme(stored) ? stored : 'system';
        }
        catch {
            return unavailableThemes.get(storageKey) ?? 'system';
        }
    }, [storageKey]);
    const subscribeTheme = React.useCallback((onChange) => {
        window.addEventListener('storage', onChange);
        window.addEventListener(eventName, onChange);
        return () => {
            window.removeEventListener('storage', onChange);
            window.removeEventListener(eventName, onChange);
        };
    }, [eventName]);
    const subscribeSystem = React.useCallback((onChange) => {
        const media = matchMedia('(prefers-color-scheme: dark)');
        media.addEventListener('change', onChange);
        return () => media.removeEventListener('change', onChange);
    }, []);
    const theme = React.useSyncExternalStore(subscribeTheme, readTheme, () => 'system');
    const prefersDark = React.useSyncExternalStore(subscribeSystem, () => matchMedia('(prefers-color-scheme: dark)').matches, () => false);
    const [mounted, setMounted] = React.useState(false);
    const resolvedTheme = theme === 'system' ? (prefersDark ? 'dark' : 'light') : theme;
    React.useEffect(() => setMounted(true), []);
    React.useEffect(() => {
        document.documentElement.classList.toggle('dark', resolvedTheme === 'dark');
        document.documentElement.classList.toggle('light', resolvedTheme === 'light');
    }, [resolvedTheme]);
    const setTheme = React.useCallback((next) => {
        try {
            if (next === 'system')
                localStorage.removeItem(storageKey);
            else
                localStorage.setItem(storageKey, next);
            unavailableThemes.delete(storageKey);
        }
        catch {
            unavailableThemes.set(storageKey, next);
        }
        window.dispatchEvent(new Event(eventName));
    }, [eventName, storageKey]);
    return (_jsx(ThemeContext.Provider, { value: { theme, resolvedTheme, setTheme, mounted }, children: children }));
}
export function useTheme() {
    const context = React.useContext(ThemeContext);
    if (!context)
        throw new Error('useTheme must be used within ThemeProvider');
    return context;
}
const THEME_OPTIONS = [
    { value: 'light', icon: Sun },
    { value: 'system', icon: Monitor },
    { value: 'dark', icon: Moon },
];
const DEFAULT_LABELS = {
    label: 'Theme',
    light: 'Light',
    system: 'System',
    dark: 'Dark',
    current: (theme) => `Theme: ${theme}`,
};
export function ThemeToggle({ collapsed = false, labels = DEFAULT_LABELS, className, }) {
    const { theme, setTheme, mounted } = useTheme();
    if (collapsed) {
        const active = THEME_OPTIONS.find((option) => option.value === theme) ?? THEME_OPTIONS[1];
        const Icon = active.icon;
        const activeLabel = labels[active.value];
        const next = theme === 'light' ? 'dark' : theme === 'dark' ? 'system' : 'light';
        return (_jsx("button", { type: "button", onClick: () => setTheme(next), title: labels.current(activeLabel), "aria-label": labels.current(activeLabel), className: cn('grid size-9 place-items-center rounded-md text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg', className), children: mounted ? _jsx(Icon, { size: 16 }) : _jsx(Monitor, { size: 16, className: "opacity-0" }) }));
    }
    return (_jsx("div", { role: "radiogroup", "aria-label": labels.label, className: cn('flex items-center gap-0.5 rounded-lg border border-border bg-bg-subtle p-0.5', className), children: THEME_OPTIONS.map((option) => {
            const Icon = option.icon;
            const selected = mounted && theme === option.value;
            return (_jsx("button", { type: "button", role: "radio", "aria-checked": selected, onClick: () => setTheme(option.value), title: labels[option.value], className: cn('inline-flex h-7 flex-1 items-center justify-center rounded-md transition-colors', selected ? 'bg-surface text-primary shadow-sm' : 'text-fg-muted hover:text-fg'), children: _jsx(Icon, { size: 15 }) }, option.value));
        }) }));
}
//# sourceMappingURL=theme.js.map