import * as React from 'react';
import type { AppShellNavigationMode } from './app-shell.js';
type NavigationModeContextValue = {
    mode: AppShellNavigationMode;
    setMode: (mode: AppShellNavigationMode) => void;
    mounted: boolean;
};
export declare function NavigationModeProvider({ children, defaultMode, cookieName, onChange, }: {
    children: React.ReactNode;
    defaultMode?: AppShellNavigationMode;
    cookieName?: string;
    onChange?: (mode: AppShellNavigationMode) => void | Promise<void>;
}): React.JSX.Element;
export declare function useNavigationMode(): NavigationModeContextValue;
export {};
//# sourceMappingURL=navigation-mode.d.ts.map