import * as React from 'react';
export type SpinnerProps = React.SVGAttributes<SVGSVGElement> & {
    size?: number;
    label?: string;
};
/**
 * Spinner — a token-colored, reduced-motion-aware loading indicator. Uses
 * currentColor so it inherits the surrounding text color by default.
 */
export declare function Spinner({ size, label, className, ...props }: SpinnerProps): React.JSX.Element;
//# sourceMappingURL=spinner.d.ts.map