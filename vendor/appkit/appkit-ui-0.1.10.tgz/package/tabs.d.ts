import * as React from 'react';
export type TabItem = {
    value: string;
    label: React.ReactNode;
};
export type TabsProps = {
    tabs: TabItem[];
    value: string;
    onValueChange: (value: string) => void;
    className?: string;
};
/**
 * Tabs — a segmented control with a spring-animated active indicator that
 * slides between options (framer `layoutId`). Reduced-motion falls back to an
 * instant swap.
 */
export declare function Tabs({ tabs, value, onValueChange, className }: TabsProps): React.JSX.Element;
//# sourceMappingURL=tabs.d.ts.map