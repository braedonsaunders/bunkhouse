import * as React from 'react';
export type ProgressProps = React.HTMLAttributes<HTMLDivElement> & {
    /** 0–100. Omit for an indeterminate bar. */
    value?: number;
};
export declare function Progress({ className, value, ...props }: ProgressProps): React.JSX.Element;
//# sourceMappingURL=progress.d.ts.map