import * as React from 'react';
export type ToastType = 'default' | 'success' | 'error' | 'warning' | 'info' | 'loading';
export type ToastAction = {
    label: React.ReactNode;
    onClick: (e: React.MouseEvent) => void;
};
export type Message = React.ReactNode;
export type ExternalToast = {
    id?: string | number;
    description?: React.ReactNode;
    duration?: number;
    icon?: React.ReactNode;
    action?: ToastAction;
    cancel?: ToastAction;
    onDismiss?: (id: string | number) => void;
    onAutoClose?: (id: string | number) => void;
    className?: string;
};
export type ToastT = ExternalToast & {
    id: string | number;
    title?: React.ReactNode;
    type: ToastType;
    jsx?: React.ReactNode;
};
declare function toastFunction(message: Message, data?: ExternalToast): string | number;
/** sonner-compatible global toast API. */
export declare const toast: typeof toastFunction & {
    success: (message: Message, data?: ExternalToast) => string | number;
    error: (message: Message, data?: ExternalToast) => string | number;
    warning: (message: Message, data?: ExternalToast) => string | number;
    info: (message: Message, data?: ExternalToast) => string | number;
    message: (message: Message, data?: ExternalToast) => string | number;
    loading: (message: Message, data?: ExternalToast) => string | number;
    custom: (jsx: (id: string | number) => React.ReactNode, data?: ExternalToast) => string | number;
    promise: <T>(promise: Promise<T>, opts: {
        loading: Message;
        success: React.ReactNode | ((data: T) => Message);
        error: Message | ((err: unknown) => Message);
    }) => string | number;
    dismiss: (id?: string | number) => string | number | undefined;
};
export type ToasterPosition = 'top-left' | 'top-center' | 'top-right' | 'bottom-left' | 'bottom-center' | 'bottom-right';
export declare function Toaster({ position, richColors, duration, closeButton, visibleToasts, className, }: {
    position?: ToasterPosition;
    richColors?: boolean;
    duration?: number;
    closeButton?: boolean;
    visibleToasts?: number;
    className?: string;
}): React.ReactPortal | null;
export {};
//# sourceMappingURL=toast.d.ts.map