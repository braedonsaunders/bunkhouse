'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronDown, ChevronRight, Minus, Plus, RotateCcw } from 'lucide-react';
import { Avatar } from './avatar.js';
import { Badge } from './badge.js';
import { Button } from './button.js';
import { EmptyState } from './empty-state.js';
import { cn } from './utils.js';
/**
 * Resolve a flat parent-pointer list into a forest.
 *
 * Real hierarchies arrive dirty: dangling parents, self-references, and — when
 * two records are edited concurrently — cycles. None of those may lose a
 * record or hang the renderer, so anything that cannot be reached from a
 * genuine root is promoted to a root itself, in input order. Every input node
 * appears exactly once in the output.
 */
export function buildOrgTree(nodes) {
    const byId = new Map();
    for (const node of nodes)
        byId.set(node.id, node);
    const childrenOf = new Map();
    const roots = [];
    for (const node of nodes) {
        const parentId = node.parentId;
        const hasParent = typeof parentId === 'string' && parentId !== node.id && byId.has(parentId);
        if (!hasParent) {
            roots.push(node);
            continue;
        }
        const siblings = childrenOf.get(parentId);
        if (siblings)
            siblings.push(node);
        else
            childrenOf.set(parentId, [node]);
    }
    const placed = new Set();
    const expand = (node, depth) => {
        placed.add(node.id);
        const children = (childrenOf.get(node.id) ?? [])
            .filter((child) => !placed.has(child.id))
            .map((child) => expand(child, depth + 1));
        return { ...node, depth, children };
    };
    const forest = roots.map((root) => expand(root, 0));
    // Whatever is left is inside a cycle: promote in input order until drained.
    for (const node of nodes) {
        if (!placed.has(node.id))
            forest.push(expand(node, 0));
    }
    return forest;
}
/** Every record beneath `id`, exclusive of `id` itself. */
export function orgChartDescendantIds(nodes, id) {
    const childrenOf = new Map();
    for (const node of nodes) {
        if (typeof node.parentId !== 'string' || node.parentId === node.id)
            continue;
        const siblings = childrenOf.get(node.parentId);
        if (siblings)
            siblings.push(node.id);
        else
            childrenOf.set(node.parentId, [node.id]);
    }
    const found = new Set();
    const queue = [...(childrenOf.get(id) ?? [])];
    while (queue.length > 0) {
        const next = queue.pop();
        if (found.has(next) || next === id)
            continue;
        found.add(next);
        queue.push(...(childrenOf.get(next) ?? []));
    }
    return found;
}
/**
 * May `childId` be moved under `parentId` without breaking the tree? Guards
 * self-reference, no-op moves, and the cycle a manager-under-own-report makes.
 * Callers must re-check server-side — this is the UI's fast path, not the rule.
 */
export function canReparent(nodes, childId, parentId) {
    const child = nodes.find((node) => node.id === childId);
    if (!child)
        return false;
    const currentParent = typeof child.parentId === 'string' ? child.parentId : null;
    if (currentParent === parentId)
        return false;
    if (parentId === null)
        return true;
    if (parentId === childId)
        return false;
    if (!nodes.some((node) => node.id === parentId))
        return false;
    return !orgChartDescendantIds(nodes, childId).has(parentId);
}
const DEFAULT_LABELS = {
    collapse: 'Collapse branch',
    expand: 'Expand branch',
    zoomIn: 'Zoom in',
    zoomOut: 'Zoom out',
    resetZoom: 'Reset zoom',
    topLevel: 'Top level',
    topLevelHint: 'Drop here to remove the reporting line',
    reports: 'reports',
};
const ZOOM_STEPS = [0.5, 0.65, 0.8, 1, 1.15];
const DEFAULT_ZOOM_INDEX = 3;
/**
 * A formal reporting hierarchy: cards connected top-down, pan by scrolling,
 * branches collapsible, and — when `onReparent` is supplied — records dragged
 * onto a new manager. Connectors are drawn with borders rather than measured
 * geometry, so the chart renders identically on the server and never needs a
 * layout pass.
 */
export function OrgChart({ nodes, selectedId, onSelect, onReparent, toolbar, empty, labels, className, }) {
    const text = { ...DEFAULT_LABELS, ...labels };
    const forest = React.useMemo(() => buildOrgTree(nodes), [nodes]);
    const [collapsed, setCollapsed] = React.useState(() => new Set());
    const [zoomIndex, setZoomIndex] = React.useState(DEFAULT_ZOOM_INDEX);
    const [dragging, setDragging] = React.useState(null);
    const [dropTarget, setDropTarget] = React.useState(null);
    const [topDrop, setTopDrop] = React.useState(false);
    // A record removed from the data must not keep a stale branch folded shut.
    React.useEffect(() => {
        setCollapsed((current) => {
            const live = new Set(nodes.map((node) => node.id));
            const next = new Set([...current].filter((id) => live.has(id)));
            return next.size === current.size ? current : next;
        });
    }, [nodes]);
    const toggle = (id) => setCollapsed((current) => {
        const next = new Set(current);
        if (next.has(id))
            next.delete(id);
        else
            next.add(id);
        return next;
    });
    const draggable = typeof onReparent === 'function';
    const endDrag = () => {
        setDragging(null);
        setDropTarget(null);
        setTopDrop(false);
    };
    const drop = (parentId) => {
        if (dragging && canReparent(nodes, dragging, parentId))
            onReparent?.(dragging, parentId);
        endDrag();
    };
    if (nodes.length === 0) {
        return (_jsx(_Fragment, { children: empty ?? _jsx(EmptyState, { title: "Nothing to chart yet", description: "Records appear here once they exist." }) }));
    }
    const zoom = ZOOM_STEPS[zoomIndex] ?? 1;
    const renderNode = (node, isRoot) => {
        const isCollapsed = collapsed.has(node.id);
        const hasChildren = node.children.length > 0;
        const isDragging = dragging === node.id;
        const isDropTarget = dropTarget === node.id;
        const invalidTarget = dragging !== null && !isDragging && !canReparent(nodes, dragging, node.id);
        return (_jsxs("li", { className: cn('appkit-org-item', isRoot && 'appkit-org-item--root'), children: [isRoot ? null : _jsx("span", { "aria-hidden": true, className: "appkit-org-stem" }), _jsxs("div", { className: cn('appkit-org-card reveal group relative flex w-56 flex-col items-center gap-2 rounded-xl border bg-surface px-4 py-3 text-center shadow-sm transition-colors', selectedId === node.id ? 'border-primary ring-1 ring-primary' : 'border-border', isDropTarget && 'border-primary bg-primary-subtle', isDragging && 'opacity-50', node.muted && 'opacity-60'), draggable: draggable, onDragStart: draggable
                        ? (event) => {
                            event.dataTransfer.effectAllowed = 'move';
                            event.dataTransfer.setData('text/plain', node.id);
                            setDragging(node.id);
                        }
                        : undefined, onDragEnd: draggable ? endDrag : undefined, onDragOver: draggable
                        ? (event) => {
                            if (!dragging || invalidTarget || isDragging)
                                return;
                            event.preventDefault();
                            event.dataTransfer.dropEffect = 'move';
                            setDropTarget(node.id);
                        }
                        : undefined, onDragLeave: draggable ? () => setDropTarget((current) => (current === node.id ? null : current)) : undefined, onDrop: draggable
                        ? (event) => {
                            event.preventDefault();
                            drop(node.id);
                        }
                        : undefined, children: [_jsxs("button", { type: "button", onClick: () => onSelect?.(node.id), className: "flex flex-col items-center gap-2 focus-visible:outline-none", "aria-current": selectedId === node.id ? 'true' : undefined, children: [node.avatar ?? (_jsx(Avatar, { name: node.name, size: 44, ...(node.avatarSrc ? { src: node.avatarSrc } : {}) })), _jsxs("span", { className: "flex flex-col items-center gap-1", children: [_jsx("span", { className: "text-sm font-semibold text-fg group-hover:text-primary", children: node.name }), node.subtitle ? _jsx("span", { className: "text-xs text-fg-muted", children: node.subtitle }) : null, node.badge ? (_jsx(Badge, { variant: node.badge.variant ?? 'secondary', children: node.badge.label })) : null, node.meta ? _jsx("span", { className: "max-w-full truncate text-[11px] text-fg-subtle", children: node.meta }) : null] })] }), hasChildren ? (_jsxs("button", { type: "button", onClick: () => toggle(node.id), "aria-expanded": !isCollapsed, "aria-label": isCollapsed ? text.expand : text.collapse, title: `${node.children.length} ${text.reports}`, className: "absolute -bottom-3 left-1/2 z-1 flex -translate-x-1/2 items-center gap-1 rounded-full border border-border bg-surface px-2 py-0.5 text-[11px] text-fg-muted shadow-sm transition-colors hover:border-primary hover:text-primary", children: [isCollapsed ? _jsx(ChevronRight, { className: "size-3" }) : _jsx(ChevronDown, { className: "size-3" }), node.children.length] })) : null] }), hasChildren && !isCollapsed ? (_jsx("ul", { className: "appkit-org-children", children: node.children.map((child) => renderNode(child, false)) })) : null] }, node.id));
    };
    return (_jsxs("div", { className: cn('space-y-3', className), children: [_jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [_jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Button, { type: "button", variant: "outline", size: "sm", className: "w-8 px-0", "aria-label": text.zoomOut, disabled: zoomIndex === 0, onClick: () => setZoomIndex((index) => Math.max(0, index - 1)), children: _jsx(Minus, { className: "size-4" }) }), _jsx(Button, { type: "button", variant: "outline", size: "sm", className: "w-8 px-0", "aria-label": text.zoomIn, disabled: zoomIndex === ZOOM_STEPS.length - 1, onClick: () => setZoomIndex((index) => Math.min(ZOOM_STEPS.length - 1, index + 1)), children: _jsx(Plus, { className: "size-4" }) }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", className: "w-8 px-0", "aria-label": text.resetZoom, onClick: () => setZoomIndex(DEFAULT_ZOOM_INDEX), children: _jsx(RotateCcw, { className: "size-4" }) }), _jsxs("span", { className: "ml-1 text-xs tabular-nums text-fg-subtle", children: [Math.round(zoom * 100), "%"] })] }), toolbar] }), _jsx("div", { className: "overflow-x-auto rounded-xl border border-border bg-bg-subtle p-6", children: _jsxs("div", { className: "appkit-org-canvas", style: { zoom }, children: [draggable ? (_jsx("div", { onDragOver: (event) => {
                                if (!dragging || !canReparent(nodes, dragging, null))
                                    return;
                                event.preventDefault();
                                event.dataTransfer.dropEffect = 'move';
                                setTopDrop(true);
                            }, onDragLeave: () => setTopDrop(false), onDrop: (event) => {
                                event.preventDefault();
                                drop(null);
                            }, className: cn('mx-auto mb-4 w-fit rounded-full border border-dashed px-4 py-1.5 text-xs transition-colors', topDrop ? 'border-primary bg-primary-subtle text-primary' : 'border-border text-fg-subtle'), children: dragging ? text.topLevelHint : text.topLevel })) : null, _jsx("ul", { className: "appkit-org-children appkit-org-roots", children: forest.map((root) => renderNode(root, true)) })] }) })] }));
}
//# sourceMappingURL=org-chart.js.map