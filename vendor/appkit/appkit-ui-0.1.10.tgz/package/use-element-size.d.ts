import * as React from 'react';
/** Measured size of an element, kept current across resizes. */
export declare function useElementSize<T extends HTMLElement>(): [React.RefObject<T | null>, {
    width: number;
    height: number;
}];
//# sourceMappingURL=use-element-size.d.ts.map