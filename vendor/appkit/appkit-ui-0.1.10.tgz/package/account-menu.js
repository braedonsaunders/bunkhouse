'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Building2, Check, ChevronDown, ChevronLeft, ChevronRight, Languages, LayoutPanelLeft, LogOut, Palette, ShieldAlert, } from 'lucide-react';
import { Avatar } from './avatar.js';
import { Badge } from './badge.js';
import { UiLink } from './link-context.js';
import { Popover } from './popover.js';
import { ThemeToggle } from './theme.js';
import { cn } from './utils.js';
const DEFAULT_LABELS = {
    menu: 'Open account menu',
    account: 'Account',
    theme: 'Theme',
    back: 'Back',
    signOut: 'Sign out',
    signingOut: 'Signing out…',
};
/**
 * Bounded account launcher generalized into controlled choices.
 * Organization, language, layout persistence and sign-out stay app-owned.
 */
export function AccountMenu({ name, email, contextLabel, contextTone = 'default', roleLabel, status, organization, language, navigation, showTheme = true, elevatedAccess, onSignOut, labels: labelOverrides, }) {
    const labels = { ...DEFAULT_LABELS, ...labelOverrides };
    const [open, setOpen] = React.useState(false);
    const [view, setView] = React.useState('home');
    const [saving, setSaving] = React.useState(false);
    const [signingOut, startSignOut] = React.useTransition();
    const displayName = name || email || labels.account;
    function close() {
        setOpen(false);
        window.setTimeout(() => setView('home'), 150);
    }
    async function choose(choice, value) {
        setSaving(true);
        try {
            await choice.onChange(value);
            close();
        }
        finally {
            setSaving(false);
        }
    }
    const title = view === 'organization'
        ? organization?.label
        : view === 'language'
            ? language?.label
            : view === 'navigation'
                ? navigation?.label
                : labels.theme;
    return (_jsx(Popover, { open: open, onOpenChange: (next) => {
            setOpen(next);
            if (!next)
                window.setTimeout(() => setView('home'), 150);
        }, align: "end", className: "w-72", trigger: _jsxs("button", { type: "button", onClick: () => setOpen((current) => !current), "aria-label": labels.menu, "aria-expanded": open, "aria-haspopup": "menu", className: "flex shrink-0 items-center gap-2 rounded-md border border-transparent px-1.5 py-1 text-sm text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg", children: [_jsx(Avatar, { name: displayName, size: 28 }), _jsxs("span", { className: "hidden min-w-0 max-w-44 flex-col text-left sm:flex", children: [_jsx("span", { className: "truncate text-sm leading-tight text-fg", children: displayName }), contextLabel ? (_jsx("span", { className: cn('truncate text-[11px] leading-tight', contextTone === 'warning' ? 'text-warning' : 'text-fg-subtle'), children: contextLabel })) : null] }), _jsx(ChevronDown, { size: 14, className: "hidden shrink-0 text-fg-subtle sm:inline" })] }), children: view === 'home' ? (_jsxs("div", { children: [_jsxs("div", { className: "flex items-center gap-3 px-3 py-3", children: [_jsx(Avatar, { name: displayName, size: 40 }), _jsxs("span", { className: "flex min-w-0 flex-col", children: [_jsx("span", { className: "truncate text-sm font-medium text-fg", children: displayName }), email ? _jsx("span", { className: "truncate text-xs text-fg-muted", children: email }) : null, _jsxs("span", { className: "mt-1 flex flex-wrap gap-1", children: [roleLabel ? _jsx(Badge, { variant: "secondary", className: "text-[10px]", children: roleLabel }) : null, status ? _jsx(Badge, { variant: status.variant ?? 'secondary', className: "text-[10px]", children: status.label }) : null] })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-2 px-2 pb-2", children: [organization ? _jsx(LauncherCard, { icon: Building2, tone: "primary", label: organization.label, summary: organization.summary, onClick: () => setView('organization') }) : null, language ? _jsx(LauncherCard, { icon: Languages, tone: "info", label: language.label, summary: language.summary, onClick: () => setView('language') }) : null, showTheme ? _jsx(LauncherCard, { icon: Palette, tone: "primary", label: labels.theme, onClick: () => setView('theme') }) : null, navigation ? _jsx(LauncherCard, { icon: LayoutPanelLeft, tone: "warning", label: navigation.label, summary: navigation.summary, onClick: () => setView('navigation') }) : null, elevatedAccess ? (_jsxs(UiLink, { href: elevatedAccess.href, onClick: close, className: "group relative flex flex-col gap-2 rounded-xl border border-border bg-surface p-3 transition-colors hover:border-border-strong hover:bg-surface-hover", children: [_jsx("span", { className: "grid size-9 place-items-center rounded-lg bg-danger-subtle text-danger", children: _jsx(ShieldAlert, { size: 18 }) }), _jsx("span", { className: "truncate text-sm font-medium text-fg", children: elevatedAccess.label })] })) : null] }), onSignOut ? (_jsx("div", { className: "border-t border-border-subtle p-1", children: _jsxs("button", { type: "button", disabled: signingOut, role: "menuitem", onClick: () => startSignOut(async () => { await onSignOut(); close(); }), className: "flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg disabled:opacity-60", children: [_jsx(LogOut, { size: 15 }), signingOut ? labels.signingOut : labels.signOut] }) })) : null] })) : (_jsxs("div", { children: [_jsxs("div", { className: "flex items-center gap-1.5 border-b border-border-subtle px-2 py-2", children: [_jsx("button", { type: "button", onClick: () => setView('home'), "aria-label": labels.back, className: "grid size-7 place-items-center rounded-md text-fg-muted hover:bg-surface-hover hover:text-fg", children: _jsx(ChevronLeft, { size: 16 }) }), _jsx("span", { className: "text-sm font-semibold text-fg", children: title })] }), view === 'theme' ? _jsx("div", { className: "p-3", children: _jsx(ThemeToggle, {}) }) : null, view === 'organization' && organization ? _jsx(ChoiceList, { choice: organization, saving: saving, onChoose: choose }) : null, view === 'language' && language ? _jsx(ChoiceList, { choice: language, saving: saving, onChoose: choose }) : null, view === 'navigation' && navigation ? _jsx(ChoiceList, { choice: navigation, saving: saving, onChoose: choose }) : null] })) }));
}
function LauncherCard({ icon: Icon, tone, label, summary, onClick }) {
    return (_jsxs("button", { type: "button", onClick: onClick, className: "group relative flex flex-col gap-2 rounded-xl border border-border bg-surface p-3 text-left transition-colors hover:border-border-strong hover:bg-surface-hover", children: [_jsx("span", { className: cn('grid size-9 place-items-center rounded-lg', tone === 'info' ? 'bg-info-subtle text-info' : tone === 'warning' ? 'bg-warning-subtle text-warning' : 'bg-primary-subtle text-primary'), children: _jsx(Icon, { size: 18 }) }), _jsxs("span", { className: "min-w-0", children: [_jsx("span", { className: "block truncate text-sm font-medium text-fg", children: label }), summary ? _jsx("span", { className: "block truncate text-[11px] text-fg-subtle", children: summary }) : null] }), _jsx(ChevronRight, { size: 14, className: "absolute right-2.5 top-3 text-fg-subtle transition-transform group-hover:translate-x-0.5" })] }));
}
function ChoiceList({ choice, saving, onChoose }) {
    return (_jsx("div", { className: "max-h-72 overflow-y-auto p-1", children: choice.options.map((option) => {
            const active = choice.value === option.value;
            return (_jsxs("button", { type: "button", role: "menuitemradio", "aria-checked": active, disabled: saving, onClick: () => void onChoose(choice, option.value), className: "flex w-full items-start gap-2 rounded-md px-3 py-2 text-left text-sm text-fg-muted hover:bg-surface-hover hover:text-fg disabled:opacity-60", children: [_jsx(Check, { size: 15, className: cn('mt-0.5 shrink-0', active ? 'text-primary' : 'text-transparent') }), _jsxs("span", { className: "min-w-0", children: [_jsx("span", { className: "block truncate", children: option.label }), option.description ? _jsx("span", { className: "block truncate text-xs text-fg-subtle", children: option.description }) : null] })] }, option.value));
        }) }));
}
//# sourceMappingURL=account-menu.js.map