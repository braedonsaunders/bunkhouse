export function buildDefaultNavigationConfig(registry) {
    return {
        version: 1,
        items: registry.map((item) => ({ key: item.key })),
    };
}
/**
 * Reconcile saved tenant state with the current application registry.
 *
 * This preserves tenant order, drops stale/duplicate entries, restores
 * required destinations, and appends modules shipped after the last save.
 */
export function reconcileNavigationConfig(config, registry) {
    if (!config)
        return buildDefaultNavigationConfig(registry);
    const registryByKey = new Map(registry.map((item) => [item.key, item]));
    const known = new Set(config.knownItemKeys ?? []);
    const seen = new Set();
    const items = [];
    for (const item of config.items) {
        const registryItem = registryByKey.get(item.key);
        if (!registryItem || seen.has(item.key))
            continue;
        seen.add(item.key);
        items.push({
            key: item.key,
            ...(item.hidden && !registryItem.required ? { hidden: true } : {}),
        });
    }
    for (const registryItem of registry) {
        if (seen.has(registryItem.key))
            continue;
        if (!registryItem.required && known.has(registryItem.key))
            continue;
        seen.add(registryItem.key);
        items.push({ key: registryItem.key });
    }
    return {
        version: 1,
        items,
        ...(config.knownItemKeys ? { knownItemKeys: [...config.knownItemKeys] } : {}),
    };
}
export function stampKnownNavigationItems(config, registry) {
    return {
        ...reconcileNavigationConfig(config, registry),
        knownItemKeys: registry.map((item) => item.key),
    };
}
export function resolveNavigationItems(registry, config) {
    const registryByKey = new Map(registry.map((item) => [item.key, item]));
    return reconcileNavigationConfig(config, registry).items.flatMap((saved) => {
        const item = registryByKey.get(saved.key);
        if (!item)
            return [];
        return [{ ...item, hidden: Boolean(saved.hidden && !item.required) }];
    });
}
export function isTenantNavigationConfig(value) {
    if (!value || typeof value !== 'object')
        return false;
    const config = value;
    if (config.version !== 1 || !Array.isArray(config.items))
        return false;
    if (config.knownItemKeys !== undefined &&
        (!Array.isArray(config.knownItemKeys) ||
            config.knownItemKeys.some((key) => typeof key !== 'string'))) {
        return false;
    }
    return config.items.every((item) => Boolean(item) &&
        typeof item === 'object' &&
        typeof item.key === 'string' &&
        (item.hidden === undefined || typeof item.hidden === 'boolean'));
}
//# sourceMappingURL=navigation-config.js.map