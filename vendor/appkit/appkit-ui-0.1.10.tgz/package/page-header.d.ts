import * as React from 'react';
export type PageHeaderProps = {
    title: string;
    description?: string;
    actions?: React.ReactNode;
    /** Optional back link. `render` lets an app supply its own <Link>. */
    back?: {
        href: string;
        label: string;
        render?: (props: {
            href: string;
            children: React.ReactNode;
            className: string;
        }) => React.ReactNode;
    };
    className?: string;
};
export declare function PageHeader({ title, description, actions, back, className }: PageHeaderProps): React.JSX.Element;
export type DetailHeaderProps = {
    back?: {
        href: string;
        label: string;
    };
    title: string;
    subtitle?: string;
    badge?: React.ReactNode;
    actions?: React.ReactNode;
    className?: string;
};
/** Source-compatible record-detail heading. */
export declare function DetailHeader({ back, title, subtitle, badge, actions, className, }: DetailHeaderProps): React.JSX.Element;
//# sourceMappingURL=page-header.d.ts.map