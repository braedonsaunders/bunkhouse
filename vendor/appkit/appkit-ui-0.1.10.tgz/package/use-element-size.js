'use client';
import * as React from 'react';
/** Measured size of an element, kept current across resizes. */
export function useElementSize() {
    const ref = React.useRef(null);
    const [size, setSize] = React.useState({ width: 0, height: 0 });
    React.useEffect(() => {
        const element = ref.current;
        if (!element)
            return;
        const observer = new ResizeObserver((entries) => {
            const rect = entries[0]?.contentRect;
            if (rect)
                setSize({ width: rect.width, height: rect.height });
        });
        observer.observe(element);
        return () => observer.disconnect();
    }, []);
    return [ref, size];
}
//# sourceMappingURL=use-element-size.js.map