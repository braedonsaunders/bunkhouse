import * as React from 'react';
export type NotificationItem = {
    id: string;
    title: string;
    body?: string | null;
    href?: string | null;
    readAt?: string | null;
    createdAt: string;
};
export type NotificationsBellLabels = {
    ariaLabel: string;
    title: string;
    markAllRead: string;
    empty: string;
};
export declare function NotificationsBell({ items, onOpenItem, onMarkRead, labels, }: {
    items: NotificationItem[];
    onOpenItem?: (item: NotificationItem) => void;
    onMarkRead?: (ids: string[] | 'all') => void | Promise<void>;
    labels?: NotificationsBellLabels;
}): React.JSX.Element;
//# sourceMappingURL=notifications-bell.d.ts.map