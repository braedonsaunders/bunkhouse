import * as React from 'react';
import { type BadgeProps } from './badge.js';
export type WorkspaceLaunchTone = 'indigo' | 'sky' | 'amber' | 'teal' | 'emerald' | 'violet' | 'rose' | 'lime' | 'cyan';
export type WorkspaceLaunchSegment = {
    label: string;
    value: number;
    tone?: WorkspaceLaunchTone;
    muted?: boolean;
};
export type WorkspaceLaunchBreakdown = {
    label: string;
    segments: WorkspaceLaunchSegment[];
};
export type WorkspaceLaunchItem<Id extends string = string> = {
    id: Id;
    title: string;
    description: string;
    icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
    metric: React.ReactNode;
    metricLabel: string;
    tone: WorkspaceLaunchTone;
    breakdown?: WorkspaceLaunchBreakdown;
    summary?: React.ReactNode;
    summaryVariant?: BadgeProps['variant'];
    disabled?: boolean;
    ghostIcon?: boolean;
    ariaLabel?: string;
};
export type WorkspaceLauncherProps<Id extends string = string> = {
    items: WorkspaceLaunchItem<Id>[];
    onSelect: (id: Id, item: WorkspaceLaunchItem<Id>) => void;
    title?: React.ReactNode;
    description?: React.ReactNode;
    framed?: boolean;
    density?: 'compact' | 'comfortable';
    /** `scroll` keeps fixed-height cards and scrolls the grid. `fit` divides the
     * available height evenly between rows and never introduces a grid scrollbar. */
    layout?: 'scroll' | 'fit';
    /** Hide composition meters without changing the data supplied by callers. */
    showBreakdowns?: boolean;
    /** Hide per-card summary badges in space-constrained launchers. */
    showSummaries?: boolean;
    className?: string;
    gridClassName?: string;
    cardClassName?: string;
    itemCountLabel?: React.ReactNode;
    formatCount?: (value: number) => React.ReactNode;
};
export declare function WorkspaceLauncher<Id extends string = string>({ items, onSelect, title, description, framed, density, layout, showBreakdowns, showSummaries, className, gridClassName, cardClassName, itemCountLabel, formatCount, }: WorkspaceLauncherProps<Id>): React.JSX.Element;
//# sourceMappingURL=workspace-launcher.d.ts.map