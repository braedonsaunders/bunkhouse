'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useTransition } from 'react';
import { Alert, AlertDescription, Button, Input, Label } from '@appkit/ui';
const defaults = {
    passwordMode: 'Password',
    magicLinkMode: 'Email link',
    email: 'Email',
    password: 'Password',
    forgotPassword: 'Forgot password?',
    signIn: 'Sign in',
    sendMagicLink: 'Email me a sign-in link',
    signingIn: 'Signing in…',
    magicLinkSent: 'Check your email for a sign-in link.',
    invalidCredentials: 'Sign-in failed. Check your details and try again.',
    requestReset: 'Send reset link',
    requestingReset: 'Sending…',
    resetSent: 'If an account exists for that email, a reset link is on its way.',
    newPassword: 'New password',
    confirmPassword: 'Confirm password',
    showPassword: 'Show password',
    hidePassword: 'Hide password',
    updatePassword: 'Update password',
    updatingPassword: 'Updating…',
    passwordTooShort: 'Password must be at least 8 characters.',
    passwordsDoNotMatch: 'Passwords do not match.',
    invalidResetLink: 'This reset link has expired or already been used. Request a new one.',
};
/** Source-parity password/magic-link sign-in form with app-owned navigation. */
export function SignInForm({ signInWithPassword, signInWithMagicLink, onSignedIn, callbackURL = '/auth/continue', forgotPasswordHref = '/forgot-password', defaultMode = 'password', labels, }) {
    const copy = { ...defaults, ...labels };
    const [pending, startTransition] = useTransition();
    const [mode, setMode] = useState(defaultMode);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const [info, setInfo] = useState(null);
    function submit(event) {
        event.preventDefault();
        setError(null);
        setInfo(null);
        startTransition(async () => {
            try {
                if (mode === 'password') {
                    const result = await signInWithPassword({ email: email.trim().toLowerCase(), password });
                    if (result.error)
                        return setError(result.error || copy.invalidCredentials);
                    onSignedIn();
                    return;
                }
                const result = await signInWithMagicLink({
                    email: email.trim().toLowerCase(),
                    callbackURL,
                });
                if (result.error)
                    return setError(result.error || copy.invalidCredentials);
                setInfo(copy.magicLinkSent);
            }
            catch (cause) {
                setError(cause instanceof Error && cause.message ? cause.message : copy.invalidCredentials);
            }
        });
    }
    return (_jsxs("form", { onSubmit: submit, className: "space-y-4", children: [_jsx("div", { className: "flex gap-1 rounded-md border border-border bg-surface p-1 text-sm", children: ['password', 'magic'].map((candidate) => (_jsx("button", { type: "button", "aria-pressed": mode === candidate, onClick: () => setMode(candidate), className: mode === candidate
                        ? 'flex-1 rounded bg-bg-subtle px-3 py-1.5 font-medium text-fg'
                        : 'flex-1 rounded px-3 py-1.5 text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg', children: candidate === 'password' ? copy.passwordMode : copy.magicLinkMode }, candidate))) }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "auth-email", children: copy.email }), _jsx(Input, { id: "auth-email", type: "email", autoComplete: "email", required: true, value: email, onChange: (event) => setEmail(event.currentTarget.value) })] }), mode === 'password' ? (_jsxs("div", { className: "space-y-1.5", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx(Label, { htmlFor: "auth-password", children: copy.password }), _jsx("a", { href: forgotPasswordHref, className: "text-xs text-primary hover:underline", children: copy.forgotPassword })] }), _jsx(Input, { id: "auth-password", type: "password", autoComplete: "current-password", required: true, value: password, onChange: (event) => setPassword(event.currentTarget.value) })] })) : null, _jsx(AuthMessage, { error: error, info: info }), _jsx(Button, { type: "submit", className: "w-full", disabled: pending, children: pending ? copy.signingIn : mode === 'password' ? copy.signIn : copy.sendMagicLink })] }));
}
/** Account-enumeration-safe reset request form. */
export function ForgotPasswordForm({ requestReset, labels }) {
    const copy = { ...defaults, ...labels };
    const [pending, startTransition] = useTransition();
    const [email, setEmail] = useState('');
    const [sent, setSent] = useState(false);
    function submit(event) {
        event.preventDefault();
        startTransition(async () => {
            try {
                await requestReset(email.trim().toLowerCase());
            }
            catch {
                // Deliberately indistinguishable: never reveal whether the identity exists.
            }
            setSent(true);
        });
    }
    return (_jsxs("form", { onSubmit: submit, className: "space-y-4", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "reset-email", children: copy.email }), _jsx(Input, { id: "reset-email", type: "email", autoComplete: "email", required: true, value: email, onChange: (event) => setEmail(event.currentTarget.value) })] }), sent ? (_jsx(Alert, { variant: "success", children: _jsx(AlertDescription, { children: copy.resetSent }) })) : null, _jsx(Button, { type: "submit", className: "w-full", disabled: pending || sent, children: pending ? copy.requestingReset : copy.requestReset })] }));
}
/** Token-bound reset form preserving the source validation and recovery states. */
export function ResetPasswordForm({ token, resetPassword, onReset, minLength = 8, labels, }) {
    const copy = { ...defaults, ...labels };
    const [pending, startTransition] = useTransition();
    const [password, setPassword] = useState('');
    const [confirm, setConfirm] = useState('');
    const [show, setShow] = useState(false);
    const [error, setError] = useState(null);
    function submit(event) {
        event.preventDefault();
        if (!token)
            return setError(copy.invalidResetLink);
        if (password.length < minLength)
            return setError(copy.passwordTooShort);
        if (password !== confirm)
            return setError(copy.passwordsDoNotMatch);
        setError(null);
        startTransition(async () => {
            try {
                const result = await resetPassword({ token, newPassword: password });
                if (result.error)
                    return setError(result.error);
                onReset();
            }
            catch {
                setError(copy.invalidResetLink);
            }
        });
    }
    return (_jsxs("form", { onSubmit: submit, className: "space-y-4", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "new-password", children: copy.newPassword }), _jsx(Input, { id: "new-password", type: show ? 'text' : 'password', autoComplete: "new-password", minLength: minLength, required: true, value: password, onChange: (event) => setPassword(event.currentTarget.value) })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { htmlFor: "confirm-password", children: copy.confirmPassword }), _jsx(Input, { id: "confirm-password", type: show ? 'text' : 'password', autoComplete: "new-password", minLength: minLength, required: true, value: confirm, onChange: (event) => setConfirm(event.currentTarget.value) })] }), _jsx("button", { type: "button", onClick: () => setShow((value) => !value), className: "text-xs text-fg-muted hover:text-fg hover:underline", children: show ? copy.hidePassword : copy.showPassword }), _jsx(AuthMessage, { error: error, info: null }), _jsx(Button, { type: "submit", className: "w-full", disabled: pending, children: pending ? copy.updatingPassword : copy.updatePassword })] }));
}
export function AuthScreen({ logo, title, description, children, footer, }) {
    return (_jsx("main", { className: "grid min-h-screen place-items-center bg-bg px-4", children: _jsxs("div", { className: "w-full max-w-sm space-y-6", children: [_jsxs("div", { className: "text-center", children: [logo ? _jsx("div", { className: "mb-5 flex justify-center", children: logo }) : null, _jsx("h1", { className: "text-xl font-semibold text-fg", children: title }), description ? _jsx("p", { className: "mt-1 text-sm text-fg-muted", children: description }) : null] }), children, footer ? _jsx("div", { className: "text-center text-xs text-fg-muted", children: footer }) : null] }) }));
}
function AuthMessage({ error, info }) {
    if (error)
        return _jsx(Alert, { variant: "destructive", children: _jsx(AlertDescription, { children: error }) });
    if (info)
        return _jsx(Alert, { variant: "success", children: _jsx(AlertDescription, { children: info }) });
    return null;
}
//# sourceMappingURL=react.js.map