export type AuthEmailKind = 'magic-link' | 'invitation' | 'password-reset';
export type AuthEmail = {
    kind: AuthEmailKind;
    to: string;
    subject: string;
    text: string;
    html: string;
};
export type AuthEmailSender = (email: AuthEmail) => Promise<void>;
export type AuthEmailRenderer = {
    magicLink?: (input: {
        appName: string;
        email: string;
        url: string;
        invitation: boolean;
        tenantName: string | null;
    }) => Omit<AuthEmail, 'kind' | 'to'>;
    passwordReset?: (input: {
        appName: string;
        email: string;
        url: string;
    }) => Omit<AuthEmail, 'kind' | 'to'>;
};
export declare function renderMagicLinkEmail(input: {
    appName: string;
    email: string;
    url: string;
    invitation: boolean;
    tenantName: string | null;
}): Omit<AuthEmail, 'kind' | 'to'>;
export declare function renderPasswordResetEmail(input: {
    appName: string;
    email: string;
    url: string;
}): Omit<AuthEmail, 'kind' | 'to'>;
//# sourceMappingURL=mail.d.ts.map