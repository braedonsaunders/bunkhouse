declare const INVITE_GRANT_VERSION = 1;
export type InviteGrantInput = {
    membershipId: string;
    tenantId: string;
    userId: string;
    invitedAt: Date;
};
export type InviteGrantPayload = {
    v: typeof INVITE_GRANT_VERSION;
    membershipId: string;
    tenantId: string;
    userId: string;
    invitedAt: number;
    issuedAt: number;
    expiresAt: number;
};
export type InviteGrantVerification = {
    ok: true;
    payload: InviteGrantPayload;
} | {
    ok: false;
    reason: 'invalid' | 'expired';
};
export type InviteAccessState = 'active' | 'pending' | 'suspended' | 'tenant_unavailable' | 'unverified' | 'invalid' | 'expired';
export type InviteRecord = {
    membershipId: string;
    tenantId: string;
    tenantName: string;
    userId: string;
    invitedAt: Date | null;
    status: 'active' | 'invited' | 'suspended';
    emailVerified: boolean;
    tenantStatus: 'active' | 'suspended' | 'archived';
};
export type InviteInspection = {
    state: InviteAccessState;
    tenantId: string | null;
    tenantName: string | null;
};
export type InviteStore = {
    /** Read-only inspection. This must never activate a membership. */
    inspect: (membershipId: string) => Promise<InviteRecord | null>;
    /**
     * Atomically lock, re-evaluate, activate, and audit a pending membership.
     * The store receives the already signature-verified grant and must return the
     * final state so concurrent or superseded links cannot double-accept.
     */
    accept: (payload: InviteGrantPayload, sessionUserId: string) => Promise<InviteAccessState>;
};
export type InviteServiceOptions = {
    secret: string;
    store: InviteStore;
    ttlSeconds?: number;
    /** HKDF domain separation. Change this only when intentionally rotating formats. */
    signingContext?: string;
    callbackPath?: string;
};
export type InviteService = {
    ttlSeconds: number;
    createInviteGrant: (input: InviteGrantInput, now?: number) => string;
    verifyInviteGrant: (raw: string, now?: number) => InviteGrantVerification;
    inviteCallbackPath: (grant: string) => string;
    inviteGrantFromCallbackURL: (callbackURL: unknown, baseURL: string) => string | null;
    acceptInviteAfterMagicLink: (rawGrant: string, sessionUserId: string) => Promise<InviteAccessState>;
    inspectInviteForUser: (rawGrant: string, sessionUserId: string) => Promise<InviteInspection>;
};
/**
 * The complete invitation grant flow extracted from the production runtime.
 * Better Auth's one-time magic-link token proves mailbox possession; this
 * independently signed grant binds that verified callback to exactly one
 * pending membership generation.
 */
export declare function createInviteService(options: InviteServiceOptions): InviteService;
/** Pure state machine shared by memory and durable stores. */
export declare function evaluateInviteAccess(payload: InviteGrantPayload, sessionUserId: string, record: InviteRecord | null): InviteAccessState;
/** Every resend advances the generation, even within the same clock tick. */
export declare function nextInviteGenerationDate(previous: Date | null, now?: Date): Date;
export {};
//# sourceMappingURL=invites.d.ts.map