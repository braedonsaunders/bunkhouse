import { and, eq } from 'drizzle-orm';
import { auditLog, memberships, tenants, users, } from '@appkit/db/schema';
import { evaluateInviteAccess } from './invites.js';
import * as appkitSchema from '@appkit/db/schema';
/**
 * Tenant-safe durable invitation adapter. Acceptance, the optional domain hook,
 * and its audit record commit atomically under the BYPASSRLS system handle.
 */
export function createDrizzleInviteStore(database, options = {}) {
    async function load(db, membershipId, lock) {
        let query = db
            .select({
            membershipId: memberships.id,
            tenantId: memberships.tenantId,
            tenantName: tenants.name,
            userId: memberships.userId,
            invitedAt: memberships.invitedAt,
            status: memberships.status,
            emailVerified: users.emailVerified,
            tenantStatus: tenants.status,
        })
            .from(memberships)
            .innerJoin(users, eq(users.id, memberships.userId))
            .innerJoin(tenants, eq(tenants.id, memberships.tenantId))
            .where(eq(memberships.id, membershipId))
            .limit(1);
        if (lock)
            query = query.for('update');
        const [row] = await query;
        return row ?? null;
    }
    return {
        inspect: (membershipId) => database.withSuperAdmin((db) => load(db, membershipId, false)),
        accept: (payload, sessionUserId) => database.withSuperAdmin((db) => db.transaction(async (tx) => acceptInTransaction(tx, payload, sessionUserId, options, load))),
    };
}
async function acceptInTransaction(tx, payload, sessionUserId, options, load) {
    const row = await load(tx, payload.membershipId, true);
    const state = evaluateInviteAccess(payload, sessionUserId, row);
    if (state !== 'pending' || !row)
        return state;
    const acceptedAt = new Date();
    const [accepted] = await tx
        .update(memberships)
        .set({ status: 'active', joinedAt: acceptedAt, updatedAt: acceptedAt })
        .where(and(eq(memberships.id, payload.membershipId), eq(memberships.tenantId, payload.tenantId), eq(memberships.userId, payload.userId), eq(memberships.status, 'invited'), eq(memberships.invitedAt, new Date(payload.invitedAt))))
        .returning({ id: memberships.id });
    if (!accepted) {
        const current = await load(tx, payload.membershipId, false);
        return evaluateInviteAccess(payload, sessionUserId, current);
    }
    await options.onAccepted?.(tx, payload.tenantId, payload.userId);
    await tx.insert(auditLog).values({
        tenantId: payload.tenantId,
        actorUserId: sessionUserId,
        entityType: options.audit?.entityType ?? 'tenant_user',
        entityId: payload.membershipId,
        action: options.audit?.action ?? 'update',
        summary: options.audit?.summary ?? 'Accepted membership invitation',
        before: { status: 'invited' },
        after: { status: 'active', joinedAt: acceptedAt.toISOString() },
        metadata: { acceptedVia: 'magic_link' },
    });
    return 'active';
}
//# sourceMappingURL=drizzle.js.map