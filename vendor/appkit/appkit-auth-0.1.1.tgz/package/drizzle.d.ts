import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { AppkitDb } from '@appkit/db';
import type { InviteStore } from './invites.js';
import * as appkitSchema from '@appkit/db/schema';
type Schema = typeof appkitSchema;
type Database = NodePgDatabase<Schema>;
export type DrizzleInviteStoreOptions = {
    /** Optional domain hook committed in the same transaction as acceptance. */
    onAccepted?: (db: Database, tenantId: string, userId: string) => Promise<void>;
    /** Customize the audit vocabulary without changing the state machine. */
    audit?: {
        entityType?: string;
        action?: string;
        summary?: string;
    };
};
/**
 * Tenant-safe durable invitation adapter. Acceptance, the optional domain hook,
 * and its audit record commit atomically under the BYPASSRLS system handle.
 */
export declare function createDrizzleInviteStore(database: Pick<AppkitDb<Schema>, 'withSuperAdmin'>, options?: DrizzleInviteStoreOptions): InviteStore;
export {};
//# sourceMappingURL=drizzle.d.ts.map