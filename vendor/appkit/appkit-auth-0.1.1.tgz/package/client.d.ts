import { createAuthClient } from 'better-auth/react';
export type AppkitAuthClientOptions = {
    baseURL?: string;
    basePath?: string;
    fetchOptions?: Parameters<typeof createAuthClient>[0] extends infer Options ? Options extends {
        fetchOptions?: infer FetchOptions;
    } ? FetchOptions : never : never;
};
/** React client with password, session, reset, and magic-link APIs. */
export declare function createAppkitAuthClient(options?: AppkitAuthClientOptions): import("better-auth/react").ReactAuthClient<{
    plugins: {
        id: "magic-link";
        version: string;
        $InferServerPlugin: ReturnType<(options: import("better-auth/plugins").MagicLinkOptions) => {
            id: "magic-link";
            version: string;
            endpoints: {
                signInMagicLink: import("better-auth").StrictEndpoint<"/sign-in/magic-link", {
                    method: "POST";
                    requireHeaders: true;
                    body: import("zod").ZodObject<{
                        email: import("zod").ZodEmail;
                        name: import("zod").ZodOptional<import("zod").ZodString>;
                        callbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                        newUserCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                        errorCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                        metadata: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>>;
                    }, import("zod/v4/core").$strip>;
                    metadata: {
                        openapi: {
                            operationId: string;
                            description: string;
                            responses: {
                                200: {
                                    description: string;
                                    content: {
                                        "application/json": {
                                            schema: {
                                                type: "object";
                                                properties: {
                                                    status: {
                                                        type: string;
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                }, {
                    status: boolean;
                }>;
                magicLinkVerify: import("better-auth").StrictEndpoint<"/magic-link/verify", {
                    method: "GET";
                    query: import("zod").ZodObject<{
                        token: import("zod").ZodString;
                        callbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                        errorCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                        newUserCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                    }, import("zod/v4/core").$strip>;
                    use: ((inputContext: import("better-auth").MiddlewareInputContext<import("better-auth").MiddlewareOptions>) => Promise<void>)[];
                    requireHeaders: true;
                    metadata: {
                        openapi: {
                            operationId: string;
                            description: string;
                            responses: {
                                200: {
                                    description: string;
                                    content: {
                                        "application/json": {
                                            schema: {
                                                type: "object";
                                                properties: {
                                                    session: {
                                                        $ref: string;
                                                    };
                                                    user: {
                                                        $ref: string;
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                }, {
                    token: string;
                    user: {
                        id: string;
                        createdAt: Date;
                        updatedAt: Date;
                        email: string;
                        emailVerified: boolean;
                        name: string;
                        image?: string | null | undefined;
                    };
                    session: {
                        id: string;
                        createdAt: Date;
                        updatedAt: Date;
                        userId: string;
                        expiresAt: Date;
                        token: string;
                        ipAddress?: string | null | undefined;
                        userAgent?: string | null | undefined;
                    };
                }>;
            };
            rateLimit: {
                pathMatcher(path: string): boolean;
                window: number;
                max: number;
            }[];
            options: import("better-auth/plugins").MagicLinkOptions;
        }>;
    }[];
    baseURL?: string;
    basePath?: string;
    fetchOptions?: Parameters<typeof createAuthClient>[0] extends infer Options ? Options extends {
        fetchOptions?: infer FetchOptions;
    } ? FetchOptions : never : never;
}>;
export type AppkitAuthClient = ReturnType<typeof createAppkitAuthClient>;
//# sourceMappingURL=client.d.ts.map