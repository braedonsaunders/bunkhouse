import type { InviteRecord, InviteStore } from './invites.js';
export type MemoryInviteStore = InviteStore & {
    records: Map<string, InviteRecord>;
};
/** Deterministic adapter for tests, local apps, and database-free demos. */
export declare function createMemoryInviteStore(seed?: InviteRecord[]): MemoryInviteStore;
//# sourceMappingURL=memory.d.ts.map