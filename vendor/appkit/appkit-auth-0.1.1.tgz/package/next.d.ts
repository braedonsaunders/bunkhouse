export { toNextJsHandler } from 'better-auth/next-js';
//# sourceMappingURL=next.d.ts.map