export { toNextJsHandler } from 'better-auth/next-js';
//# sourceMappingURL=next.js.map