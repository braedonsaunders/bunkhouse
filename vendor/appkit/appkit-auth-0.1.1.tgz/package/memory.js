import { evaluateInviteAccess } from './invites.js';
/** Deterministic adapter for tests, local apps, and database-free demos. */
export function createMemoryInviteStore(seed = []) {
    const records = new Map(seed.map((record) => [record.membershipId, structuredClone(record)]));
    return {
        records,
        async inspect(membershipId) {
            const record = records.get(membershipId);
            return record ? structuredClone(record) : null;
        },
        async accept(payload, sessionUserId) {
            const record = records.get(payload.membershipId) ?? null;
            const state = evaluateInviteAccess(payload, sessionUserId, record);
            if (state !== 'pending' || !record)
                return state;
            records.set(record.membershipId, {
                ...record,
                status: 'active',
            });
            return 'active';
        },
    };
}
//# sourceMappingURL=memory.js.map