import { betterAuth } from 'better-auth';
import type { AuthEmailRenderer, AuthEmailSender } from './mail.js';
import type { InviteService } from './invites.js';
type BetterAuthOptions = Parameters<typeof betterAuth>[0];
export type AppkitAuthOptions = {
    database: NonNullable<BetterAuthOptions['database']>;
    baseURL: string;
    secret: string;
    appName: string;
    sendEmail: AuthEmailSender;
    renderEmail?: AuthEmailRenderer;
    inviteService?: InviteService;
    onInviteAcceptanceError?: (error: unknown) => void;
    trustedOrigins?: BetterAuthOptions['trustedOrigins'];
    session?: {
        expiresIn?: number;
        updateAge?: number;
        cookieCacheMaxAge?: number;
    };
    password?: {
        disableSignUp?: boolean;
        requireEmailVerification?: boolean;
        minLength?: number;
        resetTokenExpiresIn?: number;
    };
    magicLink?: {
        expiresIn?: number;
        disableSignUp?: boolean;
    };
    /** Additional upstream options such as social providers and database hooks. */
    extend?: Omit<BetterAuthOptions, 'database' | 'baseURL' | 'secret' | 'appName' | 'trustedOrigins' | 'user' | 'session' | 'account' | 'verification' | 'emailAndPassword' | 'plugins' | 'hooks' | 'advanced'>;
};
/**
 * Complete persisted authentication runtime extracted from the production
 * reference: password sign-in/reset, hashed one-time magic links, invitation
 * activation, durable sessions/accounts/verifications, client-compatible APIs,
 * and optional social-provider extension. Product delivery and domain effects
 * are injected.
 */
export declare function createAppkitAuth(options: AppkitAuthOptions): import("better-auth").Auth<{
    database: any;
    baseURL: string;
    secret: string;
    appName: string;
    user: {
        modelName: "users";
        fields: {
            emailVerified: string;
            createdAt: string;
            updatedAt: string;
        };
        additionalFields: {
            timezone: {
                type: "string";
                fieldName: string;
                required: true;
                defaultValue: string;
            };
            isActive: {
                type: "boolean";
                fieldName: string;
                required: true;
                defaultValue: true;
                input: false;
            };
            isSuperAdmin: {
                type: "boolean";
                fieldName: string;
                required: true;
                defaultValue: false;
                input: false;
            };
        };
    };
    session: {
        modelName: "sessions";
        fields: {
            userId: string;
            expiresAt: string;
            ipAddress: string;
            userAgent: string;
            createdAt: string;
            updatedAt: string;
        };
        additionalFields: {
            activeTenantId: {
                type: "string";
                fieldName: string;
                required: false;
                input: false;
            };
            impersonatingUserId: {
                type: "string";
                fieldName: string;
                required: false;
                input: false;
            };
            impersonationTenantId: {
                type: "string";
                fieldName: string;
                required: false;
                input: false;
            };
            impersonationStartedAt: {
                type: "date";
                fieldName: string;
                required: false;
                input: false;
            };
            impersonationExpiresAt: {
                type: "date";
                fieldName: string;
                required: false;
                input: false;
            };
            impersonationReason: {
                type: "string";
                fieldName: string;
                required: false;
                input: false;
            };
        };
        expiresIn: number;
        updateAge: number;
        cookieCache: {
            enabled: true;
            maxAge: number;
        };
    };
    account: {
        modelName: "accounts";
        fields: {
            userId: string;
            accountId: string;
            providerId: string;
            accessToken: string;
            refreshToken: string;
            idToken: string;
            accessTokenExpiresAt: string;
            refreshTokenExpiresAt: string;
            createdAt: string;
            updatedAt: string;
        };
        encryptOAuthTokens: true;
    };
    verification: {
        modelName: "verifications";
        fields: {
            expiresAt: string;
            createdAt: string;
            updatedAt: string;
        };
    };
    advanced: {
        database: {
            generateId: "uuid";
        };
    };
    emailAndPassword: {
        enabled: true;
        disableSignUp: boolean;
        requireEmailVerification: boolean;
        minPasswordLength: number;
        autoSignIn: true;
        resetPasswordTokenExpiresIn: number;
        revokeSessionsOnPasswordReset: true;
        sendResetPassword: ({ user, url }: {
            user: import("better-auth").User;
            url: string;
            token: string;
        }) => Promise<void>;
    };
    plugins: [{
        id: "magic-link";
        version: string;
        endpoints: {
            signInMagicLink: import("better-auth").StrictEndpoint<"/sign-in/magic-link", {
                method: "POST";
                requireHeaders: true;
                body: import("zod").ZodObject<{
                    email: import("zod").ZodEmail;
                    name: import("zod").ZodOptional<import("zod").ZodString>;
                    callbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                    newUserCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                    errorCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                    metadata: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>>;
                }, import("zod/v4/core").$strip>;
                metadata: {
                    openapi: {
                        operationId: string;
                        description: string;
                        responses: {
                            200: {
                                description: string;
                                content: {
                                    "application/json": {
                                        schema: {
                                            type: "object";
                                            properties: {
                                                status: {
                                                    type: string;
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            }, {
                status: boolean;
            }>;
            magicLinkVerify: import("better-auth").StrictEndpoint<"/magic-link/verify", {
                method: "GET";
                query: import("zod").ZodObject<{
                    token: import("zod").ZodString;
                    callbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                    errorCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                    newUserCallbackURL: import("zod").ZodOptional<import("zod").ZodString>;
                }, import("zod/v4/core").$strip>;
                use: ((inputContext: import("better-auth").MiddlewareInputContext<import("better-auth").MiddlewareOptions>) => Promise<void>)[];
                requireHeaders: true;
                metadata: {
                    openapi: {
                        operationId: string;
                        description: string;
                        responses: {
                            200: {
                                description: string;
                                content: {
                                    "application/json": {
                                        schema: {
                                            type: "object";
                                            properties: {
                                                session: {
                                                    $ref: string;
                                                };
                                                user: {
                                                    $ref: string;
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            }, {
                token: string;
                user: {
                    id: string;
                    createdAt: Date;
                    updatedAt: Date;
                    email: string;
                    emailVerified: boolean;
                    name: string;
                    image?: string | null | undefined;
                };
                session: {
                    id: string;
                    createdAt: Date;
                    updatedAt: Date;
                    userId: string;
                    expiresAt: Date;
                    token: string;
                    ipAddress?: string | null | undefined;
                    userAgent?: string | null | undefined;
                };
            }>;
        };
        rateLimit: {
            pathMatcher(path: string): boolean;
            window: number;
            max: number;
        }[];
        options: import("better-auth/plugins").MagicLinkOptions;
    }];
    hooks: {
        after: (rawContext: import("better-auth").MiddlewareInputContext<import("better-auth").MiddlewareOptions>) => Promise<{}>;
    };
    trustedOrigins: string[] | ((request?: Request | undefined) => import("better-auth").Awaitable<(string | undefined | null)[]>);
    onAPIError?: {
        throw?: boolean;
        onError?: (error: unknown, ctx: import("better-auth").AuthContext) => void | Promise<void>;
        errorURL?: string;
        customizeDefaultErrorPage?: {
            colors?: {
                background?: string;
                foreground?: string;
                primary?: string;
                primaryForeground?: string;
                mutedForeground?: string;
                border?: string;
                destructive?: string;
                titleBorder?: string;
                titleColor?: string;
                gridColor?: string;
                cardBackground?: string;
                cornerBorder?: string;
            };
            size?: {
                radiusSm?: string;
                radiusMd?: string;
                radiusLg?: string;
                textSm?: string;
                text2xl?: string;
                text4xl?: string;
                text6xl?: string;
            };
            font?: {
                defaultFamily?: string;
                monoFamily?: string;
            };
            disableTitleBorder?: boolean;
            disableCornerDecorations?: boolean;
            disableBackgroundGrid?: boolean;
        };
    } | undefined;
    rateLimit?: import("better-auth").BetterAuthRateLimitOptions | undefined;
    basePath?: string | undefined;
    secrets?: Array<{
        version: number;
        value: string;
    }> | undefined;
    secondaryStorage?: import("better-auth").SecondaryStorage | undefined;
    emailVerification?: {
        sendVerificationEmail?: (data: {
            user: import("better-auth").User;
            url: string;
            token: string;
        }, request?: Request) => Promise<void>;
        sendOnSignUp?: boolean;
        sendOnSignIn?: boolean;
        autoSignInAfterVerification?: boolean;
        expiresIn?: number;
        beforeEmailVerification?: (user: import("better-auth").User, request?: Request) => Promise<void>;
        afterEmailVerification?: (user: import("better-auth").User, request?: Request) => Promise<void>;
    } | undefined;
    socialProviders?: import("better-auth").SocialProviders | undefined;
    logger?: import("better-auth").Logger | undefined;
    databaseHooks?: {
        user?: {
            create?: {
                before?: (user: import("better-auth").User & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        email?: string | undefined;
                        emailVerified?: boolean | undefined;
                        name?: string | undefined;
                        image?: string | null | undefined;
                    } & Record<string, any>;
                }>;
                after?: (user: import("better-auth").User & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            update?: {
                before?: (user: Partial<import("better-auth").User> & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        [x: string]: any;
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        email?: string | undefined;
                        emailVerified?: boolean | undefined;
                        name?: string | undefined;
                        image?: string | null | undefined;
                    };
                }>;
                after?: (user: import("better-auth").User & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            delete?: {
                before?: (user: import("better-auth").User & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void>;
                after?: (user: import("better-auth").User & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
        };
        session?: {
            create?: {
                before?: (session: import("better-auth").Session & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        userId?: string | undefined;
                        expiresAt?: Date | undefined;
                        token?: string | undefined;
                        ipAddress?: string | null | undefined;
                        userAgent?: string | null | undefined;
                    } & Record<string, any>;
                }>;
                after?: (session: import("better-auth").Session & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            update?: {
                before?: (session: Partial<import("better-auth").Session> & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        [x: string]: any;
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        userId?: string | undefined;
                        expiresAt?: Date | undefined;
                        token?: string | undefined;
                        ipAddress?: string | null | undefined;
                        userAgent?: string | null | undefined;
                    };
                }>;
                after?: (session: import("better-auth").Session & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            delete?: {
                before?: (session: import("better-auth").Session & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void>;
                after?: (session: import("better-auth").Session & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
        };
        account?: {
            create?: {
                before?: (account: import("better-auth").Account, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        providerId?: string | undefined;
                        accountId?: string | undefined;
                        userId?: string | undefined;
                        accessToken?: string | null | undefined;
                        refreshToken?: string | null | undefined;
                        idToken?: string | null | undefined;
                        accessTokenExpiresAt?: Date | null | undefined;
                        refreshTokenExpiresAt?: Date | null | undefined;
                        scope?: string | null | undefined;
                        password?: string | null | undefined;
                    } & Record<string, any>;
                }>;
                after?: (account: import("better-auth").Account, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            update?: {
                before?: (account: Partial<import("better-auth").Account> & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        [x: string]: any;
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        providerId?: string | undefined;
                        accountId?: string | undefined;
                        userId?: string | undefined;
                        accessToken?: string | null | undefined;
                        refreshToken?: string | null | undefined;
                        idToken?: string | null | undefined;
                        accessTokenExpiresAt?: Date | null | undefined;
                        refreshTokenExpiresAt?: Date | null | undefined;
                        scope?: string | null | undefined;
                        password?: string | null | undefined;
                    };
                }>;
                after?: (account: import("better-auth").Account & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            delete?: {
                before?: (account: import("better-auth").Account & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void>;
                after?: (account: import("better-auth").Account & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
        };
        verification?: {
            create?: {
                before?: (verification: import("better-auth").Verification & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        value?: string | undefined;
                        expiresAt?: Date | undefined;
                        identifier?: string | undefined;
                    } & Record<string, any>;
                }>;
                after?: (verification: import("better-auth").Verification & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            update?: {
                before?: (verification: Partial<import("better-auth").Verification> & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void | {
                    data: {
                        [x: string]: any;
                        id?: string | undefined;
                        createdAt?: Date | undefined;
                        updatedAt?: Date | undefined;
                        value?: string | undefined;
                        expiresAt?: Date | undefined;
                        identifier?: string | undefined;
                    };
                }>;
                after?: (verification: import("better-auth").Verification & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
            delete?: {
                before?: (verification: import("better-auth").Verification & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<boolean | void>;
                after?: (verification: import("better-auth").Verification & Record<string, unknown>, context: import("better-auth").GenericEndpointContext | null) => Promise<void>;
            };
        };
    } | undefined;
    disabledPaths?: string[] | undefined;
    telemetry?: {
        enabled?: boolean;
        debug?: boolean;
    } | undefined;
    experimental?: {
        joins?: boolean;
    };
}>;
export type AppkitAuth = ReturnType<typeof createAppkitAuth>;
/** Lazy singleton pattern used by server runtimes that must import safely at build time. */
export declare function createLazyAuth(factory: () => AppkitAuth): () => AppkitAuth;
export {};
//# sourceMappingURL=server.d.ts.map