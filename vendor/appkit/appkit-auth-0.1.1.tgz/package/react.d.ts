import { type ReactNode } from 'react';
export type AuthFormLabels = Partial<{
    passwordMode: string;
    magicLinkMode: string;
    email: string;
    password: string;
    forgotPassword: string;
    signIn: string;
    sendMagicLink: string;
    signingIn: string;
    magicLinkSent: string;
    invalidCredentials: string;
    requestReset: string;
    requestingReset: string;
    resetSent: string;
    newPassword: string;
    confirmPassword: string;
    showPassword: string;
    hidePassword: string;
    updatePassword: string;
    updatingPassword: string;
    passwordTooShort: string;
    passwordsDoNotMatch: string;
    invalidResetLink: string;
}>;
export type SignInFormProps = {
    signInWithPassword: (input: {
        email: string;
        password: string;
    }) => Promise<{
        error?: string | null;
    }>;
    signInWithMagicLink: (input: {
        email: string;
        callbackURL: string;
    }) => Promise<{
        error?: string | null;
    }>;
    onSignedIn: () => void;
    callbackURL?: string;
    forgotPasswordHref?: string;
    defaultMode?: 'password' | 'magic';
    labels?: AuthFormLabels;
};
/** Source-parity password/magic-link sign-in form with app-owned navigation. */
export declare function SignInForm({ signInWithPassword, signInWithMagicLink, onSignedIn, callbackURL, forgotPasswordHref, defaultMode, labels, }: SignInFormProps): import("react").JSX.Element;
export type ForgotPasswordFormProps = {
    requestReset: (email: string) => Promise<void>;
    labels?: AuthFormLabels;
};
/** Account-enumeration-safe reset request form. */
export declare function ForgotPasswordForm({ requestReset, labels }: ForgotPasswordFormProps): import("react").JSX.Element;
export type ResetPasswordFormProps = {
    token: string;
    resetPassword: (input: {
        token: string;
        newPassword: string;
    }) => Promise<{
        error?: string | null;
    }>;
    onReset: () => void;
    minLength?: number;
    labels?: AuthFormLabels;
};
/** Token-bound reset form preserving the source validation and recovery states. */
export declare function ResetPasswordForm({ token, resetPassword, onReset, minLength, labels, }: ResetPasswordFormProps): import("react").JSX.Element;
export declare function AuthScreen({ logo, title, description, children, footer, }: {
    logo?: ReactNode;
    title: ReactNode;
    description?: ReactNode;
    children: ReactNode;
    footer?: ReactNode;
}): import("react").JSX.Element;
//# sourceMappingURL=react.d.ts.map