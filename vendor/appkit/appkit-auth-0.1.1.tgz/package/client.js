import { createAuthClient } from 'better-auth/react';
import { magicLinkClient } from 'better-auth/client/plugins';
/** React client with password, session, reset, and magic-link APIs. */
export function createAppkitAuthClient(options = {}) {
    return createAuthClient({
        ...options,
        plugins: [magicLinkClient()],
    });
}
//# sourceMappingURL=client.js.map