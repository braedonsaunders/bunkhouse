import * as React from 'react';
export type DashboardMetricTone = 'primary' | 'info' | 'success' | 'warning' | 'danger';
export type DashboardMetricCardProps = {
    label: string;
    value: React.ReactNode;
    detail?: React.ReactNode;
    icon?: React.ReactNode;
    trend?: React.ReactNode;
    tone?: DashboardMetricTone;
    className?: string;
};
/**
 * Opinionated KPI tile for fixed or configurable dashboards. The host owns the
 * metric and its data; AppKit owns the visual grammar.
 */
export declare function DashboardMetricCard({ label, value, detail, icon, trend, tone, className, }: DashboardMetricCardProps): React.JSX.Element;
export type DashboardPanelProps = {
    title?: React.ReactNode;
    icon?: React.ReactNode;
    actions?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
    bodyClassName?: string;
};
/**
 * Shared dashboard panel chrome. Omit `title` for a body-owned header while
 * retaining the same surface, border, radius, and elevation.
 */
export declare function DashboardPanel({ title, icon, actions, children, className, bodyClassName, }: DashboardPanelProps): React.JSX.Element;
//# sourceMappingURL=dashboard-primitives.d.ts.map