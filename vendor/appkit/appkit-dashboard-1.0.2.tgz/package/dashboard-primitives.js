import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from '@appkit/ui';
/**
 * Opinionated KPI tile for fixed or configurable dashboards. The host owns the
 * metric and its data; AppKit owns the visual grammar.
 */
export function DashboardMetricCard({ label, value, detail, icon, trend, tone = 'primary', className, }) {
    const tones = {
        primary: { border: 'border-l-primary', icon: 'bg-primary-subtle text-primary' },
        info: { border: 'border-l-info', icon: 'bg-info-subtle text-info' },
        success: { border: 'border-l-success', icon: 'bg-success-subtle text-success' },
        warning: { border: 'border-l-warning', icon: 'bg-warning-subtle text-warning' },
        danger: { border: 'border-l-danger', icon: 'bg-danger-subtle text-danger' },
    };
    return (_jsxs("div", { className: cn('relative h-full overflow-hidden rounded-xl border border-border border-l-4 bg-surface p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md', tones[tone].border, className), children: [_jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsxs("div", { className: "min-w-0", children: [_jsx("div", { className: "truncate text-xs font-semibold uppercase tracking-wider text-fg-subtle", children: label }), _jsx("div", { className: "mt-3 truncate text-2xl font-semibold tabular-nums text-fg", children: value }), detail ? _jsx("div", { className: "mt-1 truncate text-xs text-fg-muted", children: detail }) : null] }), icon ? (_jsx("span", { className: cn('grid size-9 shrink-0 place-items-center rounded-lg', tones[tone].icon), children: icon })) : null] }), trend ? _jsx("div", { className: "absolute bottom-3 right-4 h-7 w-20 opacity-80", children: trend }) : null] }));
}
/**
 * Shared dashboard panel chrome. Omit `title` for a body-owned header while
 * retaining the same surface, border, radius, and elevation.
 */
export function DashboardPanel({ title, icon, actions, children, className, bodyClassName, }) {
    return (_jsxs("section", { className: cn('flex h-full min-h-0 flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-sm', className), children: [title ? (_jsxs("header", { className: "flex min-h-12 shrink-0 items-center justify-between gap-3 border-b border-border px-4", children: [_jsxs("h3", { className: "flex min-w-0 items-center gap-2 truncate text-sm font-semibold text-fg", children: [icon ? _jsx("span", { className: "text-primary", children: icon }) : null, title] }), actions] })) : null, _jsx("div", { className: cn('min-h-0 flex-1 p-4', bodyClassName), children: children })] }));
}
//# sourceMappingURL=dashboard-primitives.js.map