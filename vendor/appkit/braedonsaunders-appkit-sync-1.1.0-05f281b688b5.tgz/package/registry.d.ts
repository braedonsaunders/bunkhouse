import type { Connector } from './types.js';
export declare const CONNECTORS: Connector[];
export declare function listConnectors(): Connector[];
export declare function getConnector(key: string): Connector | null;
//# sourceMappingURL=registry.d.ts.map