export type SyncOwnershipMode = 'source_wins' | 'manual_wins';
type PersonSyncDecision = 'unchanged' | 'repair' | 'conflict';
type NaturalPersonAdoptionDecision = 'adopt' | 'conflict';
export type PersonSyncState = {
    ownershipMode: SyncOwnershipMode;
    sourceChanged: boolean;
    scalarValuesMatch: boolean;
    titleValuesMatch: boolean;
    titleOwnershipMatches: boolean;
    targetChangedAfterLastSync: boolean;
};
/**
 * Decide whether a linked person is converged without relying on rowHash
 * alone. The source hash says whether the source changed; the value and
 * provenance checks say whether the canonical target still represents it.
 */
export declare function decidePersonSync(state: PersonSyncState): PersonSyncDecision;
/**
 * A natural-key match has no source ownership record yet. Source-wins may
 * adopt it, while manual-wins may only claim a row whose visible source-owned
 * values already agree. This prevents the first sync from silently replacing
 * manually maintained identity data.
 */
export declare function decideNaturalPersonAdoption(state: Pick<PersonSyncState, 'ownershipMode' | 'scalarValuesMatch' | 'titleValuesMatch'>): NaturalPersonAdoptionDecision;
export {};
//# sourceMappingURL=person-sync-policy.d.ts.map