export function toConnectorSummary(connector) {
    return {
        key: connector.key,
        name: connector.name,
        description: connector.description,
        kind: connector.kind,
        iconKey: connector.iconKey,
        entities: connector.entities,
        configFields: connector.configFields ?? [],
        secretFields: connector.secretFields ?? [],
        supportsIntrospection: connector.supportsIntrospection ?? false,
        supportsPush: Boolean(connector.push),
        supportsConnect: connector.supportsConnect ?? false,
    };
}
export function createConnectorRegistry(connectors) {
    const map = new Map();
    for (const connector of connectors) {
        if (map.has(connector.key))
            throw new Error(`Duplicate sync connector: ${connector.key}`);
        map.set(connector.key, connector);
    }
    return {
        get(key) {
            return map.get(key);
        },
        require(key) {
            const connector = map.get(key);
            if (!connector)
                throw new Error(`Unknown sync connector: ${key}`);
            return connector;
        },
        list() {
            return [...map.values()];
        },
        summaries() {
            return [...map.values()].map(toConnectorSummary);
        },
    };
}
//# sourceMappingURL=types.js.map