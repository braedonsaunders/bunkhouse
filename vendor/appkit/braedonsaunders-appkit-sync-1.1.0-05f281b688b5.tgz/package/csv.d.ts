export type CsvParsed = {
    headers: string[];
    rows: Record<string, string>[];
};
export declare function parseCsv(text: string, delimiter?: string): CsvParsed;
//# sourceMappingURL=csv.d.ts.map