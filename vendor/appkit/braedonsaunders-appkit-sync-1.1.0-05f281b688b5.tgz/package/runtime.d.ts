import type { SyncOwnershipMode } from './person-sync-policy.js';
import type { ResolvedSecrets, SyncConnector, SyncEntityKey, SyncEntityStat, SyncLogger, SyncRecord, SyncRecordAction, SyncRecordDiff, SyncRunLogLine, SyncRunStatus, SyncRunTrigger } from './types.js';
type JsonRecord = Record<string, unknown>;
export type SyncConnectionRecord = {
    id: string;
    tenantId: string;
    connectorKey: string;
    name?: string;
    status?: 'draft' | 'connected' | 'error' | 'disabled';
    enabled?: boolean;
    config: Record<string, unknown>;
    secrets: Record<string, unknown>;
    cursor: Record<string, unknown>;
    lastRunId?: string | null;
    lastRunAt?: Date | null;
    lastStatus?: SyncRunStatus | null;
    lastError?: string | null;
};
export type SyncRun = {
    id: string;
    tenantId: string;
    connectionId: string;
    trigger: SyncRunTrigger;
    dryRun: boolean;
    status: SyncRunStatus;
    startedAt: Date;
    completedAt: Date | null;
    durationMs: number | null;
    stats: Record<string, SyncEntityStat>;
    cursorBefore: Record<string, unknown>;
    cursorAfter: Record<string, unknown>;
    error: string | null;
    log: SyncRunLogLine[];
};
export type SyncRecordChange = {
    id?: string;
    tenantId: string;
    connectionId: string;
    runId: string;
    entity: SyncEntityKey;
    externalId: string;
    canonicalId: string | null;
    action: SyncRecordAction;
    dryRun: boolean;
    rowHash: string | null;
    before: JsonRecord | null;
    after: JsonRecord | null;
    diff: SyncRecordDiff | null;
    message: string | null;
    createdAt?: Date;
};
export type SyncApplyResult = {
    action: Exclude<SyncRecordAction, 'failed' | 'archived'>;
    canonicalId?: string;
    rowHash?: string;
    before?: JsonRecord | null;
    after?: JsonRecord | null;
    diff?: SyncRecordDiff | null;
    message?: string;
};
export type SyncArchiveResult = {
    externalId: string;
    action: 'archived';
    canonicalId: string;
    rowHash?: string;
    before: JsonRecord;
    after: JsonRecord;
    diff: SyncRecordDiff;
    message: string;
};
export type SyncTargetContext<TPrepared = unknown> = {
    tenantId: string;
    connectionId: string;
    sourceSystem: string;
    dryRun: boolean;
    ownershipMode: SyncOwnershipMode;
    prepared: TPrepared;
    log: SyncLogger;
};
export interface SyncTarget<TTransaction = unknown, TPrepared = unknown> {
    prepare?(transaction: TTransaction, context: Omit<SyncTargetContext<TPrepared>, 'prepared'>): Promise<TPrepared>;
    apply(transaction: TTransaction, record: SyncRecord, context: SyncTargetContext<TPrepared>): Promise<SyncApplyResult>;
    archiveMissing?(transaction: TTransaction, entity: SyncEntityKey, seenExternalIds: ReadonlySet<string>, context: SyncTargetContext<TPrepared>): Promise<SyncArchiveResult[]>;
    canArchive?(entity: SyncEntityKey): boolean;
}
export type SyncRunStart = Pick<SyncRun, 'tenantId' | 'connectionId' | 'trigger' | 'dryRun' | 'startedAt' | 'cursorBefore' | 'cursorAfter'>;
export type SyncRunFinalization = {
    run: SyncRun;
    connection: {
        status: 'connected' | 'error';
        lastError: string | null;
        updateLastRun: boolean;
        cursor: Record<string, unknown>;
        lastRunId: string | null;
        lastRunAt: Date;
        lastStatus: SyncRunStatus;
    };
};
export interface SyncPersistence<TTransaction = unknown> {
    loadConnection(input: {
        tenantId: string;
        connectionId: string;
    }): Promise<SyncConnectionRecord | null>;
    createRun(input: SyncRunStart): Promise<string>;
    transaction<T>(tenantId: string, operation: (transaction: TTransaction) => Promise<T>): Promise<T>;
    savepoint<T>(transaction: TTransaction, operation: (transaction: TTransaction) => Promise<T>): Promise<T>;
    recordChange(transaction: TTransaction, change: Omit<SyncRecordChange, 'id' | 'createdAt'>): Promise<void>;
    finalize(input: SyncRunFinalization): Promise<void>;
}
export type SyncConnectorRegistry = {
    get(key: string): SyncConnector | null | undefined;
};
export type SyncRuntimeDependencies<TTransaction = unknown, TPrepared = unknown> = {
    connectors: SyncConnectorRegistry;
    persistence: SyncPersistence<TTransaction>;
    target: SyncTarget<TTransaction, TPrepared>;
    resolveSecrets?: (secrets: Readonly<Record<string, unknown>>, connection: SyncConnectionRecord) => Promise<ResolvedSecrets> | ResolvedSecrets;
    batchSize?: number;
    maxRecords?: number;
    now?: () => Date;
};
export interface RunSyncArgs {
    tenantId: string;
    connectionId: string;
    trigger: SyncRunTrigger;
    dryRun?: boolean;
}
export interface RunSyncResult {
    runId: string | null;
    status: SyncRunStatus;
    stats: Record<string, SyncEntityStat>;
    error: string | null;
    run: SyncRun | null;
}
export type RunSyncOptions<TTransaction = unknown, TPrepared = unknown> = RunSyncArgs & SyncRuntimeDependencies<TTransaction, TPrepared>;
export declare function createSyncOrchestrator<TTransaction, TPrepared>(dependencies: SyncRuntimeDependencies<TTransaction, TPrepared>): (args: RunSyncArgs) => Promise<RunSyncResult>;
export declare function runSync<TTransaction, TPrepared>(options: RunSyncOptions<TTransaction, TPrepared>): Promise<RunSyncResult>;
export type MemorySyncTransaction = {
    changes: SyncRecordChange[];
    records: Map<string, JsonRecord>;
};
export type MemorySyncPersistence = SyncPersistence<MemorySyncTransaction> & {
    connections: SyncConnectionRecord[];
    runs: SyncRun[];
    changes: SyncRecordChange[];
    records: Map<string, JsonRecord>;
};
export declare function createMemorySyncPersistence(initialConnections?: readonly SyncConnectionRecord[]): MemorySyncPersistence;
export declare function createMemorySyncTarget(keyOf?: (record: SyncRecord) => string): SyncTarget<MemorySyncTransaction, undefined>;
export { planSnapshotArchives } from './snapshot-policy.js';
//# sourceMappingURL=runtime.d.ts.map