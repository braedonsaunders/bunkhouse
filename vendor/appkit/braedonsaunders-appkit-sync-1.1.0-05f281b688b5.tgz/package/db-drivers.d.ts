import type { IntrospectColumn, IntrospectTable } from './types.js';
export type DbKind = 'postgres' | 'mysql' | 'mariadb' | 'mssql';
export interface DbConn {
    listTables(): Promise<IntrospectTable[]>;
    listColumns(table: {
        name: string;
        schema?: string;
    }): Promise<IntrospectColumn[]>;
    query(sql: string): Promise<Record<string, unknown>[]>;
    close(): Promise<void>;
}
export interface DbConnectConfig {
    dbKind: DbKind;
    host: string;
    port?: number;
    database: string;
    username: string;
    password: string;
    ssl?: boolean;
}
export declare function connectDb(cfg: DbConnectConfig): Promise<DbConn>;
//# sourceMappingURL=db-drivers.d.ts.map