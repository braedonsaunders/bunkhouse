// The connector registry — code is the source of truth for what connectors
// exist (the admin UI reads this). Adding a connector = implement the contract
// and add it here.
import { csvConnector } from './connectors/csv.js';
import { databaseConnector } from './connectors/database.js';
import { httpJsonConnector } from './connectors/http-json.js';
import { nangoConnector } from './connectors/nango.js';
import { netsuiteConnector } from './connectors/netsuite.js';
export const CONNECTORS = [
    databaseConnector,
    httpJsonConnector,
    netsuiteConnector,
    csvConnector,
    nangoConnector,
];
export function listConnectors() {
    return CONNECTORS;
}
export function getConnector(key) {
    return CONNECTORS.find((c) => c.key === key) ?? null;
}
//# sourceMappingURL=registry.js.map