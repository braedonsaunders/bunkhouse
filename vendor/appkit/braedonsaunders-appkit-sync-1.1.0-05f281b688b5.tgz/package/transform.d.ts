export type SourceRow = Record<string, unknown>;
export declare function getPath(row: unknown, path: string | undefined | null): unknown;
/** Normalize a source date string to YYYY-MM-DD; null when unparseable. */
export declare function datePart(v: string | null): string | null;
export declare function orgLevel(value: string | null): string | undefined;
/** Finite number or null. */
export declare function numPart(v: string | null): number | null;
/** Split "Last, First" or "First Last" into first/last. */
export declare function splitName(full: string | null): {
    first: string;
    last: string;
};
/** Short stable content hash of a source row — external-id fallback. */
export declare function hashRow(o: unknown): string;
export declare function renderTemplate(template: string, row: SourceRow): string;
export declare function fieldFromPath(row: SourceRow, path: string | undefined | null): string | null;
//# sourceMappingURL=transform.d.ts.map