import type { SyncEntityKey } from './types.js';
export interface SnapshotArchivePlan {
    eligible: SyncEntityKey[];
    blockedEmpty: SyncEntityKey[];
    blockedByFailures: boolean;
    missingAuthority: boolean;
}
/**
 * Decide which entity snapshots are safe to use for missing-record archival.
 * A failed run or a zero-record entity is never authoritative enough to drive
 * destructive changes.
 */
export declare function planSnapshotArchives(authoritativeEntities: readonly SyncEntityKey[], seenCounts: Readonly<Partial<Record<SyncEntityKey, number>>>, processingFailures: number): SnapshotArchivePlan;
//# sourceMappingURL=snapshot-policy.d.ts.map