// CSV / spreadsheet connector (native). One connection targets one entity;
// columns are auto-matched to canonical fields by header name, with an optional
// explicit mapping override. No credentials — fully self-contained.
import { parseCsv } from '../csv.js';
import { datePart, hashRow, splitName } from '../transform.js';
const PEOPLE_ALIASES = {
    fullName: ['fullname', 'name', 'employeename', 'employee'],
    firstName: ['firstname', 'first', 'givenname', 'fname'],
    lastName: ['lastname', 'last', 'surname', 'familyname', 'lname'],
    employeeNo: ['employeeno', 'employeenumber', 'empno', 'employeeid', 'payrollid', 'badge'],
    externalEmployeeId: [
        'externalemployeeid',
        'externalempid',
        'sourceemployeeid',
        'employeeinternalid',
    ],
    email: ['email', 'emailaddress', 'workemail'],
    phone: ['phone', 'mobile', 'telephone', 'cell'],
    jobTitle: ['jobtitle', 'title', 'position', 'role'],
    departmentName: ['department', 'dept'],
    tradeName: ['trade', 'craft', 'classification'],
    hireDate: ['hiredate', 'startdate', 'datehired'],
};
const ORG_ALIASES = {
    name: ['name', 'sitename', 'locationname', 'location', 'projectname', 'project', 'customername'],
    code: ['code', 'sitecode', 'number', 'locationcode', 'jobnumber', 'projectcode'],
    level: ['level', 'type', 'tier'],
    parentCode: ['parentcode', 'parent', 'parentid'],
};
const EQUIP_ALIASES = {
    name: ['name', 'description', 'equipmentname', 'assetname', 'model'],
    assetTag: ['assettag', 'tag', 'assetid', 'asset', 'assetnumber', 'number', 'unit', 'unitnumber'],
    serialNumber: ['serial', 'serialnumber', 'sn'],
    typeName: ['type', 'category', 'equipmenttype', 'class'],
};
function norm(s) {
    return s.toLowerCase().replace(/[^a-z0-9]/g, '');
}
function resolveHeaders(headers, aliases, override) {
    const byNorm = new Map();
    for (const h of headers)
        byNorm.set(norm(h), h);
    const out = {};
    for (const field of Object.keys(aliases)) {
        const ov = override?.[field];
        if (ov && headers.includes(ov)) {
            out[field] = ov;
            continue;
        }
        for (const a of aliases[field] ?? []) {
            const h = byNorm.get(norm(a));
            if (h) {
                out[field] = h;
                break;
            }
        }
    }
    return out;
}
function normLevel(v) {
    if (!v)
        return undefined;
    return v.trim().toLowerCase() || undefined;
}
export const csvConnector = {
    key: 'csv',
    name: 'CSV / Spreadsheet',
    description: 'Paste or upload a CSV of people, locations or equipment. Columns are auto-matched to fields; re-importing updates existing records.',
    kind: 'native',
    iconKey: 'file-spreadsheet',
    entities: ['people', 'org_unit', 'equipment'],
    async pull(ctx) {
        const cfg = ctx.config;
        const entity = cfg.entity;
        if (!entity) {
            throw new Error('No target entity selected for the CSV connection.');
        }
        const { headers, rows } = parseCsv(cfg.csv ?? '', cfg.delimiter || ',');
        if (rows.length === 0) {
            ctx.log('warn', 'CSV has no data rows.');
            return { records: [], mode: 'full', authoritativeEntities: [entity] };
        }
        const aliases = entity === 'people' ? PEOPLE_ALIASES : entity === 'org_unit' ? ORG_ALIASES : EQUIP_ALIASES;
        const map = resolveHeaders(headers, aliases, cfg.mapping);
        ctx.log('info', `Mapped: ${Object.entries(map)
            .filter(([, v]) => v)
            .map(([k, v]) => `${k}←${v}`)
            .join(', ') || '(no columns matched)'}`);
        const idCol = cfg.idColumn && headers.includes(cfg.idColumn) ? cfg.idColumn : null;
        const get = (row, field) => {
            const h = map[field];
            if (!h)
                return null;
            const v = (row[h] ?? '').trim();
            return v === '' ? null : v;
        };
        const out = [];
        for (const row of rows) {
            const idRaw = idCol ? (row[idCol] ?? '').trim() || null : null;
            switch (entity) {
                case 'people': {
                    const fullName = get(row, 'fullName');
                    const parsed = splitName(fullName);
                    const data = {
                        fullName,
                        firstName: get(row, 'firstName') ?? parsed.first,
                        lastName: get(row, 'lastName') ?? parsed.last,
                        employeeNo: get(row, 'employeeNo'),
                        externalEmployeeId: get(row, 'externalEmployeeId'),
                        email: get(row, 'email'),
                        phone: get(row, 'phone'),
                        jobTitle: get(row, 'jobTitle'),
                        departmentName: get(row, 'departmentName'),
                        tradeName: get(row, 'tradeName'),
                        hireDate: datePart(get(row, 'hireDate')),
                    };
                    out.push({ entity: 'people', externalId: idRaw || data.employeeNo || hashRow(row), data });
                    break;
                }
                case 'org_unit': {
                    const data = {
                        name: get(row, 'name') ?? '',
                        code: get(row, 'code'),
                        level: normLevel(get(row, 'level')),
                        parentCode: get(row, 'parentCode'),
                    };
                    out.push({ entity: 'org_unit', externalId: idRaw || data.code || hashRow(row), data });
                    break;
                }
                case 'equipment': {
                    const data = {
                        name: get(row, 'name') ?? get(row, 'assetTag') ?? '',
                        assetTag: get(row, 'assetTag') ?? '',
                        serialNumber: get(row, 'serialNumber'),
                        typeName: get(row, 'typeName'),
                    };
                    out.push({
                        entity: 'equipment',
                        externalId: idRaw || data.assetTag || hashRow(row),
                        data,
                    });
                    break;
                }
            }
        }
        return { records: out, mode: 'full', authoritativeEntities: [entity] };
    },
};
//# sourceMappingURL=csv.js.map