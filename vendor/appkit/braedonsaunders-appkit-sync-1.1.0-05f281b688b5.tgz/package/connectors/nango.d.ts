import type { Connector } from '../types.js';
export declare const nangoConnector: Connector;
//# sourceMappingURL=nango.d.ts.map