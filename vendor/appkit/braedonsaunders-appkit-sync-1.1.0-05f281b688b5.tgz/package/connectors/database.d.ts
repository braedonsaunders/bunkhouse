import type { Connector } from '../types.js';
export declare const databaseConnector: Connector;
//# sourceMappingURL=database.d.ts.map