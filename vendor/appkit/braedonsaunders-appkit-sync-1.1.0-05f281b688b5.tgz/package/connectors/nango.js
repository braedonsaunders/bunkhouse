// Nango connector (provider-backed). Nango is "just another connector" — it
// brokers 400+ SaaS sources (NetSuite, QuickBooks, Xero, Workday…). Self-serve
// auth happens through Nango's Connect UI (we mint a session token here);
// records are pulled from Nango's unified /records API and mapped to canonical.
//
// Server config: NANGO_SECRET_KEY (+ optional NANGO_HOST). A per-connection
// secret key may override the env default.
import { datePart, hashRow } from '../transform.js';
import { secureFetch } from '../egress.js';
function host(ctx) {
    const cfg = ctx.config;
    const configured = cfg.host?.trim();
    if (configured && !ctx.secrets.secretKey) {
        throw new Error('A custom Nango host requires a connection-specific secret key.');
    }
    return configured || process.env.NANGO_HOST || 'https://api.nango.dev';
}
function secretKey(ctx) {
    return ctx.secrets.secretKey || process.env.NANGO_SECRET_KEY || '';
}
async function nangoFetch(ctx, path, init) {
    const key = secretKey(ctx);
    if (!key)
        throw new Error('NANGO_SECRET_KEY is not configured on the server.');
    const base = new URL(host(ctx));
    if (base.protocol !== 'https:' ||
        base.username ||
        base.password ||
        base.pathname !== '/' ||
        base.search ||
        base.hash) {
        throw new Error('Nango host must be an HTTPS origin without credentials, a path, or a query.');
    }
    const url = new URL(path, `${base.origin}/`);
    const res = await secureFetch(url, {
        method: init?.method ?? 'GET',
        body: init?.body,
        headers: {
            Authorization: `Bearer ${key}`,
            'Content-Type': 'application/json',
            ...(init?.headers ?? {}),
        },
        timeoutMs: 15_000,
        maxResponseBytes: 8 * 1024 * 1024,
        maxRedirects: 1,
    });
    if (!res.ok) {
        const t = await res.text().catch(() => '');
        throw new Error(`Nango ${res.status}: ${t.slice(0, 300)}`);
    }
    return res;
}
function pick(rec, keys) {
    for (const k of keys) {
        const v = rec[k];
        if (v != null && v !== '')
            return typeof v === 'string' ? v : String(v);
    }
    return null;
}
function fld(rec, map, field, defaults) {
    const m = map?.[field];
    return m ? pick(rec, [m]) : pick(rec, defaults);
}
function mapNango(entity, rec, map) {
    switch (entity) {
        case 'contact':
            return null; // not mapped by this connector
        case 'people': {
            const data = {
                firstName: fld(rec, map, 'firstName', ['first_name', 'firstName', 'givenName', 'first']) ?? '',
                lastName: fld(rec, map, 'lastName', ['last_name', 'lastName', 'familyName', 'surname', 'last']) ??
                    '',
                employeeNo: fld(rec, map, 'employeeNo', [
                    'employee_number',
                    'employeeNumber',
                    'employee_id',
                    'number',
                ]),
                externalEmployeeId: fld(rec, map, 'externalEmployeeId', [
                    'external_employee_id',
                    'employee_id',
                    'worker_id',
                    'id',
                ]),
                email: fld(rec, map, 'email', ['email', 'work_email', 'workEmail']),
                phone: fld(rec, map, 'phone', ['phone', 'phone_number', 'mobile_phone']),
                jobTitle: fld(rec, map, 'jobTitle', ['title', 'job_title', 'jobTitle']),
                departmentName: fld(rec, map, 'departmentName', ['department', 'department_name']),
                hireDate: datePart(fld(rec, map, 'hireDate', ['hire_date', 'start_date', 'startDate', 'hireDate'])),
            };
            if (!data.firstName && !data.lastName)
                return null;
            const externalId = pick(rec, ['id', 'employee_id', '_nango_id']) || data.employeeNo || hashRow(rec);
            return { entity: 'people', externalId, data };
        }
        case 'org_unit': {
            const data = {
                name: fld(rec, map, 'name', ['name', 'location_name', 'site_name', 'display_name']) ?? '',
                code: fld(rec, map, 'code', ['code', 'number', 'external_id']),
            };
            if (!data.name)
                return null;
            const externalId = pick(rec, ['id', '_nango_id']) || data.code || hashRow(rec);
            return { entity: 'org_unit', externalId, data };
        }
        case 'equipment': {
            const data = {
                name: fld(rec, map, 'name', ['name', 'description', 'model']) ?? '',
                assetTag: fld(rec, map, 'assetTag', ['asset_tag', 'tag', 'serial_number', 'number']) ?? '',
                serialNumber: fld(rec, map, 'serialNumber', ['serial_number', 'serial']),
                typeName: fld(rec, map, 'typeName', ['type', 'category']),
            };
            if (!data.assetTag)
                return null;
            const externalId = pick(rec, ['id', '_nango_id']) || data.assetTag || hashRow(rec);
            return { entity: 'equipment', externalId, data };
        }
    }
    return null;
}
export const nangoConnector = {
    key: 'nango',
    name: 'Nango (400+ apps)',
    description: 'Connect SaaS sources through Nango — NetSuite, QuickBooks, Xero, Workday and more. Customers authorise their own account; records sync through your Nango project.',
    kind: 'provider',
    iconKey: 'plug-zap',
    entities: ['people', 'org_unit', 'equipment'],
    supportsConnect: true,
    configFields: [
        {
            key: 'integrationId',
            label: 'Nango integration ID',
            type: 'text',
            required: true,
            placeholder: 'netsuite',
            help: 'The integration (provider config key) configured in your Nango project.',
        },
        {
            key: 'connectionId',
            label: 'Connection ID',
            type: 'text',
            help: 'Filled in automatically after a customer authorises, or paste an existing connection ID.',
        },
        {
            key: 'host',
            label: 'Nango host',
            type: 'text',
            placeholder: 'https://api.nango.dev',
            help: 'Optional public HTTPS origin. A custom host requires its own connection-specific secret key.',
        },
    ],
    secretFields: [
        {
            key: 'secretKey',
            label: 'Nango secret key',
            help: 'Stored encrypted. Required unless a platform-wide NANGO_SECRET_KEY is configured.',
        },
    ],
    async test(ctx) {
        const cfg = ctx.config;
        if (!cfg.connectionId || !cfg.integrationId)
            return { ok: false, message: 'Not connected yet — authorise a source first.' };
        try {
            await nangoFetch(ctx, `/connection/${encodeURIComponent(cfg.connectionId)}?provider_config_key=${encodeURIComponent(cfg.integrationId)}`);
            return { ok: true, message: 'Connection is live.' };
        }
        catch (e) {
            return { ok: false, message: e instanceof Error ? e.message : String(e) };
        }
    },
    async startConnect(ctx) {
        const cfg = ctx.config;
        const body = JSON.stringify({
            end_user: { id: ctx.tenantId },
            ...(cfg.integrationId ? { allowed_integrations: [cfg.integrationId] } : {}),
        });
        const res = await nangoFetch(ctx, '/connect/sessions', { method: 'POST', body });
        const json = (await res.json());
        const token = json.data?.token;
        if (!token)
            throw new Error('Nango did not return a session token.');
        return { kind: 'nango', sessionToken: token };
    },
    async pull(ctx) {
        const cfg = ctx.config;
        const models = cfg.models ?? {};
        if (!cfg.connectionId || !cfg.integrationId) {
            throw new Error('Nango connection is not fully configured.');
        }
        const connectionId = cfg.connectionId;
        const integrationId = cfg.integrationId;
        const entities = Object.keys(models).filter((entity) => ['people', 'org_unit', 'equipment'].includes(entity));
        if (entities.length === 0)
            throw new Error('No Nango models are configured for sync.');
        const out = [];
        let truncated = false;
        for (const entity of entities) {
            const model = models[entity];
            if (!model)
                continue;
            let cursor = null;
            let page = 0;
            do {
                const url = `/records?model=${encodeURIComponent(model)}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`;
                const res = await nangoFetch(ctx, url, {
                    headers: { 'Connection-Id': connectionId, 'Provider-Config-Key': integrationId },
                });
                const json = (await res.json());
                for (const r of json.records ?? []) {
                    const rec = mapNango(entity, r, cfg.fieldMaps?.[entity]);
                    if (rec)
                        out.push(rec);
                }
                cursor = json.next_cursor ?? null;
                page++;
            } while (cursor && page < 50);
            if (cursor) {
                truncated = true;
                ctx.log('warn', `${entity}: stopped at the 50-page safety cap.`);
            }
            ctx.log('info', `${entity}: pulled from Nango model "${model}".`);
        }
        return {
            records: out,
            mode: truncated ? 'incremental' : 'full',
            authoritativeEntities: entities,
        };
    },
};
//# sourceMappingURL=nango.js.map