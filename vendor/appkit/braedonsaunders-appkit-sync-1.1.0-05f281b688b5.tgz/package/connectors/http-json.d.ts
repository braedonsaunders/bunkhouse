import type { Connector } from '../types.js';
export declare const httpJsonConnector: Connector;
//# sourceMappingURL=http-json.d.ts.map