import type { Connector } from '../types.js';
export declare const csvConnector: Connector;
//# sourceMappingURL=csv.d.ts.map