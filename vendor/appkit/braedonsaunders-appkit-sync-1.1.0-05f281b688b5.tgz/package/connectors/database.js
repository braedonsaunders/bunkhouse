// Generic SQL database connector (native). Connects to PostgreSQL / MySQL /
// MariaDB / SQL Server, can browse tables + columns live (introspection), and
// pulls rows from admin-mapped tables → canonical records. Password is the only
// secret. Incremental sync is opt-in per mapping with cursorColumn; full pulls
// remain the default and are idempotent via the crosswalk.
import { connectDb } from '../db-drivers.js';
import { datePart, hashRow, numPart, orgLevel, renderTemplate, splitName } from '../transform.js';
function cfgOf(ctx) {
    return ctx.config;
}
async function open(ctx) {
    const c = cfgOf(ctx);
    return connectDb({
        dbKind: c.dbKind,
        host: c.host,
        port: c.port,
        database: c.database,
        username: c.username,
        password: ctx.secrets.password ?? '',
        ssl: c.ssl,
    });
}
function qid(kind, name) {
    if (kind === 'mssql')
        return `[${name.replace(/]/g, ']]')}]`;
    if (kind === 'mysql' || kind === 'mariadb')
        return `\`${name.replace(/`/g, '``')}\``;
    return `"${name.replace(/"/g, '""')}"`;
}
function qpath(kind, path) {
    return path
        .split('.')
        .map((part) => qid(kind, part.trim()))
        .join('.');
}
function literal(v) {
    if (v == null)
        return 'NULL';
    if (typeof v === 'number' && Number.isFinite(v))
        return String(v);
    if (typeof v === 'boolean')
        return v ? '1' : '0';
    return `'${String(v).replace(/'/g, "''")}'`;
}
function withCursorPredicate(kind, base, m, cursor) {
    if (!m.cursorColumn?.trim() || cursor == null)
        return base;
    const pred = `${qpath(kind, m.cursorColumn.trim())} > ${literal(cursor)}`;
    if (m.query && m.query.trim())
        return `SELECT * FROM (${base}) AS appkit_src WHERE ${pred}`;
    return `${base} ${base.toLowerCase().includes(' where ') ? 'AND' : 'WHERE'} ${pred}`;
}
function buildSelect(kind, m, cursor) {
    if (m.query && m.query.trim())
        return withCursorPredicate(kind, m.query.trim(), m, cursor);
    if (!m.table)
        throw new Error('Database mapping requires either a source table or a custom query.');
    const target = m.schema ? `${qid(kind, m.schema)}.${qid(kind, m.table)}` : qid(kind, m.table);
    let q = `SELECT * FROM ${target}`;
    if (m.where && m.where.trim())
        q += ` WHERE ${m.where.trim()}`;
    return withCursorPredicate(kind, q, m, cursor);
}
function val(row, col) {
    if (!col)
        return null;
    const v = row[col];
    if (v == null)
        return null;
    if (v instanceof Date)
        return v.toISOString();
    const s = String(v);
    return s === '' ? null : s;
}
function boolish(v) {
    if (v == null)
        return null;
    const s = v.trim().toLowerCase();
    if (!s)
        return null;
    if (['1', 'true', 't', 'yes', 'y', 'active', 'on'].includes(s))
        return true;
    if (['0', 'false', 'f', 'no', 'n', 'inactive', 'off'].includes(s))
        return false;
    return null;
}
function personStatus(statusValue, inactiveValue) {
    const s = String(statusValue ?? '')
        .trim()
        .toLowerCase();
    if (['active', 'inactive', 'terminated'].includes(s)) {
        return s;
    }
    if (['term', 'terminated', 'closed'].includes(s))
        return 'terminated';
    const inactive = boolish(inactiveValue);
    if (inactive != null)
        return inactive ? 'inactive' : 'active';
    return undefined;
}
function fieldValue(row, m, field) {
    const templated = m.values?.[field];
    if (templated != null) {
        const rendered = renderTemplate(String(templated), row).trim();
        return rendered === '' ? null : rendered;
    }
    return val(row, m.columns?.[field]);
}
function cursorKey(entity, m, index) {
    const label = m.label?.trim() || m.table || m.query?.trim().slice(0, 32) || String(index + 1);
    return `${entity}:${label}`;
}
function maxCursorValue(a, b) {
    if (a == null)
        return b;
    if (b == null)
        return a;
    const an = typeof a === 'number' ? a : Number(a);
    const bn = typeof b === 'number' ? b : Number(b);
    if (Number.isFinite(an) && Number.isFinite(bn))
        return bn > an ? b : a;
    const ad = Date.parse(String(a));
    const bd = Date.parse(String(b));
    if (!Number.isNaN(ad) && !Number.isNaN(bd))
        return bd > ad ? b : a;
    return String(b) > String(a) ? b : a;
}
function cursorValue(row, m) {
    if (!m.cursorColumn?.trim())
        return undefined;
    const v = row[m.cursorColumn];
    if (v instanceof Date)
        return v.toISOString();
    return v == null || v === '' ? undefined : v;
}
function externalId(row, m, fallback) {
    if (m.externalIdTemplate?.trim()) {
        const rendered = renderTemplate(m.externalIdTemplate, row).trim();
        if (rendered)
            return rendered;
    }
    return (m.idColumn ? val(row, m.idColumn) : null) || fallback;
}
function mappingList(mappings, entity) {
    const raw = mappings?.[entity];
    if (!raw)
        return [];
    const list = Array.isArray(raw) ? raw : [raw];
    return list.filter((m) => Boolean((m.table && m.table.trim()) || (m.query && m.query.trim())));
}
function mapRow(entity, m, row) {
    const g = (f) => fieldValue(row, m, f);
    switch (entity) {
        case 'people': {
            const fullName = g('fullName');
            const parsed = splitName(fullName);
            const firstName = g('firstName') ?? parsed.first;
            const lastName = g('lastName') ?? parsed.last;
            const data = {
                fullName,
                firstName,
                lastName,
                employeeNo: g('employeeNo'),
                externalEmployeeId: g('externalEmployeeId'),
                email: g('email'),
                phone: g('phone'),
                jobTitle: g('jobTitle'),
                departmentName: g('departmentName'),
                tradeName: g('tradeName'),
                hireDate: datePart(g('hireDate')),
                status: personStatus(g('status'), g('inactive')),
            };
            if (!data.firstName && !data.lastName)
                return null;
            return {
                entity: 'people',
                externalId: externalId(row, m, data.externalEmployeeId || data.employeeNo || hashRow(row)),
                data,
            };
        }
        case 'org_unit': {
            const address = {
                line1: g('addressLine1') ?? undefined,
                line2: g('addressLine2') ?? undefined,
                city: g('addressCity') ?? undefined,
                region: g('addressRegion') ?? undefined,
                postal: g('addressPostal') ?? undefined,
                country: g('addressCountry') ?? undefined,
            };
            const data = {
                name: g('name') ?? '',
                code: g('code'),
                parentCode: g('parentCode'),
                level: orgLevel(g('level')),
                lat: numPart(g('lat')),
                lng: numPart(g('lng')),
                geofenceMeters: numPart(g('geofenceMeters')),
                address: Object.values(address).some(Boolean) ? address : null,
            };
            if (!data.name)
                return null;
            return {
                entity: 'org_unit',
                externalId: externalId(row, m, data.code || hashRow(row)),
                data,
            };
        }
        case 'equipment': {
            const data = {
                name: g('name') ?? g('assetTag') ?? '',
                assetTag: g('assetTag') ?? '',
                serialNumber: g('serialNumber'),
                typeName: g('typeName'),
            };
            if (!data.assetTag)
                return null;
            return {
                entity: 'equipment',
                externalId: externalId(row, m, data.assetTag || hashRow(row)),
                data,
            };
        }
        case 'contact': {
            const data = {
                name: g('name') ?? '',
                role: g('role'),
                email: g('email'),
                phone: g('phone'),
                notes: g('notes'),
                isPrimary: boolish(g('isPrimary')) ?? false,
                // external id of the parent location/customer — resolved to an org_unit via
                // that entity's crosswalk in the upsert. A contact whose customer isn't synced
                // is skipped there.
                customerExternalId: g('customerExternalId') ?? '',
            };
            if (!data.name || !data.customerExternalId)
                return null;
            return {
                entity: 'contact',
                externalId: externalId(row, m, hashRow(row)),
                data,
            };
        }
    }
    return null;
}
export const databaseConnector = {
    key: 'database',
    name: 'Database (SQL)',
    description: 'Connect to any SQL database — PostgreSQL, MySQL/MariaDB or SQL Server. Browse tables, map one or more source tables to People, Locations & Projects, and Equipment, then sync on a schedule.',
    kind: 'native',
    iconKey: 'database',
    entities: ['people', 'org_unit', 'equipment', 'contact'],
    supportsIntrospection: true,
    configFields: [
        {
            key: 'dbKind',
            label: 'Database type',
            type: 'select',
            required: true,
            options: [
                { value: 'postgres', label: 'PostgreSQL' },
                { value: 'mysql', label: 'MySQL' },
                { value: 'mariadb', label: 'MariaDB' },
                { value: 'mssql', label: 'SQL Server (MSSQL)' },
            ],
        },
        {
            key: 'host',
            label: 'Host',
            type: 'text',
            required: true,
            placeholder: 'db.example.com',
            help: 'Must be a public DNS name. Local, private, and IP-literal hosts are blocked.',
        },
        { key: 'port', label: 'Port', type: 'number', placeholder: '5432 / 3306 / 1433' },
        { key: 'database', label: 'Database', type: 'text', required: true },
        { key: 'username', label: 'Username', type: 'text', required: true },
        {
            key: 'ssl',
            label: 'Use SSL/TLS',
            type: 'boolean',
            required: true,
            help: 'Required. The database certificate must be valid for the host name above.',
        },
    ],
    secretFields: [{ key: 'password', label: 'Password', required: true }],
    async test(ctx) {
        let conn = null;
        try {
            conn = await open(ctx);
            await conn.query('SELECT 1');
            return { ok: true, message: 'Connected successfully.' };
        }
        catch (e) {
            return { ok: false, message: e instanceof Error ? e.message : String(e) };
        }
        finally {
            await conn?.close().catch((error) => ctx.log('warn', `Database close failed: ${error instanceof Error ? error.message : String(error)}`));
        }
    },
    async introspect(ctx) {
        const conn = await open(ctx);
        try {
            return { tables: await conn.listTables() };
        }
        finally {
            await conn.close().catch((error) => ctx.log('warn', `Database close failed: ${error instanceof Error ? error.message : String(error)}`));
        }
    },
    async introspectTable(ctx, table) {
        const conn = await open(ctx);
        try {
            return { columns: await conn.listColumns(table) };
        }
        finally {
            await conn.close().catch((error) => ctx.log('warn', `Database close failed: ${error instanceof Error ? error.message : String(error)}`));
        }
    },
    async pull(ctx) {
        const c = cfgOf(ctx);
        const mappings = c.mappings ?? {};
        const entities = ['people', 'org_unit', 'equipment', 'contact'].filter((e) => mappingList(mappings, e).length > 0);
        if (entities.length === 0) {
            throw new Error('No table mappings configured.');
        }
        const conn = await open(ctx);
        const out = [];
        const nextCursor = { ...(ctx.since ?? {}) };
        let hasCursorMapping = false;
        let usedCursor = false;
        try {
            for (const entity of entities) {
                const entityMappings = mappingList(mappings, entity);
                for (let index = 0; index < entityMappings.length; index++) {
                    const m = entityMappings[index];
                    const key = cursorKey(entity, m, index);
                    const priorCursor = m.cursorColumn?.trim() ? ctx.since?.[key] : undefined;
                    if (m.cursorColumn?.trim())
                        hasCursorMapping = true;
                    if (priorCursor != null)
                        usedCursor = true;
                    const q = buildSelect(c.dbKind, m, priorCursor);
                    const label = m.label?.trim() || m.table || 'custom query';
                    ctx.log('info', `${entity}/${label}: ${q}`);
                    const rows = await conn.query(q);
                    ctx.log('info', `${entity}/${label}: ${rows.length} row(s)`);
                    for (const row of rows) {
                        const rec = mapRow(entity, m, row);
                        if (rec)
                            out.push(rec);
                        const cv = cursorValue(row, m);
                        if (cv != null)
                            nextCursor[key] = maxCursorValue(nextCursor[key], cv);
                    }
                }
            }
        }
        finally {
            await conn.close().catch((error) => ctx.log('warn', `Database close failed: ${error instanceof Error ? error.message : String(error)}`));
        }
        return {
            records: out,
            nextCursor: hasCursorMapping ? nextCursor : undefined,
            mode: hasCursorMapping && usedCursor ? 'incremental' : 'full',
            authoritativeEntities: entities,
        };
    },
};
//# sourceMappingURL=database.js.map