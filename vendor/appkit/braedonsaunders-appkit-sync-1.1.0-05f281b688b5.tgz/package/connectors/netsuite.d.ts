import type { Connector } from '../types.js';
export declare const netsuiteConnector: Connector;
//# sourceMappingURL=netsuite.d.ts.map