import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { SyncPersistence } from './runtime.js';
type Db = NodePgDatabase<Record<string, never>>;
type TransactionCallback = Parameters<Db['transaction']>[0];
export type SyncDrizzleTransaction = Parameters<TransactionCallback>[0];
export type SyncTenantRunner = <T>(tenantId: string, operation: () => Promise<T>) => Promise<T>;
export declare function createDrizzleSyncPersistence(db: Db, withTenant: SyncTenantRunner): SyncPersistence<SyncDrizzleTransaction>;
export { syncConnections, syncCrosswalk, syncRecordChanges, syncRuns, SYNC_TENANT_TABLES, } from './schema.js';
//# sourceMappingURL=drizzle.d.ts.map