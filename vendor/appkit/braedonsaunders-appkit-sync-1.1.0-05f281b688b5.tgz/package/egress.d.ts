import type { LookupAddress } from 'node:dns';
export interface ResolvedPublicHost {
    hostname: string;
    address: string;
    family: 4 | 6;
    ipLiteral: boolean;
}
export type OutboundDnsResolver = (hostname: string) => Promise<readonly LookupAddress[]>;
export interface ResolvePublicHostOptions {
    timeoutMs?: number;
    resolver?: OutboundDnsResolver;
    signal?: AbortSignal;
}
export interface SecureFetchOptions {
    method?: 'GET' | 'HEAD' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
    headers?: Headers | Record<string, string>;
    body?: string | Uint8Array | ArrayBuffer | URLSearchParams | null;
    timeoutMs?: number;
    maxRequestBytes?: number;
    maxResponseBytes?: number;
    maxRedirects?: number;
    signal?: AbortSignal;
    /** Optional resolver for controlled runtimes and tests. Every answer is still subject to the public-IP policy. */
    resolver?: OutboundDnsResolver;
}
export interface ValidatedOutboundRequestConfiguration {
    url: URL;
    headers: Record<string, string>;
}
export declare function normalizeOutboundHostname(raw: string): string;
export declare function isPublicIpAddress(raw: string): boolean;
export declare function resolvePublicHost(rawHostname: string, options?: ResolvePublicHostOptions): Promise<ResolvedPublicHost>;
/**
 * Validate the non-network portion of an outbound request configuration.
 *
 * This is shared by persistence boundaries that need to reject malformed or
 * unsafe configuration before it is stored. Runtime callers must still use
 * `secureFetch`, which repeats these checks and validates DNS immediately
 * before opening every socket.
 */
export declare function validateOutboundRequestConfiguration(input: string | URL, headers?: Headers | Record<string, string>): ValidatedOutboundRequestConfiguration;
/** Parse an outbound redirect without allowing an origin change; the fetch loop rechecks DNS next. */
export declare function resolveOutboundRedirect(current: URL, location: string): URL;
/**
 * Make a bounded HTTPS request to a public host.
 *
 * Every redirect is resolved and validated again. The socket connects directly
 * to the selected DNS answer while TLS/SNI is verified against the original
 * hostname, closing the validation-to-connect DNS-rebinding gap.
 */
export declare function secureFetch(input: string | URL, options?: SecureFetchOptions): Promise<Response>;
//# sourceMappingURL=egress.d.ts.map