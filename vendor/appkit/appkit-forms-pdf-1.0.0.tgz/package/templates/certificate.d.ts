import { type CredentialDesignOptions } from './credential-theme.js';
export type CertificateRenderInput = {
    tenantName: string;
    tenantLogoUrl?: string;
    primaryColor?: string;
    variant?: 'completion' | 'qualification';
    recipient: {
        fullName: string;
        employeeNo?: string | null;
    };
    credential: {
        name: string;
        code?: string | null;
    };
    authorityName?: string | null;
    completedOn: string;
    expiresOn?: string | null;
    instructor?: string | null;
    grade?: number | null;
    verifyUrl?: string;
    verifyToken?: string;
    qrDataUrl?: string;
    certificateId?: string;
    generatedAt?: string | Date;
    design?: CredentialDesignOptions;
};
export declare function renderCertificateHtml(input: CertificateRenderInput): string;
//# sourceMappingURL=certificate.d.ts.map