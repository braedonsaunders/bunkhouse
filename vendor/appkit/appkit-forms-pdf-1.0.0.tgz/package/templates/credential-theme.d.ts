export declare function esc(s: string | number | null | undefined): string;
export type CredentialDesignFormat = 'letter-landscape' | 'letter-portrait' | 'wallet';
export type CredentialDesignTemplateId = 'sovereign-seal' | 'field-pass' | 'clean-authority';
export type CredentialDesignTypeface = 'classic' | 'modern' | 'technical';
export type CredentialDesignOptions = {
    format?: CredentialDesignFormat;
    templateId?: CredentialDesignTemplateId;
    primary?: string;
    accent?: string;
    paper?: string;
    typeface?: CredentialDesignTypeface;
    patternStrength?: number;
    showPhoto?: boolean;
    showQr?: boolean;
    showSeal?: boolean;
};
type NormalizedCredentialDesignOptions = Required<CredentialDesignOptions>;
export declare function normalizeCredentialDesignOptions(input: CredentialDesignOptions | null | undefined, primaryFallback?: string): NormalizedCredentialDesignOptions;
export declare function patternOpacity(strength: number, max?: number): number;
export declare function mix(hex: string, target: string, ratio: number): string;
export declare const shade: (hex: string, ratio: number) => string;
export declare const tint: (hex: string, ratio: number) => string;
export declare function rgba(hex: string, alpha: number): string;
export declare function formatDateLong(d: string | Date): string;
export declare function formatDateShort(d: string | Date): string;
export declare function initialsOf(fullName: string, max?: number): string;
export declare const GOLD: {
    light: string;
    mid: string;
    deep: string;
    shadow: string;
};
export declare function ringLattice(strokeHex: string, opacity: number): string;
export declare function sealSvg(args: {
    initials: string;
    ribbon: string;
    inscription?: string;
    size: number;
    showRibbons?: boolean;
}): string;
export {};
//# sourceMappingURL=credential-theme.d.ts.map