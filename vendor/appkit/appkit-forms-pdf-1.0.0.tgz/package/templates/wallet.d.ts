import { type CredentialDesignOptions } from './credential-theme.js';
export type WalletRenderInput = {
    tenantName: string;
    tenantLogoUrl?: string;
    primaryColor?: string;
    variant?: 'completion' | 'qualification';
    recipient: {
        fullName: string;
        employeeNo?: string | null;
        photoUrl?: string | null;
    };
    credential: {
        name: string;
        code?: string | null;
    };
    authorityName?: string | null;
    completedOn: string;
    expiresOn?: string | null;
    verifyUrl?: string;
    verifyToken?: string;
    qrDataUrl?: string;
    cardId?: string;
    design?: CredentialDesignOptions;
};
export declare function renderWalletHtml(input: WalletRenderInput): string;
//# sourceMappingURL=wallet.d.ts.map