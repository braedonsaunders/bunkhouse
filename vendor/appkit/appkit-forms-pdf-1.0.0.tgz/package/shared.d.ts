export declare function escapeHtml(value: string): string;
//# sourceMappingURL=shared.d.ts.map