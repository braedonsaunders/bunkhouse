import { type CredentialDesignData, type DesignDocument, type DesignDocumentData, type EquipmentLabelDesignData } from '@appkit/design-studio';
import { type ReportDocumentInput, type ReportLayoutConfig } from '@appkit/reports/document';
import { type CertificateRenderInput } from './templates/certificate.js';
import { type WalletRenderInput } from './templates/wallet.js';
import type { CredentialDesignFormat, CredentialDesignOptions, CredentialDesignTemplateId, CredentialDesignTypeface } from './templates/credential-theme.js';
export type { CertificateRenderInput, WalletRenderInput, CredentialDesignFormat, CredentialDesignOptions, CredentialDesignTemplateId, CredentialDesignTypeface, CredentialDesignData, DesignDocument, DesignDocumentData, EquipmentLabelDesignData, };
export declare function renderDesignDocumentPdf(input: {
    document: DesignDocument;
    data: DesignDocumentData;
    title?: string;
}): Promise<Buffer>;
/** Render each design artboard as a full-bleed PNG for physical-card bridges. */
export declare function renderDesignDocumentPngs(input: {
    document: DesignDocument;
    data: DesignDocumentData;
    dpi?: number;
}): Promise<Buffer[]>;
/**
 * N design documents printed back-to-back as ONE multi-page PDF — one page per
 * artboard, each rendered against its own data (bulk label runs). All pages
 * print at the FIRST artboard's physical size, so callers pass a uniform run.
 */
export declare function renderDesignDocumentsPdf(pages: {
    document: DesignDocument;
    data: DesignDocumentData;
}[], options?: {
    title?: string;
}): Promise<Buffer>;
export declare function renderCertificatePagePdf(input: CertificateRenderInput): Promise<Buffer>;
export declare function renderWalletCardPdf(input: WalletRenderInput): Promise<Buffer>;
export declare function renderReportPdf(input: ReportDocumentInput & {
    layout?: Partial<ReportLayoutConfig> | null;
}): Promise<Buffer>;
export declare function renderHtmlDocumentPdf(input: {
    bodyHtml: string;
    paperSize: 'letter' | 'a4' | 'legal';
    orientation: 'portrait' | 'landscape';
    marginMm: number;
    headerHtml?: string | null;
    footerHtml?: string | null;
}): Promise<Buffer>;
export type RecordSummaryRenderInput = {
    tenantName: string;
    heading: string;
    reference?: string | null;
    subtitle?: string | null;
    fields: {
        label: string;
        value: string;
    }[];
    sections?: {
        label: string;
        columns: {
            key: string;
            label: string;
        }[];
        rows: Record<string, string>[];
        moreRows?: number;
    }[];
    photos?: {
        url: string;
        caption?: string;
    }[];
};
export declare function renderRecordSummaryPdf(input: RecordSummaryRenderInput): Promise<Buffer>;
//# sourceMappingURL=production.d.ts.map