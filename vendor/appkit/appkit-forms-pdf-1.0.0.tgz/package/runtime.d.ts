import { type Browser, type Page } from 'puppeteer-core';
export type PdfRuntimeConfig = {
    appOrigin?: string;
    storageOrigin?: string;
    executablePath?: string;
};
export declare function configurePdfRuntime(config: PdfRuntimeConfig): void;
type PdfResourceDecision = 'local' | 'app' | 'storage' | 'proxy' | 'block';
export declare function pdfResourceDecision(rawUrl: string, resourceType: string, method: string, storageOrigin?: string, appOrigin?: string): PdfResourceDecision;
export declare function getBrowser(): Promise<Browser>;
export declare function closePdfBrowser(): Promise<void>;
export declare function newPdfPage(browser: Browser): Promise<Page>;
export declare function setPdfContent(page: Page, html: string, options?: {
    waitForFonts?: boolean;
}): Promise<void>;
/** Insert the application base URL after the first real `<head>` opening tag. */
export declare function injectPdfBase(html: string, appOrigin: string): string;
export declare function escapeHtml(s: string): string;
export {};
//# sourceMappingURL=runtime.d.ts.map