import type { FormPdfInput } from './types.js';
export declare function renderFormSummaryHtml(input: FormPdfInput): string;
//# sourceMappingURL=summary-html.d.ts.map