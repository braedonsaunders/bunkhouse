import type { FormPdfInput } from './types.js';
export { renderFormSummaryHtml } from './summary-html.js';
export type { FormPdfField, FormPdfSection, FormPdfPhoto, FormPdfInput } from './types.js';
export declare function renderFormSummaryPdf(input: FormPdfInput): Promise<Buffer>;
//# sourceMappingURL=summary.d.ts.map