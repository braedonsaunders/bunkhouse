import { renderHtmlDocumentPdf } from '@appkit/pdf/html';
import { escapeHtml } from './shared.js';
import { renderFormSummaryHtml } from './summary-html.js';
export { renderFormSummaryHtml } from './summary-html.js';
export async function renderFormSummaryPdf(input) {
    return renderHtmlDocumentPdf({
        bodyHtml: renderFormSummaryHtml(input),
        paperSize: input.page?.paperSize ?? 'letter',
        orientation: input.page?.orientation ?? 'portrait',
        marginMm: input.page?.marginMm ?? 15,
        footerHtml: `${escapeHtml(input.tenantName)} · {{page}} / {{pages}}`,
    });
}
//# sourceMappingURL=summary.js.map