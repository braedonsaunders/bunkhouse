import type { AuthoredFormPdfInput } from './types.js';
export type { AuthoredFormPdfInput } from './types.js';
export declare function compileAuthoredFormPdf(input: AuthoredFormPdfInput): string;
export declare function renderAuthoredFormPdf(input: AuthoredFormPdfInput): Promise<Buffer>;
//# sourceMappingURL=template.d.ts.map