# @appkit/forms-pdf

Composable form-summary HTML with optional PDF, template, and design-document adapters.

## Install

```bash
pnpm add @appkit/forms-pdf
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
