import { type DesignData, type DesignDocument } from '@appkit/design-studio';
export declare function renderDesignDocumentPdf(input: {
    document: DesignDocument;
    data: DesignData;
    title?: string;
}): Promise<Buffer>;
export declare function renderDesignDocumentsPdf(pages: {
    document: DesignDocument;
    data: DesignData;
}[], title?: string): Promise<Buffer>;
//# sourceMappingURL=design.d.ts.map