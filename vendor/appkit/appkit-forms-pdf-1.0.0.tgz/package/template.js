import { renderHtmlDocumentPdf } from '@appkit/pdf/html';
import { compileTemplateHtml, renderTemplate } from '@appkit/pdf/template';
export function compileAuthoredFormPdf(input) {
    const { compiledHtml } = compileTemplateHtml(input.sourceHtml);
    return renderTemplate(compiledHtml, input.values, {
        escapeHtml: true,
        allowRawValues: input.allowRawValues ?? false,
    });
}
export async function renderAuthoredFormPdf(input) {
    return renderHtmlDocumentPdf({
        bodyHtml: compileAuthoredFormPdf(input),
        paperSize: input.paperSize ?? 'letter',
        orientation: input.orientation ?? 'portrait',
        marginMm: input.marginMm ?? 15,
        headerHtml: input.headerHtml,
        footerHtml: input.footerHtml,
    });
}
//# sourceMappingURL=template.js.map