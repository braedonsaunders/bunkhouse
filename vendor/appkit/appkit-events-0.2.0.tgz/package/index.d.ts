import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import { type DomainEventPayload } from './relay.js';
export * from './relay.js';
export * from './recipients.js';
type Db = NodePgDatabase<Record<string, never>>;
export type AuditAction = 'create' | 'update' | 'delete' | 'sign' | 'publish' | 'archive' | 'invite' | 'login' | 'logout' | 'export' | 'copy' | 'send' | 'view_sensitive' | 'impersonate' | 'impersonate_stop';
export type AuditEvent = {
    tenantId: string;
    actorUserId?: string | null;
    actorIp?: string | null;
    actorUserAgent?: string | null;
    entityType: string;
    entityId?: string;
    action: AuditAction;
    summary?: string;
    before?: Record<string, unknown> | null;
    after?: Record<string, unknown> | null;
    metadata?: Record<string, unknown>;
};
export declare function audit(db: Db, evt: AuditEvent): Promise<void>;
/** Shallow diff of two JSON-serialisable objects → { added, removed, changed }. */
export declare function diff<T extends Record<string, unknown>>(before: T | null | undefined, after: T | null | undefined): {
    added: Record<string, unknown>;
    removed: Record<string, unknown>;
    changed: Record<string, {
        before: unknown;
        after: unknown;
    }>;
};
export type RecordDomainEventInput = {
    tenantId: string;
    eventType: string;
    subjectId: string;
    dedupKey: string;
    payload: DomainEventPayload;
};
/** Every event needs a type + a stable dedup key. */
export declare function assertDomainEvent(input: RecordDomainEventInput): void;
/**
 * Write an event to the outbox in the SAME transaction as its domain mutation.
 * Idempotent on (tenant_id, dedup_key): a re-run with the same identity returns
 * the existing id; a dedup-key collision with a *different* event throws.
 */
export declare function recordDomainEvent(tx: Db, input: RecordDomainEventInput): Promise<string>;
//# sourceMappingURL=index.d.ts.map