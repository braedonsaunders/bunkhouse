export function createRecipientResolver(directory, options = {}) {
    const fallbackRoleKeys = [...(options.fallbackRoleKeys ?? ['tenant_admin'])];
    async function resolveUserIds(tenantId, category, extraUserIds = []) {
        const policy = await directory.loadAudiencePolicy(tenantId, category);
        if (policy?.enabled === false)
            return [];
        const candidates = new Set([...extraUserIds, ...(policy?.userIds ?? [])].filter(Boolean));
        if (policy?.groupIds.length) {
            for (const userId of await directory.resolveGroupUserIds(tenantId, policy.groupIds)) {
                candidates.add(userId);
            }
        }
        const roleKeys = policy
            ? policy.roleKeys
            : [...(options.defaultRolesByCategory?.[category] ?? fallbackRoleKeys)];
        if (roleKeys.length) {
            for (const userId of await directory.resolveRoleUserIds(tenantId, roleKeys)) {
                candidates.add(userId);
            }
        }
        if (candidates.size === 0)
            return [];
        return [...new Set(await directory.filterActiveUserIds(tenantId, [...candidates]))];
    }
    async function resolveEmails(tenantId, category, extraUserIds = []) {
        const userIds = await resolveUserIds(tenantId, category, extraUserIds);
        if (userIds.length === 0)
            return [];
        return [...new Set((await directory.emailsForUserIds(tenantId, userIds))
                .map((email) => email.trim().toLowerCase())
                .filter((email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)))];
    }
    return { resolveUserIds, resolveEmails };
}
//# sourceMappingURL=recipients.js.map