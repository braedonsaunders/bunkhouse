import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
type Db = NodePgDatabase<Record<string, never>>;
export type DomainEventPayload = {
    effects: Record<string, unknown>;
    data?: Record<string, unknown>;
};
export type DomainEventEnvelope = {
    id: string;
    tenantId: string;
    eventType: string;
    subjectId: string;
    dedupKey: string;
    payload: DomainEventPayload;
    attempts: number;
    createdAt: Date;
};
export type DomainEventEffectContext = {
    event: DomainEventEnvelope;
    effectKey: string;
    input: unknown;
    /** Stable across every retry; pass it to downstream idempotency APIs. */
    idempotencyKey: string;
};
export type DomainEventEffectHandler = (context: DomainEventEffectContext) => Promise<Record<string, unknown> | void>;
export type DomainEventRelayOptions = {
    db: Db;
    handlers: Record<string, DomainEventEffectHandler>;
    batchSize?: number;
    concurrency?: number;
    claimTimeoutMs?: number;
    retryAt?: (attempts: number, now: Date) => Date;
};
export type DomainEventRelayResult = {
    claimed: number;
    published: number;
    retried: number;
};
export declare const DOMAIN_EVENT_RELAY_DEFAULTS: {
    readonly batchSize: 20;
    readonly concurrency: 5;
    readonly claimTimeoutMs: number;
};
/** Retry forever: a transient outage must never turn a committed event into lost work. */
export declare function domainEventRetryAt(attempts: number, now: Date): Date;
export declare function assertDomainEventPayload(value: unknown): asserts value is DomainEventPayload;
export declare function createDomainEventRelay(options: DomainEventRelayOptions): (now?: Date) => Promise<DomainEventRelayResult>;
export {};
//# sourceMappingURL=relay.d.ts.map