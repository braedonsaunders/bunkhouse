export type NotificationAudiencePolicy = {
    enabled: boolean;
    userIds: string[];
    groupIds: string[];
    roleKeys: string[];
};
export type RecipientDirectory = {
    loadAudiencePolicy: (tenantId: string, category: string) => Promise<NotificationAudiencePolicy | null>;
    resolveGroupUserIds: (tenantId: string, groupIds: string[]) => Promise<string[]>;
    resolveRoleUserIds: (tenantId: string, roleKeys: string[]) => Promise<string[]>;
    filterActiveUserIds: (tenantId: string, userIds: string[]) => Promise<string[]>;
    emailsForUserIds: (tenantId: string, userIds: string[]) => Promise<string[]>;
};
export type RecipientResolverOptions = {
    defaultRolesByCategory?: Readonly<Record<string, readonly string[]>>;
    fallbackRoleKeys?: readonly string[];
};
export declare function createRecipientResolver(directory: RecipientDirectory, options?: RecipientResolverOptions): {
    resolveUserIds: (tenantId: string, category: string, extraUserIds?: string[]) => Promise<string[]>;
    resolveEmails: (tenantId: string, category: string, extraUserIds?: string[]) => Promise<string[]>;
};
//# sourceMappingURL=recipients.d.ts.map