export type DomainEventRequestSignerOptions = {
    maxClockSkewMs?: number;
    keyInfo?: string;
};
export declare function createDomainEventRequestSigner(secret: string, options?: DomainEventRequestSignerOptions): {
    sign: (eventId: string, timestamp: string) => string;
    verify: (eventId: string, timestamp: string | null, signature: string | null, now?: Date) => boolean;
};
export declare function signDomainEventRequest(eventId: string, timestamp: string): string;
export declare function verifyDomainEventRequest(eventId: string, timestamp: string | null, signature: string | null, now?: Date): boolean;
//# sourceMappingURL=internal-auth.d.ts.map