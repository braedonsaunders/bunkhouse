import { createHmac, hkdfSync, timingSafeEqual } from 'node:crypto';
export function createDomainEventRequestSigner(secret, options = {}) {
    if (secret.length < 32)
        throw new Error('Domain event request signing requires a 32+ character secret');
    const maxClockSkewMs = Math.max(1_000, options.maxClockSkewMs ?? 5 * 60_000);
    const signingKey = Buffer.from(hkdfSync('sha256', Buffer.from(secret), Buffer.from(options.keyInfo ?? 'appkit-domain-events'), Buffer.from('worker-to-application-v1'), 32));
    function sign(eventId, timestamp) {
        return createHmac('sha256', signingKey).update(`${timestamp}.${eventId}`).digest('base64url');
    }
    function verify(eventId, timestamp, signature, now = new Date()) {
        const sentAt = timestamp ? Number(timestamp) : Number.NaN;
        if (!Number.isFinite(sentAt) || Math.abs(now.getTime() - sentAt) > maxClockSkewMs)
            return false;
        if (!signature || !timestamp)
            return false;
        const expected = Buffer.from(sign(eventId, timestamp), 'utf8');
        const actual = Buffer.from(signature, 'utf8');
        return expected.length === actual.length && timingSafeEqual(expected, actual);
    }
    return { sign, verify };
}
function defaultSigner() {
    const secret = process.env.APPKIT_SECRET;
    if (!secret)
        throw new Error('APPKIT_SECRET is required for internal domain event requests');
    return createDomainEventRequestSigner(secret);
}
export function signDomainEventRequest(eventId, timestamp) {
    return defaultSigner().sign(eventId, timestamp);
}
export function verifyDomainEventRequest(eventId, timestamp, signature, now = new Date()) {
    return defaultSigner().verify(eventId, timestamp, signature, now);
}
//# sourceMappingURL=internal-auth.js.map