# @appkit/events

Audit trail (audit + diff) and a transactional outbox (recordDomainEvent) over @appkit/db.

## Install

```bash
pnpm add @appkit/events
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
