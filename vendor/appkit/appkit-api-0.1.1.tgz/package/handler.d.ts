import { type ApiAuth, type ApiAuthConfig } from './auth.js';
/**
 * The public-API entry point. `createApi(config)` returns `withApiKey`, which
 * authenticates the request, runs your handler with the resolved `{ ctx, key }`,
 * and renders any thrown ApiError as a JSON envelope — attaching the key's
 * rate-limit headers and no-store caching headers to every response.
 *
 *   const { withApiKey } = createApi({ appkit, rateLimit })
 *   export const GET = (req) => withApiKey(req, async (auth) => {
 *     authorize(auth, 'records.read')
 *     const rows = await auth.ctx.db((db) => db.select()...)
 *     return Response.json({ data: rows })
 *   })
 */
export declare function createApi(config: ApiAuthConfig): {
    authenticateApiKey: (req: Request) => Promise<ApiAuth>;
    withApiKey: (req: Request, handler: (auth: ApiAuth) => Promise<Response>) => Promise<Response>;
};
//# sourceMappingURL=handler.d.ts.map