export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
export type ApiParam = {
    name: string;
    in?: 'query' | 'path' | 'header';
    type?: string;
    required?: boolean;
    description?: string;
};
export type ApiRouteDoc = {
    method: HttpMethod;
    path: string;
    summary?: string;
    description?: string;
    /** Resource group the endpoint belongs to (used to section the reference). */
    tag?: string;
    /** Permission the API key must hold. */
    permission?: string;
    params?: ApiParam[];
    requestExample?: unknown;
    responseExample?: unknown;
};
/** Identity helper — carries the type so route lists stay well-typed. */
export declare function describeRoute(doc: ApiRouteDoc): ApiRouteDoc;
/** Emit a minimal OpenAPI 3.1 document from a route list (no dependency). */
export declare function toOpenApi(routes: ApiRouteDoc[], info: {
    title: string;
    version: string;
    description?: string;
}): Record<string, unknown>;
//# sourceMappingURL=docs.d.ts.map