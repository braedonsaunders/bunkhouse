import type { AppkitDb } from '@appkit/db';
import { type RequestContext } from '@appkit/tenant';
export type ApiKeyInfo = {
    id: string;
    name: string;
    tenantId: string;
    permissions: string[];
    rateLimitHeaders: Record<string, string>;
};
export type ApiAuth = {
    ctx: RequestContext;
    key: ApiKeyInfo;
};
/** Pluggable rate limiter (e.g. Redis-backed via @appkit/jobs). */
export type RateLimiter = (key: string, opts: {
    limit: number;
    windowSeconds: number;
}) => Promise<{
    allowed: boolean;
    remaining: number;
    resetAt: Date;
}>;
export type ApiAuthConfig = {
    appkit: AppkitDb<Record<string, never>>;
    tokenPrefix?: string;
    /** Restrict a key's permissions to this catalogue at auth time. */
    permissionCatalogue?: readonly string[];
    rateLimit?: RateLimiter;
    /** Per-minute limit when a rate limiter is supplied. Default 600. */
    rateLimitPerMinute?: number;
};
export declare function createApiAuth(config: ApiAuthConfig): {
    authenticateApiKey: (req: Request) => Promise<ApiAuth>;
};
//# sourceMappingURL=auth.d.ts.map