import type { ApiAuth } from './auth.js';
/** Stable digest of method + path + canonicalized body. */
export declare function apiIdempotencyRequestDigest(request: Request, body: unknown): string;
export type IdempotentResult = {
    body: Record<string, unknown>;
    status: number;
    replayed: boolean;
};
/**
 * Run a write exactly once per Idempotency-Key. Reserves a row (processing →
 * completed), replays the stored response on retry, 409s on key-reuse with a
 * different body, and FAILS CLOSED on unknown 5xx (keeps the reservation, since
 * the write may already have committed).
 */
export declare function runIdempotentMutation(auth: ApiAuth, request: Request, body: unknown, execute: () => Promise<{
    body: Record<string, unknown>;
    status: number;
}>): Promise<IdempotentResult>;
//# sourceMappingURL=idempotency.d.ts.map