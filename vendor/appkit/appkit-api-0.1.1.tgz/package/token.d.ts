export declare function hashToken(token: string): string;
/** Mint a new API credential. Returns the plaintext token (show once) + its
 *  stored hash. Format: `<prefix>_live_<43 url-safe chars>` (256-bit secret). */
export declare function generateApiKey(opts?: {
    prefix?: string;
}): {
    token: string;
    hash: string;
};
/** Parse the exact credential format from `Authorization: Bearer …`. Length-
 *  bounded BEFORE hashing so the lookup can't be turned into unbounded work. */
export declare function parseBearerToken(req: Request, opts?: {
    prefix?: string;
}): string | null;
//# sourceMappingURL=token.d.ts.map