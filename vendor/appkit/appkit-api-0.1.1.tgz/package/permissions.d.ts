import type { ApiAuth } from './auth.js';
/** Wildcard-aware: `module.*` grants `module.x`. */
export declare function keyHasPermission(permissions: readonly string[], required: string): boolean;
/** Filter stored permissions to the app's catalogue (if supplied) + de-dupe. */
export declare function sanitizeApiPermissions(permissions: readonly string[], catalogue?: readonly string[]): string[];
/** Assert the authenticated key holds `permission`, else throw 403. */
export declare function authorize(auth: ApiAuth, permission: string): void;
//# sourceMappingURL=permissions.d.ts.map