# @appkit/api

Public REST API toolkit — API-key auth, idempotent writes, typed errors, and a request wrapper. Framework-neutral.

## Install

```bash
pnpm add @appkit/api
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
