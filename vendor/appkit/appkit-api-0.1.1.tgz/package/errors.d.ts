export type ApiErrorCode = 'unauthorized' | 'forbidden' | 'not_found' | 'invalid_request' | 'method_not_allowed' | 'rate_limited' | 'conflict' | 'payload_too_large' | 'unavailable' | 'internal';
export declare class ApiError extends Error {
    readonly status: number;
    readonly code: ApiErrorCode;
    readonly details?: unknown | undefined;
    readonly headers?: Record<string, string> | undefined;
    constructor(status: number, code: ApiErrorCode, message: string, details?: unknown | undefined, headers?: Record<string, string> | undefined);
    static unauthorized(message?: string): ApiError;
    static forbidden(message?: string): ApiError;
    static notFound(message?: string): ApiError;
    static invalid(message: string, details?: unknown): ApiError;
    static methodNotAllowed(message: string): ApiError;
    static rateLimited(retryAfterSeconds: number, headers?: Record<string, string>): ApiError;
    static conflict(message: string): ApiError;
    static tooLarge(message?: string): ApiError;
    static unavailable(message?: string): ApiError;
}
/** Per-request, key-scoped responses are never cached. */
export declare function noStore(extra?: Record<string, string>): Record<string, string>;
/** Render any thrown value as a JSON error `Response`; never leaks internals. */
export declare function errorResponse(err: unknown): Response;
//# sourceMappingURL=errors.d.ts.map