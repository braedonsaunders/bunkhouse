import type { NotificationChannel } from './index.js';
export type NotificationRoutingCategory = {
    key: string;
    label: string;
    description: string;
    defaultRoles: string[];
    defaultChannels?: NotificationChannel[];
};
export type NotificationRoleOption = {
    key: string;
    name: string;
};
export type NotificationRecipientOption = {
    value: string;
    label: string;
};
export type NotificationEscalationStep = {
    afterDays: number;
    roleKeys: string[];
};
export type NotificationCategorySetting = {
    category: string;
    enabled: boolean;
    roleKeys: string[];
    userIds: string[];
    groupIds: string[];
    channels: NotificationChannel[];
    escalation: NotificationEscalationStep[];
};
export type NotificationPolicyInput = {
    digestMode: 'off' | 'daily' | 'weekly';
    digestHourUtc: number;
    quietHours: {
        start: number;
        end: number;
    } | null;
    /** Optional application detection scan governed by the same production policy row. */
    scanEnabled: boolean;
    scanCron: string;
    scanTimezone: string;
};
export type NotificationConfigurationInput = {
    settings: NotificationCategorySetting[];
    policy: NotificationPolicyInput;
};
export type NotificationConfigurationAdapter = {
    save(input: NotificationConfigurationInput): Promise<void>;
};
export type NotificationConfigurationAllowedValues = {
    categoryKeys: ReadonlySet<string>;
    roleKeys: ReadonlySet<string>;
    userIds: ReadonlySet<string>;
    groupIds: ReadonlySet<string>;
};
export declare function normalizeNotificationConfiguration(input: NotificationConfigurationInput, allowed: NotificationConfigurationAllowedValues): NotificationConfigurationInput;
export declare function normalizeEscalation(steps: readonly NotificationEscalationStep[], allowedRoleKeys?: ReadonlySet<string>): NotificationEscalationStep[];
export declare function assertNotificationPolicy(input: NotificationPolicyInput): void;
//# sourceMappingURL=configuration.d.ts.map