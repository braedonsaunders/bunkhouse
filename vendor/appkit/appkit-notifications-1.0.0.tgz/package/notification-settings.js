'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Faithfully generalized from the production tenant notification cockpit. The
// application supplies its category catalogue, recipients, transport status,
// persistence, and optional detection-schedule terminology; AppKit retains the
// complete routing-policy and per-category authoring behavior.
import * as React from 'react';
import { Plus, X } from 'lucide-react';
import { Button, Label, SearchSelect, Select, UiLink, cn, toast } from '@appkit/ui';
import { compileCron, decompileCron, isValidCron, SCHEDULE_PRESETS, WEEKDAYS } from './schedule.js';
const DEFAULT_COPY = {
    deliveryStatus: 'Delivery status', ready: 'ready', disabledByPlatform: 'disabled by platform', notConfigured: 'not set up',
    routingPolicy: 'Routing policy', routingPolicyDescription: 'Control digest delivery, quiet hours, and the schedule used by automatic notification scans.',
    digestDelivery: 'Digest delivery', digestOff: 'Off — send immediately', digestDaily: 'Daily summary', digestWeekly: 'Weekly summary', digestHour: 'at UTC hour', digestImmediateHint: 'Non-critical messages are sent as they occur.',
    quietHours: 'Quiet hours', quietHoursUtc: 'UTC', quietHoursOff: 'Non-critical delivery is not suppressed by time.',
    schedule: 'Automatic scan schedule', scheduleDescription: 'Choose when the application evaluates scheduled notification conditions.', scheduleEnabled: 'Enabled', scheduleDisabled: 'Paused', scheduleAt: 'at', scheduleTimezone: 'timezone', invalidCron: 'Enter a valid five-part cron expression (for example, 0 6 * * *).',
    roles: 'Roles', people: 'People', groups: 'People groups', channels: 'Channels', escalation: 'Escalation', noRoles: 'No roles are available.', noEscalation: 'No escalation steps.', noRecipients: 'Choose at least one role, person, or group.', categoryDisabled: 'Automatic notifications are disabled for this category.',
    addPerson: 'Add a person…', searchPeople: 'Search people…', selectPeople: 'Select people', addGroup: 'Add a group…', searchGroups: 'Search groups…', selectGroups: 'Select groups', noGroups: 'No groups are available.',
    after: 'After', daysOverdue: 'days overdue', removeEscalation: 'Remove escalation', addEscalation: 'Add escalation', inAppLocked: 'always on', removeRecipient: (label) => `Remove ${label}`, enableCategory: (label) => `Enable ${label}`,
    saved: 'All changes saved', unsaved: 'Unsaved changes', saving: 'Saving…', save: 'Save changes', saveError: 'Notification settings could not be saved.',
};
const CHANNELS = [
    { key: 'in_app', label: 'In-app', locked: true },
    { key: 'email', label: 'Email' },
    { key: 'push', label: 'Push' },
    { key: 'sms', label: 'SMS' },
];
const chipBase = 'rounded-full border px-2.5 py-1 text-xs font-medium transition-colors disabled:cursor-default';
const chipOn = 'border-primary bg-primary-subtle text-primary';
const chipOff = 'border-border text-fg-muted hover:bg-surface-hover hover:text-fg';
const numberInput = 'h-7 w-16 rounded-md border border-border bg-surface px-2 text-center text-sm text-fg outline-none focus:border-primary focus:ring-2 focus:ring-ring/20';
export function NotificationSettings({ categories, roles, members, groups, initial, policy, adapter, channelAvailability = {}, channelSettingsHrefs = {}, showScanSchedule = true, copy: copyOverride, className, onSaved, }) {
    const copy = { ...DEFAULT_COPY, ...copyOverride };
    const availability = {
        in_app: 'ready', email: channelAvailability.email ?? 'unconfigured', push: channelAvailability.push ?? 'ready', sms: channelAvailability.sms ?? 'unconfigured',
    };
    const seed = React.useMemo(() => Object.fromEntries(categories.map((category) => [category.key, initial[category.key] ?? {
            enabled: true,
            roleKeys: [...category.defaultRoles],
            userIds: [],
            groupIds: [],
            channels: category.defaultChannels ? [...category.defaultChannels] : ['in_app', 'email'],
            escalation: [],
        }])), [categories, initial]);
    const [config, setConfig] = React.useState(seed);
    const [currentPolicy, setCurrentPolicy] = React.useState(policy);
    const [baseline, setBaseline] = React.useState(() => serialize(seed, policy));
    const [pending, startTransition] = React.useTransition();
    const [schedule, setSchedule] = React.useState(() => decompileCron(policy.scanCron));
    const dirty = serialize(config, currentPolicy) !== baseline;
    const timezones = React.useMemo(() => supportedTimezones(), []);
    const patchCategory = (key, next) => setConfig((previous) => ({ ...previous, [key]: { ...previous[key], ...next } }));
    const patchPolicy = (next) => setCurrentPolicy((previous) => ({ ...previous, ...next }));
    const updateSchedule = (next) => {
        const merged = { ...schedule, ...next };
        setSchedule(merged);
        patchPolicy({ scanCron: compileCron(merged.preset, merged.hour, merged.weekday, merged.custom) });
    };
    const save = () => {
        const input = {
            settings: categories.map((category) => ({ category: category.key, ...config[category.key] })),
            policy: currentPolicy,
        };
        startTransition(async () => {
            try {
                await adapter.save(input);
                setBaseline(serialize(config, currentPolicy));
                onSaved?.(input);
                toast.success(copy.saved);
            }
            catch (error) {
                toast.error(error instanceof Error ? error.message : copy.saveError);
            }
        });
    };
    return (_jsxs("div", { className: cn('space-y-3', className), children: [_jsxs("div", { className: "flex flex-wrap items-center gap-x-4 gap-y-1.5 rounded-lg border border-border bg-bg-subtle px-3 py-2 text-xs", children: [_jsx("span", { className: "font-medium text-fg-muted", children: copy.deliveryStatus }), CHANNELS.map((channel) => _jsx(ChannelStatus, { label: channel.label, status: availability[channel.key], href: channelSettingsHrefs[channel.key], copy: copy }, channel.key))] }), _jsxs("section", { className: "rounded-xl border border-border bg-surface shadow-sm", children: [_jsxs("header", { className: "border-b border-border-subtle px-4 py-3", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: copy.routingPolicy }), _jsx("p", { className: "mt-0.5 text-xs text-fg-muted", children: copy.routingPolicyDescription })] }), _jsxs("div", { className: "space-y-4 px-4 py-4", children: [_jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: copy.digestDelivery }), _jsxs(Select, { value: currentPolicy.digestMode, onChange: (event) => patchPolicy({ digestMode: event.target.value }), children: [_jsx("option", { value: "off", children: copy.digestOff }), _jsx("option", { value: "daily", children: copy.digestDaily }), _jsx("option", { value: "weekly", children: copy.digestWeekly })] }), currentPolicy.digestMode !== 'off' ? _jsxs("div", { className: "flex items-center gap-2 text-xs text-fg-muted", children: [_jsx("span", { children: copy.digestHour }), _jsx("input", { type: "number", min: 0, max: 23, value: currentPolicy.digestHourUtc, onChange: (event) => patchPolicy({ digestHourUtc: Number(event.target.value) || 0 }), className: numberInput })] }) : _jsx("p", { className: "text-xs text-fg-subtle", children: copy.digestImmediateHint })] }), _jsxs("div", { className: "space-y-1.5", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx(Label, { children: copy.quietHours }), _jsx(Toggle, { checked: Boolean(currentPolicy.quietHours), onChange: (enabled) => patchPolicy({ quietHours: enabled ? { start: 22, end: 6 } : null }), label: copy.quietHours })] }), currentPolicy.quietHours ? _jsxs("div", { className: "flex items-center gap-2 text-xs text-fg-muted", children: [_jsx("input", { type: "number", min: 0, max: 23, value: currentPolicy.quietHours.start, onChange: (event) => patchPolicy({ quietHours: { start: Number(event.target.value) || 0, end: currentPolicy.quietHours.end } }), className: numberInput }), _jsx("span", { children: "\u2192" }), _jsx("input", { type: "number", min: 0, max: 23, value: currentPolicy.quietHours.end, onChange: (event) => patchPolicy({ quietHours: { start: currentPolicy.quietHours.start, end: Number(event.target.value) || 0 } }), className: numberInput }), _jsx("span", { children: copy.quietHoursUtc })] }) : _jsx("p", { className: "text-xs text-fg-subtle", children: copy.quietHoursOff })] })] }), showScanSchedule ? _jsx(ScheduleEditor, { policy: currentPolicy, schedule: schedule, timezones: timezones, copy: copy, onPolicy: patchPolicy, onSchedule: updateSchedule }) : null] })] }), categories.map((category) => {
                const value = config[category.key];
                const noRecipients = value.roleKeys.length === 0 && value.userIds.length === 0 && value.groupIds.length === 0;
                return _jsxs("section", { className: "rounded-xl border border-border bg-surface shadow-sm", children: [_jsxs("header", { className: "flex items-start justify-between gap-3 p-4", children: [_jsxs("div", { className: "min-w-0", children: [_jsx("h3", { className: "text-sm font-semibold text-fg", children: category.label }), _jsx("p", { className: "mt-0.5 text-xs text-fg-muted", children: category.description })] }), _jsx(Toggle, { checked: value.enabled, onChange: (enabled) => patchCategory(category.key, { enabled }), label: copy.enableCategory(category.label) })] }), value.enabled ? _jsxs("div", { className: "space-y-4 border-t border-border-subtle px-4 py-4", children: [_jsx(Field, { label: copy.roles, children: _jsx(RoleChips, { roles: roles, value: value.roleKeys, onChange: (roleKeys) => patchCategory(category.key, { roleKeys }), empty: copy.noRoles }) }), _jsx(Field, { label: copy.people, children: _jsx(RecipientPicker, { options: members, value: value.userIds, onChange: (userIds) => patchCategory(category.key, { userIds }), placeholder: copy.addPerson, searchPlaceholder: copy.searchPeople, sheetTitle: copy.selectPeople, copy: copy }) }), _jsx(Field, { label: copy.groups, children: _jsx(RecipientPicker, { options: groups, value: value.groupIds, onChange: (groupIds) => patchCategory(category.key, { groupIds }), placeholder: copy.addGroup, searchPlaceholder: copy.searchGroups, sheetTitle: copy.selectGroups, emptyHint: copy.noGroups, copy: copy }) }), _jsx(Field, { label: copy.channels, children: _jsx(ChannelChips, { value: value.channels, onChange: (channels) => patchCategory(category.key, { channels }), availability: availability, copy: copy }) }), _jsx(Field, { label: copy.escalation, children: _jsx(EscalationEditor, { roles: roles, value: value.escalation, onChange: (escalation) => patchCategory(category.key, { escalation }), copy: copy }) }), noRecipients ? _jsx("p", { className: "text-xs text-warning", children: copy.noRecipients }) : null] }) : _jsx("div", { className: "border-t border-border-subtle px-4 py-3 text-xs text-fg-subtle", children: copy.categoryDisabled })] }, category.key);
            }), _jsxs("div", { className: "sticky bottom-0 z-10 -mx-1 flex items-center justify-between gap-3 border-t border-border bg-surface/90 px-1 py-3 backdrop-blur", children: [_jsx("p", { className: "text-xs text-fg-muted", children: dirty ? copy.unsaved : copy.saved }), _jsx(Button, { onClick: save, disabled: pending || !dirty, children: pending ? copy.saving : copy.save })] })] }));
}
function Toggle({ checked, onChange, label }) {
    return _jsx("button", { type: "button", role: "switch", "aria-checked": checked, "aria-label": label, onClick: () => onChange(!checked), className: cn('relative h-6 w-11 shrink-0 rounded-full transition-colors', checked ? 'bg-primary' : 'bg-border-strong'), children: _jsx("span", { className: cn('absolute left-0.5 top-0.5 size-5 rounded-full bg-surface shadow-sm transition-transform', checked && 'translate-x-5') }) });
}
function Field({ label, children }) { return _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: label }), children] }); }
function RoleChips({ roles, value, onChange, empty }) {
    if (!roles.length)
        return _jsx("p", { className: "text-xs text-fg-subtle", children: empty });
    return _jsx("div", { className: "flex flex-wrap gap-1.5", children: roles.map((role) => { const active = value.includes(role.key); return _jsx("button", { type: "button", "aria-pressed": active, onClick: () => onChange(active ? value.filter((key) => key !== role.key) : [...value, role.key]), className: cn(chipBase, active ? chipOn : chipOff), children: role.name }, role.key); }) });
}
function ChannelChips({ value, onChange, availability, copy }) {
    return _jsx("div", { className: "flex flex-wrap gap-1.5", children: CHANNELS.map((channel) => { const active = channel.locked || value.includes(channel.key); const status = availability[channel.key]; return _jsxs("button", { type: "button", disabled: channel.locked, "aria-pressed": active, title: status === 'ready' ? undefined : `${channel.label} ${status === 'disabled' ? copy.disabledByPlatform : copy.notConfigured}`, onClick: () => channel.locked ? undefined : onChange(active ? value.filter((key) => key !== channel.key) : [...value, channel.key]), className: cn(chipBase, active ? chipOn : chipOff, status !== 'ready' && 'border-warning text-warning'), children: [channel.label, channel.locked ? ` · ${copy.inAppLocked}` : status !== 'ready' ? ` · ${status === 'disabled' ? copy.disabledByPlatform : copy.notConfigured}` : ''] }, channel.key); }) });
}
function ChannelStatus({ label, status, href, copy }) {
    const ready = status === 'ready';
    const content = _jsxs("span", { className: "inline-flex items-center gap-1.5", children: [_jsx("span", { className: cn('size-1.5 rounded-full', ready ? 'bg-success' : 'bg-warning') }), _jsxs("span", { className: ready ? 'text-fg-muted' : 'text-warning', children: [label, ready ? '' : ` — ${status === 'disabled' ? copy.disabledByPlatform : copy.notConfigured}`] })] });
    return status === 'unconfigured' && href ? _jsx(UiLink, { href: href, className: "hover:underline", children: content }) : content;
}
function RecipientPicker({ options, value, onChange, placeholder, searchPlaceholder, sheetTitle, emptyHint, copy }) {
    const available = React.useMemo(() => options.filter((option) => !value.includes(option.value)), [options, value]);
    const selected = value.map((id) => options.find((option) => option.value === id)).filter((option) => Boolean(option));
    if (!options.length && emptyHint)
        return _jsx("p", { className: "text-xs text-fg-subtle", children: emptyHint });
    return _jsxs("div", { className: "space-y-2", children: [_jsx(SearchSelect, { value: "", onChange: (id) => id && onChange([...value, id]), options: available, placeholder: placeholder, searchPlaceholder: searchPlaceholder, sheetTitle: sheetTitle }), selected.length ? _jsx("div", { className: "flex flex-wrap gap-1.5", children: selected.map((option) => _jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-primary-subtle py-1 pl-2.5 pr-1 text-xs font-medium text-primary", children: [option.label, _jsx("button", { type: "button", "aria-label": copy.removeRecipient(option.label), onClick: () => onChange(value.filter((id) => id !== option.value)), className: "rounded-full p-0.5 hover:bg-primary/10", children: _jsx(X, { size: 12 }) })] }, option.value)) }) : null] });
}
function EscalationEditor({ roles, value, onChange, copy }) {
    const patch = (index, next) => onChange(value.map((step, position) => position === index ? { ...step, ...next } : step));
    return _jsxs("div", { className: "space-y-2", children: [!value.length ? _jsx("p", { className: "text-xs text-fg-subtle", children: copy.noEscalation }) : null, value.map((step, index) => _jsxs("div", { className: "rounded-lg border border-border p-2.5", children: [_jsxs("div", { className: "flex items-center gap-2 text-xs text-fg-muted", children: [_jsx("span", { children: copy.after }), _jsx("input", { type: "number", min: 1, max: 365, value: step.afterDays, onChange: (event) => patch(index, { afterDays: Number(event.target.value) || 1 }), className: numberInput }), _jsx("span", { children: copy.daysOverdue }), _jsx("button", { type: "button", "aria-label": copy.removeEscalation, onClick: () => onChange(value.filter((_, position) => position !== index)), className: "ml-auto rounded p-1 text-fg-subtle hover:bg-danger-subtle hover:text-danger", children: _jsx(X, { size: 14 }) })] }), _jsx("div", { className: "mt-2", children: _jsx(RoleChips, { roles: roles, value: step.roleKeys, onChange: (roleKeys) => patch(index, { roleKeys }), empty: copy.noRoles }) })] }, index)), _jsxs("button", { type: "button", onClick: () => onChange([...value, { afterDays: 3, roleKeys: [] }]), className: "inline-flex items-center gap-1 rounded-md px-1 py-1 text-xs font-medium text-primary hover:underline", children: [_jsx(Plus, { size: 13 }), copy.addEscalation] })] });
}
function ScheduleEditor({ policy, schedule, timezones, copy, onPolicy, onSchedule }) {
    return _jsxs("div", { className: "space-y-1.5 border-t border-border-subtle pt-4", children: [_jsxs("div", { className: "flex items-center justify-between gap-3", children: [_jsx(Label, { children: copy.schedule }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "text-xs font-medium text-fg-muted", children: policy.scanEnabled ? copy.scheduleEnabled : copy.scheduleDisabled }), _jsx(Toggle, { checked: policy.scanEnabled, onChange: (scanEnabled) => onPolicy({ scanEnabled }), label: copy.schedule })] })] }), _jsx("p", { className: "text-xs text-fg-muted", children: copy.scheduleDescription }), _jsxs("div", { className: cn('flex flex-wrap items-center gap-2 pt-1', !policy.scanEnabled && 'pointer-events-none opacity-50'), "aria-disabled": !policy.scanEnabled, children: [_jsx(Select, { value: schedule.preset, onChange: (event) => onSchedule({ preset: event.target.value }), className: "w-40", disabled: !policy.scanEnabled, children: SCHEDULE_PRESETS.map((preset) => _jsx("option", { value: preset.value, children: preset.label }, preset.value)) }), ['daily', 'twice_daily', 'weekly'].includes(schedule.preset) ? _jsxs("div", { className: "flex items-center gap-1.5 text-xs text-fg-muted", children: [_jsx("span", { children: copy.scheduleAt }), _jsx("input", { type: "number", min: 0, max: 23, value: schedule.hour, onChange: (event) => onSchedule({ hour: Number(event.target.value) || 0 }), className: numberInput }), _jsx("span", { children: ":00" })] }) : null, schedule.preset === 'weekly' ? _jsx(Select, { value: String(schedule.weekday), onChange: (event) => onSchedule({ weekday: Number(event.target.value) }), className: "w-36", children: WEEKDAYS.map((day) => _jsx("option", { value: day.value, children: day.label }, day.value)) }) : null, schedule.preset === 'custom' ? _jsx("input", { type: "text", spellCheck: false, value: schedule.custom, onChange: (event) => onSchedule({ custom: event.target.value }), placeholder: "0 6 * * *", className: "h-7 w-40 rounded-md border border-border bg-surface px-2 font-mono text-sm text-fg outline-none focus:border-primary focus:ring-2 focus:ring-ring/20" }) : null, _jsx("span", { className: "text-xs text-fg-subtle", children: copy.scheduleTimezone }), _jsx(Select, { value: policy.scanTimezone, onChange: (event) => onPolicy({ scanTimezone: event.target.value }), className: "w-56", children: timezones.map((timezone) => _jsx("option", { value: timezone, children: timezone }, timezone)) })] }), schedule.preset === 'custom' && !isValidCron(schedule.custom) ? _jsx("p", { className: "text-xs text-danger", children: copy.invalidCron }) : null] });
}
function supportedTimezones() {
    try {
        const zones = Intl.supportedValuesOf?.('timeZone') ?? [];
        return ['UTC', ...zones.filter((timezone) => timezone !== 'UTC')];
    }
    catch {
        return ['UTC'];
    }
}
function serialize(config, policy) { return JSON.stringify({ config, policy }); }
//# sourceMappingURL=notification-settings.js.map