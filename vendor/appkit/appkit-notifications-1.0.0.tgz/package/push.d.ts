import { type WebPushPayload, type WebPushVapidDetails } from '@appkit/jobs/web-push';
export type PushSubscription = {
    id: string;
    tenantId: string;
    userId: string;
    endpoint: string;
    p256dh: string;
    auth: string;
    userAgent?: string | null;
};
export type PushSubscriptionStore = {
    upsert(input: Omit<PushSubscription, 'id'>): Promise<PushSubscription>;
    find(input: {
        tenantId: string;
        userId: string;
        subscriptionId: string;
    }): Promise<PushSubscription | null>;
    remove(input: {
        tenantId: string;
        userId: string;
        subscriptionId?: string;
        endpoint?: string;
    }): Promise<void>;
};
export type PushDelivery = {
    tenantId: string;
    userId: string;
    subscriptionId: string;
    title: string;
    body?: string;
    linkPath?: string;
};
export declare function registerPushSubscription(input: {
    store: PushSubscriptionStore;
    tenantId: string;
    userId: string;
    subscription: {
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
    };
    userAgent?: string | null;
}): Promise<PushSubscription>;
/** Send one retry-safe queued delivery and prune unusable subscriptions. */
export declare function processPushDelivery(input: {
    delivery: PushDelivery;
    store: PushSubscriptionStore;
    vapid: WebPushVapidDetails;
    send?: (input: {
        subscription: {
            endpoint: string;
            keys: {
                p256dh: string;
                auth: string;
            };
        };
        payload: WebPushPayload;
        vapid: WebPushVapidDetails;
    }) => Promise<void>;
}): Promise<'sent' | 'missing' | 'pruned'>;
//# sourceMappingURL=push.d.ts.map