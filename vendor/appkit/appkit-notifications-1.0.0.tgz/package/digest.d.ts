export type DigestMode = 'off' | 'daily' | 'weekly';
export type DigestPolicy = {
    tenantId: string;
    mode: DigestMode;
    hourUtc: number;
};
export type DigestRecipient = {
    userId: string;
    email: string;
    total: number;
};
export type DigestItem = {
    userId: string;
    title: string;
    linkPath?: string | null;
};
export type DigestMessage = {
    to: string;
    subject: string;
    html: string;
    text: string;
    idempotencyKey: string;
    tenantId: string;
    userId: string;
};
export type NotificationDigestStore = {
    policies(): Promise<readonly DigestPolicy[]>;
    recipients(input: {
        tenantId: string;
        start: Date;
        end: Date;
        afterUserId?: string;
        limit: number;
    }): Promise<readonly DigestRecipient[]>;
    items(input: {
        tenantId: string;
        userIds: string[];
        start: Date;
        end: Date;
        limitPerUser: number;
    }): Promise<readonly DigestItem[]>;
};
/** Scan due tenant policies and emit one bounded, idempotent message per user. */
export declare function scanNotificationDigests(input: {
    store: NotificationDigestStore;
    deliver: (message: DigestMessage) => Promise<void>;
    applicationUrl: string;
    scheduledFor?: Date;
}): Promise<{
    tenants: number;
    messages: number;
}>;
//# sourceMappingURL=digest.d.ts.map