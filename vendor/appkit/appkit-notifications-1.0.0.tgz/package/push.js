import { sendWebPushNotification, validateWebPushSubscription, validateWebPushSubscriptionForPersistence, } from '@appkit/jobs/web-push';
export async function registerPushSubscription(input) {
    const validated = await validateWebPushSubscriptionForPersistence(input.subscription);
    return input.store.upsert({
        tenantId: input.tenantId,
        userId: input.userId,
        endpoint: validated.endpoint,
        p256dh: validated.keys.p256dh,
        auth: validated.keys.auth,
        userAgent: input.userAgent,
    });
}
/** Send one retry-safe queued delivery and prune unusable subscriptions. */
export async function processPushDelivery(input) {
    const { delivery } = input;
    const subscription = await input.store.find({ tenantId: delivery.tenantId, userId: delivery.userId, subscriptionId: delivery.subscriptionId });
    if (!subscription)
        return 'missing';
    let validated;
    try {
        validated = validateWebPushSubscription({ endpoint: subscription.endpoint, keys: { p256dh: subscription.p256dh, auth: subscription.auth } });
    }
    catch {
        await input.store.remove({ tenantId: delivery.tenantId, userId: delivery.userId, subscriptionId: delivery.subscriptionId });
        return 'pruned';
    }
    try {
        await (input.send ?? sendWebPushNotification)({
            subscription: validated,
            payload: { title: delivery.title, body: delivery.body, linkPath: delivery.linkPath },
            vapid: input.vapid,
        });
        return 'sent';
    }
    catch (error) {
        const statusCode = error.statusCode;
        if (statusCode === 404 || statusCode === 410) {
            await input.store.remove({ tenantId: delivery.tenantId, userId: delivery.userId, subscriptionId: delivery.subscriptionId });
            return 'pruned';
        }
        throw error;
    }
}
//# sourceMappingURL=push.js.map