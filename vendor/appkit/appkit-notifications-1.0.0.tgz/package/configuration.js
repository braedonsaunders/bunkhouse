import { isValidCron, isValidTimezone } from './schedule.js';
const CHANNEL_SET = new Set(['in_app', 'email', 'push', 'sms']);
function unique(values) {
    return [...new Set(values.map((value) => value.trim()).filter(Boolean))];
}
export function normalizeNotificationConfiguration(input, allowed) {
    assertNotificationPolicy(input.policy);
    const seen = new Set();
    const settings = input.settings.map((item) => {
        if (!allowed.categoryKeys.has(item.category) || seen.has(item.category))
            throw new Error('One or more notification categories are invalid.');
        seen.add(item.category);
        return {
            category: item.category,
            enabled: Boolean(item.enabled),
            roleKeys: unique(item.roleKeys).filter((key) => allowed.roleKeys.has(key)),
            userIds: unique(item.userIds).filter((id) => allowed.userIds.has(id)),
            groupIds: unique(item.groupIds).filter((id) => allowed.groupIds.has(id)),
            channels: unique(item.channels).filter((channel) => CHANNEL_SET.has(channel)),
            escalation: normalizeEscalation(item.escalation, allowed.roleKeys),
        };
    });
    return { settings, policy: { ...input.policy, scanCron: input.policy.scanCron.trim() } };
}
export function normalizeEscalation(steps, allowedRoleKeys) {
    return steps
        .map((step) => ({
        afterDays: Math.min(365, Math.max(1, Math.round(step.afterDays || 1))),
        roleKeys: unique(step.roleKeys).filter((key) => !allowedRoleKeys || allowedRoleKeys.has(key)),
    }))
        .filter((step) => step.roleKeys.length > 0)
        .sort((left, right) => left.afterDays - right.afterDays);
}
export function assertNotificationPolicy(input) {
    if (!['off', 'daily', 'weekly'].includes(input.digestMode))
        throw new Error('Choose a valid digest schedule.');
    if (!Number.isInteger(input.digestHourUtc) || input.digestHourUtc < 0 || input.digestHourUtc > 23) {
        throw new Error('Digest hour must be a whole UTC hour from 0 to 23.');
    }
    if (input.quietHours && (!validHour(input.quietHours.start) || !validHour(input.quietHours.end))) {
        throw new Error('Quiet hours must use whole UTC hours from 0 to 23.');
    }
    if (!isValidCron(input.scanCron))
        throw new Error('Enter a valid five-part scan schedule.');
    if (!isValidTimezone(input.scanTimezone))
        throw new Error('Choose a valid scan timezone.');
}
function validHour(value) {
    return Number.isInteger(value) && value >= 0 && value <= 23;
}
//# sourceMappingURL=configuration.js.map