import * as React from 'react';
export type PushDeviceAdapter = {
    save(input: {
        endpoint: string;
        p256dh: string;
        auth: string;
        userAgent?: string;
    }): Promise<void>;
    remove(input: {
        endpoint: string;
    }): Promise<void>;
    test(): Promise<{
        sent: number;
    }>;
};
export type PushDeviceCopy = {
    title: string;
    enabled: string;
    loading: string;
    unsupported: string;
    iosInstall: string;
    blocked: string;
    idle: string;
    subscribed: string;
    missingKey: string;
    permissionDenied: string;
    invalidSubscription: string;
    subscribeFailed: string;
    enabledMessage: string;
    disabledMessage: string;
    disableFailed: string;
    testSent: (count: number) => string;
    enable: string;
    disable: string;
    test: string;
    retry: string;
    iosSteps: [string, string, string];
};
export declare function PushDeviceNotifications({ vapidPublicKey, adapter, copy: copyOverride, className }: {
    vapidPublicKey: string | null;
    adapter: PushDeviceAdapter;
    copy?: Partial<PushDeviceCopy>;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=push-device.d.ts.map