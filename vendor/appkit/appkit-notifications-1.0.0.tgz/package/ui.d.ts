import * as React from 'react';
import { type LucideIcon } from 'lucide-react';
import { type NotificationCatalog, type NotificationChannel, type NotificationPreference } from './index.js';
import { type NotificationInboxAdapter, type NotificationInboxFolders, type NotificationInboxItem } from './inbox.js';
type InboxTone = 'primary' | 'info' | 'success' | 'warning' | 'danger' | 'neutral';
export type NotificationCategoryVisual = {
    Icon?: LucideIcon;
    tone?: InboxTone;
};
export type NotificationTodoVisual = NotificationCategoryVisual & {
    label?: string;
};
export type NotificationInboxCopy = {
    inbox: string;
    all: string;
    unread: string;
    critical: string;
    todos: string;
    categories: string;
    preferences: string;
    folders: string;
    search: string;
    clearSearch: string;
    markAllRead: string;
    markRead: string;
    markUnread: string;
    snooze: string;
    delete: string;
    openRecord: string;
    closeDetails: string;
    selectTitle: string;
    selectDescription: string;
    emptyTitle: string;
    emptyDescription: string;
    emptySearchTitle: string;
    emptySearchDescription: string;
    emptyTodosTitle: string;
    emptyTodosDescription: string;
    noBody: string;
    endOfInbox: string;
    due: string;
    item: string;
    items: string;
    unreadSuffix: (count: number) => string;
    loadError: string;
    retry: string;
};
export type NotificationInboxProps = {
    initialItems: NotificationInboxItem[];
    initialHasMore: boolean;
    initialFolders: NotificationInboxFolders;
    catalog: NotificationCatalog;
    adapter: NotificationInboxAdapter;
    categoryVisuals?: Record<string, NotificationCategoryVisual>;
    todoVisuals?: Record<string, NotificationTodoVisual>;
    preferencesHref?: string;
    copy?: Partial<NotificationInboxCopy>;
    onError?: (error: unknown) => void;
    className?: string;
};
export declare function NotificationInbox({ initialItems, initialHasMore, initialFolders, catalog, adapter, categoryVisuals, todoVisuals, preferencesHref, copy: copyOverrides, onError, className, }: NotificationInboxProps): React.JSX.Element;
export declare function NotificationInboxSkeleton({ className }: {
    className?: string;
}): React.JSX.Element;
export type NotificationPreferencesProps = {
    catalog: NotificationCatalog;
    value: NotificationPreference[];
    onChange: (preferences: NotificationPreference[]) => void;
    availableChannels?: NotificationChannel[];
    readOnly?: boolean;
    className?: string;
};
export declare function NotificationPreferences({ catalog, value, onChange, availableChannels, readOnly, className }: NotificationPreferencesProps): React.JSX.Element;
export {};
//# sourceMappingURL=ui.d.ts.map