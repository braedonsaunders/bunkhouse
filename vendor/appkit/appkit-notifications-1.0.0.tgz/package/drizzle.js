import { and, desc, eq, ilike, inArray, isNull, lt, lte, or, sql } from 'drizzle-orm';
import { notificationPreferences, notifications, tenantNotificationPolicy, tenantNotificationSettings, webPushSubscriptions, } from './schema.js';
import { normalizeNotificationConfiguration } from './configuration.js';
export function createDrizzleNotificationStore(db) {
    return {
        async preferences(tenantId, userIds, category) {
            const map = new Map();
            if (!userIds.length)
                return map;
            const rows = await db.select({ userId: notificationPreferences.userId, channel: notificationPreferences.channel, enabled: notificationPreferences.enabled }).from(notificationPreferences).where(and(eq(notificationPreferences.tenantId, tenantId), eq(notificationPreferences.category, category), inArray(notificationPreferences.userId, userIds)));
            for (const row of rows) {
                const user = map.get(row.userId) ?? new Map();
                user.set(row.channel, row.enabled);
                map.set(row.userId, user);
            }
            return map;
        },
        async insert(event, recipient) {
            const occurredAt = event.occurredAt ?? new Date();
            const [inserted] = await db.insert(notifications).values({ tenantId: event.tenantId, userId: recipient.userId, category: event.category, type: event.type, title: event.title, body: event.body, linkPath: event.linkPath, data: event.data ?? {}, isCritical: event.critical ?? false, sourceJobId: event.sourceId, occurredAt }).onConflictDoNothing({ target: [notifications.tenantId, notifications.sourceJobId, notifications.userId] }).returning();
            if (inserted)
                return { record: toRecord(inserted, event), created: true };
            const [existing] = await db.select().from(notifications).where(and(eq(notifications.tenantId, event.tenantId), eq(notifications.sourceJobId, event.sourceId), eq(notifications.userId, recipient.userId))).limit(1);
            if (!existing)
                throw new Error('Notification conflict was not visible after insertion');
            return { record: toRecord(existing, event), created: false };
        },
    };
}
/**
 * Bind the production inbox to an already RLS-scoped database handle. Tenant
 * and user predicates remain explicit as defense in depth; domain to-dos stay
 * behind an application callback because their source tables are not owned by
 * the notification package.
 */
export function createDrizzleNotificationInboxAdapter(db, options) {
    const pageSize = Math.min(100, Math.max(1, options.pageSize ?? 30));
    const now = options.now ?? (() => new Date());
    const filterConditions = (filter) => {
        const conditions = [
            eq(notifications.tenantId, options.tenantId),
            eq(notifications.userId, options.userId),
            or(isNull(notifications.snoozedUntil), lte(notifications.snoozedUntil, now())),
        ];
        if (filter?.kind === 'unread')
            conditions.push(isNull(notifications.readAt));
        if (filter?.kind === 'critical')
            conditions.push(eq(notifications.isCritical, true));
        if (filter?.kind === 'category' && filter.category) {
            conditions.push(eq(notifications.category, filter.category));
        }
        const query = filter?.q?.trim();
        if (query) {
            const like = `%${query}%`;
            conditions.push(or(ilike(notifications.title, like), ilike(notifications.body, like)));
        }
        return conditions;
    };
    return {
        async fetchPage(request) {
            if (request?.filter?.kind === 'todos')
                return { items: [], hasMore: false };
            const conditions = filterConditions(request?.filter);
            if (request?.cursor) {
                conditions.push(or(lt(notifications.occurredAt, new Date(request.cursor.occurredAt)), and(eq(notifications.occurredAt, new Date(request.cursor.occurredAt)), lt(notifications.id, request.cursor.id))));
            }
            const rows = await db
                .select()
                .from(notifications)
                .where(and(...conditions))
                .orderBy(desc(notifications.occurredAt), desc(notifications.id))
                .limit(pageSize + 1);
            return {
                items: rows.slice(0, pageSize).map(toInboxItem),
                hasMore: rows.length > pageSize,
            };
        },
        async fetchFolders() {
            const rows = await db
                .select({
                category: notifications.category,
                total: sql `count(*)::int`,
                unread: sql `(count(*) filter (where ${notifications.readAt} is null))::int`,
                criticalTotal: sql `(count(*) filter (where ${notifications.isCritical}))::int`,
                criticalUnread: sql `(count(*) filter (where ${notifications.isCritical} and ${notifications.readAt} is null))::int`,
            })
                .from(notifications)
                .where(and(...filterConditions()))
                .groupBy(notifications.category);
            const folders = rows.reduce((acc, row) => {
                acc.total += row.total;
                acc.unread += row.unread;
                acc.criticalTotal += row.criticalTotal;
                acc.criticalUnread += row.criticalUnread;
                acc.categories.push({ category: row.category, total: row.total, unread: row.unread });
                return acc;
            }, {
                total: 0,
                unread: 0,
                criticalTotal: 0,
                criticalUnread: 0,
                todos: 0,
                categories: [],
            });
            folders.todos = options.fetchTodos ? (await options.fetchTodos()).length : 0;
            return folders;
        },
        async fetchTodos() {
            return options.fetchTodos?.() ?? [];
        },
        async markRead(id) {
            await db.update(notifications).set({ readAt: now() }).where(and(eq(notifications.id, id), eq(notifications.tenantId, options.tenantId), eq(notifications.userId, options.userId)));
        },
        async markUnread(id) {
            await db.update(notifications).set({ readAt: null }).where(and(eq(notifications.id, id), eq(notifications.tenantId, options.tenantId), eq(notifications.userId, options.userId)));
        },
        async delete(id) {
            await db.delete(notifications).where(and(eq(notifications.id, id), eq(notifications.tenantId, options.tenantId), eq(notifications.userId, options.userId)));
        },
        async snooze(id, hours) {
            const boundedHours = Math.min(720, Math.max(1, Math.round(hours)));
            await db.update(notifications).set({
                snoozedUntil: new Date(now().getTime() + boundedHours * 60 * 60 * 1_000),
            }).where(and(eq(notifications.id, id), eq(notifications.tenantId, options.tenantId), eq(notifications.userId, options.userId)));
        },
        async markAllRead(filter) {
            await db.update(notifications).set({ readAt: now() }).where(and(...filterConditions(filter), isNull(notifications.readAt)));
        },
    };
}
export function createDrizzlePushSubscriptionStore(db) {
    return {
        async upsert(input) {
            const [row] = await db.insert(webPushSubscriptions).values(input).onConflictDoUpdate({
                target: webPushSubscriptions.endpoint,
                set: { tenantId: input.tenantId, userId: input.userId, p256dh: input.p256dh, auth: input.auth, userAgent: input.userAgent ?? null, updatedAt: new Date() },
            }).returning();
            if (!row)
                throw new Error('Push subscription was not visible after upsert');
            return row;
        },
        async find(input) {
            const [row] = await db.select().from(webPushSubscriptions).where(and(eq(webPushSubscriptions.id, input.subscriptionId), eq(webPushSubscriptions.tenantId, input.tenantId), eq(webPushSubscriptions.userId, input.userId))).limit(1);
            return row ?? null;
        },
        async remove(input) {
            if (!input.subscriptionId && !input.endpoint)
                throw new Error('A subscription id or endpoint is required');
            await db.delete(webPushSubscriptions).where(and(eq(webPushSubscriptions.tenantId, input.tenantId), eq(webPushSubscriptions.userId, input.userId), input.subscriptionId ? eq(webPushSubscriptions.id, input.subscriptionId) : eq(webPushSubscriptions.endpoint, input.endpoint)));
        },
    };
}
export function createDrizzleNotificationPreferencesAdapter(db, options) {
    return {
        async load() {
            return db.select({ category: notificationPreferences.category, channel: notificationPreferences.channel, enabled: notificationPreferences.enabled })
                .from(notificationPreferences)
                .where(and(eq(notificationPreferences.tenantId, options.tenantId), eq(notificationPreferences.userId, options.userId)));
        },
        async save(preferences) {
            const unique = new Map(preferences.map((preference) => [`${preference.category}\0${preference.channel}`, preference]));
            if (unique.size !== preferences.length || preferences.length > 1_000)
                throw new Error('Notification preferences contain duplicate or excessive cells.');
            await db.transaction(async (tx) => {
                for (const preference of preferences) {
                    await tx.insert(notificationPreferences).values({ ...preference, tenantId: options.tenantId, userId: options.userId }).onConflictDoUpdate({
                        target: [notificationPreferences.tenantId, notificationPreferences.userId, notificationPreferences.category, notificationPreferences.channel],
                        set: { enabled: preference.enabled, updatedAt: new Date() },
                    });
                }
            });
        },
    };
}
export function createDrizzleNotificationConfigurationAdapter(db, options) {
    return {
        async load() {
            const [settings, policies] = await Promise.all([
                db.select().from(tenantNotificationSettings).where(eq(tenantNotificationSettings.tenantId, options.tenantId)),
                db.select().from(tenantNotificationPolicy).where(eq(tenantNotificationPolicy.tenantId, options.tenantId)).limit(1),
            ]);
            const policy = policies[0];
            return {
                settings: settings.map((row) => ({ category: row.category, enabled: row.enabled, roleKeys: row.roleKeys, userIds: row.userIds, groupIds: row.groupIds, channels: row.channels, escalation: row.escalation })),
                policy: {
                    digestMode: policy?.digestMode ?? 'off',
                    digestHourUtc: policy?.digestHourUtc ?? 7,
                    quietHours: policy?.quietHours ?? null,
                    scanEnabled: policy?.scanEnabled ?? true,
                    scanCron: policy?.scanCron ?? '0 6 * * *',
                    scanTimezone: policy?.scanTimezone ?? 'UTC',
                },
            };
        },
        async save(input) {
            const allowedValues = typeof options.allowedValues === 'function' ? await options.allowedValues() : options.allowedValues;
            const normalized = normalizeNotificationConfiguration(input, allowedValues);
            await db.transaction(async (tx) => {
                for (const setting of normalized.settings) {
                    await tx.insert(tenantNotificationSettings).values({ tenantId: options.tenantId, ...setting }).onConflictDoUpdate({
                        target: [tenantNotificationSettings.tenantId, tenantNotificationSettings.category],
                        set: { enabled: setting.enabled, roleKeys: setting.roleKeys, userIds: setting.userIds, groupIds: setting.groupIds, channels: setting.channels, escalation: setting.escalation, updatedAt: new Date() },
                    });
                }
                await tx.insert(tenantNotificationPolicy).values({ tenantId: options.tenantId, ...normalized.policy }).onConflictDoUpdate({
                    target: tenantNotificationPolicy.tenantId,
                    set: { ...normalized.policy, updatedAt: new Date() },
                });
            });
            await options.onSaved?.(normalized);
        },
    };
}
function toRecord(row, event) { return { ...event, id: row.id, userId: row.userId, body: row.body ?? undefined, linkPath: row.linkPath ?? undefined, data: row.data, critical: row.isCritical, occurredAt: row.occurredAt, readAt: row.readAt, snoozedUntil: row.snoozedUntil }; }
function toInboxItem(row) {
    return {
        id: row.id,
        title: row.title,
        body: row.body,
        category: row.category,
        linkPath: row.linkPath,
        isCritical: row.isCritical,
        occurredAt: row.occurredAt.toISOString(),
        read: Boolean(row.readAt),
    };
}
export { notifications, notificationPreferences, webPushSubscriptions, tenantNotificationPolicy, tenantNotificationSettings, NOTIFICATION_TENANT_TABLES, } from './schema.js';
//# sourceMappingURL=drizzle.js.map