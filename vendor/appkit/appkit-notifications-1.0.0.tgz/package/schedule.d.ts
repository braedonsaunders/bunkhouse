export declare const DEFAULT_SCAN_CRON = "0 6 * * *";
export type SchedulePreset = 'hourly' | 'every_6h' | 'twice_daily' | 'daily' | 'weekly' | 'custom';
export declare const SCHEDULE_PRESETS: readonly {
    value: SchedulePreset;
    label: string;
}[];
export declare const WEEKDAYS: readonly [{
    readonly value: 0;
    readonly label: "Sunday";
}, {
    readonly value: 1;
    readonly label: "Monday";
}, {
    readonly value: 2;
    readonly label: "Tuesday";
}, {
    readonly value: 3;
    readonly label: "Wednesday";
}, {
    readonly value: 4;
    readonly label: "Thursday";
}, {
    readonly value: 5;
    readonly label: "Friday";
}, {
    readonly value: 6;
    readonly label: "Saturday";
}];
/** Compile a friendly preset selection into the source runtime's five-field cron grammar. */
export declare function compileCron(preset: SchedulePreset, hour: number, weekday: number, custom: string): string;
/** Best-effort decompile a stored cron back into the production cockpit controls. */
export declare function decompileCron(cron: string): {
    preset: SchedulePreset;
    hour: number;
    weekday: number;
    custom: string;
};
/** Validate the exact cron subset accepted by the production worker parser. */
export declare function isValidCron(expression: string): boolean;
export declare function isValidTimezone(timezone: string): boolean;
//# sourceMappingURL=schedule.d.ts.map