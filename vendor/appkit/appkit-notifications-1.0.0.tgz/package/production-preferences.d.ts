import * as React from 'react';
import { type NotificationCatalog, type NotificationChannel, type NotificationPreference } from './index.js';
export type NotificationPreferencesAdapter = {
    save(preferences: NotificationPreference[]): Promise<void>;
};
export type ProductionNotificationPreferencesCopy = {
    category: string;
    channelLabels: Record<NotificationChannel, string>;
    saved: string;
    saveError: string;
    defaultHint: string;
    save: string;
    saving: string;
    cellLabel: (category: string, channel: string) => string;
};
export type ProductionNotificationPreferencesProps = {
    catalog: NotificationCatalog;
    initial: NotificationPreference[];
    adapter: NotificationPreferencesAdapter;
    channels?: NotificationChannel[];
    copy?: Partial<Omit<ProductionNotificationPreferencesCopy, 'channelLabels'>> & {
        channelLabels?: Partial<Record<NotificationChannel, string>>;
    };
    className?: string;
    onSaved?: (preferences: NotificationPreference[]) => void;
};
export declare function ProductionNotificationPreferences({ catalog, initial, adapter, channels, copy: copyOverride, className, onSaved }: ProductionNotificationPreferencesProps): React.JSX.Element;
//# sourceMappingURL=production-preferences.d.ts.map