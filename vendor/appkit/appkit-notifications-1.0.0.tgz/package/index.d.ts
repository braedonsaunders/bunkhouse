export declare const NOTIFICATION_CHANNELS: readonly ["in_app", "email", "push", "sms"];
export type NotificationChannel = (typeof NOTIFICATION_CHANNELS)[number];
export type NotificationCategory = {
    key: string;
    label: string;
    description?: string;
    defaultChannels: NotificationChannel[];
};
export type NotificationCatalog = {
    categories: NotificationCategory[];
};
export type NotificationPreference = {
    category: string;
    channel: NotificationChannel;
    enabled: boolean;
};
export type NotificationRecipient = {
    userId: string;
    email?: string | null;
    phone?: string | null;
};
export type NotificationEvent = {
    tenantId: string;
    sourceId: string;
    category: string;
    type: string;
    title: string;
    body?: string;
    linkPath?: string;
    data?: Record<string, unknown>;
    critical?: boolean;
    channels?: NotificationChannel[];
    occurredAt?: Date;
};
export type NotificationRecord = NotificationEvent & {
    id: string;
    userId: string;
    readAt?: Date | null;
    snoozedUntil?: Date | null;
};
export type NotificationTenantPolicy = {
    categoryChannels?: Record<string, NotificationChannel[]>;
    digestMode?: 'off' | 'daily' | 'weekly';
    quietHoursUtc?: {
        start: number;
        end: number;
    } | null;
};
export type NotificationDelivery = {
    channel: NotificationChannel;
    recipient: NotificationRecipient;
    event: NotificationEvent;
    delayMs: number;
    deduplicationKey: string;
};
export type NotificationStore = {
    preferences(tenantId: string, userIds: string[], category: string): Promise<Map<string, Map<NotificationChannel, boolean>>>;
    insert(event: NotificationEvent, recipient: NotificationRecipient): Promise<{
        record: NotificationRecord;
        created: boolean;
    }>;
};
export type NotificationDeliverer = (delivery: NotificationDelivery) => Promise<void>;
export { applyNotificationInboxDelta, buildNotificationInboxFolders, filterNotificationInboxItems, notificationRecordToInboxItem, } from './inbox.js';
export type { NotificationInboxAdapter, NotificationInboxFilter, NotificationInboxFolders, NotificationInboxItem, NotificationInboxPage, NotificationTodoItem, } from './inbox.js';
export { assertNotificationPolicy, normalizeEscalation, normalizeNotificationConfiguration, } from './configuration.js';
export type { NotificationCategorySetting, NotificationConfigurationAdapter, NotificationConfigurationAllowedValues, NotificationConfigurationInput, NotificationEscalationStep, NotificationPolicyInput, NotificationRecipientOption, NotificationRoleOption, NotificationRoutingCategory, } from './configuration.js';
export { compileCron, decompileCron, DEFAULT_SCAN_CRON, isValidCron, isValidTimezone, SCHEDULE_PRESETS, WEEKDAYS, } from './schedule.js';
export type { SchedulePreset } from './schedule.js';
export declare function planNotificationDeliveries(event: NotificationEvent, recipients: readonly NotificationRecipient[], preferences: Map<string, Map<NotificationChannel, boolean>>, policy?: NotificationTenantPolicy, now?: Date): NotificationDelivery[];
export declare function dispatchNotification(input: {
    event: NotificationEvent;
    recipients: readonly NotificationRecipient[];
    policy?: NotificationTenantPolicy;
    store: NotificationStore;
    deliverers?: Partial<Record<NotificationChannel, NotificationDeliverer>>;
    now?: Date;
}): Promise<{
    records: NotificationRecord[];
    deliveries: NotificationDelivery[];
}>;
export declare function assertNotificationEvent(event: NotificationEvent): void;
export declare function notificationDeduplicationKey(event: NotificationEvent, userId: string, channel: NotificationChannel): string;
export declare function inQuietHours(window: {
    start: number;
    end: number;
} | null, hourUtc: number): boolean;
export declare function millisecondsUntilQuietEnd(window: {
    start: number;
    end: number;
}, now: Date): number;
//# sourceMappingURL=index.d.ts.map