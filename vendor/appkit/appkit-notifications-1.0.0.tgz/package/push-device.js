'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Production per-device Web Push enrollment surface. Browser/OS capability,
// iOS Home Screen requirements, permission state, subscription persistence,
// testing, expiry cleanup, and disable behavior are all retained. The host
// injects authenticated persistence and delivery actions.
import * as React from 'react';
import { BellOff, BellRing, Check, Loader2, RotateCw, Send, Share, Smartphone } from 'lucide-react';
import { Button, cn, toast } from '@appkit/ui';
const DEFAULT_COPY = {
    title: 'Push notifications on this device', enabled: 'Enabled', loading: 'Checking notification status on this device…', unsupported: "This browser doesn't support push notifications.", iosInstall: 'iOS delivers push notifications only to apps added to the Home Screen.', blocked: 'Notifications are blocked for this site. Enable them in your browser or system settings, then reload this page.', idle: 'Receive alerts on this device even when the application is not open.', subscribed: 'This device receives push notifications, routed by the category choices below.', missingKey: 'Push is not configured on this server.', permissionDenied: 'Notifications are blocked for this site.', invalidSubscription: 'The browser returned an incomplete push subscription.', subscribeFailed: 'Push notifications could not be enabled on this device.', enabledMessage: 'Push notifications enabled.', disabledMessage: 'Push notifications disabled.', disableFailed: 'Push notifications could not be disabled.', testSent: (count) => `Test notification sent to ${count} device${count === 1 ? '' : 's'}.`, enable: 'Enable push', disable: 'Disable', test: 'Send test', retry: 'Check again', iosSteps: ['Open the browser Share menu.', 'Choose Add to Home Screen.', 'Open the installed application and return to this page.'],
};
export function PushDeviceNotifications({ vapidPublicKey, adapter, copy: copyOverride, className }) {
    const copy = { ...DEFAULT_COPY, ...copyOverride };
    const [status, setStatus] = React.useState('loading');
    const [busy, setBusy] = React.useState(false);
    const [testing, setTesting] = React.useState(false);
    React.useEffect(() => {
        let cancelled = false;
        async function detect() {
            const supported = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
            if (!supported) {
                if (!cancelled)
                    setStatus(isIos() && !isStandalone() ? 'ios-install' : 'unsupported');
                return;
            }
            if (Notification.permission === 'denied') {
                if (!cancelled)
                    setStatus('blocked');
                return;
            }
            try {
                const registration = await navigator.serviceWorker.ready;
                const subscription = await registration.pushManager.getSubscription();
                if (!cancelled)
                    setStatus(subscription ? 'subscribed' : 'idle');
            }
            catch {
                if (!cancelled)
                    setStatus('idle');
            }
        }
        void detect();
        return () => { cancelled = true; };
    }, []);
    async function enable() {
        if (!vapidPublicKey) {
            toast.error(copy.missingKey);
            return;
        }
        setBusy(true);
        try {
            const permission = await Notification.requestPermission();
            if (permission !== 'granted') {
                setStatus(permission === 'denied' ? 'blocked' : 'idle');
                if (permission === 'denied')
                    toast.error(copy.permissionDenied);
                return;
            }
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(vapidPublicKey) });
            const value = subscription.toJSON();
            if (!value.endpoint || !value.keys?.p256dh || !value.keys.auth) {
                await subscription.unsubscribe().catch(() => undefined);
                toast.error(copy.invalidSubscription);
                return;
            }
            try {
                await adapter.save({ endpoint: value.endpoint, p256dh: value.keys.p256dh, auth: value.keys.auth, userAgent: navigator.userAgent.slice(0, 512) });
            }
            catch (error) {
                await subscription.unsubscribe().catch(() => undefined);
                throw error;
            }
            setStatus('subscribed');
            toast.success(copy.enabledMessage);
        }
        catch (error) {
            console.warn('[push] subscribe failed', error);
            toast.error(error instanceof Error ? error.message : copy.subscribeFailed);
        }
        finally {
            setBusy(false);
        }
    }
    async function disable() {
        setBusy(true);
        try {
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.getSubscription();
            const endpoint = subscription?.endpoint;
            if (subscription)
                await subscription.unsubscribe().catch(() => undefined);
            if (endpoint)
                await adapter.remove({ endpoint });
            setStatus('idle');
            toast.success(copy.disabledMessage);
        }
        catch (error) {
            console.warn('[push] unsubscribe failed', error);
            toast.error(error instanceof Error ? error.message : copy.disableFailed);
        }
        finally {
            setBusy(false);
        }
    }
    async function test() {
        setTesting(true);
        try {
            const result = await adapter.test();
            toast.success(copy.testSent(result.sent));
        }
        catch (error) {
            toast.error(error instanceof Error ? error.message : copy.subscribeFailed);
        }
        finally {
            setTesting(false);
        }
    }
    const descriptions = { loading: copy.loading, unsupported: copy.unsupported, 'ios-install': copy.iosInstall, blocked: copy.blocked, idle: copy.idle, subscribed: copy.subscribed };
    return _jsx("section", { className: cn('rounded-lg border border-border bg-surface p-4 shadow-sm', className), children: _jsxs("div", { className: "flex items-start gap-3", children: [_jsx("div", { className: "mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md bg-bg-subtle text-fg-muted", children: status === 'ios-install' ? _jsx(Smartphone, { size: 18 }) : _jsx(BellRing, { size: 18 }) }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("h3", { className: "text-sm font-medium text-fg", children: copy.title }), status === 'subscribed' ? _jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-success-subtle px-2 py-0.5 text-[11px] font-medium text-success", children: [_jsx(Check, { size: 11 }), copy.enabled] }) : null] }), _jsx("p", { className: "mt-0.5 text-sm text-fg-muted", children: descriptions[status] }), status === 'ios-install' ? _jsx("ol", { className: "mt-3 space-y-1.5 text-sm text-fg-muted", children: copy.iosSteps.map((step, index) => _jsxs("li", { className: "flex items-center gap-2", children: [_jsxs("span", { className: "text-fg-subtle", children: [index + 1, "."] }), step, index === 0 ? _jsx(Share, { size: 15, className: "text-fg-subtle" }) : null] }, step)) }) : null, status === 'idle' ? _jsx("div", { className: "mt-3", children: _jsxs(Button, { type: "button", onClick: () => void enable(), disabled: busy, children: [busy ? _jsx(Loader2, { size: 14, className: "animate-spin" }) : _jsx(BellRing, { size: 14 }), copy.enable] }) }) : null, status === 'subscribed' ? _jsxs("div", { className: "mt-3 flex flex-wrap gap-2", children: [_jsxs(Button, { type: "button", onClick: () => void test(), disabled: testing || busy, children: [testing ? _jsx(Loader2, { size: 14, className: "animate-spin" }) : _jsx(Send, { size: 14 }), copy.test] }), _jsxs(Button, { type: "button", variant: "outline", onClick: () => void disable(), disabled: busy || testing, children: [busy ? _jsx(Loader2, { size: 14, className: "animate-spin" }) : _jsx(BellOff, { size: 14 }), copy.disable] })] }) : null, status === 'blocked' ? _jsx("div", { className: "mt-3", children: _jsxs(Button, { type: "button", variant: "outline", onClick: () => window.location.reload(), children: [_jsx(RotateCw, { size: 14 }), copy.retry] }) }) : null] })] }) });
}
function urlBase64ToUint8Array(base64) {
    const padding = '='.repeat((4 - (base64.length % 4)) % 4);
    const raw = atob((base64 + padding).replace(/-/g, '+').replace(/_/g, '/'));
    const output = new Uint8Array(new ArrayBuffer(raw.length));
    for (let index = 0; index < raw.length; index += 1)
        output[index] = raw.charCodeAt(index);
    return output;
}
function isIos() { return /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); }
function isStandalone() { return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true; }
//# sourceMappingURL=push-device.js.map