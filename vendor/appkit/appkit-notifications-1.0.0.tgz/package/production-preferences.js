'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Production category × channel preference matrix, extracted from the source
// route. Missing rows deliberately render enabled, matching dispatcher
// semantics; save submits the complete bounded matrix in one operation.
import * as React from 'react';
import { Loader2, Save } from 'lucide-react';
import { Button, Checkbox, cn, toast } from '@appkit/ui';
import { NOTIFICATION_CHANNELS } from './index.js';
const DEFAULT_COPY = {
    category: 'Category',
    channelLabels: { in_app: 'In-app', email: 'Email', push: 'Web push', sms: 'SMS' },
    saved: 'Notification preferences saved.',
    saveError: 'Notification preferences could not be saved.',
    defaultHint: 'New notification categories and channels are enabled by default.',
    save: 'Save preferences',
    saving: 'Saving…',
    cellLabel: (category, channel) => `${category}: ${channel}`,
};
export function ProductionNotificationPreferences({ catalog, initial, adapter, channels = [...NOTIFICATION_CHANNELS], copy: copyOverride, className, onSaved }) {
    const copy = { ...DEFAULT_COPY, ...copyOverride, channelLabels: { ...DEFAULT_COPY.channelLabels, ...copyOverride?.channelLabels } };
    const initialMap = React.useMemo(() => new Map(initial.map((preference) => [`${preference.category}:${preference.channel}`, preference.enabled])), [initial]);
    const [state, setState] = React.useState(() => buildState(catalog, channels, initialMap));
    const [pending, startTransition] = React.useTransition();
    const toggle = (category, channel) => setState((current) => ({ ...current, [`${category}:${channel}`]: !(current[`${category}:${channel}`] ?? true) }));
    const save = () => {
        const preferences = catalog.categories.flatMap((category) => channels.map((channel) => ({ category: category.key, channel, enabled: state[`${category.key}:${channel}`] ?? true })));
        startTransition(async () => {
            try {
                await adapter.save(preferences);
                onSaved?.(preferences);
                toast.success(copy.saved);
            }
            catch (error) {
                toast.error(error instanceof Error ? error.message : copy.saveError);
            }
        });
    };
    return _jsxs("div", { className: cn('space-y-4', className), children: [_jsx("div", { className: "overflow-x-auto rounded-lg border border-border bg-surface shadow-sm", children: _jsxs("table", { className: "w-full min-w-[36rem] text-sm", children: [_jsx("thead", { className: "bg-bg-subtle text-left text-xs uppercase tracking-wider text-fg-muted", children: _jsxs("tr", { children: [_jsx("th", { className: "px-4 py-3 font-medium", children: copy.category }), channels.map((channel) => _jsx("th", { className: "px-4 py-3 text-center font-medium", children: copy.channelLabels[channel] }, channel))] }) }), _jsx("tbody", { className: "divide-y divide-border-subtle", children: catalog.categories.map((category) => _jsxs("tr", { children: [_jsxs("td", { className: "px-4 py-3 align-top", children: [_jsx("span", { className: "block font-medium text-fg", children: category.label }), category.description ? _jsx("span", { className: "block text-xs text-fg-muted", children: category.description }) : null] }), channels.map((channel) => _jsx("td", { className: "px-4 py-3 text-center align-top", children: _jsx("span", { className: "inline-flex items-center justify-center", children: _jsx(Checkbox, { "aria-label": copy.cellLabel(category.label, copy.channelLabels[channel]), checked: state[`${category.key}:${channel}`] ?? true, onChange: () => toggle(category.key, channel) }) }) }, channel))] }, category.key)) })] }) }), _jsxs("div", { className: "flex items-center justify-between gap-3", children: [_jsx("p", { className: "text-xs text-fg-muted", children: copy.defaultHint }), _jsxs(Button, { type: "button", onClick: save, disabled: pending, children: [pending ? _jsx(Loader2, { size: 14, className: "animate-spin" }) : _jsx(Save, { size: 14 }), pending ? copy.saving : copy.save] })] })] });
}
function buildState(catalog, channels, initial) {
    const state = {};
    for (const category of catalog.categories)
        for (const channel of channels)
            state[`${category.key}:${channel}`] = initial.get(`${category.key}:${channel}`) ?? true;
    return state;
}
//# sourceMappingURL=production-preferences.js.map