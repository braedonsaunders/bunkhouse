import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { NotificationChannel, NotificationInboxAdapter, NotificationStore, NotificationTodoItem } from './index.js';
import type { NotificationConfigurationAdapter, NotificationConfigurationAllowedValues, NotificationConfigurationInput } from './configuration.js';
type Db = NodePgDatabase<Record<string, never>>;
export declare function createDrizzleNotificationStore(db: Db): NotificationStore;
export type DrizzleNotificationInboxOptions = {
    tenantId: string;
    userId: string;
    pageSize?: number;
    fetchTodos?: () => Promise<NotificationTodoItem[]>;
    now?: () => Date;
};
/**
 * Bind the production inbox to an already RLS-scoped database handle. Tenant
 * and user predicates remain explicit as defense in depth; domain to-dos stay
 * behind an application callback because their source tables are not owned by
 * the notification package.
 */
export declare function createDrizzleNotificationInboxAdapter(db: Db, options: DrizzleNotificationInboxOptions): NotificationInboxAdapter;
export declare function createDrizzlePushSubscriptionStore(db: Db): {
    upsert(input: {
        tenantId: string;
        userId: string;
        endpoint: string;
        p256dh: string;
        auth: string;
        userAgent?: string | null;
    }): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        userAgent: string | null;
        tenantId: string;
        createdBy: string | null;
        updatedBy: string | null;
        endpoint: string;
        p256dh: string;
        auth: string;
    }>;
    find(input: {
        tenantId: string;
        userId: string;
        subscriptionId: string;
    }): Promise<{
        createdAt: Date;
        createdBy: string | null;
        updatedAt: Date;
        updatedBy: string | null;
        id: string;
        tenantId: string;
        userId: string;
        endpoint: string;
        p256dh: string;
        auth: string;
        userAgent: string | null;
    } | null>;
    remove(input: {
        tenantId: string;
        userId: string;
        subscriptionId?: string;
        endpoint?: string;
    }): Promise<void>;
};
export declare function createDrizzleNotificationPreferencesAdapter(db: Db, options: {
    tenantId: string;
    userId: string;
}): {
    load(): Promise<{
        category: string;
        channel: "in_app" | "email" | "push" | "sms";
        enabled: boolean;
    }[]>;
    save(preferences: {
        category: string;
        channel: NotificationChannel;
        enabled: boolean;
    }[]): Promise<void>;
};
export declare function createDrizzleNotificationConfigurationAdapter(db: Db, options: {
    tenantId: string;
    allowedValues: NotificationConfigurationAllowedValues | (() => Promise<NotificationConfigurationAllowedValues>);
    onSaved?: (input: NotificationConfigurationInput) => Promise<void> | void;
}): NotificationConfigurationAdapter & {
    load(): Promise<NotificationConfigurationInput>;
};
export { notifications, notificationPreferences, webPushSubscriptions, tenantNotificationPolicy, tenantNotificationSettings, NOTIFICATION_TENANT_TABLES, } from './schema.js';
//# sourceMappingURL=drizzle.d.ts.map