import type { NotificationRecord } from './index.js';
export type NotificationInboxItem = {
    id: string;
    title: string;
    body: string | null;
    category: string;
    linkPath: string | null;
    isCritical: boolean;
    occurredAt: string;
    read: boolean;
};
export type NotificationInboxFilter = {
    kind: 'all' | 'unread' | 'critical' | 'todos' | 'category';
    category?: string;
    q?: string;
};
export type NotificationInboxFolders = {
    total: number;
    unread: number;
    criticalTotal: number;
    criticalUnread: number;
    todos: number;
    categories: {
        category: string;
        total: number;
        unread: number;
    }[];
};
export type NotificationTodoItem = {
    id: string;
    kind: string;
    title: string;
    subtitle: string | null;
    status: string;
    dueOn: string | null;
    linkPath: string;
};
export type NotificationInboxPage = {
    items: NotificationInboxItem[];
    hasMore: boolean;
};
export type NotificationInboxAdapter = {
    fetchPage(options?: {
        cursor?: {
            occurredAt: string;
            id: string;
        };
        filter?: NotificationInboxFilter;
    }): Promise<NotificationInboxPage>;
    fetchFolders(): Promise<NotificationInboxFolders>;
    fetchTodos(): Promise<NotificationTodoItem[]>;
    markRead(id: string): Promise<void>;
    markUnread(id: string): Promise<void>;
    delete(id: string): Promise<void>;
    snooze(id: string, hours: number): Promise<void>;
    markAllRead(filter?: NotificationInboxFilter): Promise<void>;
};
export declare function notificationRecordToInboxItem(record: NotificationRecord): NotificationInboxItem;
export declare function buildNotificationInboxFolders(items: readonly NotificationInboxItem[], todos?: number): NotificationInboxFolders;
export declare function filterNotificationInboxItems(items: readonly NotificationInboxItem[], filter?: NotificationInboxFilter): NotificationInboxItem[];
/** Exact local count deltas keep the folder rail aligned with optimistic mutations. */
export declare function applyNotificationInboxDelta(folders: NotificationInboxFolders, item: NotificationInboxItem, action: 'read' | 'unread' | 'delete'): NotificationInboxFolders;
//# sourceMappingURL=inbox.d.ts.map