'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { ArrowUpRight, Bell, CheckCheck, ChevronLeft, Clock, Flag, Inbox, ListChecks, Loader2, Mail, MailOpen, Menu, RotateCw, Search, Settings, Trash2, X, } from 'lucide-react';
import { Badge, Button, Checkbox, Drawer, Skeleton, UiLink, cn } from '@appkit/ui';
import { NOTIFICATION_CHANNELS, } from './index.js';
import { applyNotificationInboxDelta, } from './inbox.js';
const DEFAULT_COPY = {
    inbox: 'Inbox',
    all: 'All',
    unread: 'Unread',
    critical: 'Critical',
    todos: 'To-dos',
    categories: 'Categories',
    preferences: 'Preferences',
    folders: 'Folders',
    search: 'Search notifications',
    clearSearch: 'Clear search',
    markAllRead: 'Mark all as read',
    markRead: 'Mark as read',
    markUnread: 'Mark as unread',
    snooze: 'Snooze for one day',
    delete: 'Delete',
    openRecord: 'Open record',
    closeDetails: 'Back to notifications',
    selectTitle: 'Select a notification',
    selectDescription: 'Choose a notification from the list to read it here.',
    emptyTitle: 'No notifications',
    emptyDescription: 'New notifications will appear here.',
    emptySearchTitle: 'No matching notifications',
    emptySearchDescription: 'Try a different search term.',
    emptyTodosTitle: 'No outstanding to-dos',
    emptyTodosDescription: 'Assigned work and overdue items will appear here.',
    noBody: 'This notification has no additional details.',
    endOfInbox: 'You’ve reached the end of the inbox.',
    due: 'Due',
    item: 'item',
    items: 'items',
    unreadSuffix: (count) => ` · ${count} unread`,
    loadError: 'The inbox could not be loaded.',
    retry: 'Try again',
};
const TONE_STYLES = {
    primary: { bg: 'bg-primary-subtle', fg: 'text-primary' },
    info: { bg: 'bg-info-subtle', fg: 'text-info' },
    success: { bg: 'bg-success-subtle', fg: 'text-success' },
    warning: { bg: 'bg-warning-subtle', fg: 'text-warning' },
    danger: { bg: 'bg-danger-subtle', fg: 'text-danger' },
    neutral: { bg: 'bg-bg-subtle', fg: 'text-fg-muted' },
};
function useIsDesktop() {
    const [isDesktop, setIsDesktop] = React.useState(true);
    React.useEffect(() => {
        const media = window.matchMedia('(min-width: 1024px)');
        const sync = () => setIsDesktop(media.matches);
        sync();
        media.addEventListener('change', sync);
        return () => media.removeEventListener('change', sync);
    }, []);
    return isDesktop;
}
function relativeTime(iso) {
    const minutes = Math.floor((Date.now() - new Date(iso).getTime()) / 60_000);
    if (minutes < 1)
        return 'now';
    if (minutes < 60)
        return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24)
        return `${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7)
        return `${days}d`;
    return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
function fullDate(iso) {
    return new Date(iso).toLocaleString(undefined, {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
}
function filterKey(filter) {
    return filter.kind === 'category' ? `category:${filter.category}` : filter.kind;
}
function CountPill({ value, active }) {
    if (value <= 0)
        return null;
    return (_jsx("span", { className: cn('ml-auto inline-flex min-w-5 items-center justify-center rounded-full px-1.5 text-[11px] font-semibold tabular-nums', active ? 'bg-primary text-primary-fg' : 'bg-bg-subtle text-fg-muted'), children: value > 99 ? '99+' : value }));
}
function FolderButton({ icon, label, count, active, onClick, }) {
    return (_jsxs("button", { type: "button", onClick: onClick, "aria-current": active ? 'true' : undefined, className: cn('flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition-colors', active
            ? 'bg-primary-subtle font-medium text-fg'
            : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx("span", { className: cn('shrink-0', active ? 'text-primary' : 'text-fg-subtle'), children: icon }), _jsx("span", { className: "min-w-0 flex-1 truncate text-left", children: label }), _jsx(CountPill, { value: count, active: active })] }));
}
function CategoryIcon({ category, visuals, size = 16, }) {
    const visual = visuals?.[category];
    const Icon = visual?.Icon ?? Bell;
    const tone = TONE_STYLES[visual?.tone ?? 'neutral'];
    return (_jsx("span", { className: cn('flex size-9 shrink-0 items-center justify-center rounded-full', tone.bg), children: _jsx(Icon, { size: size, className: tone.fg }) }));
}
function FolderRail({ folders, filter, catalog, visuals, copy, preferencesHref, onSelect, variant, className, }) {
    const active = filterKey(filter);
    const labels = React.useMemo(() => new Map(catalog.categories.map((category) => [category.key, category.label])), [catalog.categories]);
    const categories = React.useMemo(() => [...folders.categories].sort((a, b) => (labels.get(a.category) ?? a.category).localeCompare(labels.get(b.category) ?? b.category)), [folders.categories, labels]);
    const nav = (_jsxs(_Fragment, { children: [_jsxs("div", { className: "space-y-0.5", children: [_jsx(FolderButton, { icon: _jsx(Inbox, { size: 16 }), label: copy.all, count: folders.unread, active: active === 'all', onClick: () => onSelect({ kind: 'all' }) }), _jsx(FolderButton, { icon: _jsx(Mail, { size: 16 }), label: copy.unread, count: folders.unread, active: active === 'unread', onClick: () => onSelect({ kind: 'unread' }) }), _jsx(FolderButton, { icon: _jsx(Flag, { size: 16 }), label: copy.critical, count: folders.criticalUnread, active: active === 'critical', onClick: () => onSelect({ kind: 'critical' }) }), _jsx(FolderButton, { icon: _jsx(ListChecks, { size: 16 }), label: copy.todos, count: folders.todos, active: active === 'todos', onClick: () => onSelect({ kind: 'todos' }) })] }), categories.length ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "px-2.5 pb-1 pt-4 text-[11px] font-semibold uppercase tracking-wide text-fg-subtle", children: copy.categories }), _jsx("div", { className: "space-y-0.5", children: categories.map((category) => {
                            const visual = visuals?.[category.category];
                            const Icon = visual?.Icon ?? Bell;
                            return (_jsx(FolderButton, { icon: _jsx(Icon, { size: 16 }), label: labels.get(category.category) ?? category.category, count: category.unread, active: active === `category:${category.category}`, onClick: () => onSelect({ kind: 'category', category: category.category }) }, category.category));
                        }) })] })) : null] }));
    const preferences = (_jsxs(UiLink, { href: preferencesHref, className: "flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg", children: [_jsx(Settings, { size: 16, className: "shrink-0 text-fg-subtle" }), copy.preferences] }));
    if (variant === 'flyout') {
        return (_jsxs("div", { className: "flex h-full flex-col", children: [_jsx("div", { className: "min-h-0 flex-1 overflow-y-auto", children: nav }), _jsx("div", { className: "mt-2 border-t border-border pt-2", children: preferences })] }));
    }
    return (_jsxs("aside", { className: cn('flex-col border-r border-border bg-surface', className), children: [_jsxs("div", { className: "flex h-14 shrink-0 items-center gap-2 px-4", children: [_jsx(Bell, { size: 18, className: "text-primary" }), _jsx("span", { className: "text-base font-semibold text-fg", children: copy.inbox })] }), _jsx("nav", { className: "app-scroll min-h-0 flex-1 overflow-y-auto px-2 pb-2", children: nav }), _jsx("div", { className: "border-t border-border p-2", children: preferences })] }));
}
function MessageRow({ item, label, visuals, copy, selected, onOpen, onToggleRead, onDelete, }) {
    return (_jsxs("div", { role: "button", tabIndex: 0, onClick: onOpen, onKeyDown: (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                onOpen();
            }
        }, className: cn('group relative flex cursor-pointer gap-3 border-b border-border-subtle px-3 py-2.5 transition-colors sm:px-4', selected ? 'bg-primary-subtle/70' : 'hover:bg-surface-hover'), children: [!item.read ? _jsx("span", { className: "absolute inset-y-0 left-0 w-[3px] bg-primary", "aria-hidden": true }) : null, _jsx(CategoryIcon, { category: item.category, visuals: visuals }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: cn('min-w-0 truncate text-xs', item.read ? 'text-fg-muted' : 'font-semibold text-fg'), children: label }), _jsx("time", { suppressHydrationWarning: true, className: "ml-auto shrink-0 text-[11px] whitespace-nowrap text-fg-subtle group-hover:opacity-0", children: relativeTime(item.occurredAt) })] }), _jsx("p", { className: cn('truncate text-sm', item.read ? 'text-fg-muted' : 'font-semibold text-fg'), children: item.title }), item.body ? _jsx("p", { className: "truncate text-xs text-fg-subtle", children: item.body }) : null, item.isCritical ? _jsx(Badge, { variant: "destructive", className: "mt-1 h-4 px-1.5 text-[10px]", children: copy.critical }) : null] }), _jsxs("div", { className: "absolute right-2 top-1.5 hidden items-center gap-0.5 rounded-md bg-surface/95 p-0.5 shadow-sm group-hover:flex group-focus-within:flex", children: [_jsx("button", { type: "button", onClick: (event) => { event.stopPropagation(); onToggleRead(); }, title: item.read ? copy.markUnread : copy.markRead, "aria-label": item.read ? copy.markUnread : copy.markRead, className: "rounded p-1 text-fg-muted hover:bg-surface-hover hover:text-fg", children: item.read ? _jsx(Mail, { size: 14 }) : _jsx(MailOpen, { size: 14 }) }), _jsx("button", { type: "button", onClick: (event) => { event.stopPropagation(); onDelete(); }, title: copy.delete, "aria-label": copy.delete, className: "rounded p-1 text-fg-muted hover:bg-danger-subtle hover:text-danger", children: _jsx(Trash2, { size: 14 }) })] })] }));
}
function TodoRow({ todo, visual, copy }) {
    const Icon = visual?.Icon ?? ListChecks;
    const tone = TONE_STYLES[visual?.tone ?? 'neutral'];
    return (_jsxs(UiLink, { href: todo.linkPath, className: "group flex w-full items-center gap-3 border-b border-border-subtle px-3 py-2.5 text-left transition-colors hover:bg-surface-hover sm:px-4", children: [_jsx("span", { className: cn('flex size-9 shrink-0 items-center justify-center rounded-full', tone.bg), children: _jsx(Icon, { size: 16, className: tone.fg }) }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "min-w-0 truncate text-xs text-fg-muted", children: visual?.label ?? todo.kind }), todo.dueOn ? _jsxs("span", { className: cn('ml-auto shrink-0 text-[11px] whitespace-nowrap', todo.status === 'overdue' ? 'font-medium text-danger' : 'text-fg-subtle'), children: [copy.due, " ", todo.dueOn] }) : null] }), _jsx("p", { className: "truncate text-sm font-medium text-fg", children: todo.title }), todo.subtitle ? _jsx("p", { className: "truncate text-xs capitalize text-fg-subtle", children: todo.subtitle }) : null] }), _jsx(ArrowUpRight, { size: 15, className: "shrink-0 text-fg-subtle opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100" })] }));
}
function ReadingPane({ item, label, visuals, copy, onToggleRead, onDelete, onSnooze, onClose, }) {
    if (!item) {
        return (_jsxs("div", { className: "flex h-full flex-col items-center justify-center gap-3 px-6 text-center", children: [_jsx("div", { className: "flex size-16 items-center justify-center rounded-full bg-bg-subtle", children: _jsx(Mail, { size: 28, className: "text-fg-subtle" }) }), _jsx("p", { className: "text-sm font-medium text-fg-muted", children: copy.selectTitle }), _jsx("p", { className: "max-w-xs text-xs text-fg-subtle", children: copy.selectDescription })] }));
    }
    const toolbar = (_jsxs("div", { className: "flex items-center gap-1.5 overflow-x-auto", children: [onClose ? _jsx("button", { type: "button", onClick: onClose, "aria-label": copy.closeDetails, className: "-ml-1 mr-1 rounded-md p-1.5 text-fg-muted hover:bg-surface-hover hover:text-fg lg:hidden", children: _jsx(ChevronLeft, { size: 20 }) }) : null, _jsxs(Button, { variant: "outline", size: "sm", onClick: () => onToggleRead(item), children: [item.read ? _jsx(Mail, { size: 14 }) : _jsx(MailOpen, { size: 14 }), item.read ? copy.markUnread : copy.markRead] }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => onSnooze(item), title: copy.snooze, children: [_jsx(Clock, { size: 14 }), copy.snooze] }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => onDelete(item), className: "text-danger hover:bg-danger-subtle", children: [_jsx(Trash2, { size: 14 }), copy.delete] }), item.linkPath ? _jsx(Button, { asChild: true, size: "sm", className: "ml-auto", children: _jsxs(UiLink, { href: item.linkPath, children: [copy.openRecord, _jsx(ArrowUpRight, { size: 14 })] }) }) : null] }));
    const header = (_jsxs("div", { className: "flex items-start gap-3", children: [_jsx(CategoryIcon, { category: item.category, visuals: visuals, size: 18 }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("h2", { className: "text-lg font-semibold leading-snug text-fg", children: item.title }), _jsxs("div", { className: "mt-1 flex flex-wrap items-center gap-2 text-xs text-fg-muted", children: [_jsx(Badge, { variant: "secondary", className: "font-normal", children: label ?? item.category }), item.isCritical ? _jsx(Badge, { variant: "destructive", children: copy.critical }) : null, _jsx("span", { suppressHydrationWarning: true, children: fullDate(item.occurredAt) })] })] })] }));
    const body = (_jsxs("div", { className: "space-y-5", children: [item.body ? _jsx("p", { className: "text-sm leading-relaxed whitespace-pre-wrap text-fg-muted", children: item.body }) : _jsx("p", { className: "text-sm text-fg-subtle", children: copy.noBody }), item.linkPath ? _jsx(Button, { asChild: true, children: _jsxs(UiLink, { href: item.linkPath, children: [copy.openRecord, _jsx(ArrowUpRight, { size: 16 })] }) }) : null] }));
    if (onClose)
        return _jsxs("div", { className: "space-y-4", children: [toolbar, _jsx("div", { className: "border-b border-border pb-4", children: header }), body] });
    return (_jsxs("div", { className: "flex h-full flex-col", children: [_jsxs("div", { className: "shrink-0 space-y-4 border-b border-border px-6 py-4", children: [toolbar, header] }), _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto px-6 py-5", children: body })] }));
}
export function NotificationInbox({ initialItems, initialHasMore, initialFolders, catalog, adapter, categoryVisuals, todoVisuals, preferencesHref = '/notifications/preferences', copy: copyOverrides, onError, className, }) {
    const copy = React.useMemo(() => ({ ...DEFAULT_COPY, ...copyOverrides }), [copyOverrides]);
    const labels = React.useMemo(() => new Map(catalog.categories.map((category) => [category.key, category.label])), [catalog.categories]);
    const isDesktop = useIsDesktop();
    const [folders, setFolders] = React.useState(initialFolders);
    const [filter, setFilter] = React.useState({ kind: 'all' });
    const [search, setSearch] = React.useState('');
    const [items, setItems] = React.useState(initialItems);
    const [todos, setTodos] = React.useState([]);
    const [hasMore, setHasMore] = React.useState(initialHasMore);
    const [loading, setLoading] = React.useState(false);
    const [error, setError] = React.useState(null);
    const [selectedId, setSelectedId] = React.useState(null);
    const [foldersOpen, setFoldersOpen] = React.useState(false);
    const [, startTransition] = React.useTransition();
    const selected = React.useMemo(() => items.find((item) => item.id === selectedId) ?? null, [items, selectedId]);
    const requestRef = React.useRef(0);
    const firstRun = React.useRef(true);
    const reportError = React.useCallback((nextError) => {
        setError(nextError);
        onError?.(nextError);
    }, [onError]);
    const load = React.useCallback(async (nextFilter) => {
        const request = ++requestRef.current;
        setLoading(true);
        setError(null);
        try {
            if (nextFilter.kind === 'todos') {
                const nextTodos = await adapter.fetchTodos();
                if (request !== requestRef.current)
                    return;
                setTodos(nextTodos);
                setItems([]);
                setHasMore(false);
            }
            else {
                const page = await adapter.fetchPage({ filter: nextFilter });
                if (request !== requestRef.current)
                    return;
                setItems(page.items);
                setHasMore(page.hasMore);
            }
        }
        catch (nextError) {
            if (request === requestRef.current)
                reportError(nextError);
        }
        finally {
            if (request === requestRef.current)
                setLoading(false);
        }
    }, [adapter, reportError]);
    React.useEffect(() => {
        if (firstRun.current) {
            firstRun.current = false;
            return;
        }
        void load(filter);
    }, [filter, load]);
    React.useEffect(() => {
        const timeout = window.setTimeout(() => {
            const q = search.trim() || undefined;
            setFilter((current) => current.q === q ? current : { ...current, q });
        }, 300);
        return () => window.clearTimeout(timeout);
    }, [search]);
    const sentinelRef = React.useRef(null);
    const loadingMoreRef = React.useRef(false);
    React.useEffect(() => {
        const element = sentinelRef.current;
        if (!element || !hasMore)
            return;
        const observer = new IntersectionObserver(async (entries) => {
            if (!entries[0]?.isIntersecting || loadingMoreRef.current)
                return;
            loadingMoreRef.current = true;
            try {
                const last = items.at(-1);
                if (!last)
                    return;
                const page = await adapter.fetchPage({ cursor: { occurredAt: last.occurredAt, id: last.id }, filter });
                setItems((current) => {
                    const seen = new Set(current.map((item) => item.id));
                    return [...current, ...page.items.filter((item) => !seen.has(item.id))];
                });
                setHasMore(page.hasMore);
            }
            catch (nextError) {
                reportError(nextError);
            }
            finally {
                loadingMoreRef.current = false;
            }
        }, { rootMargin: '600px 0px' });
        observer.observe(element);
        return () => observer.disconnect();
    }, [adapter, filter, hasMore, items, reportError]);
    const recover = React.useCallback(async (nextError) => {
        reportError(nextError);
        await Promise.all([load(filter), adapter.fetchFolders().then(setFolders).catch(reportError)]);
    }, [adapter, filter, load, reportError]);
    const setRead = (item, read) => {
        if (item.read === read)
            return;
        setFolders((current) => applyNotificationInboxDelta(current, item, read ? 'read' : 'unread'));
        setItems((current) => current.map((entry) => entry.id === item.id ? { ...entry, read } : entry));
        startTransition(() => { void (read ? adapter.markRead(item.id) : adapter.markUnread(item.id)).catch(recover); });
    };
    const remove = (item) => {
        setSelectedId((current) => current === item.id ? null : current);
        setFolders((current) => applyNotificationInboxDelta(current, item, 'delete'));
        setItems((current) => current.filter((entry) => entry.id !== item.id));
        startTransition(() => { void adapter.delete(item.id).catch(recover); });
    };
    const snooze = (item) => {
        setSelectedId((current) => current === item.id ? null : current);
        setFolders((current) => applyNotificationInboxDelta(current, item, 'delete'));
        setItems((current) => current.filter((entry) => entry.id !== item.id));
        startTransition(() => { void adapter.snooze(item.id, 24).catch(recover); });
    };
    const open = (item) => {
        setSelectedId(item.id);
        if (!item.read)
            setRead(item, true);
    };
    const selectFolder = (nextFilter) => {
        setFoldersOpen(false);
        setSelectedId(null);
        setSearch('');
        setFilter({ kind: nextFilter.kind, category: nextFilter.category });
    };
    const markAll = async () => {
        setItems((current) => current.map((item) => item.read ? item : { ...item, read: true }));
        try {
            await adapter.markAllRead(filter);
            setFolders(await adapter.fetchFolders());
        }
        catch (nextError) {
            await recover(nextError);
        }
    };
    const active = React.useMemo(() => {
        if (filter.kind === 'category' && filter.category) {
            const category = folders.categories.find((entry) => entry.category === filter.category);
            return { label: labels.get(filter.category) ?? filter.category, total: category?.total ?? 0, unread: category?.unread ?? 0 };
        }
        if (filter.kind === 'todos')
            return { label: copy.todos, total: todos.length || folders.todos, unread: 0 };
        if (filter.kind === 'unread')
            return { label: copy.unread, total: folders.unread, unread: folders.unread };
        if (filter.kind === 'critical')
            return { label: copy.critical, total: folders.criticalTotal, unread: folders.criticalUnread };
        return { label: copy.all, total: folders.total, unread: folders.unread };
    }, [copy, filter, folders, labels, todos.length]);
    const empty = (icon, title, description) => (_jsxs("div", { className: "flex flex-col items-center justify-center px-6 py-20 text-center", children: [_jsx("div", { className: "flex size-14 items-center justify-center rounded-full bg-bg-subtle text-fg-subtle", children: icon }), _jsx("p", { className: "mt-3 text-sm font-medium text-fg-muted", children: title }), _jsx("p", { className: "mt-1 text-xs text-fg-subtle", children: description })] }));
    const listBody = filter.kind === 'todos'
        ? todos.length
            ? todos.map((todo) => _jsx(TodoRow, { todo: todo, visual: todoVisuals?.[todo.kind], copy: copy }, todo.id))
            : empty(_jsx(ListChecks, { size: 26 }), copy.emptyTodosTitle, copy.emptyTodosDescription)
        : items.length
            ? _jsxs(_Fragment, { children: [items.map((item) => _jsx(MessageRow, { item: item, label: labels.get(item.category) ?? item.category, visuals: categoryVisuals, copy: copy, selected: item.id === selectedId, onOpen: () => open(item), onToggleRead: () => setRead(item, !item.read), onDelete: () => remove(item) }, item.id)), hasMore ? _jsx("div", { ref: sentinelRef, className: "flex items-center justify-center py-6", children: _jsx(Loader2, { size: 18, className: "animate-spin text-fg-subtle" }) }) : _jsx("p", { className: "py-6 text-center text-xs text-fg-subtle", children: copy.endOfInbox })] })
            : empty(_jsx(Inbox, { size: 26 }), search.trim() ? copy.emptySearchTitle : copy.emptyTitle, search.trim() ? copy.emptySearchDescription : copy.emptyDescription);
    return (_jsxs("div", { className: cn('flex h-full min-h-0 bg-bg-subtle', className), children: [_jsx(FolderRail, { variant: "rail", folders: folders, filter: filter, catalog: catalog, visuals: categoryVisuals, copy: copy, preferencesHref: preferencesHref, onSelect: selectFolder, className: "hidden w-64 shrink-0 lg:flex" }), _jsxs("section", { className: "flex min-w-0 flex-1 flex-col border-r border-border bg-surface lg:w-96 lg:flex-none xl:w-[28rem]", children: [_jsxs("header", { className: "shrink-0 border-b border-border", children: [_jsxs("div", { className: "flex h-14 items-center gap-2 px-3 sm:px-4", children: [_jsx("button", { type: "button", onClick: () => setFoldersOpen(true), "aria-label": copy.folders, className: "-ml-1 rounded-md p-1.5 text-fg-muted hover:bg-surface-hover hover:text-fg lg:hidden", children: _jsx(Menu, { size: 20 }) }), _jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("h1", { className: "truncate text-sm font-semibold text-fg", children: active.label }), _jsxs("p", { className: "text-[11px] text-fg-subtle", children: [active.total, " ", active.total === 1 ? copy.item : copy.items, active.unread ? copy.unreadSuffix(active.unread) : ''] })] }), active.unread ? _jsx("button", { type: "button", onClick: () => void markAll(), title: copy.markAllRead, "aria-label": copy.markAllRead, className: "rounded-md p-1.5 text-fg-muted hover:bg-surface-hover hover:text-fg", children: _jsx(CheckCheck, { size: 18 }) }) : null, _jsx(UiLink, { href: preferencesHref, "aria-label": copy.preferences, className: "rounded-md p-1.5 text-fg-muted hover:bg-surface-hover hover:text-fg lg:hidden", children: _jsx(Settings, { size: 18 }) })] }), _jsx("div", { className: cn('px-3 pb-2.5 sm:px-4', filter.kind === 'todos' && 'hidden'), children: _jsxs("div", { className: "relative", children: [_jsx(Search, { size: 15, className: "pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-fg-subtle" }), _jsx("input", { type: "search", value: search, onChange: (event) => setSearch(event.target.value), placeholder: copy.search, className: "h-9 w-full rounded-lg border border-border bg-bg-subtle pl-8 pr-8 text-base text-fg outline-none transition-colors placeholder:text-fg-subtle focus:border-primary focus:bg-surface focus:ring-2 focus:ring-ring/20 sm:text-sm" }), search ? _jsx("button", { type: "button", onClick: () => setSearch(''), "aria-label": copy.clearSearch, className: "absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-fg-subtle hover:text-fg", children: _jsx(X, { size: 14 }) }) : null] }) })] }), _jsxs("div", { className: "app-scroll relative min-h-0 flex-1 overflow-y-auto", children: [loading ? _jsx("div", { className: "absolute inset-x-0 top-0 z-10 flex justify-center py-3", children: _jsx(Loader2, { size: 16, className: "animate-spin text-fg-subtle" }) }) : null, error && !loading ? _jsxs("div", { role: "alert", className: "m-3 flex items-center gap-3 rounded-lg border border-danger/25 bg-danger-subtle p-3 text-sm text-danger", children: [_jsx("span", { className: "min-w-0 flex-1", children: copy.loadError }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => void load(filter), children: [_jsx(RotateCw, { size: 14 }), copy.retry] })] }) : null, listBody] })] }), _jsx("section", { className: "hidden min-w-0 flex-1 bg-surface lg:flex", children: _jsx("div", { className: "w-full", children: _jsx(ReadingPane, { item: selected, label: selected ? labels.get(selected.category) : undefined, visuals: categoryVisuals, copy: copy, onToggleRead: (item) => setRead(item, !item.read), onDelete: remove, onSnooze: snooze }) }) }), !isDesktop ? _jsxs(_Fragment, { children: [_jsx(Drawer, { open: foldersOpen, onClose: () => setFoldersOpen(false), side: "left", size: "sm", title: copy.folders, disableFullscreen: true, bodyClassName: "min-h-0 flex-1 overflow-hidden px-4 py-5", children: _jsx(FolderRail, { variant: "flyout", folders: folders, filter: filter, catalog: catalog, visuals: categoryVisuals, copy: copy, preferencesHref: preferencesHref, onSelect: selectFolder }) }), _jsx(Drawer, { open: Boolean(selectedId), onClose: () => setSelectedId(null), size: "lg", title: selected?.title, disableFullscreen: true, children: _jsx(ReadingPane, { item: selected, label: selected ? labels.get(selected.category) : undefined, visuals: categoryVisuals, copy: copy, onToggleRead: (item) => setRead(item, !item.read), onDelete: (item) => { remove(item); setSelectedId(null); }, onSnooze: (item) => { snooze(item); setSelectedId(null); }, onClose: () => setSelectedId(null) }) })] }) : null] }));
}
export function NotificationInboxSkeleton({ className }) {
    return (_jsxs("div", { role: "status", "aria-label": "Loading inbox", "aria-busy": "true", className: cn('flex h-full min-h-0 bg-bg-subtle', className), children: [_jsx("div", { className: "hidden w-64 shrink-0 flex-col gap-2 border-r border-border p-3 lg:flex", children: Array.from({ length: 6 }).map((_, index) => _jsx(Skeleton, { className: "h-9 w-full rounded-lg" }, index)) }), _jsxs("section", { className: "flex min-w-0 flex-1 flex-col border-r border-border bg-surface lg:w-96 lg:flex-none xl:w-[28rem]", children: [_jsxs("div", { className: "shrink-0 space-y-2.5 border-b border-border px-3 py-3 sm:px-4", children: [_jsx(Skeleton, { className: "h-5 w-28" }), _jsx(Skeleton, { className: "h-9 w-full rounded-lg" })] }), _jsx("div", { className: "flex-1 overflow-hidden", children: Array.from({ length: 8 }).map((_, index) => _jsxs("div", { className: "flex items-center gap-3 border-b border-border-subtle px-3 py-3 sm:px-4", children: [_jsx(Skeleton, { className: "size-9 shrink-0 rounded-full" }), _jsxs("div", { className: "min-w-0 flex-1 space-y-2", children: [_jsx(Skeleton, { className: "h-3.5 w-3/4" }), _jsx(Skeleton, { className: "h-3 w-1/2" })] })] }, index)) })] }), _jsx("div", { className: "hidden min-w-0 flex-1 items-center justify-center lg:flex", children: _jsx(Skeleton, { className: "size-10 rounded-full" }) })] }));
}
export function NotificationPreferences({ catalog, value, onChange, availableChannels = [...NOTIFICATION_CHANNELS], readOnly = false, className }) {
    const enabled = (category, channel) => value.find((item) => item.category === category && item.channel === channel)?.enabled ?? catalog.categories.find((item) => item.key === category)?.defaultChannels.includes(channel) ?? false;
    const update = (category, channel, next) => onChange([...value.filter((item) => item.category !== category || item.channel !== channel), { category, channel, enabled: next }]);
    const gridStyle = { gridTemplateColumns: `minmax(14rem, 1fr) repeat(${availableChannels.length}, minmax(4.5rem, auto))` };
    return _jsx("div", { className: cn('overflow-x-auto rounded-lg border border-border bg-surface', className), children: _jsxs("div", { className: "min-w-[36rem]", children: [_jsxs("div", { style: gridStyle, className: "grid border-b border-border bg-bg-subtle px-4 py-2 text-xs font-semibold text-fg-muted", children: [_jsx("span", { children: "Category" }), availableChannels.map((channel) => _jsx("span", { className: "text-center capitalize", children: channel.replace('_', ' ') }, channel))] }), catalog.categories.map((category) => _jsxs("div", { style: gridStyle, className: "grid items-center border-b border-border-subtle px-4 py-3 last:border-b-0", children: [_jsxs("span", { children: [_jsx("span", { className: "block text-sm font-medium text-fg", children: category.label }), category.description ? _jsx("span", { className: "block text-xs text-fg-muted", children: category.description }) : null] }), availableChannels.map((channel) => _jsx("span", { className: "flex justify-center", children: _jsx(Checkbox, { "aria-label": `${category.label}: ${channel}`, checked: enabled(category.key, channel), disabled: readOnly, onChange: (event) => update(category.key, channel, event.currentTarget.checked) }) }, channel))] }, category.key))] }) });
}
//# sourceMappingURL=ui.js.map