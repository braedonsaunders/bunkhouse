# @appkit/telephony

Carrier telephony — buy phone numbers and provision the SIP trunk they arrive on, via fetch, with sealed-secret config and an injectable carrier adapter.

## Install

```bash
pnpm add @appkit/telephony
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
