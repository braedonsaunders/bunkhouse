import { type CarrierProvider } from './providers.js';
/** Unseal a stored secret → plaintext. Supplied by the app (e.g. @appkit/crypto). */
export type Unseal = (sealed: {
    ciphertext: string;
    nonce: string;
}) => string | null;
export type RawCarrierConfig = {
    enabled?: boolean;
    provider?: CarrierProvider;
    /** Non-secret account identifier (Twilio: the Account SID). */
    accountId?: string;
    keyCiphertext?: string;
    keyNonce?: string;
};
export type PlainCarrierConfig = Omit<RawCarrierConfig, 'keyCiphertext' | 'keyNonce'> & {
    secret?: string;
};
export type CarrierCredentials = {
    provider: CarrierProvider;
    accountId: string;
    secret: string;
};
/** A number the carrier has for sale. `number` is E.164 with the leading '+'. */
export type AvailableNumber = {
    number: string;
    label: string;
    locality: string;
    region: string;
    voice: boolean;
    sms: boolean;
};
export type NumberSearchQuery = {
    /** ISO 3166-1 alpha-2, e.g. 'US'. */
    country: string;
    areaCode?: string;
    contains?: string;
    limit?: number;
};
export type EnsureTrunkInput = {
    /** Operator-facing name recorded on the carrier side. */
    label: string;
    /** Full SIP URI the carrier delivers inbound calls to, e.g. sip:host:5060. */
    originationUri: string;
};
/**
 * One carrier trunk, normalized. This is the whole seam between a carrier and
 * whatever SIP infrastructure a consumer runs.
 */
export type CarrierTrunk = {
    /** The carrier's own id, stored by the consumer and passed back to buy on. */
    carrierTrunkId: string;
    /** Where the consumer sends outbound calls. */
    terminationHost: string;
    terminationPort: number;
    /** What the consumer authenticates outbound calls with. */
    authUsername: string;
    authPassword: string;
    /**
     * Addresses inbound calls arrive from, for the consumer's ingress allowlist.
     * A suggested default from the carrier catalogue — persist it as editable
     * configuration rather than reading it fresh on every call.
     */
    signalingRanges: string[];
};
export type BuyNumberInput = {
    /** E.164 with the leading '+', as returned by `searchNumbers`. */
    number: string;
    label: string;
    /** The trunk the number should arrive on, from `ensureTrunk`. */
    carrierTrunkId: string;
};
export type PurchasedNumber = {
    /** The carrier's id for the number, needed to release it later. */
    numberId: string;
    number: string;
};
export type CarrierClient = {
    provider: CarrierProvider;
    /** Confirm the credentials work, and say whose account they are. */
    verifyAccount(): Promise<{
        accountLabel: string;
    }>;
    searchNumbers(query: NumberSearchQuery): Promise<AvailableNumber[]>;
    /**
     * Build a trunk that delivers to `originationUri` and accepts authenticated
     * calls back. Partial failures are unwound before throwing, so a rejected
     * call leaves the carrier account as it was found.
     */
    ensureTrunk(input: EnsureTrunkInput): Promise<CarrierTrunk>;
    deleteTrunk(carrierTrunkId: string): Promise<void>;
    buyNumber(input: BuyNumberInput): Promise<PurchasedNumber>;
    releaseNumber(numberId: string): Promise<void>;
};
/** A carrier refusal, carrying what the carrier actually said. */
export declare class CarrierError extends Error {
    provider: CarrierProvider;
    status: number;
    code: number | null;
    constructor(message: string, provider: CarrierProvider, status: number, code: number | null);
}
/** Strict E.164, used for every number bought or presented. */
export declare function isValidPhoneNumber(value: string): boolean;
/**
 * Validate a stored config. With `requireComplete`, also insists it is
 * sendable — a provider, an account identifier, and a sealed secret.
 */
export declare function validateStoredCarrierConfig(raw: RawCarrierConfig, options?: {
    requireComplete?: boolean;
}): void;
/** Validate a config carrying a plaintext secret, before it is sealed. */
export declare function validatePlainCarrierConfig(raw: PlainCarrierConfig, options?: {
    requireComplete?: boolean;
}): void;
/** A client from already-plaintext credentials. */
export declare function buildCarrierClient(credentials: CarrierCredentials): CarrierClient;
/**
 * A client from stored config, or null when none is configured. A secret that
 * will not unseal — sealed under a key this deployment no longer holds — is no
 * account at all, so it resolves to null rather than a client that fails later.
 */
export declare function resolveCarrierClient(raw: RawCarrierConfig, unseal: Unseal): CarrierClient | null;
//# sourceMappingURL=carrier.d.ts.map