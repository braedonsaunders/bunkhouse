export type CarrierProvider = 'twilio';
export declare function isCarrierProvider(value: unknown): value is CarrierProvider;
export type CarrierProviderField = {
    key: string;
    label: string;
    placeholder?: string;
    required?: boolean;
    help?: string;
};
export type CarrierProviderSpec = {
    value: CarrierProvider;
    label: string;
    /** Label for the single sealed secret. */
    secretLabel: string;
    /** Placeholder shown in the secret field. */
    keyHint: string;
    /** Non-secret account identifier this carrier needs. */
    accountField: CarrierProviderField;
    /**
     * The carrier's published SIP signalling ranges — the addresses inbound
     * calls arrive from, and so the allowlist a SIP ingress needs before it will
     * accept one.
     *
     * This is a **suggested default, not a runtime source of truth**. Carriers
     * add edges, and a consumer that read this list at call time would need a
     * package release to fix a broken trunk. Seed editable per-tenant
     * configuration from it and let an operator correct it in the app.
     */
    signalingRanges: string[];
    docsHint?: string;
};
export declare const CARRIER_PROVIDER_SPECS: CarrierProviderSpec[];
export declare function carrierProviderSpec(provider: CarrierProvider): CarrierProviderSpec;
//# sourceMappingURL=providers.d.ts.map